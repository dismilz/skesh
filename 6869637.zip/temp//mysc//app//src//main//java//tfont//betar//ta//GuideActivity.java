package tfont.betar.ta;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;
import android.view.View;
import android.graphics.Typeface;

public class GuideActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	
	private LinearLayout linear1;
	private ScrollView vscroll1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private TextView textview1;
	private TextView textview2;
	private ImageView imageview1;
	private TextView textview3;
	private TextView textview4;
	private ImageView imageview2;
	private TextView textview5;
	private TextView textview6;
	private ImageView imageview3;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.guide);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview6 = (TextView) findViewById(R.id.textview6);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		
		linear1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
	}
	private void initializeLogic() {
		setTitle("Guide");
		android.graphics.drawable.GradientDrawable IHCADCJ = new android.graphics.drawable.GradientDrawable();
		IHCADCJ.setColor(Color.parseColor("#FFFFFFFF"));
		IHCADCJ.setCornerRadius(50);
		linear3.setBackground(IHCADCJ);
		if(Build.VERSION.SDK_INT >= 21) { linear3.setElevation(5f); }
		android.graphics.drawable.GradientDrawable DGAGJIB = new android.graphics.drawable.GradientDrawable();
		DGAGJIB.setColor(Color.parseColor("#FFFFFFFF"));
		DGAGJIB.setCornerRadius(19);
		linear4.setBackground(DGAGJIB);
		if(Build.VERSION.SDK_INT >= 21) { linear4.setElevation(5f); }
		textview2.setText("ပထမဦးဆုံးအနေနဲ့ အောက်မှာကျွန်နော်ဝိုင်းပြထားတဲ့ ဖောင့်စတိုင်းဆိုတဲ့\nစာကြောင်းလေးကိုနိုပ်ပြီး လိုချင်တဲ့ဖောင့်ကိုသုံးချင်တဲ့ဖောင့်ကို\nရွေးချယ်ထည့်သွင်းပေးပါ၊");
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		android.graphics.drawable.GradientDrawable FIDGFDG = new android.graphics.drawable.GradientDrawable();
		FIDGFDG.setColor(Color.parseColor("#FFFFFFFF"));
		FIDGFDG.setCornerRadius(19);
		linear5.setBackground(FIDGFDG);
		if(Build.VERSION.SDK_INT >= 21) { linear5.setElevation(5f); }
		android.graphics.drawable.GradientDrawable JEAFJBH = new android.graphics.drawable.GradientDrawable();
		JEAFJBH.setColor(Color.parseColor("#FFFFFFFF"));
		JEAFJBH.setCornerRadius(19);
		linear6.setBackground(JEAFJBH);
		if(Build.VERSION.SDK_INT >= 21) { linear6.setElevation(5f); }
		android.graphics.drawable.GradientDrawable HFGFBHA = new android.graphics.drawable.GradientDrawable();
		HFGFBHA.setColor(Color.parseColor("#FFFFFFFF"));
		HFGFBHA.setCornerRadius(20);
		linear7.setBackground(HFGFBHA);
		if(Build.VERSION.SDK_INT >= 21) { linear7.setElevation(5f); }
		android.graphics.drawable.GradientDrawable CHGBGBE = new android.graphics.drawable.GradientDrawable();
		CHGBGBE.setColor(Color.parseColor("#FFFFFFFF"));
		CHGBGBE.setCornerRadius(20);
		linear8.setBackground(CHGBGBE);
		if(Build.VERSION.SDK_INT >= 21) { linear8.setElevation(5f); }
		android.graphics.drawable.GradientDrawable FBFADHA = new android.graphics.drawable.GradientDrawable();
		FBFADHA.setColor(Color.parseColor("#FFFFFFFF"));
		FBFADHA.setCornerRadius(30);
		linear9.setBackground(FBFADHA);
		if(Build.VERSION.SDK_INT >= 21) { linear9.setElevation(5f); }
		textview4.setText("ဖောင့်ချိန်းရန်ကိုတစ်ချက်နိုက်ပြီး ဆက်တင်ထဲကိုဝင်သွားပြီး ဖောင့်ချိန်းရန် \nအသင့်နေရာသို့ရောက်ရှိသွားပါမည်၊ ဆက်တင်ထဲရှိ \nအောက်ပါပြထားသော ဖောင့်စတိုင်ကိုရွေးချယ်ပါ၊");
		android.graphics.drawable.GradientDrawable GFBAAHJ = new android.graphics.drawable.GradientDrawable();
		GFBAAHJ.setColor(Color.parseColor("#FFFFFFFF"));
		GFBAAHJ.setCornerRadius(22);
		linear10.setBackground(GFBAAHJ);
		if(Build.VERSION.SDK_INT >= 21) { linear10.setElevation(5f); }
		android.graphics.drawable.GradientDrawable EAFFHJD = new android.graphics.drawable.GradientDrawable();
		EAFFHJD.setColor(Color.parseColor("#FFFFFFFF"));
		EAFFHJD.setCornerRadius(22);
		linear11.setBackground(EAFFHJD);
		if(Build.VERSION.SDK_INT >= 21) { linear11.setElevation(5f); }
		textview6.setText("ဖောင့်စတိုင်ဆိုတာကိုနိုပ်ပြီး\nအစဆုံးက မိမိကြိုက်နစ်သက်ရာ ရွေးချယ်ခဲ့သည့် ဖောင့် နာမည်(သို့)ဖောင့်စတိုင်းကို အောက်ပါပြသည့်အတိုင်း\nရွေးခယ်အသုံးပြုပေးပါ၊");
		Bitmap bm = ((android.graphics.drawable.BitmapDrawable)imageview2.getDrawable()).getBitmap();
		
		imageview2.setImageBitmap(getRoundedCornerBitmap(bm, 30));
		
		// onCreate
	}
	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(output);
		final int color = 0xff424242;
		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		final RectF rectF = new RectF(rect);
		final float roundPx = pixels;
		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint); 
		paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN)); 
		canvas.drawBitmap(bitmap, rect, rect, paint);
		return output;
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
