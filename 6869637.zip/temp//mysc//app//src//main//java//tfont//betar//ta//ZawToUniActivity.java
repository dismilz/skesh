package tfont.betar.ta;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.EditText;
import android.view.View;
import android.graphics.Typeface;
import android.content.ClipData;
import android.content.ClipboardManager;

public class ZawToUniActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	
	private LinearLayout linear1;
	private ScrollView vscroll1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear10;
	private LinearLayout linear4;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private TextView textview1;
	private LinearLayout linear11;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private TextView textview2;
	private TextView textview3;
	private TextView textview4;
	private EditText edittext1;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private TextView textview5;
	private TextView textview6;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.zaw_to_uni);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview6 = (TextView) findViewById(R.id.textview6);
		
		linear7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "unicode");
				edittext1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 0);
				textview2.setTextColor(0xFF004D40);
				textview3.setTextColor(0xFFB2DFDB);
				textview4.setTextColor(0xFFB2DFDB);
			}
		});
		
		linear8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "copy");
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", "(Zawgyi)\n\n".concat(edittext1.getText().toString().concat("\n\n(unicode)\n\n".concat(edittext1.getText().toString())))));
				textview2.setTextColor(0xFFB2DFDB);
				textview3.setTextColor(0xFF004D40);
				textview4.setTextColor(0xFFB2DFDB);
			}
		});
		
		linear9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "zawgyi ");
				edittext1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/zawgyi.ttf"), 0);
				textview2.setTextColor(0xFFB2DFDB);
				textview3.setTextColor(0xFFB2DFDB);
				textview4.setTextColor(0xFF004D40);
			}
		});
		
		edittext1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		linear14.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "paste");
				ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
				edittext1.setText(clipboard.getText());
			}
		});
		
		linear15.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "share");
				String mString= edittext1.getText().toString();
				Intent shareIntent = new Intent(Intent.ACTION_SEND); shareIntent.putExtra(Intent.EXTRA_TEXT, mString); shareIntent.setType("text/plain"); startActivity(shareIntent);
			}
		});
	}
	private void initializeLogic() {
		setTitle("Font Converters");
		android.graphics.drawable.GradientDrawable CBGEFCG = new android.graphics.drawable.GradientDrawable();
		CBGEFCG.setColor(Color.parseColor("#FFFFFFFF"));
		CBGEFCG.setCornerRadius(50);
		linear3.setBackground(CBGEFCG);
		if(Build.VERSION.SDK_INT >= 21) { linear3.setElevation(5f); }
		android.graphics.drawable.GradientDrawable HAGJCHD = new android.graphics.drawable.GradientDrawable();
		HAGJCHD.setColor(Color.parseColor("#FFFFFFFF"));
		HAGJCHD.setCornerRadius(20);
		linear7.setBackground(HAGJCHD);
		if(Build.VERSION.SDK_INT >= 21) { linear7.setElevation(5f); }
		android.graphics.drawable.GradientDrawable GGGHCEB = new android.graphics.drawable.GradientDrawable();
		GGGHCEB.setColor(Color.parseColor("#FFFFFFFF"));
		GGGHCEB.setCornerRadius(14);
		linear4.setBackground(GGGHCEB);
		if(Build.VERSION.SDK_INT >= 21) { linear4.setElevation(5f); }
		android.graphics.drawable.GradientDrawable GHHFAJH = new android.graphics.drawable.GradientDrawable();
		GHHFAJH.setColor(Color.parseColor("#FFFFFFFF"));
		GHHFAJH.setCornerRadius(20);
		linear8.setBackground(GHHFAJH);
		if(Build.VERSION.SDK_INT >= 21) { linear8.setElevation(5f); }
		android.graphics.drawable.GradientDrawable HFIGJJA = new android.graphics.drawable.GradientDrawable();
		HFIGJJA.setColor(Color.parseColor("#FFFFFFFF"));
		HFIGJJA.setCornerRadius(20);
		linear9.setBackground(HFIGJJA);
		if(Build.VERSION.SDK_INT >= 21) { linear9.setElevation(5f); }
		android.graphics.drawable.GradientDrawable IBACDJJ = new android.graphics.drawable.GradientDrawable();
		IBACDJJ.setColor(Color.parseColor("#FFFFFFFF"));
		IBACDJJ.setCornerRadius(14);
		linear6.setBackground(IBACDJJ);
		if(Build.VERSION.SDK_INT >= 21) { linear6.setElevation(5f); }
		android.graphics.drawable.GradientDrawable FHJEFBD = new android.graphics.drawable.GradientDrawable();
		FHJEFBD.setColor(Color.parseColor("#FFFFFFFF"));
		FHJEFBD.setCornerRadius(50);
		linear12.setBackground(FHJEFBD);
		android.graphics.drawable.GradientDrawable BFHAHCG = new android.graphics.drawable.GradientDrawable();
		BFHAHCG.setColor(Color.parseColor("#FFFFFFFF"));
		BFHAHCG.setCornerRadius(50);
		linear14.setBackground(BFHAHCG);
		if(Build.VERSION.SDK_INT >= 21) { linear14.setElevation(7f); }
		android.graphics.drawable.GradientDrawable JEDAEJJ = new android.graphics.drawable.GradientDrawable();
		JEDAEJJ.setColor(Color.parseColor("#FFFFFFFF"));
		JEDAEJJ.setCornerRadius(50);
		linear15.setBackground(JEDAEJJ);
		if(Build.VERSION.SDK_INT >= 21) { linear15.setElevation(7f); }
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		edittext1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
