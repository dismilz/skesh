package tfont.betar.ta;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.view.View;
import android.graphics.Typeface;

public class FontActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private TextView textview2;
	private LinearLayout linear9;
	private TextView textview3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private ImageView imageview1;
	private TextView textview1;
	private ImageView imageview2;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.font);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		
		linear4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "soon");
			}
		});
		
		linear5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "soon");
			}
		});
		
		linear6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "soon");
			}
		});
	}
	private void initializeLogic() {
		setTitle("Local Font");
		android.graphics.drawable.GradientDrawable FGIHDHD = new android.graphics.drawable.GradientDrawable();
		FGIHDHD.setColor(Color.parseColor("#FFFFC107"));
		FGIHDHD.setCornerRadius(90);
		linear4.setBackground(FGIHDHD);
		if(Build.VERSION.SDK_INT >= 21) { linear4.setElevation(4f); }
		android.graphics.drawable.GradientDrawable CGEDAAF = new android.graphics.drawable.GradientDrawable();
		CGEDAAF.setColor(Color.parseColor("#FFFFC107"));
		CGEDAAF.setCornerRadius(90);
		linear6.setBackground(CGEDAAF);
		if(Build.VERSION.SDK_INT >= 21) { linear6.setElevation(4f); }
		android.graphics.drawable.GradientDrawable BJADDIJ = new android.graphics.drawable.GradientDrawable();
		BJADDIJ.setColor(Color.parseColor("#FFFFC107"));
		BJADDIJ.setCornerRadius(50);
		linear5.setBackground(BJADDIJ);
		if(Build.VERSION.SDK_INT >= 21) { linear5.setElevation(4f); }
		android.graphics.drawable.GradientDrawable DIIEDBG = new android.graphics.drawable.GradientDrawable();
		DIIEDBG.setColor(Color.parseColor("#FFFFFFFF"));
		DIIEDBG.setCornerRadius(50);
		linear7.setBackground(DIIEDBG);
		if(Build.VERSION.SDK_INT >= 21) { linear7.setElevation(4f); }
		android.graphics.drawable.GradientDrawable GICAGII = new android.graphics.drawable.GradientDrawable();
		GICAGII.setColor(Color.parseColor("#FFFFFFFF"));
		GICAGII.setCornerRadius(18);
		linear9.setBackground(GICAGII);
		if(Build.VERSION.SDK_INT >= 21) { linear9.setElevation(4f); }
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/zawgyi.ttf"), 1);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/zawgyi.ttf"), 1);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/zawgyi.ttf"), 1);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
