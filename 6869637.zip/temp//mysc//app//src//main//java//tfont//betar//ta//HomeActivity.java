package tfont.betar.ta;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.graphics.Typeface;

public class HomeActivity extends AppCompatActivity {
	
	
	private double list = 0;
	private double list_back = 0;
	
	private LinearLayout linear2;
	private LinearLayout linear1;
	private LinearLayout bbb;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private ImageView imageview1;
	private LinearLayout linear3;
	private LinearLayout linear5;
	private TextView textview1;
	private TextView textview3;
	private ImageView imageview2;
	private LinearLayout page1;
	private LinearLayout page2;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private TextView textview4;
	private TextView textview5;
	
	private Intent intent = new Intent();
	private Intent n = new Intent();
	private Intent i = new Intent();
	private Intent b = new Intent();
	private Intent o = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		bbb = (LinearLayout) findViewById(R.id.bbb);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview3 = (TextView) findViewById(R.id.textview3);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		page1 = (LinearLayout) findViewById(R.id.page1);
		page2 = (LinearLayout) findViewById(R.id.page2);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		
		linear6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		linear3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				o.setClass(getApplicationContext(), FontActivity.class);
				startActivity(o);
			}
		});
		
		linear5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Guide");
				n.setClass(getApplicationContext(), GuideActivity.class);
				startActivity(n);
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (list == 0) {
					SketchwareUtil.showMessage(getApplicationContext(), "add");
					
					RotateAnimation rotateAnimation = new RotateAnimation(0, 90, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f); rotateAnimation.setInterpolator(new LinearInterpolator()); rotateAnimation.setDuration(2000); linear6.startAnimation(rotateAnimation);
					imageview2.setImageResource(R.drawable.cale100);
					
					ObjectAnimator anim = ObjectAnimator.ofFloat(linear10, "ScaleY", 0, 1);
					anim.setInterpolator(new BounceInterpolator()); 
					anim.setDuration(1000);
					anim.start();
					page1.setVisibility(View.GONE);
					page2.setVisibility(View.VISIBLE);
					list = 1;
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "cancel");
					
					RotateAnimation rotateAnimation = new RotateAnimation(90, 0, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f); 
					rotateAnimation.setInterpolator(new AccelerateInterpolator()); 
					rotateAnimation.setDuration(2000); 
					linear6.startAnimation(rotateAnimation);
					imageview2.setImageResource(R.drawable.add);
					page1.setVisibility(View.VISIBLE);
					page2.setVisibility(View.GONE);
					list = 0;
				}
			}
		});
		
		linear10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ZawToUniActivity.class);
				startActivity(i);
			}
		});
		
		linear11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				b.setClass(getApplicationContext(), AboutActivity.class);
				startActivity(b);
			}
		});
	}
	private void initializeLogic() {
		page1.setVisibility(View.VISIBLE);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/unicode.ttf"), 1);
		
		
		ObjectAnimator anim = ObjectAnimator.ofFloat(linear1, "ScaleY", 0, 1);
		anim.setInterpolator(new BounceInterpolator()); 
		anim.setDuration(1000);
		anim.start();
		android.graphics.drawable.GradientDrawable GHDHCHB = new android.graphics.drawable.GradientDrawable();GHDHCHB.setColor(Color.argb(255,255,255,255));
		GHDHCHB.setCornerRadii(new float[] { 30, 30, 30, 30, 30, 30, 30, 30 });
		linear1.setBackground(GHDHCHB);
		if(Build.VERSION.SDK_INT >= 21) { linear1.setElevation(5f); }
		android.graphics.drawable.GradientDrawable CDIJGEB = new android.graphics.drawable.GradientDrawable();CDIJGEB.setColor(Color.argb(255,255,255,255));
		CDIJGEB.setCornerRadii(new float[] { 30, 30, 30, 30, 30, 30, 30, 30 });
		linear3.setBackground(CDIJGEB);
		if(Build.VERSION.SDK_INT >= 21) { linear3.setElevation(5f); }
		android.graphics.drawable.GradientDrawable JFBFEHC = new android.graphics.drawable.GradientDrawable();JFBFEHC.setColor(Color.argb(255,255,255,255));
		JFBFEHC.setCornerRadii(new float[] { 30, 30, 30, 30, 30, 30, 30, 30 });
		linear5.setBackground(JFBFEHC);
		if(Build.VERSION.SDK_INT >= 21) { linear5.setElevation(5f); }
		android.graphics.drawable.GradientDrawable BJCGBE1 = new android.graphics.drawable.GradientDrawable();
		BJCGBE1.setColor(Color.parseColor("#FFFFFFFF"));
		BJCGBE1.setCornerRadius(21);
		bbb.setBackground(BJCGBE1);
		android.graphics.drawable.GradientDrawable EJIBEFH = new android.graphics.drawable.GradientDrawable();
		EJIBEFH.setColor(Color.parseColor("#FFFFFFFF"));
		EJIBEFH.setCornerRadius(90);
		linear6.setBackground(EJIBEFH);
		if(Build.VERSION.SDK_INT >= 21) { linear6.setElevation(5f); }
		android.graphics.drawable.GradientDrawable HBGFIFE = new android.graphics.drawable.GradientDrawable();
		HBGFIFE.setColor(Color.parseColor("#FFFFFFFF"));
		HBGFIFE.setCornerRadius(50);
		linear10.setBackground(HBGFIFE);
		if(Build.VERSION.SDK_INT >= 21) { linear10.setElevation(5f); }
		android.graphics.drawable.GradientDrawable JIBDJIB = new android.graphics.drawable.GradientDrawable();
		JIBDJIB.setColor(Color.parseColor("#FFFFFFFF"));
		JIBDJIB.setCornerRadius(50);
		linear11.setBackground(JIBDJIB);
		if(Build.VERSION.SDK_INT >= 21) { linear11.setElevation(7f); }
		Bitmap bm = ((android.graphics.drawable.BitmapDrawable)imageview1.getDrawable()).getBitmap();
		
		imageview1.setImageBitmap(getRoundedCornerBitmap(bm, 50));
		
		// onCreate
	}
	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(output);
		final int color = 0xff424242;
		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		final RectF rectF = new RectF(rect);
		final float roundPx = pixels;
		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint); 
		paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN)); 
		canvas.drawBitmap(bitmap, rect, rect, paint);
		return output;
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (list_back == 0) {
			list_back = 1;
			SketchwareUtil.showMessage(getApplicationContext(), "Press one more time to exit TFont (Betar)");
		}
		else {
			list_back = 0;
			finishAffinity();
		}
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
