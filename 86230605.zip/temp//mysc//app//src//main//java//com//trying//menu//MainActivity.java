package com.trying.menu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.widget.LinearLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.SeekBar;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ProgressBar;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.content.Intent;
import android.content.ClipData;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Continuation;
import android.net.Uri;
import java.io.File;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.Task;
import android.view.View;
import android.widget.AdapterView;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
	
	public final int REQ_CD_FP = 101;
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private DrawerLayout _drawer;
	private double n1 = 0;
	private HashMap<String, Object> Map1 = new HashMap<>();
	private HashMap<String, Object> Maps = new HashMap<>();
	private String filepath = "";
	private String filename = "";
	private String phone = "";
	private String codeSent = "";
	private String code = "";
	
	private ArrayList<Double> list1 = new ArrayList<>();
	private ArrayList<String> m1 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> Mapps = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private EditText edittext4;
	private Button button1;
	private EditText edittext5;
	private Button button2;
	private TextView textview3;
	private EditText edittext6;
	private EditText edittext7;
	private Button button3;
	private Button button4;
	private LinearLayout linear13;
	private LinearLayout linear10;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private SeekBar seekbar2;
	private ListView listview1;
	private EditText edittext1;
	private EditText edittext2;
	private EditText edittext3;
	private LinearLayout linear12;
	private Button save;
	private Button uploadfiles;
	private Button selectfile;
	private TextView textview1;
	private ListView listview2;
	private ProgressBar progressbar2;
	private Button download;
	private TextView textview2;
	private LinearLayout _drawer_linear1;
	private Button _drawer_button1;
	
	private DatabaseReference Dtest = _firebase.getReference("dtest");
	private ChildEventListener _Dtest_child_listener;
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private StorageReference fstorage = _firebase_storage.getReference("folder1");
	private OnCompleteListener<Uri> _fstorage_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fstorage_download_success_listener;
	private OnSuccessListener _fstorage_delete_success_listener;
	private OnProgressListener _fstorage_upload_progress_listener;
	private OnProgressListener _fstorage_download_progress_listener;
	private OnFailureListener _fstorage_failure_listener;
	private FirebaseAuth fa;
	private OnCompleteListener<AuthResult> _fa_create_user_listener;
	private OnCompleteListener<AuthResult> _fa_sign_in_listener;
	private OnCompleteListener<Void> _fa_reset_password_listener;
	private Intent i = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = (DrawerLayout) findViewById(R.id._drawer);ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(MainActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view);
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		edittext4 = (EditText) findViewById(R.id.edittext4);
		button1 = (Button) findViewById(R.id.button1);
		edittext5 = (EditText) findViewById(R.id.edittext5);
		button2 = (Button) findViewById(R.id.button2);
		textview3 = (TextView) findViewById(R.id.textview3);
		edittext6 = (EditText) findViewById(R.id.edittext6);
		edittext7 = (EditText) findViewById(R.id.edittext7);
		button3 = (Button) findViewById(R.id.button3);
		button4 = (Button) findViewById(R.id.button4);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		seekbar2 = (SeekBar) findViewById(R.id.seekbar2);
		listview1 = (ListView) findViewById(R.id.listview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		edittext3 = (EditText) findViewById(R.id.edittext3);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		save = (Button) findViewById(R.id.save);
		uploadfiles = (Button) findViewById(R.id.uploadfiles);
		selectfile = (Button) findViewById(R.id.selectfile);
		textview1 = (TextView) findViewById(R.id.textview1);
		listview2 = (ListView) findViewById(R.id.listview2);
		progressbar2 = (ProgressBar) findViewById(R.id.progressbar2);
		download = (Button) findViewById(R.id.download);
		textview2 = (TextView) findViewById(R.id.textview2);
		_drawer_linear1 = (LinearLayout) _nav_view.findViewById(R.id.linear1);
		_drawer_button1 = (Button) _nav_view.findViewById(R.id.button1);
		fp.setType("*/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		fa = FirebaseAuth.getInstance();
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_sendVerificationCode();
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_verifyCode();
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				fa.signInWithEmailAndPassword(edittext6.getText().toString(), edittext7.getText().toString()).addOnCompleteListener(MainActivity.this, _fa_sign_in_listener);
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				fa.createUserWithEmailAndPassword(edittext6.getText().toString(), edittext7.getText().toString()).addOnCompleteListener(MainActivity.this, _fa_create_user_listener);
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				Map1 = new HashMap<>();
				Map1.put("a1", edittext1.getText().toString());
				Map1.put("name", edittext2.getText().toString());
				Map1.put("mobile", edittext3.getText().toString());
				Dtest.child(m1.get((int)(_position))).updateChildren(Map1);
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				Dtest.child(m1.get((int)(_position))).removeValue();
				Mapps.remove((int)(_position));
				m1.remove((int)(_position));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
				return true;
			}
		});
		
		save.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Map1 = new HashMap<>();
				Map1.put("a1", edittext1.getText().toString());
				Map1.put("name", edittext2.getText().toString());
				Map1.put("mobile", edittext3.getText().toString());
				Dtest.push().updateChildren(Map1);
			}
		});
		
		uploadfiles.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				fstorage.child(filename).putFile(Uri.fromFile(new File(filepath))).addOnFailureListener(_fstorage_failure_listener).addOnProgressListener(_fstorage_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return fstorage.child(filename).getDownloadUrl();
					}}).addOnCompleteListener(_fstorage_upload_success_listener);
			}
		});
		
		selectfile.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(fp, REQ_CD_FP);
			}
		});
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), String.valueOf((long)(m1.indexOf(textview2.getText().toString()))));
			}
		});
		
		download.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_firebase_storage.getReferenceFromUrl(textview2.getText().toString()).getFile(new File(FileUtil.getPublicDir(Environment.DIRECTORY_DOWNLOADS).concat("/".concat(textview1.getText().toString())))).addOnSuccessListener(_fstorage_download_success_listener).addOnFailureListener(_fstorage_failure_listener).addOnProgressListener(_fstorage_download_progress_listener);
			}
		});
		
		textview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		_Dtest_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Dtest.addChildEventListener(_Dtest_child_listener);
		
		_fstorage_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fstorage_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fstorage_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_fstorage_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_fstorage_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fstorage_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_fa_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					SketchwareUtil.showMessage(getApplicationContext(), "sign up success");
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "sign up error");
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		_fa_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					i.setClass(getApplicationContext(), SuccessActivity.class);
					startActivity(i);
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
					textview3.setText(_errorMessage);
				}
			}
		};
		
		_fa_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		_drawer.openDrawer(GravityCompat.START);
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
			i.setClass(getApplicationContext(), SuccessActivity.class);
			startActivity(i);
		}
		progressbar2.setVisibility(View.INVISIBLE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				filepath = _filePath.get((int)(0));
				filename = Uri.parse(filepath).getLastPathSegment();
				textview1.setText(filename);
				textview2.setText(filepath);
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		SketchwareUtil.showMessage(getApplicationContext(), "gooood");
	}
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		}
		else {
			super.onBackPressed();
		}
	}
	private void _sendVerificationCode () {
		phone = edittext4.getText().toString();
		if (edittext4.getText().toString().length() < 10) {
			SketchwareUtil.showMessage(getApplicationContext(), "pls insert correct phone no");
		}
		com.google.firebase.auth.PhoneAuthProvider.getInstance().verifyPhoneNumber(phone, 60,java.util.concurrent. TimeUnit.SECONDS, this, mCallbacks);
	}
	com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
		 @Override
		public void onVerificationCompleted(com.google.firebase.auth.PhoneAuthCredential phoneAuthCredential) {
			showMessage("Verification completed");
		}
		 @Override
		public void onVerificationFailed(com.google.firebase.FirebaseException e) {
			showMessage(e.toString());
		}
		 @Override
		public void onCodeSent(String s, com.google.firebase.auth.PhoneAuthProvider.ForceResendingToken forceResendingToken) {
			super.onCodeSent(s, forceResendingToken);
			codeSent = s;
		}
		
	};
	
	{
	}
	
	
	private void _verifyCode () {
		code = edittext5.getText().toString();
		com.google.firebase.auth.PhoneAuthCredential credential = com.google.firebase.auth.PhoneAuthProvider.getCredential(codeSent, code);
		
		signInWithPhoneAuthCredential(credential);
	}
	private void signInWithPhoneAuthCredential(com.google.firebase.auth.PhoneAuthCredential credential) {
		fa.signInWithCredential(credential) .addOnCompleteListener(this, _fa_sign_in_listener);
	}
	{
	}
	
	
	private void _Dtest_onChildAdd () {
		Dtest.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				Mapps = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						Mapps.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				SketchwareUtil.showMessage(getApplicationContext(), "");
				m1.add("");
				textview2.setText("");
				listview1.setAdapter(new Listview1Adapter(Mapps));
				listview2.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_list_item_1, m1));
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.megacustview, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final TextView textview2 = (TextView) _v.findViewById(R.id.textview2);
			final TextView textview3 = (TextView) _v.findViewById(R.id.textview3);
			
			textview1.setText(Mapps.get((int)_position).get("a1").toString());
			textview2.setText(Mapps.get((int)_position).get("name").toString());
			textview3.setText(Mapps.get((int)_position).get("mobile").toString());
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
