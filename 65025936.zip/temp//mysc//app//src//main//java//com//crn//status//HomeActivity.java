package com.crn.status;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.AdapterView;
import android.Manifest;
import android.content.pm.PackageManager;

public class HomeActivity extends Activity {
	
	
	private double n = 0;
	private double c = 0;
	private boolean dismiss = false;
	private double pos = 0;
	private double post = 0;
	private double z = 0;
	private String st = "";
	
	private ArrayList<String> list1 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> maplist1 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> map = new ArrayList<>();
	private ArrayList<String> str = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> p = new ArrayList<>();
	private ArrayList<String> as = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout linear12;
	private ListView listview1;
	private ListView listview2;
	private LinearLayout linear7;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear6;
	private TextView textview2;
	private TextView textview3;
	private LinearLayout linear13;
	private LinearLayout linear15;
	private LinearLayout linear14;
	private TextView textview4;
	private ImageView imageview2;
	private LinearLayout linear16;
	private TextView textview5;
	private ImageView imageview3;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private ImageView pic;
	private ImageView vid;
	private ImageView set;
	
	private SharedPreferences vids;
	private AlertDialog.Builder d;
	private Intent go = new Intent();
	private SharedPreferences view;
	private SharedPreferences num;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		listview1 = (ListView) findViewById(R.id.listview1);
		listview2 = (ListView) findViewById(R.id.listview2);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		textview4 = (TextView) findViewById(R.id.textview4);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		textview5 = (TextView) findViewById(R.id.textview5);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		pic = (ImageView) findViewById(R.id.pic);
		vid = (ImageView) findViewById(R.id.vid);
		set = (ImageView) findViewById(R.id.set);
		vids = getSharedPreferences("vids", Activity.MODE_PRIVATE);
		d = new AlertDialog.Builder(this);
		view = getSharedPreferences("view", Activity.MODE_PRIVATE);
		num = getSharedPreferences("num", Activity.MODE_PRIVATE);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				go.putExtra("p", "p");
				go.putExtra("saved", "nothing");
				view.edit().putString("picture", list1.get((int)(_position))).commit();
				go.setClass(getApplicationContext(), ViewActivity.class);
				startActivity(go);
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				d.setMessage("Delete Picture?");
				d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						maplist1.remove((int)(_position));
						FileUtil.deleteFile(list1.get((int)(_position)));
						listview1.setAdapter(new Listview1Adapter(maplist1));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						SketchwareUtil.showMessage(getApplicationContext(), "Deleted");
					}
				});
				d.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				d.create().show();
				return true;
			}
		});
		
		listview2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				view.edit().putString("video", str.get((int)(_position))).commit();
				go.setClass(getApplicationContext(), ViewActivity.class);
				startActivity(go);
			}
		});
		
		listview2.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				d.setMessage("Delete Video?");
				d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						map.remove((int)(_position));
						FileUtil.deleteFile(str.get((int)(_position)));
						((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
						SketchwareUtil.showMessage(getApplicationContext(), "Deleted");
					}
				});
				d.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				d.create().show();
				return true;
			}
		});
		
		linear13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.setMessage("Delete All Statuses?");
				d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/WhatsApp/Media/.Statuses"));
						listview1.setAdapter(new Listview1Adapter(maplist1));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						listview2.setAdapter(new Listview2Adapter(map));
						((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
						SketchwareUtil.showMessage(getApplicationContext(), "Deleted successfully");
					}
				});
				d.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				d.create().show();
			}
		});
		
		linear15.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.setMessage("Make zip backup of all your statuses?");
				d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						_zip(FileUtil.getExternalStorageDir().concat("/WhatsApp/Media/.Statuses"), FileUtil.getExternalStorageDir().concat("/CRN/wss/StatusesBackup.zip"));
					}
				});
				d.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				d.create().show();
			}
		});
		
		linear9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_circleRipple("#000000", linear9);
				linear12.setVisibility(View.GONE);
				listview1.setVisibility(View.VISIBLE);
				listview2.setVisibility(View.GONE);
				
				pic.setImageResource(R.drawable.dda);
				vid.setImageResource(R.drawable.mzm);
				set.setImageResource(R.drawable.fhj);
				
				textview3.setText("Pictures");
			}
		});
		
		linear10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_circleRipple("#000000", linear10);
				linear12.setVisibility(View.GONE);
				listview2.setVisibility(View.VISIBLE);
				listview1.setVisibility(View.GONE);
				
				pic.setImageResource(R.drawable.nzks);
				vid.setImageResource(R.drawable.cam);
				set.setImageResource(R.drawable.fhj);
				
				textview3.setText("Videos");
			}
		});
		
		linear11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_circleRipple("#000000", linear11);
				linear12.setVisibility(View.VISIBLE);
				listview1.setVisibility(View.GONE);
				listview2.setVisibility(View.GONE);
				
				set.setImageResource(R.drawable.aer);
				pic.setImageResource(R.drawable.nzks);
				vid.setImageResource(R.drawable.mzm);
				
				textview3.setText("Settings");
			}
		});
	}
	private void initializeLogic() {
		android.graphics.drawable.GradientDrawable CRNPE = new android.graphics.drawable.GradientDrawable();
		CRNPE.setColor(Color.parseColor("#ffffff"));
		CRNPE.setCornerRadii(new float[]{ (float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10 });
		CRNPE.setStroke((int) 2, Color.parseColor("#009688"));
		linear13.setElevation((float) 5);
		linear13.setBackground(CRNPE);
		//Milz
		android.graphics.drawable.GradientDrawable CRNEF = new android.graphics.drawable.GradientDrawable();
		CRNEF.setColor(Color.parseColor("#ffffff"));
		CRNEF.setCornerRadii(new float[]{ (float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10 });
		CRNEF.setStroke((int) 2, Color.parseColor("#009688"));
		linear15.setElevation((float) 5);
		linear15.setBackground(CRNEF);
		//Milz
		android.graphics.drawable.GradientDrawable CRNGA = new android.graphics.drawable.GradientDrawable();
		CRNGA.setColor(Color.parseColor("#009688"));
		CRNGA.setCornerRadii(new float[]{ (float) 11,(float) 11,(float) 11,(float) 11,(float) 11,(float) 11,(float) 11,(float) 11 });
		CRNGA.setStroke((int) 3, Color.parseColor("#ffffff"));
		linear6.setElevation((float) 5);
		linear6.setBackground(CRNGA);
		//Milz
		listview2.setVisibility(View.GONE);
		linear12.setVisibility(View.GONE);
		
		_Refresh();
		_Ref2();
		_ref3();
		_Shadow(linear13, 2);
		_Shadow(linear8, 2);
		_Shadow(linear15, 2);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		d.setMessage("Exit app?");
		d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				view.edit().remove("v").commit();
				view.edit().remove("p").commit();
				view.edit().remove("m").commit();
				view.edit().remove("num").commit();
				view.edit().remove("home").commit();
				view.edit().remove("lo").commit();
				finishAffinity();
			}
		});
		d.setNegativeButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		d.create().show();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		_ref3();
	}
	private void _Refresh () {
		FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/WhatsApp/Media/.Statuses/.nomedia"));
		FileUtil.listDir(FileUtil.getExternalStorageDir().concat("/WhatsApp/Media/.Statuses/"), list1);
		n = 0;
		for(int _repeat13 = 0; _repeat13 < (int)(list1.size()); _repeat13++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("media", list1.get((int)(n)));
				maplist1.add(_item);
			}
			
			n++;
		}
		listview1.setAdapter(new Listview1Adapter(maplist1));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	
	private void _Ref2 () {
		FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/WhatsApp/Media/.Statuses/.nomedia"));
		FileUtil.listDir(FileUtil.getExternalStorageDir().concat("/WhatsApp/Media/.Statuses/"), str);
		c = 0;
		for(int _repeat17 = 0; _repeat17 < (int)(str.size()); _repeat17++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("media", str.get((int)(c)));
				map.add(_item);
			}
			
			c++;
		}
		listview2.setAdapter(new Listview2Adapter(map));
		((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
	}
	
	
	private void _Shadow (final View _v, final double _n) {
		_v.setElevation((float)_n);
	}
	
	
	private void _zip (final String _source, final String _destination) {
		FileUtil.writeFile("Don't Remove it Thanks.\nModified By: Manish Nirmal", "This Block Added for Manage Permission");
		try {
			java.util.zip.ZipOutputStream os = new java.util.zip.ZipOutputStream(new java.io.FileOutputStream(_destination));
					zip(os, _source, null);
					os.close();
		}
		
		catch(java.io.IOException e) {}
	}
	private void zip(java.util.zip.ZipOutputStream os, String filePath, String name) throws java.io.IOException
		{
				java.io.File file = new java.io.File(filePath);
				java.util.zip.ZipEntry entry = new java.util.zip.ZipEntry((name != null ? name + java.io.File.separator : "") + file.getName() + (file.isDirectory() ? java.io.File.separator : ""));
				os.putNextEntry(entry);
				
				if(file.isFile()) {
						java.io.InputStream is = new java.io.FileInputStream(file);
						int size = is.available();
						byte[] buff = new byte[size];
						int len = is.read(buff);
						os.write(buff, 0, len);
						return;
				}
				
				java.io.File[] fileArr = file.listFiles();
				for(java.io.File subFile : fileArr) {
						zip(os, subFile.getAbsolutePath(), entry.getName());
				}
	}
	
	
	private void _circleRipple (final String _color, final View _v) {
		android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor(_color)});
		android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , null, null);
		_v.setBackground(ripdrb);
	}
	
	
	private void _ref3 () {
		FileUtil.listDir(FileUtil.getPublicDir(Environment.DIRECTORY_DCIM).concat("/CRN/wss/"), as);
		z = 0;
		for(int _repeat14 = 0; _repeat14 < (int)(as.size()); _repeat14++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("media", as.get((int)(z)));
				p.add(_item);
			}
			
			z++;
		}
		
		
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.costum, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			
			android.graphics.drawable.GradientDrawable CRNOD = new android.graphics.drawable.GradientDrawable();
			CRNOD.setColor(Color.parseColor("#ffffff"));
			CRNOD.setCornerRadii(new float[]{ (float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10 });
			CRNOD.setStroke((int) 2, Color.parseColor("#009688"));
			linear2.setElevation((float) 5);
			linear2.setBackground(CRNOD);
			//Milz
			android.graphics.drawable.GradientDrawable CRNTN = new android.graphics.drawable.GradientDrawable();
			CRNTN.setColor(Color.parseColor("#ffffff"));
			CRNTN.setCornerRadii(new float[]{ (float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10 });
			CRNTN.setStroke((int) 2, Color.parseColor("#009688"));
			linear1.setElevation((float) 5);
			linear1.setBackground(CRNTN);
			//Milz
			if (list1.get((int)(_position)).endsWith(".mp4")) {
				linear1.setVisibility(View.GONE);
			}
			else {
				linear1.setVisibility(View.VISIBLE);
				imageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(list1.get((int)(_position)), 1024, 1024));
				textview1.setText(Uri.parse(list1.get((int)(_position))).getLastPathSegment());
			}
			
			return _v;
		}
	}
	
	public class Listview2Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.costum, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			
			android.graphics.drawable.GradientDrawable CRNTY = new android.graphics.drawable.GradientDrawable();
			CRNTY.setColor(Color.parseColor("#ffffff"));
			CRNTY.setCornerRadii(new float[]{ (float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10 });
			CRNTY.setStroke((int) 2, Color.parseColor("#009688"));
			linear2.setElevation((float) 5);
			linear2.setBackground(CRNTY);
			//Milz
			android.graphics.drawable.GradientDrawable CRNHW = new android.graphics.drawable.GradientDrawable();
			CRNHW.setColor(Color.parseColor("#ffffff"));
			CRNHW.setCornerRadii(new float[]{ (float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10 });
			CRNHW.setStroke((int) 2, Color.parseColor("#009688"));
			linear1.setElevation((float) 5);
			linear1.setBackground(CRNHW);
			//Milz
			textview1.setText(Uri.parse(str.get((int)(_position))).getLastPathSegment());
			if (str.get((int)(_position)).endsWith(".mp4")) {
				Bitmap bMap = ThumbnailUtils.createVideoThumbnail(map.get(_position).get("media").toString(), android.provider.MediaStore.Video.Thumbnails.MICRO_KIND); imageview1.setImageBitmap(bMap);
				linear1.setVisibility(View.VISIBLE);
			}
			else {
				linear1.setVisibility(View.GONE);
			}
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
