package com.crn.status;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.View;
import android.Manifest;
import android.content.pm.PackageManager;

public class ViewActivity extends Activity {
	
	
	private String str = "";
	private String imagepath = "";
	
	private LinearLayout linear2;
	private LinearLayout linear1;
	private LinearLayout linear7;
	private LinearLayout linear3;
	private LinearLayout linear5;
	private LinearLayout linear4;
	private TextView textview1;
	private ImageView imageview1;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear12;
	private LinearLayout linear11;
	private ImageView save;
	private ImageView share;
	private ImageView delete;
	
	private SharedPreferences view;
	private Intent go = new Intent();
	private AlertDialog.Builder d;
	private ObjectAnimator animation = new ObjectAnimator();
	private ObjectAnimator anime = new ObjectAnimator();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.view);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		textview1 = (TextView) findViewById(R.id.textview1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		save = (ImageView) findViewById(R.id.save);
		share = (ImageView) findViewById(R.id.share);
		delete = (ImageView) findViewById(R.id.delete);
		view = getSharedPreferences("view", Activity.MODE_PRIVATE);
		d = new AlertDialog.Builder(this);
		
		save.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (view.getString("picture", "").endsWith(".jpg") || (view.getString("picture", "").endsWith(".jpg") || view.getString("picture", "").endsWith(".png"))) {
					if (FileUtil.isExistFile(FileUtil.getPublicDir(Environment.DIRECTORY_DCIM).concat("/CRN/wss"))) {
						
					}
					else {
						FileUtil.makeDir(FileUtil.getPublicDir(Environment.DIRECTORY_DCIM).concat("/CRN/wss"));
					}
					FileUtil.copyFile(view.getString("picture", ""), FileUtil.getPublicDir(Environment.DIRECTORY_DCIM).concat("/CRN/wss/").concat(Uri.parse(view.getString("picture", "")).getLastPathSegment()));
					Notification.Builder mBuilder = new Notification.Builder(ViewActivity.this);mBuilder.setSmallIcon(R.drawable.nzks);mBuilder.setContentTitle("Image Status Saved");mBuilder.setContentText("Saved In/DCIM/CRN/wss folder.");NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);int onx = 1;notificationManager.notify(onx, mBuilder.build());
					SketchwareUtil.showMessage(getApplicationContext(), "Saved In DCIM/CRN/wss folder.");
				}
				android.media.MediaScannerConnection.scanFile(ViewActivity.this,new String[]{imagepath.toString()},null, new MediaScannerConnection.OnScanCompletedListener(){ @Override public void onScanCompleted(String path, Uri uri) { 
						
						
						
						
						
						
					} });
				if (view.getString("video", "").endsWith(".mp4")) {
					if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/DCIM/CRN/wss"))) {
						
					}
					else {
						FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/DCIM/CRN/wss"));
					}
					FileUtil.copyFile(str, FileUtil.getExternalStorageDir().concat("/DCIM/CRN/wss/").concat(Uri.parse(str).getLastPathSegment()));
					Notification.Builder mBuilder = new Notification.Builder(ViewActivity.this);mBuilder.setSmallIcon(R.drawable.mzm);mBuilder.setContentTitle("Video Status Saved");mBuilder.setContentText("Saved In DCIM/wss folder.");NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);int onx = 1;notificationManager.notify(onx, mBuilder.build());
					SketchwareUtil.showMessage(getApplicationContext(), "Saved In /DCIM/CRN/wss Folder");
				}
				animation.setTarget(save);
				animation.setPropertyName("alpha");
				animation.setFloatValues((float)(0), (float)(1));
				animation.setDuration((int)(3000));
				animation.setInterpolator(new LinearInterpolator());
				animation.start();
			}
		});
		
		share.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (view.getString("p", "").equals("p")) {
					d.setMessage("Share picture?");
					d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							_Share(view.getString("picture", ""), true, "");
						}
					});
					d.setNegativeButton("No", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					d.create().show();
				}
				else {
					d.setMessage("Share video?");
					d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							_Share(view.getString("video", ""), true, "");
						}
					});
					d.setNegativeButton("No", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					d.create().show();
				}
				animation.setTarget(share);
				animation.setPropertyName("alpha");
				animation.setFloatValues((float)(0), (float)(1));
				animation.setDuration((int)(1000));
				animation.setInterpolator(new LinearInterpolator());
				animation.start();
			}
		});
		
		delete.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (getIntent().getStringExtra("p").equals("p")) {
					d.setMessage("Delete Picture?");
					d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							FileUtil.deleteFile(view.getString("picture", ""));
							SketchwareUtil.showMessage(getApplicationContext(), "Deleted Picture");
							go.setClass(getApplicationContext(), HomeActivity.class);
							startActivity(go);
						}
					});
					d.setNegativeButton("No", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					d.create().show();
				}
				else {
					d.setMessage("Delete Video?");
					d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							FileUtil.deleteFile(view.getString("video", ""));
							SketchwareUtil.showMessage(getApplicationContext(), "Deleted Video");
							go.setClass(getApplicationContext(), HomeActivity.class);
							startActivity(go);
						}
					});
					d.setNegativeButton("No", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					d.create().show();
				}
				animation.setTarget(delete);
				animation.setPropertyName("alpha");
				animation.setFloatValues((float)(0), (float)(1));
				animation.setDuration((int)(1000));
				animation.setInterpolator(new LinearInterpolator());
				animation.start();
			}
		});
	}
	private void initializeLogic() {
		android.graphics.drawable.GradientDrawable CRNZC = new android.graphics.drawable.GradientDrawable();
		CRNZC.setColor(Color.parseColor("#009688"));
		CRNZC.setCornerRadii(new float[]{ (float) 11,(float) 11,(float) 11,(float) 11,(float) 11,(float) 11,(float) 11,(float) 11 });
		CRNZC.setStroke((int) 3, Color.parseColor("#ffffff"));
		linear8.setElevation((float) 5);
		linear8.setBackground(CRNZC);
		//Milz
		android.graphics.drawable.GradientDrawable CRNIY = new android.graphics.drawable.GradientDrawable();
		CRNIY.setColor(Color.parseColor("#009688"));
		CRNIY.setCornerRadii(new float[]{ (float) 11,(float) 11,(float) 11,(float) 11,(float) 11,(float) 11,(float) 11,(float) 11 });
		CRNIY.setStroke((int) 3, Color.parseColor("#ffffff"));
		linear9.setElevation((float) 5);
		linear9.setBackground(CRNIY);
		//Milz
		android.graphics.drawable.GradientDrawable CRNGA = new android.graphics.drawable.GradientDrawable();
		CRNGA.setColor(Color.parseColor("#009688"));
		CRNGA.setCornerRadii(new float[]{ (float) 11,(float) 11,(float) 11,(float) 11,(float) 11,(float) 11,(float) 11,(float) 11 });
		CRNGA.setStroke((int) 3, Color.parseColor("#ffffff"));
		linear11.setElevation((float) 5);
		linear11.setBackground(CRNGA);
		//Milz
		if (getIntent().getStringExtra("p").equals("p")) {
			imagepath = view.getString("picture", "");
			textview1.setText("Picture");
			imageview1.setVisibility(View.VISIBLE);
			imageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(view.getString("picture", ""), 1024, 1024));
		}
		else {
			textview1.setText("Video");
			imageview1.setVisibility(View.GONE);
			str = view.getString("video", "");
			imagepath = view.getString("video", "");
			vidview = new VideoView(this);
			vidview.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
			linear1.addView(vidview);
			mediaControls = new MediaController(this); mediaControls.setAnchorView(vidview); vidview.setMediaController(mediaControls);
			vidview.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
				@Override
				public void onCompletion(MediaPlayer mp) {
				} });
			
			vidview.setOnErrorListener(new MediaPlayer.OnErrorListener() {
				@Override
				public boolean onError(MediaPlayer mp, int what, int extra) {
					showMessage("Oops An Error Occured While Playing Video!!");
					return false; } });
			vidview.setVideoURI(Uri.parse(str));
			vidview.start();
		}
		if (getIntent().getStringExtra("saved").equals("saved")) {
			linear8.setVisibility(View.GONE);
		}
		else {
			linear8.setVisibility(View.VISIBLE);
		}
		ZoomView zoomView = new ZoomView(ViewActivity.this);
		zoomView.setMaxZoom(3.0f);
		zoomView.setLayoutParams(new FrameLayout.LayoutParams( FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
		
		linear1.addView(zoomView);
		linear1.removeView(imageview1);
		zoomView.addView(imageview1);
		
	}
	
	public static class ZoomView extends FrameLayout {
		
		/**
     * Zooming view listener interface.
     * 
     * @author karooolek
     * 
     */
		public interface ZoomViewListener {
			
			void onZoomStarted(float zoom, float zoomx, float zoomy);
			
			void onZooming(float zoom, float zoomx, float zoomy);
			
			void onZoomEnded(float zoom, float zoomx, float zoomy);
		}
		
		// zooming
		float zoom = 1.0f;
		float maxZoom = 2.0f;
		float smoothZoom = 1.0f;
		float zoomX, zoomY;
		float smoothZoomX, smoothZoomY;
		private boolean scrolling; // NOPMD by karooolek on 29.06.11 11:45
		private boolean doubleTouch = true;
		
		// minimap variables
		private boolean showMinimap = false;
		private int miniMapColor = Color.BLACK;
		private int miniMapHeight = -1;
		private String miniMapCaption;
		private float miniMapCaptionSize = 10.0f;
		private int miniMapCaptionColor = Color.WHITE;
		
		/*
//own variables
private float minimapX = 0.0f;
private float minimapY = 0.0f;
*/
		
		// touching variables
		private long lastTapTime;
		private float touchStartX, touchStartY;
		private float touchLastX, touchLastY;
		private float startd;
		private boolean pinching;
		private float lastd;
		private float lastdx1, lastdy1;
		private float lastdx2, lastdy2;
		
		// drawing
		private final Matrix m = new Matrix();
		private final Paint p = new Paint();
		
		// listener
		ZoomViewListener listener;
		
		private Bitmap ch;
		
		public ZoomView(final Context context) {
			super(context);
		}
		
		public float getZoom() {
			return zoom;
		}
		
		public float getMaxZoom() {
			return maxZoom;
		}
		
		public void setMaxZoom(final float maxZoom) {
			if (maxZoom < 1.0f) {
				return;
			}
			
			this.maxZoom = maxZoom;
		}
		
		public void setDoubleTouchEnabled(final boolean doubleTouch) {
			this.doubleTouch = doubleTouch;
		}
		
		public void setMiniMapEnabled(final boolean showMiniMap) {
			this.showMinimap = showMiniMap;
		}
		
		public boolean isMiniMapEnabled() {
			return showMinimap;
		}
		
		public void setMiniMapHeight(final int miniMapHeight) {
			if (miniMapHeight < 0) {
				return;
			}
			this.miniMapHeight = miniMapHeight;
		}
		
		public int getMiniMapHeight() {
			return miniMapHeight;
		}
		
		/*
//own methods start

public float getMinimapX() {
  return minimapX;
}

public float getMinimapY() {
  return minimapY;
}

public void setMinimapX(final float minimapX) {
  this.minimapX = minimapX;
}

public void setMinimapY(final float minimapY) {
  this.minimapY = minimapY;
}

//own methods end
*/
		
		public void setMiniMapColor(final int color) {
			miniMapColor = color;
		}
		
		public int getMiniMapColor() {
			return miniMapColor;
		}
		
		public String getMiniMapCaption() {
			return miniMapCaption;
		}
		
		public void setMiniMapCaption(final String miniMapCaption) {
			this.miniMapCaption = miniMapCaption;
		}
		
		public float getMiniMapCaptionSize() {
			return miniMapCaptionSize;
		}
		
		public void setMiniMapCaptionSize(final float size) {
			miniMapCaptionSize = size;
		}
		
		public int getMiniMapCaptionColor() {
			return miniMapCaptionColor;
		}
		
		public void setMiniMapCaptionColor(final int color) {
			miniMapCaptionColor = color;
		}
		
		public void zoomTo(final float zoom, final float x, final float y) {
			this.zoom = Math.min(zoom, maxZoom);
			zoomX = x;
			zoomY = y;
			smoothZoomTo(this.zoom, x, y);
		}
		
		public void smoothZoomTo(final float zoom, final float x, final float y) {
			smoothZoom = clamp(1.0f, zoom, maxZoom);
			smoothZoomX = x;
			smoothZoomY = y;
			if (listener != null) {
				listener.onZoomStarted(smoothZoom, x, y);
			}
		}
		
		public ZoomViewListener getListener() {
			return listener;
		}
		
		public void setListner(final ZoomViewListener listener) {
			this.listener = listener;
		}
		
		public float getZoomFocusX() {
			return zoomX * zoom;
		}
		
		public float getZoomFocusY() {
			return zoomY * zoom;
		}
		
		@Override
		public boolean dispatchTouchEvent(final MotionEvent ev) {
			// single touch
			if (ev.getPointerCount() == 1) {
				processSingleTouchEvent(ev);
			}
			
			// // double touch
			if (ev.getPointerCount() == 2) {
				processDoubleTouchEvent(ev);
			}
			
			// redraw
			getRootView().invalidate();
			invalidate();
			
			return true;
		}
		
		private void processSingleTouchEvent(final MotionEvent ev) {
			
			final float x = ev.getX();
			final float y = ev.getY();
			
			final float w = miniMapHeight * (float) getWidth() / getHeight();
			final float h = miniMapHeight;
			final boolean touchingMiniMap = x >= 10.0f && x <= 10.0f + w && y >= 10.0f && y <= 10.0f + h;
			
			if (showMinimap && smoothZoom > 1.0f && touchingMiniMap) {
				processSingleTouchOnMinimap(ev);
			} else {
				processSingleTouchOutsideMinimap(ev);
			}
		}
		
		private void processSingleTouchOnMinimap(final MotionEvent ev) {
			final float x = ev.getX();
			final float y = ev.getY();
			
			final float w = miniMapHeight * (float) getWidth() / getHeight();
			final float h = miniMapHeight;
			final float zx = (x - 10.0f) / w * getWidth();
			final float zy = (y - 10.0f) / h * getHeight();
			smoothZoomTo(smoothZoom, zx, zy);
		}
		
		private void processSingleTouchOutsideMinimap(final MotionEvent ev) {
			final float x = ev.getX();
			final float y = ev.getY();
			float lx = x - touchStartX;
			float ly = y - touchStartY;
			final float l = (float) Math.hypot(lx, ly);
			float dx = x - touchLastX;
			float dy = y - touchLastY;
			touchLastX = x;
			touchLastY = y;
			
			switch (ev.getAction()) {
				case MotionEvent.ACTION_DOWN:
				touchStartX = x;
				touchStartY = y;
				touchLastX = x;
				touchLastY = y;
				dx = 0;
				dy = 0;
				lx = 0;
				ly = 0;
				scrolling = false;
				break;
				
				case MotionEvent.ACTION_MOVE:
				if (scrolling || (smoothZoom > 1.0f && l > 30.0f)) {
					if (!scrolling) {
						scrolling = true;
						ev.setAction(MotionEvent.ACTION_CANCEL);
						super.dispatchTouchEvent(ev);
					}
					smoothZoomX -= dx / zoom;
					smoothZoomY -= dy / zoom;
					return;
				}
				break;
				
				case MotionEvent.ACTION_OUTSIDE:
				case MotionEvent.ACTION_UP:
				if (doubleTouch == true) {
					// tap
					if (l < 30.0f) {
						// check double tap
						if (System.currentTimeMillis() - lastTapTime < 500) {
							if (smoothZoom == 1.0f) {
								smoothZoomTo(maxZoom, x, y);
							} else {
								smoothZoomTo(1.0f, getWidth() / 2.0f, getHeight() / 2.0f);
							}
							lastTapTime = 0;
							ev.setAction(MotionEvent.ACTION_CANCEL);
							super.dispatchTouchEvent(ev);
							return;
						}
						
						lastTapTime = System.currentTimeMillis();
						
						performClick();
					}
				}
				break;
				
				default:
				break;
			}
			
			ev.setLocation(zoomX + (x - 0.5f * getWidth()) / zoom, zoomY + (y - 0.5f * getHeight()) / zoom);
			
			ev.getX();
			ev.getY();
			
			super.dispatchTouchEvent(ev);
		}
		
		private void processDoubleTouchEvent(final MotionEvent ev) {
			final float x1 = ev.getX(0);
			final float dx1 = x1 - lastdx1;
			lastdx1 = x1;
			final float y1 = ev.getY(0);
			final float dy1 = y1 - lastdy1;
			lastdy1 = y1;
			final float x2 = ev.getX(1);
			final float dx2 = x2 - lastdx2;
			lastdx2 = x2;
			final float y2 = ev.getY(1);
			final float dy2 = y2 - lastdy2;
			lastdy2 = y2;
			
			// pointers distance
			final float d = (float) Math.hypot(x2 - x1, y2 - y1);
			final float dd = d - lastd;
			lastd = d;
			final float ld = Math.abs(d - startd);
			
			Math.atan2(y2 - y1, x2 - x1);
			switch (ev.getAction()) {
				case MotionEvent.ACTION_DOWN:
				startd = d;
				pinching = false;
				break;
				
				case MotionEvent.ACTION_MOVE:
				if (pinching || ld > 30.0f) {
					pinching = true;
					final float dxk = 0.5f * (dx1 + dx2);
					final float dyk = 0.5f * (dy1 + dy2);
					smoothZoomTo(Math.max(1.0f, zoom * d / (d - dd)), zoomX - dxk / zoom, zoomY - dyk / zoom);
				}
				
				break;
				
				case MotionEvent.ACTION_UP:
				default:
				pinching = false;
				break;
			}
			
			ev.setAction(MotionEvent.ACTION_CANCEL);
			super.dispatchTouchEvent(ev);
		}
		
		private float clamp(final float min, final float value, final float max) {
			return Math.max(min, Math.min(value, max));
		}
		
		private float lerp(final float a, final float b, final float k) {
			return a + (b - a) * k;
		}
		
		private float bias(final float a, final float b, final float k) {
			return Math.abs(b - a) >= k ? a + k * Math.signum(b - a) : b;
		}
		
		@Override
		protected void dispatchDraw(final Canvas canvas) {
			// do zoom
			zoom = lerp(bias(zoom, smoothZoom, 0.05f), smoothZoom, 0.2f);
			smoothZoomX = clamp(0.5f * getWidth() / smoothZoom, smoothZoomX, getWidth() - 0.5f * getWidth() / smoothZoom);
			smoothZoomY = clamp(0.5f * getHeight() / smoothZoom, smoothZoomY, getHeight() - 0.5f * getHeight() / smoothZoom);
			
			zoomX = lerp(bias(zoomX, smoothZoomX, 0.1f), smoothZoomX, 0.35f);
			zoomY = lerp(bias(zoomY, smoothZoomY, 0.1f), smoothZoomY, 0.35f);
			if (zoom != smoothZoom && listener != null) {
				listener.onZooming(zoom, zoomX, zoomY);
			}
			
			final boolean animating = Math.abs(zoom - smoothZoom) > 0.0000001f
			|| Math.abs(zoomX - smoothZoomX) > 0.0000001f || Math.abs(zoomY - smoothZoomY) > 0.0000001f;
			
			// nothing to draw
			if (getChildCount() == 0) {
				return;
			}
			
			// prepare matrix
			m.setTranslate(0.5f * getWidth(), 0.5f * getHeight());
			m.preScale(zoom, zoom);
			m.preTranslate(-clamp(0.5f * getWidth() / zoom, zoomX, getWidth() - 0.5f * getWidth() / zoom),
			-clamp(0.5f * getHeight() / zoom, zoomY, getHeight() - 0.5f * getHeight() / zoom));
			
			// get view
			final View v = getChildAt(0);
			m.preTranslate(v.getLeft(), v.getTop());
			
			// get drawing cache if available
			if (animating && ch == null && isAnimationCacheEnabled()) {
				v.setDrawingCacheEnabled(true);
				ch = v.getDrawingCache();
			}
			
			// draw using cache while animating
			if (animating && isAnimationCacheEnabled() && ch != null) {
				p.setColor(0xffffffff);
				canvas.drawBitmap(ch, m, p);
			} else { // zoomed or cache unavailable
				ch = null;
				canvas.save();
				canvas.concat(m);
				v.draw(canvas);
				canvas.restore();
			}
			
			// draw minimap
			if (showMinimap) {
				if (miniMapHeight < 0) {
					miniMapHeight = getHeight() / 4;
				}
				
				canvas.translate(10.0f, 10.0f);
				
				p.setColor(0x80000000 | 0x00ffffff & miniMapColor);
				final float w = miniMapHeight * (float) getWidth() / getHeight();
				final float h = miniMapHeight;
				canvas.drawRect(0.0f, 0.0f, w, h, p);
				
				if (miniMapCaption != null && miniMapCaption.length() > 0) {
					p.setTextSize(miniMapCaptionSize);
					p.setColor(miniMapCaptionColor);
					p.setAntiAlias(true);
					canvas.drawText(miniMapCaption, 10.0f, 10.0f + miniMapCaptionSize, p);
					p.setAntiAlias(false);
				}
				
				p.setColor(0x80000000 | 0x00ffffff & miniMapColor);
				final float dx = w * zoomX / getWidth();
				final float dy = h * zoomY / getHeight();
				canvas.drawRect(dx - 0.5f * w / zoom, dy - 0.5f * h / zoom, dx + 0.5f * w / zoom, dy + 0.5f * h / zoom, p);
				
				canvas.translate(-10.0f, -10.0f);
			}
			
			// redraw
			// if (animating) {
			getRootView().invalidate();
			invalidate();
			// }
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _extra () {
	}
	VideoView vidview;
	MediaController mediaControls;
	{
	}
	
	
	private void _Share (final String _dat, final boolean _file, final String _des) {
		if (_file) {
			Intent shareIntent = new Intent(Intent.ACTION_SEND); shareIntent.setType("text/plain");
			shareIntent.putExtra(Intent.EXTRA_TEXT, (_des)); shareIntent.putExtra(Intent.EXTRA_STREAM, Uri.parse(_dat));
			startActivity(Intent.createChooser(shareIntent, "Share"));
			//By GiantMurloc\\
		}
		else {
			Intent shareIntent = new Intent(Intent.ACTION_SEND); shareIntent.setType("text/plain"); shareIntent.putExtra(Intent.EXTRA_TEXT, (_dat));
			startActivity(Intent.createChooser(shareIntent, "Share"));
		}
	}
	
	
	private void _Zoomable_Imageview () {
	}
	public static interface Animation {
		public boolean update(GestureImageView view, long time);
	}
	public static class Animator extends Thread {
		private GestureImageView view;
		private Animation animation;
		private boolean running = false;
		private boolean active = false;
		private long lastTime = -1L;
		
		public Animator(GestureImageView view, String threadName) {
			super(threadName);
			this.view = view;
		}
		
		@Override
		public void run() {
			running = true;
			while(running) {
				while(active && animation != null) {	
					long time = System.currentTimeMillis();
					active = animation.update(view, time - lastTime);				view.redraw();
					lastTime = time;
					while(active) {
						try {
							if(view.waitForDraw(32)) {
								break;
							}
						} catch (InterruptedException ignore) {
							active = false;
						} } }
				synchronized(this) {	
					if(running) {
						try {
							wait();
						} catch (InterruptedException ignore) {}
					} } } }
		
		public synchronized void finish() {
			running = false;
			active = false;
			notifyAll();
		}
		
		public void play(Animation transformer) {
			if(active) {
				cancel();
			}
			this.animation = transformer;
			activate();
		}
		
		public synchronized void activate() {
			lastTime = System.currentTimeMillis();
			active = true;
			notifyAll();
		}
		
		public void cancel() {
			active = false;
		}
	}
	public static class FlingAnimation implements Animation {		private float velocityX;
		private float velocityY;
		private float factor = 0.95f;
		private float threshold = 10;
		private FlingAnimationListener listener;
		
		@Override
		public boolean update(GestureImageView view, long time) {	
			float seconds = (float) time / 1000.0f;
			float dx = velocityX * seconds;
			float dy = velocityY * seconds;	
			velocityX *= factor;
			velocityY *= factor;
			boolean active = (Math.abs(velocityX) > threshold && Math.abs(velocityY) > threshold);
			if(listener != null) {	
				listener.onMove(dx, dy);
				if(!active) {
					listener.onComplete();
				} }
			return active;
		}
		
		public void setVelocityX(float velocityX) {		this.velocityX = velocityX;
		}
		
		public void setVelocityY(float velocityY) {
			this.velocityY = velocityY;
		}
		
		public void setFactor(float factor) {
			this.factor = factor;
		}
		
		public void setListener(FlingAnimationListener listener) {
			this.listener = listener;
		}
	}
	public static interface FlingAnimationListener {
		public void onMove(float x, float y);
		public void onComplete();
	}
	public static class FlingListener extends android.view.GestureDetector.SimpleOnGestureListener {
		private float velocityX;
		private float velocityY;
		
		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
			this.velocityX = velocityX;
			this.velocityY = velocityY;
			return true;
		}
		
		public float getVelocityX() {
			return velocityX;
		}
		
		public float getVelocityY() {
			return velocityY;
		}
	}
	public static class GestureImageView extends ImageView {
		public static final String GLOBAL_NS = "http://schemas.android.com/apk/res/android";
		public static final String LOCAL_NS = "http://schemas.polites.com/android";
		private final java.util.concurrent.Semaphore drawLock = new java.util.concurrent.Semaphore(0);
		private Animator animator;
		private android.graphics.drawable.Drawable drawable;
		private float x = 0, y = 0;
		private boolean layout = false;
		private float scaleAdjust = 1.0f;
		private float startingScale = -1.0f;
		private float scale = 1.0f;
		private float maxScale = 5.0f;
		private float minScale = 0.75f;
		private float fitScaleHorizontal = 1.0f;
		private float fitScaleVertical = 1.0f;
		private float rotation = 0.0f;
		private float centerX;
		private float centerY;
		private Float startX, startY;
		private int hWidth;
		private int hHeight;
		private int resId = -1;
		private boolean recycle = false;
		private boolean strict = false;
		private int displayHeight;
		private int displayWidth;
		private int alpha = 255;
		private ColorFilter colorFilter;
		private int deviceOrientation = -1;
		private int imageOrientation;
		private GestureImageViewListener gestureImageViewListener;
		private GestureImageViewTouchListener gestureImageViewTouchListener;
		private OnTouchListener customOnTouchListener;
		private OnClickListener onClickListener;
		
		public GestureImageView(Context context, AttributeSet attrs, int defStyle) {
			this(context, attrs);
		}
		
		public GestureImageView(Context context, AttributeSet attrs) {
			super(context, attrs);
			String scaleType = attrs.getAttributeValue(GLOBAL_NS, "scaleType");
			if(scaleType == null || scaleType.trim().length() == 0) {
				setScaleType(ScaleType.CENTER_INSIDE);
			}
			String strStartX = attrs.getAttributeValue(LOCAL_NS, "start-x");
			String strStartY = attrs.getAttributeValue(LOCAL_NS, "start-y");
			if(strStartX != null && strStartX.trim().length() > 0) {
				startX = Float.parseFloat(strStartX);
			}
			if(strStartY != null && strStartY.trim().length() > 0) {
				startY = Float.parseFloat(strStartY);
			}
			setStartingScale(attrs.getAttributeFloatValue(LOCAL_NS, "start-scale", startingScale));
			setMinScale(attrs.getAttributeFloatValue(LOCAL_NS, "min-scale", minScale));
			setMaxScale(attrs.getAttributeFloatValue(LOCAL_NS, "max-scale", maxScale));
			setStrict(attrs.getAttributeBooleanValue(LOCAL_NS, "strict", strict));
			setRecycle(attrs.getAttributeBooleanValue(LOCAL_NS, "recycle", recycle));
			initImage();
		}
		
		public GestureImageView(Context context) {
			super(context);
			setScaleType(ScaleType.CENTER_INSIDE);
			initImage();
		}
		
		@Override
		protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
			if(drawable != null) {
				int orientation = getResources().getConfiguration().orientation;
				if(orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) {
					displayHeight = MeasureSpec.getSize(heightMeasureSpec);
					if(getLayoutParams().width == android.view.ViewGroup.LayoutParams.WRAP_CONTENT) {
						float ratio = (float) getImageWidth() / (float) getImageHeight();
						displayWidth = Math.round( (float) displayHeight * ratio) ;
					} else {
						displayWidth = MeasureSpec.getSize(widthMeasureSpec);
					} } else {
					displayWidth = MeasureSpec.getSize(widthMeasureSpec);
					if(getLayoutParams().height == android.view.ViewGroup.LayoutParams.WRAP_CONTENT) {
						float ratio = (float) getImageHeight() / (float) getImageWidth();
						displayHeight = Math.round( (float) displayWidth * ratio) ;
					} else {
						displayHeight = MeasureSpec.getSize(heightMeasureSpec);
					} }
			} else {
				displayHeight = MeasureSpec.getSize(heightMeasureSpec);
				displayWidth = MeasureSpec.getSize(widthMeasureSpec);
			}
			setMeasuredDimension(displayWidth, displayHeight);
		}
		
		@Override
		protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
			super.onLayout(changed, left, top, right, bottom);
			if(changed || !layout) {
				setupCanvas(displayWidth, displayHeight, getResources().getConfiguration().orientation);
			} }
		
		protected void setupCanvas(int measuredWidth, int measuredHeight, int orientation) {
			if(deviceOrientation != orientation) {
				layout = false;
				deviceOrientation = orientation;
			}
			if(drawable != null && !layout) {
				int imageWidth = getImageWidth();
				int imageHeight = getImageHeight();
				hWidth = Math.round(((float)imageWidth / 2.0f));
				hHeight = Math.round(((float)imageHeight / 2.0f));
				measuredWidth -= (getPaddingLeft() + getPaddingRight());
				measuredHeight -= (getPaddingTop() + getPaddingBottom());
				computeCropScale(imageWidth, imageHeight, measuredWidth, measuredHeight);
				if(startingScale <= 0.0f) {
					computeStartingScale(imageWidth, imageHeight, measuredWidth, measuredHeight);
				}
				scaleAdjust = startingScale;
				this.centerX = (float) measuredWidth / 2.0f;
				this.centerY = (float) measuredHeight / 2.0f;
				if(startX == null) {
					x = centerX;
				} else {
					x = startX;
				}
				if(startY == null) {
					y = centerY;
				} else {
					y = startY;
				}
				gestureImageViewTouchListener = new GestureImageViewTouchListener(this, measuredWidth, measuredHeight);
				if(isLandscape()) {
					gestureImageViewTouchListener.setMinScale(minScale * fitScaleHorizontal);
				} else {
					gestureImageViewTouchListener.setMinScale(minScale * fitScaleVertical);
				}
				gestureImageViewTouchListener.setMaxScale(maxScale * startingScale);
				gestureImageViewTouchListener.setFitScaleHorizontal(fitScaleHorizontal);
				gestureImageViewTouchListener.setFitScaleVertical(fitScaleVertical);
				gestureImageViewTouchListener.setCanvasWidth(measuredWidth);
				gestureImageViewTouchListener.setCanvasHeight(measuredHeight);
				gestureImageViewTouchListener.setOnClickListener(onClickListener);
				drawable.setBounds(-hWidth,-hHeight,hWidth,hHeight);
				super.setOnTouchListener(new OnTouchListener() {
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						if(customOnTouchListener != null) {
							customOnTouchListener.onTouch(v, event);
						}
						return gestureImageViewTouchListener.onTouch(v, event);
					}
				});
				layout = true;
			}
		}
		
		protected void computeCropScale(int imageWidth, int imageHeight, int measuredWidth, int measuredHeight) {
			fitScaleHorizontal = (float) measuredWidth / (float) imageWidth;
			fitScaleVertical = (float) measuredHeight / (float) imageHeight;
		}
		
		protected void computeStartingScale(int imageWidth, int imageHeight, int measuredWidth, int measuredHeight) {
			switch(getScaleType()) {
				case CENTER: 
				startingScale = 1.0f;
				break;
				case CENTER_CROP: 
				startingScale = Math.max((float) measuredHeight / (float) imageHeight, (float) measuredWidth/ (float) imageWidth);
				break;
				case CENTER_INSIDE: 
				float wRatio = (float) imageWidth / (float) measuredWidth;
				float hRatio = (float) imageHeight / (float) measuredHeight;
				if(wRatio > hRatio) {
					startingScale = fitScaleHorizontal;
				} else {
					startingScale = fitScaleVertical;
				}
				break;
			} }
		
		protected boolean isRecycled() {
			if(drawable != null && drawable instanceof android.graphics.drawable.BitmapDrawable) {
				Bitmap bitmap = ((android.graphics.drawable.BitmapDrawable)drawable).getBitmap();
				if(bitmap != null) {
					return bitmap.isRecycled();
				} }
			return false;
		}
		
		protected void recycle() {
			if(recycle && drawable != null && drawable instanceof android.graphics.drawable.BitmapDrawable) {
				Bitmap bitmap = ((android.graphics.drawable.BitmapDrawable)drawable).getBitmap();
				if(bitmap != null) {
					bitmap.recycle();
				} } }
		
		@Override
		protected void onDraw(Canvas canvas) {
			if(layout) {
				if(drawable != null && !isRecycled()) {
					canvas.save();
					float adjustedScale = scale * scaleAdjust;
					canvas.translate(x, y);
					if(rotation != 0.0f) {
						canvas.rotate(rotation);
					}
					if(adjustedScale != 1.0f) {
						canvas.scale(adjustedScale, adjustedScale);
					}
					drawable.draw(canvas);
					canvas.restore();
				}
				if(drawLock.availablePermits() <= 0) {
					drawLock.release();
				} } }
		
		public boolean waitForDraw(long timeout) throws InterruptedException {
			return drawLock.tryAcquire(timeout, java.util.concurrent.TimeUnit.MILLISECONDS);
		}
		
		@Override
		protected void onAttachedToWindow() {
			animator = new Animator(this, "GestureImageViewAnimator");
			animator.start();
			if(resId >= 0 && drawable == null) {
				setImageResource(resId);
			}
			super.onAttachedToWindow();
		}
		
		public void animationStart(Animation animation) {
			if(animator != null) {
				animator.play(animation);
			} }
		
		public void animationStop() {
			if(animator != null) {
				animator.cancel();
			} }
		
		@Override protected void onDetachedFromWindow() {
			if(animator != null) {
				animator.finish();
			}
			if(recycle && drawable != null && !isRecycled()) {
				recycle();
				drawable = null;
			}
			super.onDetachedFromWindow();
		}
		
		protected void initImage() {
			if(this.drawable != null) {
				this.drawable.setAlpha(alpha);
				this.drawable.setFilterBitmap(true);
				if(colorFilter != null) {
					this.drawable.setColorFilter(colorFilter);
				} }
			if(!layout) {
				requestLayout();
				redraw();
			} }
		
		public void setImageBitmap(Bitmap image) {
			this.drawable = new android.graphics.drawable.BitmapDrawable(getResources(), image);
			initImage();
		}
		
		@Override
		public void setImageDrawable(android.graphics.drawable.Drawable drawable) {
			this.drawable = drawable;
			initImage();
		}
		
		public void setImageResource(int id) {
			if(this.drawable != null) {
				this.recycle();
			}
			if(id >= 0) {
				this.resId = id;
				setImageDrawable(getContext().getResources().getDrawable(id));
			} }
		
		public int getScaledWidth() {
			return Math.round(getImageWidth() * getScale());
		}
		
		public int getScaledHeight() {
			return Math.round(getImageHeight() * getScale());
		}
		
		public int getImageWidth() {
			if(drawable != null) {
				return drawable.getIntrinsicWidth();
			}
			return 0;
		}
		
		public int getImageHeight() {
			if(drawable != null) {
				return drawable.getIntrinsicHeight();
			}
			return 0;
		}
		
		public void moveBy(float x, float y) {
			this.x += x;
			this.y += y;
		}
		
		public void setPosition(float x, float y) {
			this.x = x;
			this.y = y;
		}
		
		public void redraw() {
			postInvalidate();
		}
		
		public void setMinScale(float min) {
			this.minScale = min;
			if(gestureImageViewTouchListener != null) {
				gestureImageViewTouchListener.setMinScale(min * fitScaleHorizontal);
			} }
		
		public void setMaxScale(float max) {
			this.maxScale = max;
			if(gestureImageViewTouchListener != null) {
				gestureImageViewTouchListener.setMaxScale(max * startingScale);
			} }
		
		public void setScale(float scale) {
			scaleAdjust = scale;
		}
		
		public float getScale() {
			return scaleAdjust;
		}
		
		public float getImageX() {
			return x;
		}
		
		public float getImageY() {
			return y;
		}
		
		public boolean isStrict() {
			return strict;
		}
		
		public void setStrict(boolean strict) {
			this.strict = strict;
		}
		
		public boolean isRecycle() {
			return recycle;
		}
		
		public void setRecycle(boolean recycle) {
			this.recycle = recycle;
		}
		
		public void reset() {
			x = centerX;
			y = centerY;
			scaleAdjust = startingScale;
			if (gestureImageViewTouchListener != null) {
				gestureImageViewTouchListener.reset();
			}
			redraw();
		}
		
		public void setRotation(float rotation) {
			this.rotation = rotation;
		}
		
		public void setGestureImageViewListener(GestureImageViewListener pinchImageViewListener) {
			this.gestureImageViewListener = pinchImageViewListener;
		}
		
		public GestureImageViewListener getGestureImageViewListener() {
			return gestureImageViewListener;
		}
		
		@Override
		public android.graphics.drawable.Drawable getDrawable() {
			return drawable;
		}
		
		@Override
		public void setAlpha(int alpha) {
			this.alpha = alpha;
			if(drawable != null) {
				drawable.setAlpha(alpha);
			} }
		
		@Override public void setColorFilter(ColorFilter cf) {
			this.colorFilter = cf;
			if(drawable != null) {
				drawable.setColorFilter(cf);
			} }
		
		@Override
		public void setImageURI(Uri mUri) {
			if ("content".equals(mUri.getScheme())) {
				try {
					String[] orientationColumn = {android.provider.MediaStore.Images.Media.ORIENTATION};
					android.database.Cursor cur = getContext().getContentResolver().query(mUri, orientationColumn, null, null, null);
					if (cur != null && cur.moveToFirst()) {
						imageOrientation = cur.getInt(cur.getColumnIndex(orientationColumn[0]));
					}
					java.io.InputStream in = null;
					try {
						in = getContext().getContentResolver().openInputStream(mUri);
						Bitmap bmp = BitmapFactory.decodeStream(in);
						if(imageOrientation != 0) {
							Matrix m = new Matrix();
							m.postRotate(imageOrientation);
							Bitmap rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
							bmp.recycle();
							setImageDrawable(new android.graphics.drawable.BitmapDrawable(getResources(), rotated));
						} else {
							setImageDrawable(new android.graphics.drawable.BitmapDrawable(getResources(), bmp));
						} } finally {
						if(in != null) {
							in.close();
						}
						if(cur != null) {
							cur.close();
						} } } catch (Exception e) {}
			} else {
				setImageDrawable(android.graphics.drawable.Drawable.createFromPath(mUri.toString()));
			}
			if (drawable == null) {
				mUri = null;
			} }
		
		@Override
		public Matrix getImageMatrix() {
			if(strict) {
				throw new UnsupportedOperationException("Not supported");
			}
			return super.getImageMatrix();
		}
		
		@Override
		public void setScaleType(ScaleType scaleType) {
			if(scaleType == ScaleType.CENTER || scaleType == ScaleType.CENTER_CROP || scaleType == ScaleType.CENTER_INSIDE) {
				super.setScaleType(scaleType);
			} else if(strict) {
				throw new UnsupportedOperationException("Not supported");
			} }
		
		@Override
		public void invalidateDrawable(android.graphics.drawable.Drawable dr) {
			if(strict) {
				throw new UnsupportedOperationException("Not supported");
			}
			super.invalidateDrawable(dr);
		}
		
		@Override
		public int[] onCreateDrawableState(int extraSpace) {
			if(strict) {
				throw new UnsupportedOperationException("Not supported");
			}
			return super.onCreateDrawableState(extraSpace);
		}
		
		@Override
		public void setAdjustViewBounds(boolean adjustViewBounds) {
			if(strict) {
				throw new UnsupportedOperationException("Not supported");
			}
			super.setAdjustViewBounds(adjustViewBounds);
		}
		
		@Override
		public void setImageLevel(int level) {
			if(strict) {
				throw new UnsupportedOperationException("Not supported");
			}
			super.setImageLevel(level);
		}
		
		@Override
		public void setImageMatrix(Matrix matrix) {
			if(strict) {
				throw new UnsupportedOperationException("Not supported");
			} }
		
		@Override
		public void setImageState(int[] state, boolean merge) {
			if(strict) {
				throw new UnsupportedOperationException("Not supported");
			} }
		
		@Override
		public void setSelected(boolean selected) {
			if(strict) {
				throw new UnsupportedOperationException("Not supported");
			}
			super.setSelected(selected);
		}
		
		@Override
		public void setOnTouchListener(OnTouchListener l) {
			this.customOnTouchListener = l;
		}
		
		public float getCenterX() {
			return centerX;
		}
		
		public float getCenterY() {
			return centerY;
		}
		
		public boolean isLandscape() {
			return getImageWidth() >= getImageHeight();
		}
		
		public boolean isPortrait() {
			return getImageWidth() <= getImageHeight();
		}
		
		public void setStartingScale(float startingScale) {
			this.startingScale = startingScale;
		}
		
		public void setStartingPosition(float x, float y) {
			this.startX = x;
			this.startY = y;
		}
		
		@Override
		public void setOnClickListener(OnClickListener l) {
			this.onClickListener = l;
			if(gestureImageViewTouchListener != null) {
				gestureImageViewTouchListener.setOnClickListener(l);
			} }
		
		public boolean isOrientationAligned() {
			if(deviceOrientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) {
				return isLandscape();
			} else if(deviceOrientation == android.content.res.Configuration.ORIENTATION_PORTRAIT) {
				return isPortrait();
			}
			return true;
		}
		
		public int getDeviceOrientation() {
			return deviceOrientation;
		}}
	public static interface GestureImageViewListener {
		public void onTouch(float x, float y);
		public void onScale(float scale);
		public void onPosition(float x, float y);
	}
	public static class GestureImageViewTouchListener implements OnTouchListener {
		private GestureImageView image;
		private OnClickListener onClickListener;
		private final PointF current = new PointF();
		private final PointF last = new PointF();
		private final PointF next = new PointF();
		private final PointF midpoint = new PointF();
		private final VectorF scaleVector = new VectorF();
		private final VectorF pinchVector = new VectorF();
		private boolean touched = false;
		private boolean inZoom = false;
		private float initialDistance;
		private float lastScale = 1.0f;
		private float currentScale = 1.0f;
		private float boundaryLeft = 0;
		private float boundaryTop = 0;
		private float boundaryRight = 0;
		private float boundaryBottom = 0;
		private float maxScale = 5.0f;
		private float minScale = 0.25f;
		private float fitScaleHorizontal = 1.0f;
		private float fitScaleVertical = 1.0f;
		private int canvasWidth = 0;
		private int canvasHeight = 0;
		private float centerX = 0;
		private float centerY = 0;
		private float startingScale = 0;
		private boolean canDragX = false;
		private boolean canDragY = false;
		private boolean multiTouch = false;
		private int displayWidth;
		private int displayHeight;
		private int imageWidth;
		private int imageHeight;
		private FlingListener flingListener;
		private FlingAnimation flingAnimation;
		private ZoomAnimation zoomAnimation;
		private MoveAnimation moveAnimation;
		private GestureDetector tapDetector;
		private GestureDetector flingDetector;
		private GestureImageViewListener imageListener;
		
		public GestureImageViewTouchListener(final GestureImageView image, int displayWidth, int displayHeight) {
			super();
			this.image = image;
			this.displayWidth = displayWidth;
			this.displayHeight = displayHeight;
			this.centerX = (float) displayWidth / 2.0f;
			this.centerY = (float) displayHeight / 2.0f;
			this.imageWidth = image.getImageWidth();
			this.imageHeight = image.getImageHeight();
			startingScale = image.getScale();
			currentScale = startingScale;
			lastScale = startingScale;
			boundaryRight = displayWidth;
			boundaryBottom = displayHeight;
			boundaryLeft = 0;
			boundaryTop = 0;
			next.x = image.getImageX();
			next.y = image.getImageY();
			flingListener = new FlingListener();
			flingAnimation = new FlingAnimation();
			zoomAnimation = new ZoomAnimation();
			moveAnimation = new MoveAnimation();
			flingAnimation.setListener(new FlingAnimationListener() {
				@Override
				public void onMove(float x, float y) {
					handleDrag(current.x + x, current.y + y);
				}
				@Override
				public void onComplete() {}
			});
			zoomAnimation.setZoom(2.0f);
			zoomAnimation.setZoomAnimationListener(new ZoomAnimationListener() {
				@Override
				public void onZoom(float scale, float x, float y) {
					if(scale <= maxScale && scale >= minScale) {
						handleScale(scale, x, y);
					}
				}
				@Override
				public void onComplete() {
					inZoom = false;
					handleUp();
				}
			});
			moveAnimation.setMoveAnimationListener(new MoveAnimationListener() {
				@Override
				public void onMove(float x, float y) {
					image.setPosition(x, y);
					image.redraw();
				}
			});
			tapDetector = new GestureDetector(image.getContext(), new android.view.GestureDetector.SimpleOnGestureListener() {
				@Override
				public boolean onDoubleTap(MotionEvent e) {
					startZoom(e);
					return true;
				}
				@Override
				public boolean onSingleTapConfirmed(MotionEvent e) {
					if(!inZoom) {
						if(onClickListener != null) {
							onClickListener.onClick(image);
							return true;
						}
					}
					return false;
				}
			});
			flingDetector = new GestureDetector(image.getContext(), flingListener);
			imageListener = image.getGestureImageViewListener();
			calculateBoundaries();
		}
		
		private void startFling() {
			flingAnimation.setVelocityX(flingListener.getVelocityX());
			flingAnimation.setVelocityY(flingListener.getVelocityY());
			image.animationStart(flingAnimation);
		}
		
		private void startZoom(MotionEvent e) {
			inZoom = true;
			zoomAnimation.reset();
			float zoomTo;
			if(image.isLandscape()) {
				if(image.getDeviceOrientation() == android.content.res.Configuration.ORIENTATION_PORTRAIT) {
					int scaledHeight = image.getScaledHeight();
					if(scaledHeight < canvasHeight) {
						zoomTo = fitScaleVertical / currentScale;
						zoomAnimation.setTouchX(e.getX());
						zoomAnimation.setTouchY(image.getCenterY());
					} else {
						zoomTo = fitScaleHorizontal / currentScale;
						zoomAnimation.setTouchX(image.getCenterX());
						zoomAnimation.setTouchY(image.getCenterY());
					}
				} else {
					int scaledWidth = image.getScaledWidth();
					if(scaledWidth == canvasWidth) {
						zoomTo = currentScale*4.0f;
						zoomAnimation.setTouchX(e.getX());
						zoomAnimation.setTouchY(e.getY());
					} else if(scaledWidth < canvasWidth) {
						zoomTo = fitScaleHorizontal / currentScale;
						zoomAnimation.setTouchX(image.getCenterX());
						zoomAnimation.setTouchY(e.getY());
					} else {
						zoomTo = fitScaleHorizontal / currentScale;
						zoomAnimation.setTouchX(image.getCenterX());
						zoomAnimation.setTouchY(image.getCenterY());
					}
				}
			} else {
				if(image.getDeviceOrientation() == android.content.res.Configuration.ORIENTATION_PORTRAIT) {
					int scaledHeight = image.getScaledHeight();
					if(scaledHeight == canvasHeight) {
						zoomTo = currentScale*4.0f;
						zoomAnimation.setTouchX(e.getX());
						zoomAnimation.setTouchY(e.getY());
					} else if(scaledHeight < canvasHeight) {
						zoomTo = fitScaleVertical / currentScale;
						zoomAnimation.setTouchX(e.getX());
						zoomAnimation.setTouchY(image.getCenterY());
					} else {
						zoomTo = fitScaleVertical / currentScale;
						zoomAnimation.setTouchX(image.getCenterX());
						zoomAnimation.setTouchY(image.getCenterY());
					}
				} else {
					int scaledWidth = image.getScaledWidth();
					if(scaledWidth < canvasWidth) {
						zoomTo = fitScaleHorizontal / currentScale;
						zoomAnimation.setTouchX(image.getCenterX());
						zoomAnimation.setTouchY(e.getY());
					} else {
						zoomTo = fitScaleVertical / currentScale;
						zoomAnimation.setTouchX(image.getCenterX());
						zoomAnimation.setTouchY(image.getCenterY());
					}
				}
			}
			zoomAnimation.setZoom(zoomTo);
			image.animationStart(zoomAnimation);
		}
		
		private void stopAnimations() {
			image.animationStop();
		}
		
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			if(!inZoom) {
				if(!tapDetector.onTouchEvent(event)) {
					if(event.getPointerCount() == 1 && flingDetector.onTouchEvent(event)) {
						startFling();
					}
					if(event.getAction() == MotionEvent.ACTION_UP) {
						handleUp();
					} else if(event.getAction() == MotionEvent.ACTION_DOWN) {
						stopAnimations();
						last.x = event.getX();
						last.y = event.getY();
						if(imageListener != null) {
							imageListener.onTouch(last.x, last.y);
						}
						touched = true;
					} else if(event.getAction() == MotionEvent.ACTION_MOVE) {
						if(event.getPointerCount() > 1) {
							multiTouch = true;
							if(initialDistance > 0) {
								pinchVector.set(event);
								pinchVector.calculateLength();
								float distance = pinchVector.length;
								if(initialDistance != distance) {
									float newScale = (distance / initialDistance) * lastScale;
									if(newScale <= maxScale) {
										scaleVector.length *= newScale;
										scaleVector.calculateEndPoint();
										scaleVector.length /= newScale;
										float newX = scaleVector.end.x;
										float newY = scaleVector.end.y;
										handleScale(newScale, newX, newY);
									} } } else {
								initialDistance = MathUtils.distance(event);
								MathUtils.midpoint(event, midpoint);
								scaleVector.setStart(midpoint);
								scaleVector.setEnd(next);
								scaleVector.calculateLength();
								scaleVector.calculateAngle();
								scaleVector.length /= lastScale;
							}
						} else {
							if(!touched) {
								touched = true;
								last.x = event.getX();
								last.y = event.getY();
								next.x = image.getImageX();
								next.y = image.getImageY();
							} else if(!multiTouch) {
								if(handleDrag(event.getX(), event.getY())) {
									image.redraw();
								} } } } } }
			return true;
		}
		
		protected void handleUp() {
			multiTouch = false;
			initialDistance = 0;
			lastScale = currentScale;
			if(!canDragX) {
				next.x = centerX;
			}
			if(!canDragY) {
				next.y = centerY;
			}
			boundCoordinates();
			if(!canDragX && !canDragY) {
				if(image.isLandscape()) {
					currentScale = fitScaleHorizontal;
					lastScale = fitScaleHorizontal;
				} else {
					currentScale = fitScaleVertical;
					lastScale = fitScaleVertical;
				} }
			image.setScale(currentScale);
			image.setPosition(next.x, next.y);
			if(imageListener != null) {
				imageListener.onScale(currentScale);
				imageListener.onPosition(next.x, next.y);
			}
			image.redraw();
		}
		
		protected void handleScale(float scale, float x, float y) {
			currentScale = scale;
			if(currentScale > maxScale) {
				currentScale = maxScale;
			} else if (currentScale < minScale) {
				currentScale = minScale;
			} else {
				next.x = x;
				next.y = y;
			}
			calculateBoundaries();
			image.setScale(currentScale);
			image.setPosition(next.x, next.y);
			if(imageListener != null) {
				imageListener.onScale(currentScale);
				imageListener.onPosition(next.x, next.y);
			}
			image.redraw();
		}
		
		protected boolean handleDrag(float x, float y) {
			current.x = x;
			current.y = y;
			float diffX = (current.x - last.x);
			float diffY = (current.y - last.y);
			if(diffX != 0 || diffY != 0) {
				if(canDragX) next.x += diffX;
				if(canDragY) next.y += diffY;
				boundCoordinates();
				last.x = current.x;
				last.y = current.y;
				if(canDragX || canDragY) {
					image.setPosition(next.x, next.y);
					if(imageListener != null) {
						imageListener.onPosition(next.x, next.y);
					}
					return true;
				} }
			return false;
		}
		
		public void reset() {
			currentScale = startingScale;
			next.x = centerX;
			next.y = centerY;
			calculateBoundaries();
			image.setScale(currentScale);
			image.setPosition(next.x, next.y);
			image.redraw();
		}
		
		public float getMaxScale() {
			return maxScale;
		}
		
		public void setMaxScale(float maxScale) {
			this.maxScale = maxScale;
		}
		
		public float getMinScale() {
			return minScale;
		}
		
		public void setMinScale(float minScale) {
			this.minScale = minScale;
		}
		
		public void setOnClickListener(OnClickListener onClickListener) {
			this.onClickListener = onClickListener;
		}
		
		protected void setCanvasWidth(int canvasWidth) {
			this.canvasWidth = canvasWidth;
		}
		
		protected void setCanvasHeight(int canvasHeight) {
			this.canvasHeight = canvasHeight;
		}
		
		protected void setFitScaleHorizontal(float fitScale) {
			this.fitScaleHorizontal = fitScale;
		}
		
		protected void setFitScaleVertical(float fitScaleVertical) {
			this.fitScaleVertical = fitScaleVertical;
		}
		
		protected void boundCoordinates() {
			if(next.x < boundaryLeft) {
				next.x = boundaryLeft;
			} else if(next.x > boundaryRight) {
				next.x = boundaryRight;
			}
			if(next.y < boundaryTop) {
				next.y = boundaryTop;
			} else if(next.y > boundaryBottom) {
				next.y = boundaryBottom;
			} }
		
		protected void calculateBoundaries() {
			int effectiveWidth = Math.round( (float) imageWidth * currentScale );
			int effectiveHeight = Math.round( (float) imageHeight * currentScale );
			canDragX = effectiveWidth > displayWidth;
			canDragY = effectiveHeight > displayHeight;
			if(canDragX) {
				float diff = (float)(effectiveWidth - displayWidth) / 2.0f;
				boundaryLeft = centerX - diff;
				boundaryRight = centerX + diff;
			}
			if(canDragY) {
				float diff = (float)(effectiveHeight - displayHeight) / 2.0f;
				boundaryTop = centerY - diff;
				boundaryBottom = centerY + diff;
			} } }
	public static class MathUtils {
		
		public static float distance(MotionEvent event) {
			float x = event.getX(0) - event.getX(1);
			float y = event.getY(0) - event.getY(1);
			return (float)Math.sqrt(x * x + y * y);
		}
		
		public static float distance(PointF p1, PointF p2) {
			float x = p1.x - p2.x;
			float y = p1.y - p2.y;
			return (float)Math.sqrt(x * x + y * y);
		}
		
		public static float distance(float x1, float y1, float x2, float y2) {
			float x = x1 - x2;
			float y = y1 - y2;
			return (float)Math.sqrt(x * x + y * y);
		}
		
		public static void midpoint(MotionEvent event, PointF point) {
			float x1 = event.getX(0);
			float y1 = event.getY(0);
			float x2 = event.getX(1);
			float y2 = event.getY(1);
			midpoint(x1, y1, x2, y2, point);
		}
		
		public static void midpoint(float x1, float y1, float x2, float y2, PointF point) {
			point.x = (x1 + x2) / 2.0f;
			point.y = (y1 + y2) / 2.0f;
		}
		
		public void rotate(PointF p1, PointF p2, float angle) {
			float px = p1.x;
			float py = p1.y;
			float ox = p2.x;
			float oy = p2.y;
			p1.x = ((float)Math.cos(angle) * (px-ox) - (float)Math.sin(angle) * (py-oy) + ox);
			p1.y = ((float)Math.sin(angle) * (px-ox) + (float)Math.cos(angle) * (py-oy) + oy);
		}
		
		public static float angle(PointF p1, PointF p2) {
			return angle(p1.x, p1.y, p2.x, p2.y);
		}
		
		public static float angle(float x1, float y1, float x2, float y2) {
			return (float) Math.atan2(y2 - y1, x2 - x1);
		}
	}
	public static class MoveAnimation implements Animation {
		private boolean firstFrame = true;
		private float startX;
		private float startY;
		private float targetX;
		private float targetY;
		private long animationTimeMS = 100;
		private long totalTime = 0;
		private MoveAnimationListener moveAnimationListener;
		
		@Override
		public boolean update(GestureImageView view, long time) {	
			totalTime += time;
			if(firstFrame) {
				firstFrame = false;
				startX = view.getImageX();
				startY = view.getImageY();
			}
			if(totalTime < animationTimeMS) {
				float ratio = (float) totalTime / animationTimeMS;
				float newX = ((targetX - startX) * ratio) + startX;
				float newY = ((targetY - startY) * ratio) + startY;
				if(moveAnimationListener != null) {
					moveAnimationListener.onMove(newX, newY);
				} return true; }		else {
				if(moveAnimationListener != null) {
					moveAnimationListener.onMove(targetX, targetY);
				} } return false;
		}
		
		public void reset() {
			firstFrame = true;
			totalTime = 0;
		}
		
		public float getTargetX() {
			return targetX;
		}
		
		public void setTargetX(float targetX) {
			this.targetX = targetX;
		}
		
		public float getTargetY() {
			return targetY;
		}
		
		public void setTargetY(float targetY) {
			this.targetY = targetY;
		}
		
		public long getAnimationTimeMS() {
			return animationTimeMS;
		}
		
		public void setAnimationTimeMS(long animationTimeMS) {
			this.animationTimeMS = animationTimeMS;
		}
		
		public void setMoveAnimationListener(MoveAnimationListener moveAnimationListener) {
			this.moveAnimationListener = moveAnimationListener;
		}
	}
	public static interface MoveAnimationListener {
		public void onMove(float x, float y);
	}
	public static class VectorF {	
		public float angle;
		public float length;
		public final PointF start = new PointF();
		public final PointF end = new PointF();
		
		public void calculateEndPoint() {
			end.x = (float)Math.cos(angle) * length + start.x;
			end.y = (float)Math.sin(angle) * length + start.y;
		}
		
		public void setStart(PointF p) {
			this.start.x = p.x;	
			this.start.y = p.y;	
		}
		
		public void setEnd(PointF p) {
			this.end.x = p.x;
			this.end.y = p.y;
		}
		
		public void set(MotionEvent event) {
			this.start.x = event.getX(0);
			this.start.y = event.getY(0);
			this.end.x = event.getX(1);
			this.end.y = event.getY(1);
		}
		
		public float calculateLength() {
			length = MathUtils.distance(start, end);
			return length;	
		}
		
		public float calculateAngle() {
			angle = MathUtils.angle(start, end);
			return angle;
		}
	}
	public static class ZoomAnimation implements Animation {
		private boolean firstFrame = true;
		private float touchX;
		private float touchY;
		private float zoom;
		private float startX;
		private float startY;
		private float startScale;	
		private float xDiff;
		private float yDiff;
		private float scaleDiff;
		private long animationLengthMS = 200;
		private long totalTime = 0;
		private ZoomAnimationListener zoomAnimationListener;
		
		@Override
		public boolean update(GestureImageView view, long time) {	
			if(firstFrame) {
				firstFrame = false;
				startX = view.getImageX();
				startY = view.getImageY();
				startScale = view.getScale();
				scaleDiff = (zoom * startScale) - startScale;						if(scaleDiff > 0) {
					VectorF vector = new VectorF();
					vector.setStart(new PointF(touchX, touchY));				vector.setEnd(new PointF(startX, startY));											vector.calculateAngle();
					float length = vector.calculateLength();
					vector.length = length*zoom;
					vector.calculateEndPoint();
					xDiff = vector.end.x - startX;
					yDiff = vector.end.y - startY;
				} else {
					xDiff = view.getCenterX() - startX;
					yDiff = view.getCenterY() - startY;
				} }
			totalTime += time;
			float ratio = (float) totalTime / (float) animationLengthMS;
			if(ratio < 1) {
				if(ratio > 0) {
					float newScale = (ratio * scaleDiff) + startScale;				float newX = (ratio * xDiff) + startX;	
					float newY = (ratio * yDiff) + startY;								if(zoomAnimationListener != null) {					zoomAnimationListener.onZoom(newScale, newX, newY);
					} } return true; }	 else {
				float newScale = scaleDiff + startScale;
				float newX = xDiff + startX;
				float newY = yDiff + startY; 			if(zoomAnimationListener != null) {				zoomAnimationListener.onZoom(newScale, newX, newY);
					zoomAnimationListener.onComplete();
				}
				return false;
			}}
		
		public void reset() {
			firstFrame = true;
			totalTime = 0;
		}
		
		public float getZoom() {
			return zoom;
		}
		
		public void setZoom(float zoom) {
			this.zoom = zoom;
		}
		
		public float getTouchX() {
			return touchX;
		}
		
		public void setTouchX(float touchX) {
			this.touchX = touchX;
		}
		
		public float getTouchY() {
			return touchY;
		}
		
		public void setTouchY(float touchY) {
			this.touchY = touchY;
		}
		
		public long getAnimationLengthMS() {	
			return animationLengthMS;
		}
		
		public void setAnimationLengthMS(long animationLengthMS) {
			this.animationLengthMS = animationLengthMS;
		}
		
		public ZoomAnimationListener getZoomAnimationListener() {
			return zoomAnimationListener;
		}
		
		public void setZoomAnimationListener(ZoomAnimationListener zoomAnimationListener) {		this.zoomAnimationListener = zoomAnimationListener;
		}
	}
	public static interface ZoomAnimationListener {
		public void onZoom(float scale, float x, float y);
		public void onComplete();
	}
	
	
	private void _setBackground (final View _layout, final String _path) {
		_layout.setBackground(new android.graphics.drawable.BitmapDrawable(getResources(), FileUtil.decodeSampleBitmapFromPath(_path, 1024, 1024)));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
