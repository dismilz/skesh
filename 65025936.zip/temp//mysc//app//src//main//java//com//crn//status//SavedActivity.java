package com.crn.status;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.AdapterView;
import android.Manifest;
import android.content.pm.PackageManager;

public class SavedActivity extends Activity {
	
	
	private double z = 0;
	
	private ArrayList<String> as = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> p = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear5;
	private TextView textview1;
	private ListView listview1;
	
	private SharedPreferences view;
	private Intent go = new Intent();
	private AlertDialog.Builder d;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.saved);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		textview1 = (TextView) findViewById(R.id.textview1);
		listview1 = (ListView) findViewById(R.id.listview1);
		view = getSharedPreferences("view", Activity.MODE_PRIVATE);
		d = new AlertDialog.Builder(this);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (as.get((int)(_position)).endsWith(".mp4")) {
					view.edit().putString("video", as.get((int)(_position))).commit();
					go.setClass(getApplicationContext(), ViewActivity.class);
					go.putExtra("saved", "saved");
					startActivity(go);
				}
				else {
					go.putExtra("p", "p");
					go.putExtra("saved", "nothing");
					view.edit().putString("picture", as.get((int)(_position))).commit();
					go.setClass(getApplicationContext(), ViewActivity.class);
					go.putExtra("saved", "saved");
					startActivity(go);
				}
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (as.get((int)(_position)).endsWith(".mp4")) {
					d.setMessage("Delete Video?");
					d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							p.remove((int)(_position));
							FileUtil.deleteFile(as.get((int)(_position)));
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
							SketchwareUtil.showMessage(getApplicationContext(), "Deleted");
						}
					});
					d.setNegativeButton("No", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					d.create().show();
				}
				else {
					d.setMessage("Delete Picture?");
					d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							p.remove((int)(_position));
							FileUtil.deleteFile(as.get((int)(_position)));
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
							SketchwareUtil.showMessage(getApplicationContext(), "Deleted");
						}
					});
					d.setNegativeButton("No", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					d.create().show();
				}
				return true;
			}
		});
	}
	private void initializeLogic() {
		_ref3();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _ref3 () {
		FileUtil.listDir(FileUtil.getPublicDir(Environment.DIRECTORY_DCIM).concat("/CRN/wss/"), as);
		z = 0;
		for(int _repeat14 = 0; _repeat14 < (int)(as.size()); _repeat14++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("media", as.get((int)(z)));
				p.add(_item);
			}
			
			z++;
		}
		listview1.setAdapter(new Listview1Adapter(p));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.costum, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			
			android.graphics.drawable.GradientDrawable CRNTY = new android.graphics.drawable.GradientDrawable();
			CRNTY.setColor(Color.parseColor("#ffffff"));
			CRNTY.setCornerRadii(new float[]{ (float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10 });
			CRNTY.setStroke((int) 2, Color.parseColor("#009688"));
			linear2.setElevation((float) 5);
			linear2.setBackground(CRNTY);
			//Milz
			android.graphics.drawable.GradientDrawable CRNHW = new android.graphics.drawable.GradientDrawable();
			CRNHW.setColor(Color.parseColor("#ffffff"));
			CRNHW.setCornerRadii(new float[]{ (float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10 });
			CRNHW.setStroke((int) 2, Color.parseColor("#009688"));
			linear1.setElevation((float) 5);
			linear1.setBackground(CRNHW);
			//Milz
			textview1.setText(Uri.parse(as.get((int)(_position))).getLastPathSegment());
			if (as.get((int)(_position)).endsWith(".mp4")) {
				Bitmap bMap = ThumbnailUtils.createVideoThumbnail(p.get(_position).get("media").toString(), android.provider.MediaStore.Video.Thumbnails.MICRO_KIND); imageview1.setImageBitmap(bMap);
			}
			else {
				imageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(as.get((int)(_position)), 1024, 1024));
			}
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
