package growtopia.hack.com;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.widget.LinearLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.webkit.WebView;
import android.webkit.WebSettings;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import android.widget.EditText;
import android.widget.Button;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.AdListener;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;
import android.webkit.WebViewClient;
import android.view.View;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private DrawerLayout _drawer;
	private boolean darkUI = false;
	private HashMap<String, Object> dowloads = new HashMap<>();
	
	private ArrayList<String> dowload = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private WebView webview1;
	private AdView adview1;
	private EditText edittext1;
	private Button button3;
	private Button _drawer_views;
	private Button _drawer_likes;
	private Button _drawer_subs;
	private Button _drawer_subscribetostirrergt;
	private Button _drawer_freemoney;
	private AdView _drawer_adview1;
	private LinearLayout _drawer_linear1;
	private Button _drawer_report_bug;
	
	private InterstitialAd ads;
	private AdListener _ads_ad_listener;
	private AlertDialog.Builder d;
	private Intent i = new Intent();
	private TimerTask timer;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = (DrawerLayout) findViewById(R.id._drawer);ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(MainActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view);
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		adview1 = (AdView) findViewById(R.id.adview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		button3 = (Button) findViewById(R.id.button3);
		_drawer_views = (Button) _nav_view.findViewById(R.id.views);
		_drawer_likes = (Button) _nav_view.findViewById(R.id.likes);
		_drawer_subs = (Button) _nav_view.findViewById(R.id.subs);
		_drawer_subscribetostirrergt = (Button) _nav_view.findViewById(R.id.subscribetostirrergt);
		_drawer_freemoney = (Button) _nav_view.findViewById(R.id.freemoney);
		_drawer_adview1 = (AdView) _nav_view.findViewById(R.id.adview1);
		_drawer_linear1 = (LinearLayout) _nav_view.findViewById(R.id.linear1);
		_drawer_report_bug = (Button) _nav_view.findViewById(R.id.report_bug);
		d = new AlertDialog.Builder(this);
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				if (mRewardedVideoAd.isLoaded()) {
					mRewardedVideoAd.show();
				} else {
					Toast.makeText(MainActivity.this, "Ad not loaded yet", Toast.LENGTH_SHORT).show();
				}
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				if (mRewardedVideoAd.isLoaded()) {
					mRewardedVideoAd.show();
				} else {
					Toast.makeText(MainActivity.this, "Ad not loaded yet", Toast.LENGTH_SHORT).show();
				}
				super.onPageFinished(_param1, _param2);
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.loadUrl(edittext1.getText().toString());
			}
		});
		
		_drawer_views.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.setTitle("FREE  10 VIEWS JUST SUBSCRIBE TO STIRRER GT  ");
				d.setPositiveButton("OKAY", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (mRewardedVideoAd.isLoaded()) {
							mRewardedVideoAd.show();
						} else {
							Toast.makeText(MainActivity.this, "Ad not loaded yet", Toast.LENGTH_SHORT).show();
						}
						i.setData(Uri.parse("https://www.youtube.com/channel/UCIJMQMPcuHGQrPd14ao_jJw"));
						i.setAction(Intent.ACTION_VIEW);
						startActivity(i);
						finish();
					}
				});
				d.setNegativeButton("NO THANKS", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (mRewardedVideoAd.isLoaded()) {
							mRewardedVideoAd.show();
						} else {
							Toast.makeText(MainActivity.this, "Ad not loaded yet", Toast.LENGTH_SHORT).show();
						}
					}
				});
				d.create().show();
			}
		});
		
		_drawer_likes.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.setTitle("FREE 10 LIKES JUST SUBSCRIBE TO STIRRER GT ");
				d.setPositiveButton("OKAY", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (mRewardedVideoAd.isLoaded()) {
							mRewardedVideoAd.show();
						} else {
							Toast.makeText(MainActivity.this, "Ad not loaded yet", Toast.LENGTH_SHORT).show();
						}
						i.setData(Uri.parse("https://www.youtube.com/channel/UCIJMQMPcuHGQrPd14ao_jJw"));
						i.setAction(Intent.ACTION_VIEW);
						startActivity(i);
						finish();
					}
				});
				d.setNegativeButton("NO THANKS", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (mRewardedVideoAd.isLoaded()) {
							mRewardedVideoAd.show();
						} else {
							Toast.makeText(MainActivity.this, "Ad not loaded yet", Toast.LENGTH_SHORT).show();
						}
					}
				});
				d.create().show();
			}
		});
		
		_drawer_subs.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.setTitle("FREE SUBSCRIBERS JUST SUBSCRIBE TO STIRRER GT");
				d.setPositiveButton("OKAY", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (mRewardedVideoAd.isLoaded()) {
							mRewardedVideoAd.show();
						} else {
							Toast.makeText(MainActivity.this, "Ad not loaded yet", Toast.LENGTH_SHORT).show();
						}
						i.setData(Uri.parse("https://www.youtube.com/channel/UCIJMQMPcuHGQrPd14ao_jJw"));
						i.setAction(Intent.ACTION_VIEW);
						startActivity(i);
						finish();
					}
				});
				d.setNegativeButton("NO THANKS", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (mRewardedVideoAd.isLoaded()) {
							mRewardedVideoAd.show();
						} else {
							Toast.makeText(MainActivity.this, "Ad not loaded yet", Toast.LENGTH_SHORT).show();
						}
					}
				});
				d.create().show();
			}
		});
		
		_drawer_subscribetostirrergt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.setTitle("Are You SHURE U WANT TO subscribe to stirrer gt");
				d.setPositiveButton("OKAY", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (mRewardedVideoAd.isLoaded()) {
							mRewardedVideoAd.show();
						} else {
							Toast.makeText(MainActivity.this, "Ad not loaded yet", Toast.LENGTH_SHORT).show();
						}
						i.setData(Uri.parse("https://www.youtube.com/channel/UCIJMQMPcuHGQrPd14ao_jJw"));
						i.setAction(Intent.ACTION_VIEW);
						startActivity(i);
						finish();
					}
				});
				d.setNegativeButton("NO THANKS", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (mRewardedVideoAd.isLoaded()) {
							mRewardedVideoAd.show();
						} else {
							Toast.makeText(MainActivity.this, "Ad not loaded yet", Toast.LENGTH_SHORT).show();
						}
					}
				});
				d.create().show();
			}
		});
		
		_drawer_freemoney.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (mRewardedVideoAd.isLoaded()) {
					mRewardedVideoAd.show();
				} else {
					Toast.makeText(MainActivity.this, "Ad not loaded yet", Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		_drawer_report_bug.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_push_notification("REPORT BUG ", "BUG REPORTED");
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								d.setTitle("REPORT BUG");
								d.setMessage("BUG REPORTED TO ADMIN");
								d.setPositiveButton("CLOSE", new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface _dialog, int _which) {
										if (mRewardedVideoAd.isLoaded()) {
											mRewardedVideoAd.show();
										} else {
											Toast.makeText(MainActivity.this, "Ad not loaded yet", Toast.LENGTH_SHORT).show();
										}
									}
								});
								d.create().show();
							}
						});
					}
				};
				_timer.schedule(timer, (int)(6000));
			}
		});
		
		_ads_ad_listener = new AdListener() {
			@Override
			public void onAdLoaded() {
				ads.show();
			}
			
			@Override
			public void onAdFailedToLoad(int _param1) {
				final int _errorCode = _param1;
				
			}
			
			@Override
			public void onAdOpened() {
				
			}
			
			@Override
			public void onAdClosed() {
				
			}
		};
	}
	private void initializeLogic() {
		com.google.android.gms.ads.MobileAds.initialize(this, "ca-app-pub-3940256099942544/1033173712");
		// Define mRewardedVideoAd
		mRewardedVideoAd = com.google.android.gms.ads.MobileAds.getRewardedVideoAdInstance(this);
		// Set RewardedVideoAdListener for mRewardedVideoAd
		mRewardedVideoAd.setRewardedVideoAdListener(new com.google.android.gms.ads.reward.RewardedVideoAdListener(){
			@Override
			public void onRewarded(com.google.android.gms.ads.reward.RewardItem reward) {
				Toast.makeText(MainActivity.this, "onRewarded! currency: " + reward.getType() + " amount: " + reward.getAmount(), Toast.LENGTH_SHORT).show();
				// Put code for Rewarding the user here
			}
			@Override
			public void onRewardedVideoAdLeftApplication() {
				Toast.makeText(MainActivity.this, "onRewardedVideoAdLeftApplication", Toast.LENGTH_SHORT).show();
			}
			@Override
			public void onRewardedVideoAdClosed() {
				Toast.makeText(MainActivity.this, "onRewardedVideoAdClosed", Toast.LENGTH_SHORT).show();
				// Reload new Ad when Ad is closed
				loadRewardedVideoAd();
			}
			@Override
			public void onRewardedVideoAdFailedToLoad(int errorCode) {
				Toast.makeText(MainActivity.this, "onRewardedVideoAdFailedToLoad", Toast.LENGTH_SHORT).show();
			}
			@Override
			public void onRewardedVideoAdLoaded() {
				Toast.makeText(MainActivity.this, "onRewardedVideoAdLoaded", Toast.LENGTH_SHORT).show();
			}
			@Override
			public void onRewardedVideoAdOpened() {
				Toast.makeText(MainActivity.this, "onRewardedVideoAdOpened", Toast.LENGTH_SHORT).show();
			}
			@Override
			public void onRewardedVideoStarted() {
				Toast.makeText(MainActivity.this, "onRewardedVideoStarted", Toast.LENGTH_SHORT).show();
			}
			@Override
			public void onRewardedVideoCompleted() {
				Toast.makeText(MainActivity.this, "onRewardedVideoCompleted", Toast.LENGTH_SHORT).show();
			}
		});
		// Load the Rewarded Video Ad
		loadRewardedVideoAd();
		ads = new InterstitialAd(getApplicationContext());
		ads.setAdListener(_ads_ad_listener);
		ads.setAdUnitId("ca-app-pub-3940256099942544/1033173712");
		ads.loadAd(new AdRequest.Builder().build());
		adview1.loadAd(new AdRequest.Builder().build());
		ads.show();
		
		ads.loadAd(new AdRequest.Builder().build());
		_setCornerRadius(linear2, 25, "#2196F3");
		webview1.loadUrl("http://www.youtube.com");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		mRewardedVideoAd.resume(this);
	}
	
	@Override
	public void onPause() {
		super.onPause();
		mRewardedVideoAd.pause(this);
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		mRewardedVideoAd.destroy(this);
	}
	
	@Override
	public void onBackPressed() {
		d.setTitle("exit");
		d.setMessage("rr you so want to exit");
		d.setPositiveButton("yess", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				if (mRewardedVideoAd.isLoaded()) {
					mRewardedVideoAd.show();
				} else {
					Toast.makeText(MainActivity.this, "Ad not loaded yet", Toast.LENGTH_SHORT).show();
				}
				webview1.goBack();
				ads.show();
			}
		});
		d.setNegativeButton("NO", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				if (mRewardedVideoAd.isLoaded()) {
					mRewardedVideoAd.show();
				} else {
					Toast.makeText(MainActivity.this, "Ad not loaded yet", Toast.LENGTH_SHORT).show();
				}
				ads.show();
			}
		});
		d.create().show();
	}
	private void _extra () {
	}
	com.google.android.gms.ads.reward.RewardedVideoAd mRewardedVideoAd;
	private void loadRewardedVideoAd() {
		mRewardedVideoAd.loadAd("ca-app-pub-3940256099942544/5224354917", new AdRequest.Builder().build());
	}
	
	
	private void _setCornerRadius (final View _view, final double _value, final String _color) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_value);
		_view.setBackground(gd);
	}
	
	
	private void _push_notification (final String _title, final String _message) {
		final Context context = getApplicationContext();
		
		NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
		
		Intent intent = new Intent(this, MainActivity.class); 
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP); 
		PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0); 
		androidx.core.app.NotificationCompat.Builder builder; 
		
		    int notificationId = 1;
		    String channelId = "channel-01";
		    String channelName = "Channel Name";
		    int importance = NotificationManager.IMPORTANCE_HIGH;
		
		    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
			        NotificationChannel mChannel = new NotificationChannel(
			                channelId, channelName, importance);
			        notificationManager.createNotificationChannel(mChannel);
			    }
		 androidx.core.app.NotificationCompat.Builder mBuilder = new androidx.core.app.NotificationCompat.Builder(context, channelId)
		            .setSmallIcon(R.drawable.icon3)
		            .setContentTitle(_title)
		            .setContentText(_message)
		            .setAutoCancel(true)
		            .setOngoing(false)
		            .setContentIntent(pendingIntent);
		    TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
		    stackBuilder.addNextIntent(intent);
		    PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(
		            0,
		            PendingIntent.FLAG_UPDATE_CURRENT
		    );
		    mBuilder.setContentIntent(resultPendingIntent);
		
		    notificationManager.notify(notificationId, mBuilder.build());
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
