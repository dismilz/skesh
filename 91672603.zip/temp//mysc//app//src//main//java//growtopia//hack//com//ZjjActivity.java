package growtopia.hack.com;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;

public class ZjjActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout website;
	private LinearLayout a6lb;
	private LinearLayout note;
	private LinearLayout man_nahn;
	private LinearLayout shareapp;
	private LinearLayout update;
	private LinearLayout download;
	private LinearLayout linear13;
	private LinearLayout h2ooo2;
	private ImageView img_profile;
	private TextView textview7;
	private TextView textview8;
	private ImageView imageview5;
	private TextView textview11;
	private ImageView imageview6;
	private TextView textview12;
	private ImageView imageview7;
	private TextView textview13;
	private ImageView imageview8;
	private TextView textview14;
	private ImageView imageview9;
	private TextView textview15;
	private ImageView imageview10;
	private TextView textview16;
	private ImageView imageview11;
	private TextView textview17;
	private ImageView face;
	private LinearLayout linear14;
	private ImageView youtube;
	private LinearLayout linear15;
	private ImageView twitter;
	private LinearLayout linear16;
	private ImageView gmail;
	private TextView h2o2;
	private LinearLayout clickl;
	private LinearLayout linear_icon;
	private LinearLayout linear_text;
	private LinearLayout dropdown_liniar;
	private ImageView i;
	private TextView t;
	private TextView p;
	private LinearLayout linear11;
	private TextView textview18;
	private TextView textview6;
	private ImageView dropdown;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.zjj);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		website = (LinearLayout) findViewById(R.id.website);
		a6lb = (LinearLayout) findViewById(R.id.a6lb);
		note = (LinearLayout) findViewById(R.id.note);
		man_nahn = (LinearLayout) findViewById(R.id.man_nahn);
		shareapp = (LinearLayout) findViewById(R.id.shareapp);
		update = (LinearLayout) findViewById(R.id.update);
		download = (LinearLayout) findViewById(R.id.download);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		h2ooo2 = (LinearLayout) findViewById(R.id.h2ooo2);
		img_profile = (ImageView) findViewById(R.id.img_profile);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview8 = (TextView) findViewById(R.id.textview8);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview11 = (TextView) findViewById(R.id.textview11);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		textview12 = (TextView) findViewById(R.id.textview12);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		textview13 = (TextView) findViewById(R.id.textview13);
		imageview8 = (ImageView) findViewById(R.id.imageview8);
		textview14 = (TextView) findViewById(R.id.textview14);
		imageview9 = (ImageView) findViewById(R.id.imageview9);
		textview15 = (TextView) findViewById(R.id.textview15);
		imageview10 = (ImageView) findViewById(R.id.imageview10);
		textview16 = (TextView) findViewById(R.id.textview16);
		imageview11 = (ImageView) findViewById(R.id.imageview11);
		textview17 = (TextView) findViewById(R.id.textview17);
		face = (ImageView) findViewById(R.id.face);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		youtube = (ImageView) findViewById(R.id.youtube);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		twitter = (ImageView) findViewById(R.id.twitter);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		gmail = (ImageView) findViewById(R.id.gmail);
		h2o2 = (TextView) findViewById(R.id.h2o2);
		clickl = (LinearLayout) findViewById(R.id.clickl);
		linear_icon = (LinearLayout) findViewById(R.id.linear_icon);
		linear_text = (LinearLayout) findViewById(R.id.linear_text);
		dropdown_liniar = (LinearLayout) findViewById(R.id.dropdown_liniar);
		i = (ImageView) findViewById(R.id.i);
		t = (TextView) findViewById(R.id.t);
		p = (TextView) findViewById(R.id.p);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		textview18 = (TextView) findViewById(R.id.textview18);
		textview6 = (TextView) findViewById(R.id.textview6);
		dropdown = (ImageView) findViewById(R.id.dropdown);
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
