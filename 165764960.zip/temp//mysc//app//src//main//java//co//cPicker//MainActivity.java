package co.cPicker;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.SeekBar;
import android.view.View;
import android.content.ClipData;
import android.content.ClipboardManager;

public class MainActivity extends Activity {
	
	
	private double color1 = 0;
	private double color2 = 0;
	private double color3 = 0;
	private String RgbToHex = "";
	
	private LinearLayout linear1;
	private TextView textview6;
	private LinearLayout linear5;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private TextView textview1;
	private TextView textview5;
	private TextView textview2;
	private SeekBar seekbar1;
	private TextView textview3;
	private SeekBar seekbar2;
	private TextView textview4;
	private SeekBar seekbar3;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		textview6 = (TextView) findViewById(R.id.textview6);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview2 = (TextView) findViewById(R.id.textview2);
		seekbar1 = (SeekBar) findViewById(R.id.seekbar1);
		textview3 = (TextView) findViewById(R.id.textview3);
		seekbar2 = (SeekBar) findViewById(R.id.seekbar2);
		textview4 = (TextView) findViewById(R.id.textview4);
		seekbar3 = (SeekBar) findViewById(R.id.seekbar3);
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Rgb code copied");
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview1.getText().toString()));
			}
		});
		
		textview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Hex code copied");
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", RgbToHex));
			}
		});
		
		seekbar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged (SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				color1 = _progressValue;
				_setBackgroud_RGB(linear1, _progressValue, color2, color3);
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				
			}
		});
		
		seekbar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged (SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				color2 = _progressValue;
				_setBackgroud_RGB(linear1, color1, _progressValue, color3);
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				
			}
		});
		
		seekbar3.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged (SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				color3 = _progressValue;
				_setBackgroud_RGB(linear1, color1, color2, _progressValue);
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				
			}
		});
	}
	private void initializeLogic() {
		color1 = 0;
		color2 = 0;
		color3 = 0;
		RgbToHex = String.format("#%02x%02x%02x",(int)color1,(int)color2,(int)color3);
		_setBackgroud_RGB(linear1, color1, color1, color1);
		textview1.setText("RGB(".concat(String.valueOf((long)(color1)).concat(String.valueOf((long)(color2)).concat(String.valueOf((long)(color3))).concat(")"))));
		textview5.setText(RgbToHex);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _setBackgroud_RGB (final View _target, final double _Red, final double _Green, final double _Blue) {
		_target.setBackgroundColor(android.graphics.Color.rgb((int)_Red,(int)_Green,(int)_Blue));
		getActionBar().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.rgb((int)_Red,(int)_Green,(int)_Blue)));
		
		textview1.setText("RGB("+String.valueOf((long)(color1)+","+String.valueOf((long)color2)+","+String.valueOf((long)color3)+")"));
		
		RgbToHex = String.format("#%02x%02x%02x",(int)_Red,(int)_Green,(int)_Blue);
		
		textview5.setText("HEX("+RgbToHex+")");
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
