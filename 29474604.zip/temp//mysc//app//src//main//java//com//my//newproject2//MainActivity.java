package com.my.newproject2;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.AdapterView;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
	
	
	private String v_lang1 = "";
	private double length = 0;
	private double pos = 0;
	private String datakey = "";
	private String value = "";
	private String key = "";
	private String mode = "";
	
	private ArrayList<HashMap<String, Object>> vokabeln = new ArrayList<>();
	
	private LinearLayout linear_main;
	private LinearLayout linear_buttons;
	private LinearLayout linear_input;
	private ListView listview_vokabeln;
	private TextView button_new;
	private TextView button_lang;
	private TextView button_hidden;
	private LinearLayout linear_input_buttons;
	private LinearLayout linear_input_lang1;
	private LinearLayout linear_input_lang2;
	private TextView button_ok;
	private TextView button_back;
	private TextView text_input_header;
	private TextView text_lang1;
	private EditText edit_lang1;
	private TextView text_lang2;
	private EditText edit_lang2;
	
	private Intent i = new Intent();
	private SharedPreferences data;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear_main = (LinearLayout) findViewById(R.id.linear_main);
		linear_buttons = (LinearLayout) findViewById(R.id.linear_buttons);
		linear_input = (LinearLayout) findViewById(R.id.linear_input);
		listview_vokabeln = (ListView) findViewById(R.id.listview_vokabeln);
		button_new = (TextView) findViewById(R.id.button_new);
		button_lang = (TextView) findViewById(R.id.button_lang);
		button_hidden = (TextView) findViewById(R.id.button_hidden);
		linear_input_buttons = (LinearLayout) findViewById(R.id.linear_input_buttons);
		linear_input_lang1 = (LinearLayout) findViewById(R.id.linear_input_lang1);
		linear_input_lang2 = (LinearLayout) findViewById(R.id.linear_input_lang2);
		button_ok = (TextView) findViewById(R.id.button_ok);
		button_back = (TextView) findViewById(R.id.button_back);
		text_input_header = (TextView) findViewById(R.id.text_input_header);
		text_lang1 = (TextView) findViewById(R.id.text_lang1);
		edit_lang1 = (EditText) findViewById(R.id.edit_lang1);
		text_lang2 = (TextView) findViewById(R.id.text_lang2);
		edit_lang2 = (EditText) findViewById(R.id.edit_lang2);
		data = getSharedPreferences("vokabelbox_data", Activity.MODE_PRIVATE);
		
		listview_vokabeln.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				mode = "edit";
				pos = _position;
				linear_buttons.setVisibility(View.GONE);
				linear_input.setVisibility(View.VISIBLE);
				text_lang1.setText(v_lang1);
				value = vokabeln.get((int)_position).get(v_lang1.concat(String.valueOf((long)(_position)))).toString();
				edit_lang1.setText(value.substring((int)(0), (int)(value.indexOf("+"))));
				edit_lang2.setText(value.substring((int)(value.indexOf("+") + 1), (int)(value.length())));
			}
		});
		
		button_new.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mode = "new";
				pos = vokabeln.size();
				linear_buttons.setVisibility(View.GONE);
				linear_input.setVisibility(View.VISIBLE);
				text_lang1.setText(v_lang1);
				edit_lang1.setText("");
				edit_lang2.setText("");
			}
		});
		
		button_lang.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), LanguagesActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		
		button_hidden.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				vokabeln.clear();
				data.edit().putString(v_lang1.concat("0"), "hello+hallo").commit();
				data.edit().putString(v_lang1.concat("1"), "yes+ja").commit();
				data.edit().putString(v_lang1.concat("2"), "no+nein").commit();
				data.edit().putString(v_lang1.concat("length"), "3").commit();
				pos = 0;
				length = Double.parseDouble(data.getString(v_lang1.concat("length"), ""));
				for(int _repeat14 = 0; _repeat14 < (int)(length); _repeat14++) {
					datakey = v_lang1.concat(String.valueOf((long)(pos)));
					{
						HashMap<String, Object> _item = new HashMap<>();
						_item.put(datakey, data.getString(datakey, ""));
						vokabeln.add(_item);
					}
					
					pos++;
				}
				listview_vokabeln.setAdapter(new Listview_vokabelnAdapter(vokabeln));
				((BaseAdapter)listview_vokabeln.getAdapter()).notifyDataSetChanged();
			}
		});
		
		button_ok.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_buttons.setVisibility(View.VISIBLE);
				linear_input.setVisibility(View.GONE);
				if (mode.equals("new")) {
					SketchwareUtil.showMessage(getApplicationContext(), "new");
					{
						HashMap<String, Object> _item = new HashMap<>();
						_item.put(v_lang1.concat(String.valueOf((long)(vokabeln.size()))), edit_lang1.getText().toString().concat("+".concat(edit_lang2.getText().toString())));
						vokabeln.add(_item);
					}
					
					((BaseAdapter)listview_vokabeln.getAdapter()).notifyDataSetChanged();
					data.edit().putString(v_lang1.concat(String.valueOf((long)(vokabeln.size() - 1))), edit_lang1.getText().toString().concat("+".concat(edit_lang2.getText().toString()))).commit();
					data.edit().putString(v_lang1.concat("length"), String.valueOf((long)(vokabeln.size()))).commit();
				}
				if (mode.equals("edit")) {
					SketchwareUtil.showMessage(getApplicationContext(), "edit");
					vokabeln.get((int)pos).put(v_lang1.concat(String.valueOf((long)(pos))), edit_lang1.getText().toString().concat("+".concat(edit_lang2.getText().toString())));
					((BaseAdapter)listview_vokabeln.getAdapter()).notifyDataSetChanged();
					data.edit().putString(v_lang1.concat(String.valueOf((long)(pos))), edit_lang1.getText().toString().concat("+".concat(edit_lang2.getText().toString()))).commit();
				}
				mode = "standby";
			}
		});
		
		button_back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_buttons.setVisibility(View.VISIBLE);
				linear_input.setVisibility(View.GONE);
			}
		});
	}
	private void initializeLogic() {
		mode = "standby";
		linear_input.setVisibility(View.GONE);
		if (data.getString("d_lang1", "").equals("")) {
			v_lang1 = "EN";
		}
		else {
			v_lang1 = data.getString("d_lang1", "");
		}
		if (data.getString(v_lang1.concat("length"), "").equals("")) {
			length = 0;
		}
		else {
			length = Double.parseDouble(data.getString(v_lang1.concat("length"), ""));
		}
		pos = 0;
		for(int _repeat25 = 0; _repeat25 < (int)(length); _repeat25++) {
			datakey = v_lang1.concat(String.valueOf((long)(pos)));
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put(datakey, data.getString(datakey, ""));
				vokabeln.add(_item);
			}
			
			pos++;
		}
		listview_vokabeln.setAdapter(new Listview_vokabelnAdapter(vokabeln));
		((BaseAdapter)listview_vokabeln.getAdapter()).notifyDataSetChanged();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public class Listview_vokabelnAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview_vokabelnAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.vokabel_listitem, null);
			}
			
			final LinearLayout linear_item_main = (LinearLayout) _v.findViewById(R.id.linear_item_main);
			final TextView text_item_lang1 = (TextView) _v.findViewById(R.id.text_item_lang1);
			final TextView text_item1 = (TextView) _v.findViewById(R.id.text_item1);
			final TextView text_item_2 = (TextView) _v.findViewById(R.id.text_item_2);
			final CheckBox checkbox_item = (CheckBox) _v.findViewById(R.id.checkbox_item);
			
			key = v_lang1.concat(String.valueOf(_position));
			value = vokabeln.get((int)_position).get(key).toString();
			text_item_lang1.setText(v_lang1);
			text_item1.setText(value.substring((int)(0), (int)(value.indexOf("+"))));
			text_item_2.setText(value.substring((int)(value.indexOf("+") + 1), (int)(value.length())));
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
