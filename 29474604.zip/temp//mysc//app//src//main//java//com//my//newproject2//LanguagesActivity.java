package com.my.newproject2;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.AdapterView;
import android.view.View;

public class LanguagesActivity extends Activity {
	
	
	private ArrayList<String> languages = new ArrayList<>();
	
	private LinearLayout linear_main;
	private LinearLayout linear_input;
	private ListView listview_languages;
	private TextView button_back;
	private EditText edit_input;
	private TextView button_ok;
	
	private Intent i = new Intent();
	private SharedPreferences data;
	private AlertDialog.Builder dialog;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.languages);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear_main = (LinearLayout) findViewById(R.id.linear_main);
		linear_input = (LinearLayout) findViewById(R.id.linear_input);
		listview_languages = (ListView) findViewById(R.id.listview_languages);
		button_back = (TextView) findViewById(R.id.button_back);
		edit_input = (EditText) findViewById(R.id.edit_input);
		button_ok = (TextView) findViewById(R.id.button_ok);
		data = getSharedPreferences("vokabelbox_data", Activity.MODE_PRIVATE);
		dialog = new AlertDialog.Builder(this);
		
		listview_languages.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (languages.get((int)(_position)).equals("+")) {
					linear_input.setVisibility(View.VISIBLE);
				}
				else {
					data.edit().putString("d_lang1", languages.get((int)(_position))).commit();
					SketchwareUtil.showMessage(getApplicationContext(), languages.get((int)(_position)));
					i.setClass(getApplicationContext(), MainActivity.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
			}
		});
		
		listview_languages.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				dialog.setTitle("Sprache löschen!");
				dialog.setMessage("Wirklich löschen?");
				dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						SketchwareUtil.showMessage(getApplicationContext(), "Nicht gelöscht!");
					}
				});
				dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						languages.remove((int)(_position));
						((BaseAdapter)listview_languages.getAdapter()).notifyDataSetChanged();
						SketchwareUtil.showMessage(getApplicationContext(), "Gelöscht!");
					}
				});
				dialog.create().show();
				return true;
			}
		});
		
		button_back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_input.setVisibility(View.GONE);
			}
		});
		
		button_ok.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				languages.add(edit_input.getText().toString());
				linear_input.setVisibility(View.GONE);
				listview_languages.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_list_item_1, languages));
				((BaseAdapter)listview_languages.getAdapter()).notifyDataSetChanged();
			}
		});
	}
	private void initializeLogic() {
		linear_input.setVisibility(View.GONE);
		languages.add("+");
		languages.add("EN");
		languages.add("FR");
		languages.add("IT");
		languages.add("RU");
		listview_languages.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_list_item_1, languages));
		((BaseAdapter)listview_languages.getAdapter()).notifyDataSetChanged();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
