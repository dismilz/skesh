package com.fire.base.datas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.ProgressBar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Continuation;
import android.net.Uri;
import java.io.File;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.view.View;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class AppDownloadActivity extends AppCompatActivity {
	
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private HashMap<String, Object> map = new HashMap<>();
	private String imageString = "";
	
	private LinearLayout linear1;
	private ScrollView vscroll1;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear9;
	private LinearLayout linear15;
	private LinearLayout linear8;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear7;
	private ImageView imageview1;
	private TextView textview8;
	private EditText appname;
	private TextView textview15;
	private EditText publisher;
	private TextView textview7;
	private EditText time;
	private TextView textview10;
	private EditText package_name;
	private TextView textview11;
	private EditText version;
	private TextView textview12;
	private EditText size;
	private ProgressBar progressbar1;
	private TextView textview13;
	private TextView textview_save;
	
	private FirebaseAuth fauth;
	private OnCompleteListener<AuthResult> _fauth_create_user_listener;
	private OnCompleteListener<AuthResult> _fauth_sign_in_listener;
	private OnCompleteListener<Void> _fauth_reset_password_listener;
	private StorageReference fstore = _firebase_storage.getReference("apk_store");
	private OnCompleteListener<Uri> _fstore_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fstore_download_success_listener;
	private OnSuccessListener _fstore_delete_success_listener;
	private OnProgressListener _fstore_upload_progress_listener;
	private OnProgressListener _fstore_download_progress_listener;
	private OnFailureListener _fstore_failure_listener;
	private Calendar cal = Calendar.getInstance();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.app_download);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview8 = (TextView) findViewById(R.id.textview8);
		appname = (EditText) findViewById(R.id.appname);
		textview15 = (TextView) findViewById(R.id.textview15);
		publisher = (EditText) findViewById(R.id.publisher);
		textview7 = (TextView) findViewById(R.id.textview7);
		time = (EditText) findViewById(R.id.time);
		textview10 = (TextView) findViewById(R.id.textview10);
		package_name = (EditText) findViewById(R.id.package_name);
		textview11 = (TextView) findViewById(R.id.textview11);
		version = (EditText) findViewById(R.id.version);
		textview12 = (TextView) findViewById(R.id.textview12);
		size = (EditText) findViewById(R.id.size);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		textview13 = (TextView) findViewById(R.id.textview13);
		textview_save = (TextView) findViewById(R.id.textview_save);
		fauth = FirebaseAuth.getInstance();
		
		textview_save.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_firebase_storage.getReferenceFromUrl(map.get("app_url").toString()).getFile(new File(FileUtil.getPublicDir(Environment.DIRECTORY_DOWNLOADS).concat("/".concat(Uri.parse(Uri.parse(map.get("app_url").toString()).getLastPathSegment()).getLastPathSegment())))).addOnSuccessListener(_fstore_download_success_listener).addOnFailureListener(_fstore_failure_listener).addOnProgressListener(_fstore_download_progress_listener);
				progressbar1.setVisibility(View.VISIBLE);
				textview13.setVisibility(View.VISIBLE);
				textview_save.setEnabled(false);
			}
		});
		
		_fstore_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fstore_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				textview13.setText(String.valueOf((long)(_progressValue)).concat(" % downloaded"));
			}
		};
		
		_fstore_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_fstore_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				progressbar1.setVisibility(View.GONE);
				textview13.setVisibility(View.GONE);
				textview_save.setEnabled(true);
				SketchwareUtil.showMessage(getApplicationContext(), String.valueOf((long)(_totalByteCount / 1024)).concat(" kb file downloaded"));
			}
		};
		
		_fstore_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fstore_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				progressbar1.setVisibility(View.GONE);
				textview13.setVisibility(View.GONE);
				textview_save.setEnabled(true);
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_fauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		time.setEnabled(false);
		appname.setEnabled(false);
		package_name.setEnabled(false);
		version.setEnabled(false);
		size.setEnabled(false);
		publisher.setEnabled(false);
		progressbar1.setVisibility(View.GONE);
		textview13.setVisibility(View.GONE);
		map = new Gson().fromJson(getIntent().getStringExtra("appdata"), new TypeToken<HashMap<String, Object>>(){}.getType());
		if (map.containsKey("app_icon")) {
			imageString = map.get("app_icon").toString();
			byte[] imageBytes = android.util.Base64.decode(imageString, android.util.Base64.DEFAULT);
			
			Bitmap decodedImage = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
			
			imageview1.setImageBitmap(decodedImage);
		}
		else {
			imageview1.setImageResource(R.drawable.ic_launcher);
		}
		if (map.containsKey("app_name")) {
			appname.setText(map.get("app_name").toString());
		}
		else {
			appname.setText("unknown");
		}
		if (map.containsKey("app_package")) {
			package_name.setText(map.get("app_package").toString());
		}
		else {
			package_name.setText("unknown");
		}
		if (map.containsKey("app_version")) {
			version.setText(map.get("app_version").toString());
		}
		else {
			version.setText("unknown");
		}
		if (map.containsKey("app_size")) {
			size.setText(map.get("app_size").toString());
		}
		else {
			size.setText("unknown");
		}
		if (map.containsKey("publisher_mail")) {
			publisher.setText(map.get("publisher_mail").toString());
		}
		else {
			publisher.setText("unknown");
		}
		if (map.containsKey("time")) {
			cal.setTimeInMillis((long)(Double.parseDouble(map.get("time").toString())));
			time.setText(new SimpleDateFormat("dd MMM yyyy").format(cal.getTime()));
		}
		else {
			time.setText("unknown");
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
