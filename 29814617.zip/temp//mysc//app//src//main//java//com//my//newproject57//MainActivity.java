package com.my.newproject57;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.HorizontalScrollView;
import android.widget.Button;
import android.view.View;

public class MainActivity extends Activity {
	
	
	private LinearLayout linear1;
	private LinearLayout linear18;
	private LinearLayout linear33;
	private LinearLayout linear36;
	private LinearLayout linear2;
	private ImageView imageview6;
	private TextView textview6;
	private ImageView imageview7;
	private ImageView imageview8;
	private ImageView imageview9;
	private ImageView imageview10;
	private LinearLayout linear24;
	private LinearLayout linear25;
	private LinearLayout linear26;
	private TextView textview7;
	private TextView textview9;
	private TextView textview8;
	private LinearLayout linear28;
	private LinearLayout linear34;
	private LinearLayout linear27;
	private LinearLayout linear3;
	private LinearLayout linear19;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private ImageView imageview13;
	private ImageView imageview12;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear7;
	private TextView textview1;
	private LinearLayout linear9;
	private LinearLayout linear8;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private LinearLayout linear17;
	private ImageView imageview1;
	private TextView textview2;
	private ImageView imageview2;
	private TextView textview3;
	private ImageView imageview5;
	private TextView textview4;
	private ImageView imageview3;
	private TextView textview5;
	private LinearLayout linear35;
	private ImageView imageview16;
	private LinearLayout linear37;
	private ImageView imageview14;
	private TextView textview10;
	private LinearLayout linear39;
	private Button executar;
	private ImageView imageview15;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		linear33 = (LinearLayout) findViewById(R.id.linear33);
		linear36 = (LinearLayout) findViewById(R.id.linear36);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		textview6 = (TextView) findViewById(R.id.textview6);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		imageview8 = (ImageView) findViewById(R.id.imageview8);
		imageview9 = (ImageView) findViewById(R.id.imageview9);
		imageview10 = (ImageView) findViewById(R.id.imageview10);
		linear24 = (LinearLayout) findViewById(R.id.linear24);
		linear25 = (LinearLayout) findViewById(R.id.linear25);
		linear26 = (LinearLayout) findViewById(R.id.linear26);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview9 = (TextView) findViewById(R.id.textview9);
		textview8 = (TextView) findViewById(R.id.textview8);
		linear28 = (LinearLayout) findViewById(R.id.linear28);
		linear34 = (LinearLayout) findViewById(R.id.linear34);
		linear27 = (LinearLayout) findViewById(R.id.linear27);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		linear21 = (LinearLayout) findViewById(R.id.linear21);
		imageview13 = (ImageView) findViewById(R.id.imageview13);
		imageview12 = (ImageView) findViewById(R.id.imageview12);
		hscroll1 = (HorizontalScrollView) findViewById(R.id.hscroll1);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview4 = (TextView) findViewById(R.id.textview4);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview5 = (TextView) findViewById(R.id.textview5);
		linear35 = (LinearLayout) findViewById(R.id.linear35);
		imageview16 = (ImageView) findViewById(R.id.imageview16);
		linear37 = (LinearLayout) findViewById(R.id.linear37);
		imageview14 = (ImageView) findViewById(R.id.imageview14);
		textview10 = (TextView) findViewById(R.id.textview10);
		linear39 = (LinearLayout) findViewById(R.id.linear39);
		executar = (Button) findViewById(R.id.executar);
		imageview15 = (ImageView) findViewById(R.id.imageview15);
		
		executar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
	}
	private void initializeLogic() {
		android.graphics.drawable.GradientDrawable CHGHDCJ = new android.graphics.drawable.GradientDrawable();
		CHGHDCJ.setColor(Color.parseColor("#FF2196F3"));
		CHGHDCJ.setCornerRadii(new float[] { 5, 5, 5, 5, 5, 5, 5, 5 });
		executar.setBackground(CHGHDCJ);
		android.graphics.drawable.GradientDrawable CEGEFAD = new android.graphics.drawable.GradientDrawable();
		CEGEFAD.setColor(Color.parseColor("#FFFFFFFF"));
		CEGEFAD.setCornerRadii(new float[] { 5, 5, 5, 5, 5, 5, 5, 5 });
		linear8.setBackground(CEGEFAD);
		if(Build.VERSION.SDK_INT >= 21) { linear8.setElevation(4f); }
		android.graphics.drawable.GradientDrawable GBBGEEH = new android.graphics.drawable.GradientDrawable();
		GBBGEEH.setColor(Color.parseColor("#FFFFFFFF"));
		GBBGEEH.setCornerRadii(new float[] { 5, 5, 5, 5, 5, 5, 5, 5 });
		linear12.setBackground(GBBGEEH);
		if(Build.VERSION.SDK_INT >= 21) { linear12.setElevation(4f); }
		android.graphics.drawable.GradientDrawable IAJGBCB = new android.graphics.drawable.GradientDrawable();
		IAJGBCB.setColor(Color.parseColor("#FFFFFFFF"));
		IAJGBCB.setCornerRadii(new float[] { 5, 5, 5, 5, 5, 5, 5, 5 });
		linear14.setBackground(IAJGBCB);
		if(Build.VERSION.SDK_INT >= 21) { linear14.setElevation(4f); }
		android.graphics.drawable.GradientDrawable ECAGAEJ = new android.graphics.drawable.GradientDrawable();
		ECAGAEJ.setColor(Color.parseColor("#FFFFFFFF"));
		ECAGAEJ.setCornerRadii(new float[] { 5, 5, 5, 5, 5, 5, 5, 5 });
		linear17.setBackground(ECAGAEJ);
		if(Build.VERSION.SDK_INT >= 21) { linear17.setElevation(4f); }
		android.graphics.drawable.GradientDrawable GCIECAF = new android.graphics.drawable.GradientDrawable();
		GCIECAF.setColor(Color.parseColor("#FF1976D2"));
		GCIECAF.setCornerRadii(new float[] { 12, 12, 12, 12, 0, 0, 0, 0 });
		linear20.setBackground(GCIECAF);
		android.graphics.drawable.GradientDrawable CHCAGAH = new android.graphics.drawable.GradientDrawable();
		CHCAGAH.setColor(Color.parseColor("#FFCFD8DC"));
		CHCAGAH.setCornerRadii(new float[] { 12, 12, 12, 12, 0, 0, 0, 0 });
		linear21.setBackground(CHCAGAH);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
