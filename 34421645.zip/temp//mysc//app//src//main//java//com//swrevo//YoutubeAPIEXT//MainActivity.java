package com.swrevo.YoutubeAPIEXT;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.utils.YouTubePlayerUtils;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.view.View;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerFullScreenListener;
import androidx.core.content.ContextCompat;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
	
	
	private HashMap<String, Object> map = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> lm = new ArrayList<>();
	
	private LinearLayout linear1;
	private YouTubePlayerView youtubeplayer1;
	private LinearLayout linear2;
	private ListView listview1;
	private Button button1;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		youtubeplayer1 = (YouTubePlayerView) findViewById(R.id.youtubeplayer1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		listview1 = (ListView) findViewById(R.id.listview1);
		button1 = (Button) findViewById(R.id.button1);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				listview1.setAdapter(new Listview1Adapter(lm));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
		});
	}
	private void initializeLogic() {
		getLifecycle().addObserver(youtubeplayer1);
		initPictureInPicture(youtubeplayer1);
		youtubeplayer1.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
			  @Override
			  public void onReady(@NonNull YouTubePlayer youTubePlayer) {
				    String videoId = "NZWnWQrwiJE";
				    youTubePlayer.cueVideo(videoId, 0);
				    addFullScreenListenerToPlayer();
				  }
		});
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("id", "OOFVyL4_b9g");
			lm.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("id", "-T79Dg5Bn04");
			lm.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("id", "q2aRphxa6eA");
			lm.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("id", "y-ijfXlpKkw");
			lm.add(_item);
		}
		
		
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (youtubeplayer1.isFullScreen()) {
			youtubeplayer1.exitFullScreen();
			SketchwareUtil.showMessage(getApplicationContext(), "Exit From Full Screen");
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "Exit App");
			finish();
		}
	}
	private void _ClassExternal1 () {
	}
	public class FullScreenHelper {
		
		    private Activity context;
		    private View[] views;
		
		    /**
     * @param context
     * @param views to hide/show
     */
		    public FullScreenHelper(Activity context, View ... views) {
			        this.context = context;
			        this.views = views;
			    }
		
		    /**
     * call this method to enter full screen
     */
		    public void enterFullScreen() {
			        View decorView = context.getWindow().getDecorView();
			
			        hideSystemUi(decorView);
			
			        for(View view : views) {
				            view.setVisibility(View.GONE);
				            view.invalidate();
				        }
			    }
		
		    /**
     * call this method to exit full screen
     */
		    public void exitFullScreen() {
			        View decorView = context.getWindow().getDecorView();
			
			        showSystemUi(decorView);
			
			        for(View view : views) {
				            view.setVisibility(View.VISIBLE);
				            view.invalidate();
				        }
			    }
		
		    private void hideSystemUi(View mDecorView) {
			        mDecorView.setSystemUiVisibility(
			                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
			                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
			                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
			                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
			                        | View.SYSTEM_UI_FLAG_FULLSCREEN
			                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
			    }
		
		    private void showSystemUi(View mDecorView) {
			        mDecorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
			    }
	}
	{
	}
	
	
	private void _ListenerFullScreen () {
	}
	
	private FullScreenHelper fullScreenHelper = new FullScreenHelper(MainActivity.this);
	
	    private void addFullScreenListenerToPlayer() {
		        youtubeplayer1.addFullScreenListener(new YouTubePlayerFullScreenListener() {
			            @Override
			            public void onYouTubePlayerEnterFullScreen() {
				                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
				                fullScreenHelper.enterFullScreen();
				
				                
				            }
			
			            @Override
			            public void onYouTubePlayerExitFullScreen() {
				                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
				                fullScreenHelper.exitFullScreen();
				
				                
				            }
			        });
		    }
	{
	}
	
	
	private void _PictureInPicture () {
	}
	private void initPictureInPicture(YouTubePlayerView youTubePlayerView) {
		        ImageView pictureInPictureIcon = new ImageView(this);
		        pictureInPictureIcon.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_picture_in_picture_white));
		
		        pictureInPictureIcon.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
				
									if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
											boolean supportsPIP = getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE);
											if(supportsPIP)
												enterPictureInPictureMode();
									} else {
											new AlertDialog.Builder(MainActivity.this)
												.setTitle("Can't enter picture in picture mode")
												.setMessage("In order to enter picture in picture mode you need a SDK version >= N.")
												.show();
									}
							}
			
					});
		
		        youTubePlayerView.getPlayerUiController().addView(pictureInPictureIcon);
		    }
	
	
	@Override
	    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, Configuration newConfig) {
		        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig);
		
		        if(isInPictureInPictureMode) {
			            youtubeplayer1.enterFullScreen();
			            youtubeplayer1.getPlayerUiController().showUi(false);
			        } else {
			            youtubeplayer1.exitFullScreen();
			            youtubeplayer1.getPlayerUiController().showUi(true);
			        }
		    }
	
	
	{
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.cus_v, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			
			
			final YouTubePlayerView youtubeplayer1 = _v.findViewById(R.id.youtubeplayer1);
			getLifecycle().addObserver(youtubeplayer1);
			youtubeplayer1.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
				  @Override
				  public void onReady(@NonNull YouTubePlayer youTubePlayer) {
					    String videoId = _data.get((int)_position).get("id").toString();
					    youTubePlayer.cueVideo(videoId, 0);
					     
					  }
			});
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
