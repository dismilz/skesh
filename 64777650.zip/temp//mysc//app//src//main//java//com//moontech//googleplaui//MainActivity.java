package com.moontech.googleplaui;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.HorizontalScrollView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;
import android.graphics.Typeface;

public class MainActivity extends Activity {
	
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear32;
	private LinearLayout bottom;
	private LinearLayout menubg;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear19;
	private EditText edittext1;
	private LinearLayout linear20;
	private ImageView imageview3;
	private ImageView imageview1;
	private ImageView imageview2;
	private LinearLayout linear5;
	private LinearLayout m1;
	private LinearLayout m2;
	private LinearLayout m3;
	private LinearLayout m4;
	private LinearLayout linear24;
	private LinearLayout slider1;
	private TextView t1;
	private LinearLayout linear23;
	private LinearLayout slider2;
	private TextView t2;
	private LinearLayout linear25;
	private LinearLayout slider3;
	private TextView t3;
	private LinearLayout linear26;
	private LinearLayout slider4;
	private TextView t4;
	private LinearLayout linear31;
	private LinearLayout linear21;
	private LinearLayout l1;
	private LinearLayout l2;
	private LinearLayout l3;
	private LinearLayout l4;
	private ImageView g1;
	private TextView b1;
	private ImageView g2;
	private TextView b2;
	private ImageView g3;
	private TextView b3;
	private ImageView g4;
	private TextView b4;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear32 = (LinearLayout) findViewById(R.id.linear32);
		bottom = (LinearLayout) findViewById(R.id.bottom);
		menubg = (LinearLayout) findViewById(R.id.menubg);
		hscroll1 = (HorizontalScrollView) findViewById(R.id.hscroll1);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		m1 = (LinearLayout) findViewById(R.id.m1);
		m2 = (LinearLayout) findViewById(R.id.m2);
		m3 = (LinearLayout) findViewById(R.id.m3);
		m4 = (LinearLayout) findViewById(R.id.m4);
		linear24 = (LinearLayout) findViewById(R.id.linear24);
		slider1 = (LinearLayout) findViewById(R.id.slider1);
		t1 = (TextView) findViewById(R.id.t1);
		linear23 = (LinearLayout) findViewById(R.id.linear23);
		slider2 = (LinearLayout) findViewById(R.id.slider2);
		t2 = (TextView) findViewById(R.id.t2);
		linear25 = (LinearLayout) findViewById(R.id.linear25);
		slider3 = (LinearLayout) findViewById(R.id.slider3);
		t3 = (TextView) findViewById(R.id.t3);
		linear26 = (LinearLayout) findViewById(R.id.linear26);
		slider4 = (LinearLayout) findViewById(R.id.slider4);
		t4 = (TextView) findViewById(R.id.t4);
		linear31 = (LinearLayout) findViewById(R.id.linear31);
		linear21 = (LinearLayout) findViewById(R.id.linear21);
		l1 = (LinearLayout) findViewById(R.id.l1);
		l2 = (LinearLayout) findViewById(R.id.l2);
		l3 = (LinearLayout) findViewById(R.id.l3);
		l4 = (LinearLayout) findViewById(R.id.l4);
		g1 = (ImageView) findViewById(R.id.g1);
		b1 = (TextView) findViewById(R.id.b1);
		g2 = (ImageView) findViewById(R.id.g2);
		b2 = (TextView) findViewById(R.id.b2);
		g3 = (ImageView) findViewById(R.id.g3);
		b3 = (TextView) findViewById(R.id.b3);
		g4 = (ImageView) findViewById(R.id.g4);
		b4 = (TextView) findViewById(R.id.b4);
		
		m1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_TransitionManager(linear1, 300);
				slider1.setVisibility(View.VISIBLE);
				slider2.setVisibility(View.GONE);
				slider3.setVisibility(View.GONE);
				slider4.setVisibility(View.GONE);
				t1.setTextColor(0xFF2E7D32);
				t2.setTextColor(0xFF424242);
				t3.setTextColor(0xFF424242);
				t4.setTextColor(0xFF424242);
			}
		});
		
		m2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_TransitionManager(linear1, 300);
				slider1.setVisibility(View.GONE);
				slider2.setVisibility(View.VISIBLE);
				slider3.setVisibility(View.GONE);
				slider4.setVisibility(View.GONE);
				t1.setTextColor(0xFF424242);
				t2.setTextColor(0xFF2E7D32);
				t3.setTextColor(0xFF424242);
				t4.setTextColor(0xFF424242);
			}
		});
		
		m3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_TransitionManager(linear1, 300);
				slider1.setVisibility(View.GONE);
				slider2.setVisibility(View.GONE);
				slider3.setVisibility(View.VISIBLE);
				slider4.setVisibility(View.GONE);
				t1.setTextColor(0xFF424242);
				t2.setTextColor(0xFF424242);
				t3.setTextColor(0xFF2E7D32);
				t4.setTextColor(0xFF424242);
			}
		});
		
		m4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_TransitionManager(linear1, 300);
				slider1.setVisibility(View.GONE);
				slider2.setVisibility(View.GONE);
				slider3.setVisibility(View.GONE);
				slider4.setVisibility(View.VISIBLE);
				t1.setTextColor(0xFF424242);
				t2.setTextColor(0xFF424242);
				t3.setTextColor(0xFF424242);
				t4.setTextColor(0xFF2E7D32);
			}
		});
		
		l1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_TransitionManager(bottom, 300);
				g1.setImageResource(R.drawable.gamepad);
				g2.setImageResource(R.drawable.allapps);
				g3.setImageResource(R.drawable.camerafilm);
				g4.setImageResource(R.drawable.book);
				b1.setTextColor(0xFF2E7D32);
				b2.setTextColor(0xFF424242);
				b3.setTextColor(0xFF424242);
				b4.setTextColor(0xFF424242);
				g1.setColorFilter(0xFF2E7D32, PorterDuff.Mode.MULTIPLY);
				g2.setColorFilter(0xFF424242, PorterDuff.Mode.MULTIPLY);
				g3.setColorFilter(0xFF424242, PorterDuff.Mode.MULTIPLY);
				g4.setColorFilter(0xFF424242, PorterDuff.Mode.MULTIPLY);
			}
		});
		
		l2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_TransitionManager(bottom, 300);
				g1.setImageResource(R.drawable.technology);
				g2.setImageResource(R.drawable.allappsclick);
				g3.setImageResource(R.drawable.camerafilm);
				g4.setImageResource(R.drawable.book);
				b1.setTextColor(0xFF424242);
				b2.setTextColor(0xFF2E7D32);
				b3.setTextColor(0xFF424242);
				b4.setTextColor(0xFF424242);
				g1.setColorFilter(0xFF424242, PorterDuff.Mode.MULTIPLY);
				g2.setColorFilter(0xFF2E7D32, PorterDuff.Mode.MULTIPLY);
				g3.setColorFilter(0xFF424242, PorterDuff.Mode.MULTIPLY);
				g4.setColorFilter(0xFF424242, PorterDuff.Mode.MULTIPLY);
			}
		});
		
		l3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_TransitionManager(bottom, 300);
				g1.setImageResource(R.drawable.technology);
				g2.setImageResource(R.drawable.allapps);
				g3.setImageResource(R.drawable.filmstrip);
				g4.setImageResource(R.drawable.book);
				b1.setTextColor(0xFF424242);
				b2.setTextColor(0xFF424242);
				b3.setTextColor(0xFFC62828);
				b4.setTextColor(0xFF424242);
				g1.setColorFilter(0xFF424242, PorterDuff.Mode.MULTIPLY);
				g2.setColorFilter(0xFF424242, PorterDuff.Mode.MULTIPLY);
				g3.setColorFilter(0xFFC62828, PorterDuff.Mode.MULTIPLY);
				g4.setColorFilter(0xFF424242, PorterDuff.Mode.MULTIPLY);
			}
		});
		
		l4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_TransitionManager(bottom, 300);
				g1.setImageResource(R.drawable.technology);
				g2.setImageResource(R.drawable.allapps);
				g3.setImageResource(R.drawable.camerafilm);
				g4.setImageResource(R.drawable.education);
				b1.setTextColor(0xFF424242);
				b2.setTextColor(0xFF424242);
				b3.setTextColor(0xFF424242);
				b4.setTextColor(0xFF1565C0);
				g1.setColorFilter(0xFF424242, PorterDuff.Mode.MULTIPLY);
				g2.setColorFilter(0xFF424242, PorterDuff.Mode.MULTIPLY);
				g3.setColorFilter(0xFF424242, PorterDuff.Mode.MULTIPLY);
				g4.setColorFilter(0xFF1565C0, PorterDuff.Mode.MULTIPLY);
			}
		});
	}
	private void initializeLogic() {
		linear1.setElevation(8f);
		_removeScollBar(hscroll1);
		slider1.setVisibility(View.VISIBLE);
		slider2.setVisibility(View.GONE);
		slider3.setVisibility(View.GONE);
		slider4.setVisibility(View.GONE);
		_Menu();
		_Font();
		_ClickEffect();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _SX_CornerRadius_4 (final View _view, final String _color1, final String _color2, final double _str, final double _n1, final double _n2, final double _n3, final double _n4) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		
		gd.setColor(Color.parseColor(_color1));
		
		gd.setStroke((int)_str, Color.parseColor(_color2));
		
		gd.setCornerRadii(new float[]{(int)_n1,(int)_n1,(int)_n2,(int)_n2,(int)_n3,(int)_n3,(int)_n4,(int)_n4});
		
		_view.setBackground(gd);
		
		_view.setElevation(8);
	}
	
	
	private void _Menu () {
		_CardStyle(menubg, 8, 15, "#ffffff", true);
		_SX_CornerRadius_4(slider1, "#2E7D32", "#2E7D32", 0, 10, 10, 0, 0);
		_SX_CornerRadius_4(slider2, "#2E7D32", "#2E7D32", 0, 10, 10, 0, 0);
		_SX_CornerRadius_4(slider3, "#2E7D32", "#2E7D32", 0, 10, 10, 0, 0);
		_SX_CornerRadius_4(slider4, "#2E7D32", "#2E7D32", 0, 10, 10, 0, 0);
	}
	
	
	private void _CardStyle (final View _view, final double _shadow, final double _radius, final String _color, final boolean _touch) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_radius);
		android.graphics.drawable.RippleDrawable re = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor("#f44336")}), null, null);
		_view.setBackground(gd);
		
		if (Build.VERSION.SDK_INT >= 21){
			_view.setElevation((int)_shadow);}
	}
	
	
	private void _Font () {
		edittext1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google.ttf"), 1);
		t1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google.ttf"), 0);
		t2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google.ttf"), 0);
		t3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google.ttf"), 0);
		t4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google.ttf"), 0);
		b1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google.ttf"), 0);
		b2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google.ttf"), 0);
		b3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google.ttf"), 0);
		b4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google.ttf"), 0);
	}
	
	
	private void _removeScollBar (final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	private void _TransitionManager (final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	private void _ClickEffect () {
		_click_effect(m1, "#e0e0e0");
		_click_effect(m2, "#e0e0e0");
		_click_effect(m3, "#e0e0e0");
		_click_effect(m4, "#e0e0e0");
		_click_effect(l1, "#e0e0e0");
		_click_effect(l2, "#e0e0e0");
		_click_effect(l3, "#e0e0e0");
		_click_effect(l4, "#e0e0e0");
		_click_effect(linear19, "#e0e0e0");
	}
	
	
	private void _click_effect (final View _view, final String _c) {
		_view.setBackground(Drawables.getSelectableDrawableFor(Color.parseColor(_c)));
		_view.setClickable(true);
		
	}
	
	public static class Drawables {
		    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {
			        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
				            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_pressed},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_focused},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            return stateListDrawable;
				        } else {
				            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);
				            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"));
				            
				android.graphics.drawable.Drawable rippleColor = getRippleColor(color);
				            return new android.graphics.drawable.RippleDrawable(
				                pressedColor,
				                defaultColor,
				                rippleColor
				            );
				        }
			    }
		
		    private static android.graphics.drawable.Drawable getRippleColor(int color) {
			        float[] outerRadii = new float[100];
			        Arrays.fill(outerRadii, 10);
			        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);
			        
			android.graphics.drawable.ShapeDrawable shapeDrawable = new 
			android.graphics.drawable.ShapeDrawable(r);
			        shapeDrawable.getPaint().setColor(color);
			        return shapeDrawable;
			    }
		 
		    private static int lightenOrDarken(int color, double fraction) {
			        if (canLighten(color, fraction)) {
				            return lighten(color, fraction);
				        } else {
				            return darken(color, fraction);
				        }
			    }
		 
		    private static int lighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = lightenColor(red, fraction);
			        green = lightenColor(green, fraction);
			        blue = lightenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static int darken(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = darkenColor(red, fraction);
			        green = darkenColor(green, fraction);
			        blue = darkenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			 
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static boolean canLighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        return canLightenComponent(red, fraction)
			            && canLightenComponent(green, fraction)
			            && canLightenComponent(blue, fraction);
			    }
		 
		    private static boolean canLightenComponent(int colorComponent, double fraction) {
			        int red = Color.red(colorComponent);
			        int green = Color.green(colorComponent);
			        int blue = Color.blue(colorComponent);
			        return red + (red * fraction) < 255
			            && green + (green * fraction) < 255
			            && blue + (blue * fraction) < 255;
			    }
		 
		    private static int darkenColor(int color, double fraction) {
			        return (int) Math.max(color - (color * fraction), 10);
			    }
		 
		    private static int lightenColor(int color, double fraction) {
			        return (int) Math.min(color + (color * fraction), 255);
			    }
	}
	public static class CircleDrawables {
		    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {
			        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
				            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_pressed},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_focused},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            return stateListDrawable;
				        } else {
				            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);
				            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"));
				            
				android.graphics.drawable.Drawable rippleColor = getRippleColor(color);
				            return new android.graphics.drawable.RippleDrawable(
				                pressedColor,
				                defaultColor,
				                rippleColor
				            );
				        }
			    }
		
		    private static android.graphics.drawable.Drawable getRippleColor(int color) {
			        float[] outerRadii = new float[180];
			        Arrays.fill(outerRadii, 10);
			        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);
			        
			android.graphics.drawable.ShapeDrawable shapeDrawable = new 
			android.graphics.drawable.ShapeDrawable(r);
			        shapeDrawable.getPaint().setColor(color);
			        return shapeDrawable;
			    }
		 
		    private static int lightenOrDarken(int color, double fraction) {
			        if (canLighten(color, fraction)) {
				            return lighten(color, fraction);
				        } else {
				            return darken(color, fraction);
				        }
			    }
		 
		    private static int lighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = lightenColor(red, fraction);
			        green = lightenColor(green, fraction);
			        blue = lightenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static int darken(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = darkenColor(red, fraction);
			        green = darkenColor(green, fraction);
			        blue = darkenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			 
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static boolean canLighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        return canLightenComponent(red, fraction)
			            && canLightenComponent(green, fraction)
			            && canLightenComponent(blue, fraction);
			    }
		 
		    private static boolean canLightenComponent(int colorComponent, double fraction) {
			        int red = Color.red(colorComponent);
			        int green = Color.green(colorComponent);
			        int blue = Color.blue(colorComponent);
			        return red + (red * fraction) < 255
			            && green + (green * fraction) < 255
			            && blue + (blue * fraction) < 255;
			    }
		 
		    private static int darkenColor(int color, double fraction) {
			        return (int) Math.max(color - (color * fraction), 10);
			    }
		 
		    private static int lightenColor(int color, double fraction) {
			        return (int) Math.min(color + (color * fraction), 255);
		}
	}
	
	public void drawableclass() {
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
