package com.edream.jcrbusqueda;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.AdapterView;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends Activity {
	
	
	private double contador = 0;
	private String contenido = "";
	private double p = 0;
	private double u = 0;
	private double anterior = 0;
	private String mipuntero = "";
	
	private ArrayList<String> list = new ArrayList<>();
	
	private ImageView imfondo;
	private TextView txtencontrado;
	private ListView listview1;
	private LinearLayout linear1;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		imfondo = (ImageView) findViewById(R.id.imfondo);
		txtencontrado = (TextView) findViewById(R.id.txtencontrado);
		listview1 = (ListView) findViewById(R.id.listview1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				txtencontrado.setText(list.get((int)(_position)).replace(";", ""));
				FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/edream/datos/auxdato.txt"), mipuntero.replace(" ; ", ";").toUpperCase());
			}
		});
	}
	private void initializeLogic() {
		if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/edream/datos/cobrogrande.txt"))) {
			contador = 1;
			contenido = FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/edream/datos/cobrogrande.txt"));
			p = 0;
			u = 1;
			anterior = 0;
			if (contenido.length() > 0) {
				for(int _repeat26 = 0; _repeat26 < (int)((contenido.length() - 1)); _repeat26++) {
					if (contenido.substring((int)(p), (int)(u)).equals("\n")) {
						list.add(contenido.substring((int)(anterior), (int)(p + -1)).replace(";", " ; "));
						anterior = p + 1;
						contador++;
					}
					p++;
					u++;
				}
				list.add(contenido.substring((int)(anterior), (int)(contenido.length())).replace(";", " ; "));
			}
		}
		else {
			FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/edream"));
			FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/edream/datos"));
			FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/edream/datos/cobrogrande.txt"), "edream;1000;necesita cargar datos\n\n");
			SketchwareUtil.showMessage(getApplicationContext(), "Archivos Creados Vuelva");
			finish();
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _extra () {
		
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
