package com.Dictionary.v2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ImageView;
import android.app.Activity;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Context;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.AdapterView;
import android.view.View;
import android.graphics.Typeface;
import android.content.ClipData;
import android.content.ClipboardManager;

public class MainActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	private FloatingActionButton _fab;
	private double a = 0;
	private double vis = 0;
	
	private ArrayList<String> list = new ArrayList<>();
	
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linearedit;
	private ListView listview2;
	private EditText edittext2;
	private TextView textview3;
	private TextView textview4;
	private LinearLayout linear7;
	private ImageView imageview1;
	
	private SharedPreferences f;
	private AlertDialog.Builder D;
	private Vibrator V;
	private TextToSpeech ttp;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_fab = (FloatingActionButton) findViewById(R.id._fab);
		
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linearedit = (LinearLayout) findViewById(R.id.linearedit);
		listview2 = (ListView) findViewById(R.id.listview2);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		f = getSharedPreferences("f", Activity.MODE_PRIVATE);
		D = new AlertDialog.Builder(this);
		V = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		ttp = new TextToSpeech(getApplicationContext(), null);
		
		listview2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				//show fab
				_fab.setVisibility(View.VISIBLE);
				final ObjectAnimator animator = ObjectAnimator.ofInt(_fab, "backgroundTint", Color.rgb(0, 121, 107), Color.rgb(23, 169, 191));
				animator.setDuration(2000L);
				animator.setEvaluator(new ArgbEvaluator());
				animator.setInterpolator(new DecelerateInterpolator(2));
				animator.addUpdateListener(new ObjectAnimator.AnimatorUpdateListener() {
					    @Override
					    public void onAnimationUpdate(ValueAnimator animation) {
						        int animatedValue = (int) animation.getAnimatedValue();
						        _fab.setBackgroundTintList(android.content.res.ColorStateList.valueOf(animatedValue));
						    }
				});
				animator.start();
				vis = 0;
				linear6.setVisibility(View.VISIBLE);
				linear5.setVisibility(View.GONE);
				textview3.setText(list.get((int)(_position)));
				textview4.setText(f.getString(list.get((int)(_position)), ""));
			}
		});
		
		edittext2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				//hide fab
				_fab.setVisibility(View.GONE);
				list.clear();
				a = 0;
				while(true) {
					if (f.getString(String.valueOf((long)(a)), "").equals("")) {
						break;
					}
					else {
						if (_charSeq.length() > f.getString(String.valueOf((long)(a)), "").length()) {
							
						}
						else {
							if (f.getString(String.valueOf((long)(a)), "").substring((int)(0), (int)(_charSeq.length())).toLowerCase().contains(_charSeq.toLowerCase())) {
								list.add(f.getString(String.valueOf((long)(a)), ""));
							}
						}
						a++;
					}
				}
				listview2.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_list_item_1, list));
				((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				V.vibrate((long)(100));
				SketchwareUtil.showMessage(getApplicationContext(), "Play Sound🔊");
				ttp.speak(textview3.getText().toString().concat(textview4.getText().toString()), TextToSpeech.QUEUE_ADD, null);
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview4.getText().toString()));
				SketchwareUtil.showMessage(getApplicationContext(), "Copied");
				final ObjectAnimator animator = ObjectAnimator.ofInt(_fab, "backgroundTint", Color.rgb(0, 121, 107), Color.rgb(67, 194, 25));
				animator.setDuration(2000L);
				animator.setEvaluator(new ArgbEvaluator());
				animator.setInterpolator(new DecelerateInterpolator(2));
				animator.addUpdateListener(new ObjectAnimator.AnimatorUpdateListener() {
					    @Override
					    public void onAnimationUpdate(ValueAnimator animation) {
						        int animatedValue = (int) animation.getAnimatedValue();
						        _fab.setBackgroundTintList(android.content.res.ColorStateList.valueOf(animatedValue));
						    }
				});
				animator.start();
			}
		});
	}
	private void initializeLogic() {
		//hide fab
		_fab.setVisibility(View.GONE);
		final ObjectAnimator animator = ObjectAnimator.ofInt(_fab, "backgroundTint", Color.rgb(0, 121, 107), Color.rgb(23, 169, 191));
		animator.setDuration(2000L);
		animator.setEvaluator(new ArgbEvaluator());
		animator.setInterpolator(new DecelerateInterpolator(2));
		animator.addUpdateListener(new ObjectAnimator.AnimatorUpdateListener() {
			    @Override
			    public void onAnimationUpdate(ValueAnimator animation) {
				        int animatedValue = (int) animation.getAnimatedValue();
				        _fab.setBackgroundTintList(android.content.res.ColorStateList.valueOf(animatedValue));
				    }
		});
		animator.start();
		vis = 1;
		linear5.setVisibility(View.VISIBLE);
		linear6.setVisibility(View.GONE);
		if (f.getString("-1", "").equals("")) {
			_words();
			f.edit().putString("-1", "-1").commit();
		}
		else {
			
		}
		list.clear();
		a = 0;
		while(true) {
			if (f.getString(String.valueOf((long)(a)), "").equals("")) {
				break;
			}
			else {
				if (f.getString(String.valueOf((long)(a)), "").length() > 0) {
					list.add(f.getString(String.valueOf((long)(a)), ""));
				}
				a++;
			}
		}
		
		((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor("#FFFFFF"));
		gd.setCornerRadius(25);
		linearedit.setBackground(gd);
		//App Developed by 
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (vis == 0) {
			vis = 1;
			linear6.setVisibility(View.GONE);
			linear5.setVisibility(View.VISIBLE);
			edittext2.setText("");
			ttp.stop();
		}
		else {
			D.setTitle("EXIT");
			D.setMessage("Are You Sure Want To Exit ?");
			D.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					finish();
				}
			});
			D.setNegativeButton("No", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					
				}
			});
			D.create().show();
		}
	}
	private void _words () {
		_Add(0, "Abandon", "verb (used with object)\n\nto leave completely and finally; forsake utterly; desert:to abandon one's farm; to abandon a child; to abandon a sinking ship.");
		_Add(1, "Able", "adjective, a·bler, a·blest.\n\nhaving necessary power, skill, resources, or qualifications; qualified:able to lift a two-hundred-pound weight; able to write music; able to travel widely; able to vote.");
		_Add(2, "about", "preposition\n\nof; concerning; in regard to:instructions about the work; a book about the Civil War.");
		_Add(3, "accept", "verb (used with object)\n\nto take or receive (something offered); receive with approval or favor:to accept a present; to accept a proposal.");
		_Add(4, "Accident", "noun\n\nan undesirable or unfortunate happening that occurs unintentionally and usually results in harm, injury, damage, or loss; casualty; mishap:automobile accidents.");
		_Add(5, "account", "noun\n\nan oral or written description of particular events or situations; narrative:an account of the meetings; an account of the trip.");
		_Add(6, "address", "noun\n\na speech or written statement, usually formal, directed to a particular group of persons:the president's address on the state of the economy.");
		_Add(7, "breathe", "verb (used without object), breathed  [breethd] , breath·ing.\n\nto take air, oxygen, etc., into the lungs and expel it; inhale and exhale; respire.");
		_Add(8, "brick", "noun\n\na block of clay hardened by drying in the sun or burning in a kiln, and used for building, paving, etc.: traditionally, in the U.S., a rectangle 2.25 × 3.75 × 8 inches (5.7 × 9.5 × 20.3 cm), red, brown, or yellow in color.");
		_Add(9, "bus", "noun, plural bus·es, bus·ses.\n\na large motor vehicle, having a long body, equipped with seats or benches for passengers, usually operating as part of a scheduled service; omnibus.");
		_Add(10, "cake", "noun\n\na sweet, baked, breadlike food, made with or without shortening, and usually containing flour, sugar, baking powder or soda, eggs, and liquid flavoring.");
		_Add(11, "camp", "noun\n\na place where an army or other group of persons or an individual is lodged in a tent or tents or other temporary means of shelter.");
		_Add(12, "aim", "verb (used with object)\n\nto position or direct (a firearm, ball, arrow, rocket, etc.) so that, on firing or release, the discharged projectile will hit a target or travel along a certain path.");
		_Add(13, "offer", "verb (used with object)\n\nto present for acceptance or rejection; proffer:He offered me a cigarette.");
	}
	
	
	private void _Add (final double _pos, final String _word, final String _meaning) {
		f.edit().putString(String.valueOf((long)(_pos)), _word).commit();
		f.edit().putString(_word, _meaning).commit();
	}
	
	
	public class Listview2Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.custom, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/default_font.ttf"), 1);
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
