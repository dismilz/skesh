package com.crn.rona;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;
import android.content.SharedPreferences;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import android.graphics.Typeface;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private HashMap<String, Object> crn = new HashMap<>();
	private String jsonstring1 = "";
	private String fontName = "";
	private String typeace = "";
	private boolean dismiss = false;
	private HashMap<String, Object> mip = new HashMap<>();
	private double searchnum = 0;
	private HashMap<String, Object> iu = new HashMap<>();
	private double len = 0;
	private double N = 0;
	private double n = 0;
	private boolean connected = false;
	private String recovered = "";
	private HashMap<String, Object> test = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> map = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> side = new ArrayList<>();
	private ArrayList<String> cr = new ArrayList<>();
	
	private LinearLayout linear10;
	private LinearLayout linear13;
	private ListView listview1;
	private LinearLayout linear19;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private ImageView imageview1;
	private EditText edittext1;
	private TextView textview3;
	private LinearLayout linear14;
	private LinearLayout linear16;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private TextView textview5;
	private TextView textview4;
	private TextView textview7;
	private TextView textview6;
	private TextView textview9;
	private TextView textview8;
	private LinearLayout linear21;
	private LinearLayout linear20;
	private TextView textview10;
	private TextView textview11;
	private Button button1;
	
	private RequestNetwork r;
	private RequestNetwork.RequestListener _r_request_listener;
	private Intent go = new Intent();
	private TimerTask timer;
	private RequestNetwork all;
	private RequestNetwork.RequestListener _all_request_listener;
	private SharedPreferences save;
	private TimerTask t;
	private RequestNetwork rec;
	private RequestNetwork.RequestListener _rec_request_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		listview1 = (ListView) findViewById(R.id.listview1);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview9 = (TextView) findViewById(R.id.textview9);
		textview8 = (TextView) findViewById(R.id.textview8);
		linear21 = (LinearLayout) findViewById(R.id.linear21);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		textview10 = (TextView) findViewById(R.id.textview10);
		textview11 = (TextView) findViewById(R.id.textview11);
		button1 = (Button) findViewById(R.id.button1);
		r = new RequestNetwork(this);
		all = new RequestNetwork(this);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		rec = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finishAffinity();
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.length() > 1) {
					n = map.size() - 1;
					len = map.size();
					for(int _repeat30 = 0; _repeat30 < (int)(len); _repeat30++) {
						if (map.get((int)n).get("country").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
							
						}
						else {
							map.remove((int)(n));
						}
						n--;
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
				}
				else {
					r.startRequestNetwork(RequestNetworkController.GET, "https://coronavirus-19-api.herokuapp.com/countries", "a", _r_request_listener);
					all.startRequestNetwork(RequestNetworkController.GET, "https://coronavirus-19-api.herokuapp.com/all", "b", _all_request_listener);
				}
				listview1.setAdapter(new Listview1Adapter(map));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				go.setClass(getApplicationContext(), KnowActivity.class);
				startActivity(go);
			}
		});
		
		_r_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				map = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				listview1.setAdapter(new Listview1Adapter(map));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				dismiss = true;
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/Rona 19"));
				FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/Rona 19/data.json"), new Gson().toJson(map));
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_all_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				mip = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
				textview4.setText(mip.get("cases").toString());
				textview6.setText(mip.get("deaths").toString());
				textview8.setText(mip.get("recovered").toString());
				save.edit().putString("cases", mip.get("cases").toString()).commit();
				save.edit().putString("deaths", mip.get("deaths").toString()).commit();
				save.edit().putString("recovered", mip.get("recovered").toString()).commit();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_rec_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				test = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
				cr.add(test.get("recovered").toString());
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	private void initializeLogic() {
		r.startRequestNetwork(RequestNetworkController.GET, "https://coronavirus-19-api.herokuapp.com/countries", "a", _r_request_listener);
		all.startRequestNetwork(RequestNetworkController.GET, "https://coronavirus-19-api.herokuapp.com/all", "b", _all_request_listener);
		rec.startRequestNetwork(RequestNetworkController.GET, "https://pomber.github.io/covid19/timeseries.json", "a", _rec_request_listener);
		android.graphics.drawable.GradientDrawable CRNFS = new android.graphics.drawable.GradientDrawable();
		CRNFS.setColor(Color.parseColor("#ffffff"));
		CRNFS.setCornerRadii(new float[]{ (float) 20,(float) 20,(float) 20,(float) 20,(float) 20,(float) 20,(float) 20,(float) 20 });
		CRNFS.setStroke((int) 4, Color.parseColor("#ffffff"));
		edittext1.setElevation((float) 5);
		edittext1.setBackground(CRNFS);
		//Milz
		android.graphics.drawable.GradientDrawable CRNWQ = new android.graphics.drawable.GradientDrawable();
		CRNWQ.setColor(Color.parseColor("#2196f3"));
		CRNWQ.setCornerRadii(new float[]{ (float) 21,(float) 21,(float) 21,(float) 21,(float) 21,(float) 21,(float) 21,(float) 21 });
		CRNWQ.setStroke((int) 0, Color.parseColor("#000000"));
		linear16.setElevation((float) 5);
		linear16.setBackground(CRNWQ);
		//Milz
		android.graphics.drawable.GradientDrawable CRNZK = new android.graphics.drawable.GradientDrawable();
		CRNZK.setColor(Color.parseColor("#4ff336"));
		CRNZK.setCornerRadii(new float[]{ (float) 21,(float) 21,(float) 21,(float) 21,(float) 21,(float) 21,(float) 21,(float) 21 });
		CRNZK.setStroke((int) 0, Color.parseColor("#000000"));
		linear17.setElevation((float) 5);
		linear17.setBackground(CRNZK);
		//Milz
		android.graphics.drawable.GradientDrawable CRNXF = new android.graphics.drawable.GradientDrawable();
		CRNXF.setColor(Color.parseColor("#4caf50"));
		CRNXF.setCornerRadii(new float[]{ (float) 21,(float) 21,(float) 21,(float) 21,(float) 21,(float) 21,(float) 21,(float) 21 });
		CRNXF.setStroke((int) 0, Color.parseColor("#000000"));
		linear18.setElevation((float) 5);
		linear18.setBackground(CRNXF);
		//Milz
		android.graphics.drawable.GradientDrawable CRNZE = new android.graphics.drawable.GradientDrawable();
		CRNZE.setColor(Color.parseColor("#4caf50"));
		CRNZE.setCornerRadii(new float[]{ (float) 17,(float) 17,(float) 17,(float) 17,(float) 17,(float) 17,(float) 17,(float) 17 });
		CRNZE.setStroke((int) 0, Color.parseColor("#000000"));
		button1.setElevation((float) 5);
		button1.setBackground(CRNZE);
		//Milz
		_cust_prog("Connecting to server... please wait");
		if (save.getString("recovered", "").equals("")) {
			
		}
		else {
			textview4.setText(save.getString("cases", ""));
			textview6.setText(save.getString("deaths", ""));
			textview8.setText(save.getString("recovered", ""));
		}
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
		textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
		textview9.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 1);
		textview10.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
		textview11.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
		_Shadow(linear13, 4);
		_Shadow(linear19, 4);
		_networkConnected();
		if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/Rona 19/data.json"))) {
			map = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/Rona 19/data.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			listview1.setAdapter(new Listview1Adapter(map));
			((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
		}
		else {
			
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _Shadow (final View _v, final double _n) {
		_v.setElevation((float)_n);
	}
	
	
	private void _changeActivityFont (final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				}
				else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					}
					else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	private void _cust_prog (final String _text) {
		AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this); 
		
		View dialog1 = getLayoutInflater().inflate(R.layout.prog, null); 
		
		alert.setView(dialog1); final AlertDialog dialog = alert.create(); dialog.show();
		dialog.setCancelable(true);
		
		TextView text1 = (TextView)
		dialog1.findViewById(R.id.textview1);
		
		text1.setText(_text);
		
		
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		dialog.getWindow().setBackgroundDrawable(gd);
		gd.setColor(Color.TRANSPARENT);
		dismiss = false;
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (dismiss) {
							dialog.dismiss();
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer, (int)(0), (int)(100));
	}
	
	
	private void _search_word (final String _word, final String _key, final ArrayList<HashMap<String, Object>> _listmap) {
		map.clear();
		if (_word.equals("")) {
			listview1.setAdapter(new Listview1Adapter(map));
			((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
		}
		else {
			searchnum = 0;
			for(int _repeat16 = 0; _repeat16 < (int)(map.size()); _repeat16++) {
				iu = new HashMap<>();
				if (map.get((int)searchnum).get(_key).toString().toLowerCase().contains(_word.toLowerCase())) {
					
				}
				searchnum++;
			}
			listview1.setAdapter(new Listview1Adapter(map));
			((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
		}
	}
	
	
	private void _networkConnected () {
		//Needs RequestNetwork to work!
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		connected = (netInfo != null && netInfo.isConnectedOrConnecting());
		if (connected) {
			
		}
		else {
			if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/Rona 19/data.json"))) {
				SketchwareUtil.showMessage(getApplicationContext(), "Offline mode...");
			}
			else {
				SketchwareUtil.showMessage(getApplicationContext(), "No internet and no data cache");
			}
			dismiss = true;
		}
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.data, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final LinearLayout linear4 = (LinearLayout) _v.findViewById(R.id.linear4);
			final LinearLayout linear5 = (LinearLayout) _v.findViewById(R.id.linear5);
			final LinearLayout linear6 = (LinearLayout) _v.findViewById(R.id.linear6);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final LinearLayout linear7 = (LinearLayout) _v.findViewById(R.id.linear7);
			final LinearLayout linear8 = (LinearLayout) _v.findViewById(R.id.linear8);
			final LinearLayout linear9 = (LinearLayout) _v.findViewById(R.id.linear9);
			final LinearLayout linear10 = (LinearLayout) _v.findViewById(R.id.linear10);
			final LinearLayout linear11 = (LinearLayout) _v.findViewById(R.id.linear11);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final TextView textview15 = (TextView) _v.findViewById(R.id.textview15);
			final TextView textview3 = (TextView) _v.findViewById(R.id.textview3);
			final LinearLayout linear12 = (LinearLayout) _v.findViewById(R.id.linear12);
			final TextView textview6 = (TextView) _v.findViewById(R.id.textview6);
			final TextView textview8 = (TextView) _v.findViewById(R.id.textview8);
			final LinearLayout linear13 = (LinearLayout) _v.findViewById(R.id.linear13);
			final TextView textview7 = (TextView) _v.findViewById(R.id.textview7);
			final TextView textview4 = (TextView) _v.findViewById(R.id.textview4);
			final LinearLayout linear14 = (LinearLayout) _v.findViewById(R.id.linear14);
			final TextView textview2 = (TextView) _v.findViewById(R.id.textview2);
			final TextView textview9 = (TextView) _v.findViewById(R.id.textview9);
			final LinearLayout linear16 = (LinearLayout) _v.findViewById(R.id.linear16);
			final TextView textview10 = (TextView) _v.findViewById(R.id.textview10);
			final TextView textview11 = (TextView) _v.findViewById(R.id.textview11);
			final LinearLayout linear15 = (LinearLayout) _v.findViewById(R.id.linear15);
			final TextView textview12 = (TextView) _v.findViewById(R.id.textview12);
			final TextView textview13 = (TextView) _v.findViewById(R.id.textview13);
			final LinearLayout linear17 = (LinearLayout) _v.findViewById(R.id.linear17);
			final TextView textview14 = (TextView) _v.findViewById(R.id.textview14);
			
			android.graphics.drawable.GradientDrawable CRNPK = new android.graphics.drawable.GradientDrawable();
			CRNPK.setColor(Color.parseColor("#2196f3"));
			CRNPK.setCornerRadii(new float[]{ (float) 80,(float) 80,(float) 0,(float) 0,(float) 0,(float) 0,(float) 82,(float) 82 });
			CRNPK.setStroke((int) 0, Color.parseColor("#000000"));
			textview6.setElevation((float) 3);
			textview6.setBackground(CRNPK);
			//Milz
			android.graphics.drawable.GradientDrawable CRNLY = new android.graphics.drawable.GradientDrawable();
			CRNLY.setColor(Color.parseColor("#ff5722"));
			CRNLY.setCornerRadii(new float[]{ (float) 80,(float) 80,(float) 0,(float) 0,(float) 0,(float) 0,(float) 82,(float) 82 });
			CRNLY.setStroke((int) 0, Color.parseColor("#000000"));
			textview7.setElevation((float) 3);
			textview7.setBackground(CRNLY);
			//Milz
			android.graphics.drawable.GradientDrawable CRNWO = new android.graphics.drawable.GradientDrawable();
			CRNWO.setColor(Color.parseColor("#f44336"));
			CRNWO.setCornerRadii(new float[]{ (float) 80,(float) 80,(float) 0,(float) 0,(float) 0,(float) 0,(float) 82,(float) 82 });
			CRNWO.setStroke((int) 0, Color.parseColor("#000000"));
			textview2.setElevation((float) 3);
			textview2.setBackground(CRNWO);
			//Milz
			android.graphics.drawable.GradientDrawable CRNPH = new android.graphics.drawable.GradientDrawable();
			CRNPH.setColor(Color.parseColor("#b71c1c"));
			CRNPH.setCornerRadii(new float[]{ (float) 80,(float) 80,(float) 0,(float) 0,(float) 0,(float) 0,(float) 82,(float) 82 });
			CRNPH.setStroke((int) 0, Color.parseColor("#000000"));
			textview10.setElevation((float) 3);
			textview10.setBackground(CRNPH);
			//Milz
			android.graphics.drawable.GradientDrawable CRNSC = new android.graphics.drawable.GradientDrawable();
			CRNSC.setColor(Color.parseColor("#4caf50"));
			CRNSC.setCornerRadii(new float[]{ (float) 80,(float) 80,(float) 0,(float) 0,(float) 0,(float) 0,(float) 82,(float) 82 });
			CRNSC.setStroke((int) 0, Color.parseColor("#000000"));
			textview12.setElevation((float) 3);
			textview12.setBackground(CRNSC);
			//Milz
			android.graphics.drawable.GradientDrawable CRNAM = new android.graphics.drawable.GradientDrawable();
			CRNAM.setColor(Color.parseColor("#000000"));
			CRNAM.setCornerRadii(new float[]{ (float) 80,(float) 80,(float) 0,(float) 0,(float) 0,(float) 0,(float) 82,(float) 82 });
			CRNAM.setStroke((int) 0, Color.parseColor("#000000"));
			textview14.setElevation((float) 3);
			textview14.setBackground(CRNAM);
			//Milz
			if (map.get((int)_position).containsKey("country")) {
				textview1.setText(map.get((int)_position).get("country").toString());
			}
			else {
				
			}
			if (map.get((int)_position).containsKey("cases")) {
				textview6.setText(map.get((int)_position).get("cases").toString());
			}
			else {
				
			}
			if (map.get((int)_position).containsKey("todayCases")) {
				textview7.setText(map.get((int)_position).get("todayCases").toString());
			}
			else {
				
			}
			if (map.get((int)_position).containsKey("deaths")) {
				textview2.setText(map.get((int)_position).get("deaths").toString());
			}
			else {
				
			}
			if (map.get((int)_position).containsKey("todayDeaths")) {
				textview10.setText(map.get((int)_position).get("todayDeaths").toString());
			}
			else {
				
			}
			if (map.get((int)_position).containsKey("critical")) {
				textview14.setText(map.get((int)_position).get("critical").toString());
			}
			else {
				
			}
			textview12.setText(cr.get((int)(_position)));
			textview15.setText(String.valueOf((long)(_position + 1)));
			_Shadow(linear4, 2);
			_Shadow(linear1, 2);
			_Shadow(linear5, 2);
			_Shadow(linear6, 2);
			_Shadow(linear2, 2);
			_Shadow(linear7, 2);
			_Shadow(linear8, 2);
			_Shadow(linear9, 2);
			textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
			textview8.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
			textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
			textview9.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
			textview11.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
			textview13.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
			textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
			textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
			textview10.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
			textview12.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
			textview14.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
			textview15.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nunito.ttf"), 0);
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
