package com.filemanager.sketch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.content.Intent;
import android.net.Uri;
import android.media.MediaPlayer;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.AdapterView;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	private String Folder = "";
	private String UpFolder = "";
	private double position = 0;
	private String subtitle = "";
	private String play = "";
	private String info = "";
	private double song = 0;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	private ArrayList<String> liststring = new ArrayList<>();
	
	private LinearLayout linear1;
	private ListView listview1;
	
	private Intent in = new Intent();
	private MediaPlayer Mp;
	private AlertDialog.Builder dialog;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		listview1 = (ListView) findViewById(R.id.listview1);
		dialog = new AlertDialog.Builder(this);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (FileUtil.isDirectory(liststring.get((int)(_position)))) {
					Folder = liststring.get((int)(_position));
					_RefreshData();
				}
				else {
					if (liststring.get((int)(_position)).endsWith(".txt")) {
						in.setClass(getApplicationContext(), TextActivity.class);
						in.putExtra("title", Uri.parse(liststring.get((int)(_position))).getLastPathSegment());
						in.putExtra("text", FileUtil.readFile(liststring.get((int)(_position))));
						startActivity(in);
					}
					if (liststring.get((int)(_position)).endsWith(".jpg")) {
						in.setClass(getApplicationContext(), ImgeActivity.class);
						in.putExtra("title", Uri.parse(liststring.get((int)(_position))).getLastPathSegment());
						in.putExtra("img", liststring.get((int)(_position)));
						startActivity(in);
					}
					if (liststring.get((int)(_position)).endsWith(".apk")) {
						_install(liststring.get((int)(_position)));
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), Uri.parse(liststring.get((int)(_position))).getLastPathSegment());
					}
					if (liststring.get((int)(_position)).endsWith(".png")) {
						in.setClass(getApplicationContext(), ImgeActivity.class);
						in.putExtra("title", Uri.parse(liststring.get((int)(_position))).getLastPathSegment());
						in.putExtra("img", liststring.get((int)(_position)));
						startActivity(in);
					}
					if (liststring.get((int)(_position)).endsWith(".mp3")) {
						if (song == -1) {
							play = liststring.get((int)(_position));
							song = _position;
							Mp =
							MediaPlayer.create(getApplicationContext(), Uri.fromFile(new
							java.io.File(play)));
							Mp.start();
						}
						else {
							if (_position == song) {
								if (Mp.isPlaying()) {
									Mp.pause();
								}
								else {
									Mp.start();
								}
							}
							else {
								if (Mp.isPlaying()) {
									Mp.pause();
								}
								Mp.reset();
								Mp.release();
								song = _position;
								play = liststring.get((int)(_position));
								Mp =
								MediaPlayer.create(getApplicationContext(), Uri.fromFile(new
								java.io.File(play)));
								Mp.start();
							}
						}
					}
					if (liststring.get((int)(_position)).endsWith(".mp4")) {
						in.setClass(getApplicationContext(), PlayActivity.class);
						in.putExtra("title", Uri.parse(liststring.get((int)(_position))).getLastPathSegment());
						in.putExtra("path", liststring.get((int)(_position)));
						startActivity(in);
					}
					if (liststring.get((int)(_position)).endsWith(".xml")) {
						in.setClass(getApplicationContext(), TextActivity.class);
						in.putExtra("title", Uri.parse(liststring.get((int)(_position))).getLastPathSegment());
						in.putExtra("text", FileUtil.readFile(liststring.get((int)(_position))));
						startActivity(in);
					}
					if (liststring.get((int)(_position)).endsWith(".java")) {
						in.setClass(getApplicationContext(), TextActivity.class);
						in.putExtra("title", Uri.parse(liststring.get((int)(_position))).getLastPathSegment());
						in.putExtra("text", FileUtil.readFile(liststring.get((int)(_position))));
						startActivity(in);
					}
					_Open_Pdf(_position);
				}
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				dialog.setTitle("File Delete?");
				dialog.setIcon(R.drawable.delete100);
				dialog.setMessage("".concat(Uri.parse(liststring.get((int)(_position))).getLastPathSegment()));
				dialog.setNegativeButton("Delete ✔️", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						FileUtil.deleteFile(liststring.get((int)(_position)));
						liststring.remove((int)(_position));
						listmap.clear();
						_RefreshData();
					}
				});
				dialog.setNeutralButton("Cancel ❌", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
				return true;
			}
		});
	}
	private void initializeLogic() {
		getSupportActionBar().setDisplayHomeAsUpEnabled(false);
		song = -1;
		Folder = FileUtil.getExternalStorageDir();
		_RefreshData();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (Folder.equals(FileUtil.getExternalStorageDir())) {
			finish();
		}
		else {
			UpFolder = Folder.substring((int)(0), (int)(Folder.lastIndexOf("/")));
			Folder = UpFolder;
			_RefreshData();
		}
	}
	private void _RefreshData () {
		listmap.clear();
		subtitle = Folder.replace(FileUtil.getExternalStorageDir(), "");
		getSupportActionBar().setSubtitle(Folder);
		FileUtil.listDir(Folder, liststring);
		Collections.sort(liststring, String.CASE_INSENSITIVE_ORDER);
		position = 0;
		for(int _repeat14 = 0; _repeat14 < (int)(liststring.size()); _repeat14++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("file", liststring.get((int)(position)));
				listmap.add(_item);
			}
			
			position++;
		}
		listview1.setAdapter(new Listview1Adapter(listmap));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	
	private void _install (final String _p) {
		/*Intent i = new Intent(Intent.ACTION_VIEW);
i.setDataAndType(Uri.fromFile(new java.io.File(_p)), "application/vnd.android.package-archive");
startActivity(i);*/
	}
	
	
	private void _Open_Pdf (final double _position) {
		if (liststring.get((int)(_position)).endsWith(".pdf")) {
			in.setClass(getApplicationContext(), PageActivity.class);
			in.putExtra("title", Uri.parse(liststring.get((int)(_position))).getLastPathSegment());
			in.putExtra("text", FileUtil.readFile(liststring.get((int)(_position))));
			startActivity(in);
		}
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.list_item, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final TextView textview2 = (TextView) _v.findViewById(R.id.textview2);
			
			textview1.setText(Uri.parse(liststring.get((int)(_position))).getLastPathSegment());
			textview2.setVisibility(View.GONE);
			if (FileUtil.isDirectory(liststring.get((int)(_position)))) {
				imageview1.setImageResource(R.drawable.ic_folder_grey);
			}
			else {
				if (liststring.get((int)(_position)).endsWith(".apk")) {
					info = liststring.get((int)(_position));
					android.content.pm.PackageInfo pckgInfo = getPackageManager().getPackageArchiveInfo(info, android.content.pm.PackageManager.GET_ACTIVITIES);
					pckgInfo.applicationInfo.sourceDir = pckgInfo.applicationInfo.publicSourceDir = info;
					imageview1.setImageDrawable(getPackageManager().getApplicationIcon(pckgInfo.applicationInfo));
					final java.io.File file1 = new java.io.File(info);
					try{
						long length = file1.length();
						length = length/1024;
						textview2.setText("File size : " + length +" KB");
					}catch(Exception e){
						showMessage("File not found : " + e.getMessage() + e);
					}
					textview2.setVisibility(View.VISIBLE);
				}
				else {
					if (liststring.get((int)(_position)).endsWith(".png")) {
						imageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(liststring.get((int)(_position)), 1024, 1024));
						info = liststring.get((int)(_position));
						final java.io.File file1 = new java.io.File(info);
						try{
							long length = file1.length();
							length = length/1024;
							textview2.setText("File size : " + length +" KB");
						}catch(Exception e){
							showMessage("File not found : " + e.getMessage() + e);
						}
						textview2.setVisibility(View.VISIBLE);
					}
					else {
						if (liststring.get((int)(_position)).endsWith(".mp3")) {
							imageview1.setImageResource(R.drawable.file_audio_mp3_ic);
							info = liststring.get((int)(_position));
							final java.io.File file1 = new java.io.File(info);
							try{
								long length = file1.length();
								length = length/1024;
								textview2.setText("File size : " + length +" KB");
							}catch(Exception e){
								showMessage("File not found : " + e.getMessage() + e);
							}
							textview2.setVisibility(View.VISIBLE);
						}
						else {
							if (liststring.get((int)(_position)).endsWith(".mp4")) {
								imageview1.setImageResource(R.drawable.file_video_mp4_ic);
								info = liststring.get((int)(_position));
								final java.io.File file1 = new java.io.File(info);
								try{
									long length = file1.length();
									length = length/1024;
									textview2.setText("File size : " + length +" KB");
								}catch(Exception e){
									showMessage("File not found : " + e.getMessage() + e);
								}
								textview2.setVisibility(View.VISIBLE);
							}
							else {
								if (liststring.get((int)(_position)).endsWith(".html") || liststring.get((int)(_position)).endsWith(".mhtml")) {
									imageview1.setImageResource(R.drawable.file_item_web_ic);
									info = liststring.get((int)(_position));
									final java.io.File file1 = new java.io.File(info);
									try{
										long length = file1.length();
										length = length/1024;
										textview2.setText("File size : " + length +" KB");
									}catch(Exception e){
										showMessage("File not found : " + e.getMessage() + e);
									}
									textview2.setVisibility(View.VISIBLE);
								}
								else {
									if (liststring.get((int)(_position)).endsWith(".txt")) {
										imageview1.setImageResource(R.drawable.file_doc_txt_ic);
										info = liststring.get((int)(_position));
										final java.io.File file1 = new java.io.File(info);
										try{
											long length = file1.length();
											length = length/1024;
											textview2.setText("File size : " + length +" KB");
										}catch(Exception e){
											showMessage("File not found : " + e.getMessage() + e);
										}
										textview2.setVisibility(View.VISIBLE);
									}
									else {
										if (liststring.get((int)(_position)).endsWith(".pdf")) {
											imageview1.setImageResource(R.drawable.file_doc_pdf_ic);
											info = liststring.get((int)(_position));
											final java.io.File file1 = new java.io.File(info);
											try{
												long length = file1.length();
												length = length/1024;
												textview2.setText("File size : " + length +" KB");
											}catch(Exception e){
												showMessage("File not found : " + e.getMessage() + e);
											}
											textview2.setVisibility(View.VISIBLE);
										}
										else {
											if (liststring.get((int)(_position)).endsWith(".zip")) {
												imageview1.setImageResource(R.drawable.file_type_large_archive);
												info = liststring.get((int)(_position));
												final java.io.File file1 = new java.io.File(info);
												try{
													long length = file1.length();
													length = length/1024;
													textview2.setText("File size : " + length +" KB");
												}catch(Exception e){
													showMessage("File not found : " + e.getMessage() + e);
												}
												textview2.setVisibility(View.VISIBLE);
											}
											else {
												if (liststring.get((int)(_position)).endsWith(".jpg")) {
													imageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(liststring.get((int)(_position)), 1024, 1024));
													info = liststring.get((int)(_position));
													final java.io.File file1 = new java.io.File(info);
													try{
														long length = file1.length();
														length = length/1024;
														textview2.setText("File size : " + length +" KB");
													}catch(Exception e){
														showMessage("File not found : " + e.getMessage() + e);
													}
													textview2.setVisibility(View.VISIBLE);
												}
												else {
													if (liststring.get((int)(_position)).endsWith(".java")) {
														imageview1.setImageResource(R.drawable.java);
														info = liststring.get((int)(_position));
														final java.io.File file1 = new java.io.File(info);
														try{
															long length = file1.length();
															length = length/1024;
															textview2.setText("File size : " + length +" KB");
														}catch(Exception e){
															showMessage("File not found : " + e.getMessage() + e);
														}
														textview2.setVisibility(View.VISIBLE);
													}
													else {
														imageview1.setImageResource(R.drawable.file_item_default_ic);
														info = liststring.get((int)(_position));
														final java.io.File file1 = new java.io.File(info);
														try{
															long length = file1.length();
															length = length/1024;
															textview2.setText("File size : " + length +" KB");
														}catch(Exception e){
															showMessage("File not found : " + e.getMessage() + e);
														}
														textview2.setVisibility(View.VISIBLE);
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
