package com.my.newproject3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.Button;
import android.view.View;

public class MainActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	
	private Button button1;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		button1 = (Button) findViewById(R.id.button1);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_notify(0, "TitleX", "Bla Bla Bla some text", "notif_ic", "large_ic", "SecActivity", "My App Channel", "app_channel_x01");
			}
		});
	}
	private void initializeLogic() {
		Class c = SecActivity.class;
	} void notifyMsg() {
		int _id = 0;
		String _title = "Title";
		String _text = "Text";
		String _small = "notif_ic";
		String _large = "large_ic";
		String _activity = "SecActivity";
		String _channelName = "My App";
		String _channelId = "My channel id";
		
		Class<?> act = null;
		try {
			act = Class.forName(getClass().getPackage().getName() + "." + _activity);
		} catch (ClassNotFoundException e) {}
		
		PendingIntent pen;
		if (act == null)
		pen = PendingIntent.getActivity(this, 0, new Intent(), PendingIntent.FLAG_UPDATE_CURRENT);
		else
		pen = PendingIntent.getActivity(this, 0, new Intent(this, act), 0);
		
		int small_ic = R.drawable.app_icon;
		int large_ic = -1;
		
		if (!_small.equals(""))
		try {
			small_ic = Class.forName(getClass().getPackage().getName() + ".R$drawable").getDeclaredField(_small).getInt(null);
		} catch (Exception e) {}
		
		if (!_large.equals(""))
		try {
			large_ic = Class.forName(getClass().getPackage().getName() + ".R$drawable").getDeclaredField(_large).getInt(null);
		} catch (Exception e) {}
		
		androidx.core.app.NotificationCompat.Builder mBuilder = new androidx.core.app.NotificationCompat.Builder(this);
		if (large_ic != -1)
		mBuilder.setLargeIcon(BitmapFactory.decodeResource(getResources(), large_ic));
		mBuilder.setSmallIcon(small_ic)
		.setContentTitle(_title)
		.setContentText(_text)
		.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
		.setPriority(Notification.PRIORITY_MAX)
		.setContentIntent(pen);
		
		NotificationManager nMan = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
		
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			NotificationChannel channel = new NotificationChannel(_channelId, _channelName, NotificationManager.IMPORTANCE_HIGH);
			nMan.createNotificationChannel(channel); mBuilder.setChannelId(_channelId);
		}
		
		nMan.notify((int)_id, mBuilder.build());
		
		showMessage(R.class + " " + R.drawable.class);
	} {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _notify (final double _id, final String _title, final String _text, final String _small, final String _large, final String _activity, final String _channelName, final String _channelId) {
		Class<?> act = null;
		try {
			act = Class.forName(getClass().getPackage().getName() + "." + _activity);
		} catch (ClassNotFoundException e) {}
		
		PendingIntent pen;
		if (act == null)
		pen = PendingIntent.getActivity(this, 0, new Intent(), PendingIntent.FLAG_UPDATE_CURRENT);
		else
		pen = PendingIntent.getActivity(this, 0, new Intent(this, act), 0);
		
		int small_ic = R.drawable.app_icon;
		int large_ic = -1;
		
		if (!_small.equals(""))
		try {
			small_ic = Class.forName(getClass().getPackage().getName() + ".R$drawable").getDeclaredField(_small).getInt(null);
		} catch (Exception e) {}
		
		if (!_large.equals(""))
		try {
			large_ic = Class.forName(getClass().getPackage().getName() + ".R$drawable").getDeclaredField(_large).getInt(null);
		} catch (Exception e) {}
		
		androidx.core.app.NotificationCompat.Builder mBuilder = new androidx.core.app.NotificationCompat.Builder(this);
		if (large_ic != -1)
		mBuilder.setLargeIcon(BitmapFactory.decodeResource(getResources(), large_ic));
		mBuilder.setSmallIcon(small_ic)
		.setContentTitle(_title)
		.setContentText(_text)
		.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
		.setPriority(Notification.PRIORITY_MAX)
		.setContentIntent(pen);
		
		NotificationManager nMan = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
		
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			NotificationChannel channel = new NotificationChannel(_channelId, _channelName, NotificationManager.IMPORTANCE_HIGH);
			nMan.createNotificationChannel(channel); mBuilder.setChannelId(_channelId);
		}
		
		nMan.notify((int)_id, mBuilder.build());
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
