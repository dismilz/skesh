package com.my.newproject;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.webkit.WebView;
import android.webkit.WebSettings;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private double ping = 0;
	private boolean start = false;
	private boolean re = false;
	
	private LinearLayout linear1;
	private TextView textview4;
	private LinearLayout linear4;
	private TextView textview7;
	private LinearLayout linear3;
	private TextView textview3;
	private WebView webview1;
	private LinearLayout linear2;
	private TextView textview_ping;
	private TextView textview1;
	
	private TimerTask ping_timer;
	private RequestNetwork api;
	private RequestNetwork.RequestListener _api_request_listener;
	private TimerTask t;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		textview4 = (TextView) findViewById(R.id.textview4);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		textview7 = (TextView) findViewById(R.id.textview7);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		textview3 = (TextView) findViewById(R.id.textview3);
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		textview_ping = (TextView) findViewById(R.id.textview_ping);
		textview1 = (TextView) findViewById(R.id.textview1);
		api = new RequestNetwork(this);
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		_api_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				textview3.setVisibility(View.INVISIBLE);
				start = false;
				textview_ping.setText(String.valueOf((long)(ping)).concat(" ms"));
				textview_ping.setTextColor(0xFFFFFFFF);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								ping = 0;
								start = true;
								_ping_start();
								api.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com", "A", _api_request_listener);
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				textview3.setVisibility(View.VISIBLE);
				ping = 0;
				start = true;
				api.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com", "A", _api_request_listener);
				textview_ping.setText("999+ ms");
				textview_ping.setTextColor(0xFFF44336);
			}
		};
	}
	private void initializeLogic() {
		textview3.setVisibility(View.INVISIBLE);
		start = true;
		_ping_start();
		api.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com", "A", _api_request_listener);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _ping_start () {
		if (start) {
			ping++;
			ping_timer = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							_ping_start();
						}
					});
				}
			};
			_timer.schedule(ping_timer, (int)(1));
		}
		else {
			
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
