package altamash.coronainformation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.widget.LinearLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ProgressBar;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class MainActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	private DrawerLayout _drawer;
	private String save = "";
	private double len = 0;
	private double r = 0;
	private String value1 = "";
	
	private ArrayList<HashMap<String, Object>> research = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private ListView listview1;
	private ProgressBar progressbar1;
	private ImageView imageview1;
	private TextView textview1;
	private EditText edittext1;
	private LinearLayout _drawer_linear1;
	private LinearLayout _drawer_linear2;
	private LinearLayout _drawer_linear3;
	private LinearLayout _drawer_linear4;
	private HorizontalScrollView _drawer_hscroll1;
	private LinearLayout _drawer_linear6;
	private HorizontalScrollView _drawer_hscroll2;
	private LinearLayout _drawer_linear8;
	private LinearLayout _drawer_lin;
	private ImageView _drawer_imageview1;
	private TextView _drawer_textview1;
	private TextView _drawer_textview2;
	private LinearLayout _drawer_linear5;
	private ImageView _drawer_imageview2;
	private ImageView _drawer_imageview3;
	private ImageView _drawer_imageview4;
	private ImageView _drawer_imageview5;
	private ImageView _drawer_imageview7;
	private ImageView _drawer_imageview6;
	private TextView _drawer_textview3;
	private LinearLayout _drawer_linear7;
	private ImageView _drawer_imageview8;
	private ImageView _drawer_imageview9;
	private ImageView _drawer_imageview10;
	private ImageView _drawer_imageview11;
	private ImageView _drawer_imageview12;
	private ImageView _drawer_imageview14;
	private ImageView _drawer_imageview13;
	private TextView _drawer_textview4;
	private ImageView _drawer_imageview16;
	
	private RequestNetwork nt;
	private RequestNetwork.RequestListener _nt_request_listener;
	private AlertDialog.Builder dlg;
	private Intent j = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = (DrawerLayout) findViewById(R.id._drawer);ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(MainActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view);
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		listview1 = (ListView) findViewById(R.id.listview1);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		_drawer_linear1 = (LinearLayout) _nav_view.findViewById(R.id.linear1);
		_drawer_linear2 = (LinearLayout) _nav_view.findViewById(R.id.linear2);
		_drawer_linear3 = (LinearLayout) _nav_view.findViewById(R.id.linear3);
		_drawer_linear4 = (LinearLayout) _nav_view.findViewById(R.id.linear4);
		_drawer_hscroll1 = (HorizontalScrollView) _nav_view.findViewById(R.id.hscroll1);
		_drawer_linear6 = (LinearLayout) _nav_view.findViewById(R.id.linear6);
		_drawer_hscroll2 = (HorizontalScrollView) _nav_view.findViewById(R.id.hscroll2);
		_drawer_linear8 = (LinearLayout) _nav_view.findViewById(R.id.linear8);
		_drawer_lin = (LinearLayout) _nav_view.findViewById(R.id.lin);
		_drawer_imageview1 = (ImageView) _nav_view.findViewById(R.id.imageview1);
		_drawer_textview1 = (TextView) _nav_view.findViewById(R.id.textview1);
		_drawer_textview2 = (TextView) _nav_view.findViewById(R.id.textview2);
		_drawer_linear5 = (LinearLayout) _nav_view.findViewById(R.id.linear5);
		_drawer_imageview2 = (ImageView) _nav_view.findViewById(R.id.imageview2);
		_drawer_imageview3 = (ImageView) _nav_view.findViewById(R.id.imageview3);
		_drawer_imageview4 = (ImageView) _nav_view.findViewById(R.id.imageview4);
		_drawer_imageview5 = (ImageView) _nav_view.findViewById(R.id.imageview5);
		_drawer_imageview7 = (ImageView) _nav_view.findViewById(R.id.imageview7);
		_drawer_imageview6 = (ImageView) _nav_view.findViewById(R.id.imageview6);
		_drawer_textview3 = (TextView) _nav_view.findViewById(R.id.textview3);
		_drawer_linear7 = (LinearLayout) _nav_view.findViewById(R.id.linear7);
		_drawer_imageview8 = (ImageView) _nav_view.findViewById(R.id.imageview8);
		_drawer_imageview9 = (ImageView) _nav_view.findViewById(R.id.imageview9);
		_drawer_imageview10 = (ImageView) _nav_view.findViewById(R.id.imageview10);
		_drawer_imageview11 = (ImageView) _nav_view.findViewById(R.id.imageview11);
		_drawer_imageview12 = (ImageView) _nav_view.findViewById(R.id.imageview12);
		_drawer_imageview14 = (ImageView) _nav_view.findViewById(R.id.imageview14);
		_drawer_imageview13 = (ImageView) _nav_view.findViewById(R.id.imageview13);
		_drawer_textview4 = (TextView) _nav_view.findViewById(R.id.textview4);
		_drawer_imageview16 = (ImageView) _nav_view.findViewById(R.id.imageview16);
		nt = new RequestNetwork(this);
		dlg = new AlertDialog.Builder(this);
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				research = new Gson().fromJson(save, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				len = research.size();
				r = len - 1;
				for(int _repeat17 = 0; _repeat17 < (int)(len); _repeat17++) {
					value1 = research.get((int)r).get("cntry").toString();
					if (!(_charSeq.length() > value1.length()) && value1.toLowerCase().contains(_charSeq.toLowerCase())) {
						
					}
					else {
						research.remove((int)(r));
					}
					r--;
				}
				listview1.setAdapter(new Listview1Adapter(research));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_nt_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "Server Connected");
				research = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				listview1.setAdapter(new Listview1Adapter(research));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				progressbar1.setVisibility(View.GONE);
				listview1.setVisibility(View.VISIBLE);
				save = new Gson().toJson(research);
				edittext1.setEnabled(true);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				listview1.setVisibility(View.GONE);
				progressbar1.setVisibility(View.GONE);
				dlg.setTitle("Network Error");
				dlg.setNegativeButton("Retry", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						nt.startRequestNetwork(RequestNetworkController.GET, "https://gulshan-covid.herokuapp.com/overall", "nt", _nt_request_listener);
					}
				});
				dlg.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						finish();
					}
				});
				dlg.create().show();
			}
		};
		
		_drawer_lin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				j.setClass(getApplicationContext(), CoronamapActivity.class);
				startActivity(j);
			}
		});
	}
	private void initializeLogic() {
		_round_stock(30, 30, 30, 30, "white", edittext1, 1, "green");
		listview1.setVisibility(View.GONE);
		progressbar1.setVisibility(View.VISIBLE);
		nt.startRequestNetwork(RequestNetworkController.GET, "https://gulshan-covid.herokuapp.com/overall", "nt", _nt_request_listener);
		edittext1.setEnabled(false);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		}
		else {
			super.onBackPressed();
		}
	}
	private void _round_stock (final double _one, final double _two, final double _three, final double _four, final String _color, final View _view, final double _swidth, final String _scolor) {
		Double left_top = _one;
		Double right_top = _two;
		Double left_bottom = _three;
		Double right_bottom = _four;
		Double sw = _swidth;
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable();
		s.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		s.setCornerRadii(new float[] {left_top.floatValue(),left_top.floatValue(), right_top.floatValue(),right_top.floatValue(), left_bottom.floatValue(),left_bottom.floatValue(), right_bottom.floatValue(),right_bottom.floatValue()});
		s.setColor(Color.parseColor(_color));
		_view.setBackground(s);
		s.setStroke(sw.intValue(), Color.parseColor(_scolor));
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.custom, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final LinearLayout linear5 = (LinearLayout) _v.findViewById(R.id.linear5);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final LinearLayout linear3 = (LinearLayout) _v.findViewById(R.id.linear3);
			final LinearLayout linear6 = (LinearLayout) _v.findViewById(R.id.linear6);
			final LinearLayout linear8 = (LinearLayout) _v.findViewById(R.id.linear8);
			final LinearLayout linear10 = (LinearLayout) _v.findViewById(R.id.linear10);
			final LinearLayout linear12 = (LinearLayout) _v.findViewById(R.id.linear12);
			final LinearLayout linear18 = (LinearLayout) _v.findViewById(R.id.linear18);
			final LinearLayout linear14 = (LinearLayout) _v.findViewById(R.id.linear14);
			final LinearLayout linear15 = (LinearLayout) _v.findViewById(R.id.linear15);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			final TextView textview2 = (TextView) _v.findViewById(R.id.textview2);
			final TextView textview3 = (TextView) _v.findViewById(R.id.textview3);
			final ImageView imageview2 = (ImageView) _v.findViewById(R.id.imageview2);
			final TextView textview4 = (TextView) _v.findViewById(R.id.textview4);
			final TextView textview5 = (TextView) _v.findViewById(R.id.textview5);
			final ImageView imageview3 = (ImageView) _v.findViewById(R.id.imageview3);
			final TextView textview6 = (TextView) _v.findViewById(R.id.textview6);
			final TextView textview7 = (TextView) _v.findViewById(R.id.textview7);
			final ImageView imageview4 = (ImageView) _v.findViewById(R.id.imageview4);
			final TextView textview8 = (TextView) _v.findViewById(R.id.textview8);
			final TextView textview9 = (TextView) _v.findViewById(R.id.textview9);
			final ImageView imageview5 = (ImageView) _v.findViewById(R.id.imageview5);
			final TextView textview10 = (TextView) _v.findViewById(R.id.textview10);
			final TextView textview11 = (TextView) _v.findViewById(R.id.textview11);
			final ImageView imageview6 = (ImageView) _v.findViewById(R.id.imageview6);
			final TextView textview12 = (TextView) _v.findViewById(R.id.textview12);
			final TextView textview13 = (TextView) _v.findViewById(R.id.textview13);
			final TextView textview14 = (TextView) _v.findViewById(R.id.textview14);
			final LinearLayout linear16 = (LinearLayout) _v.findViewById(R.id.linear16);
			final TextView textview15 = (TextView) _v.findViewById(R.id.textview15);
			final TextView textview16 = (TextView) _v.findViewById(R.id.textview16);
			
			_round_stock(40, 40, 40, 40, "white", linear2, 2, "red");
			textview1.setText(research.get((int)_position).get("cntry").toString());
			textview3.setText(research.get((int)_position).get("cases").toString());
			textview5.setText(research.get((int)_position).get("activecase").toString());
			textview7.setText(research.get((int)_position).get("critical").toString());
			textview9.setText(research.get((int)_position).get("death").toString());
			textview11.setText(research.get((int)_position).get("recovered").toString());
			textview14.setText(research.get((int)_position).get("todaycase").toString());
			textview16.setText(research.get((int)_position).get("todaydeath").toString());
			androidx.cardview.widget.CardView cv = new androidx.cardview.widget.CardView(MainActivity.this);
			
			LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
			
			lp.setMargins(30,30,30,30);
			
			cv.setLayoutParams(lp);
			
			cv.setCardBackgroundColor(Color.WHITE);
			
			cv.setRadius(10);
			
			cv.setCardElevation(8);
			
			cv.setMaxCardElevation(12);
			
			cv.setPreventCornerOverlap(true);
			
			((ViewGroup)linear5.getParent()).removeView(linear5);
			
			linear1.removeAllViews();
			
			linear1.addView(cv);
			
			cv.addView(linear5);
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
