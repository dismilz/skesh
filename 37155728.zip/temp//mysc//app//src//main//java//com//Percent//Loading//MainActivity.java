package com.Percent.Loading;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ProgressBar;
import java.util.Timer;
import java.util.TimerTask;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private double n = 0;
	
	private LinearLayout ui;
	private TextView textview1;
	private LinearLayout load;
	private ProgressBar progressbar1;
	private TextView persen;
	
	private TimerTask t;
	private Intent i = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		ui = (LinearLayout) findViewById(R.id.ui);
		textview1 = (TextView) findViewById(R.id.textview1);
		load = (LinearLayout) findViewById(R.id.load);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		persen = (TextView) findViewById(R.id.persen);
	}
	private void initializeLogic() {
		n = 0;
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						progressbar1.setProgress((int)n);
						if (n==0) {
							persen.setText ("0%");
						}
						if (n==1) {
							persen.setText ("1%");
						}
						if (n==2) {
							persen.setText ("2%");
						}
						if (n==3) {
							persen.setText ("3%");
						}
						if (n==4) {
							persen.setText ("4%");
						}
						if (n==5) {
							persen.setText ("5%");
						}
						if (n==6) {
							persen.setText ("6%");
						}
						if (n==7) {
							persen.setText ("7%");
						}
						if (n==8) {
							persen.setText ("8%");
						}
						if (n==9) {
							persen.setText ("9%");
						}
						if (n==10) {
							persen.setText ("10%");
						}
						if (n==11) {
							persen.setText ("11%");
						}
						if (n==12) {
							persen.setText ("12%");
						}
						if (n==13) {
							persen.setText ("13%");
						}
						if (n==14) {
							persen.setText ("14%");
						}
						if (n==15) {
							persen.setText ("15%");
						}
						if (n==16) {
							persen.setText ("16%");
						}
						if (n==17) {
							persen.setText ("17%");
						}
						if (n==18) {
							persen.setText ("18%");
						}
						if (n==19) {
							persen.setText ("19%");
						}
						if (n==20) {
							persen.setText ("20%");
						}
						if (n==21) {
							persen.setText ("21%");
						}
						if (n==22) {
							persen.setText ("22%");
						}
						if (n==23) {
							persen.setText ("23%");
						}
						if (n==24) {
							persen.setText ("24%");
						}
						if (n==25) {
							persen.setText ("25%");
						}
						if (n==26) {
							persen.setText ("26%");
						}
						if (n==27) {
							persen.setText ("27%");
						}
						if (n==28) {
							persen.setText ("28%");
						}
						if (n==29) {
							persen.setText ("29%");
						}
						if (n==30) {
							persen.setText ("30%");
						}
						if (n==31) {
							persen.setText ("31%");
						}
						if (n==32) {
							persen.setText ("32%");
						}
						if (n==33) {
							persen.setText ("33%");
						}
						if (n==34) {
							persen.setText ("34%");
						}
						if (n==35) {
							persen.setText ("35%");
						}
						if (n==36) {
							persen.setText ("36%");
						}
						if (n==37) {
							persen.setText ("37%");
						}
						if (n==38) {
							persen.setText ("38%");
						}
						if (n==39) {
							persen.setText ("39%");
						}
						if (n==40) {
							persen.setText ("40%");
						}
						if (n==41) {
							persen.setText ("41%");
						}
						if (n==42) {
							persen.setText ("42%");
						}
						if (n==43) {
							persen.setText ("43%");
						}
						if (n==44) {
							persen.setText ("44%");
						}
						if (n==45) {
							persen.setText ("45%");
						}
						if (n==46) {
							persen.setText ("46%");
						}
						if (n==47) {
							persen.setText ("47%");
						}
						if (n==48) {
							persen.setText ("48%");
						}
						if (n==49) {
							persen.setText ("49%");
						}
						if (n==50) {
							persen.setText ("50%");
						}
						if (n==51) {
							persen.setText ("51%");
						}
						if (n==52) {
							persen.setText ("52%");
						}
						if (n==53) {
							persen.setText ("53%");
						}
						if (n==54) {
							persen.setText ("54%");
						}
						if (n==55) {
							persen.setText ("55%");
						}
						if (n==56) {
							persen.setText ("56%");
						}
						if (n==57) {
							persen.setText ("57%");
						}
						if (n==58) {
							persen.setText ("58%");
						}
						if (n==59) {
							persen.setText ("59%");
						}
						if (n==60) {
							persen.setText ("60%");
						}
						if (n==61) {
							persen.setText ("61%");
						}
						if (n==62) {
							persen.setText ("62%");
						}
						if (n==63) {
							persen.setText ("63%");
						}
						if (n==64) {
							persen.setText ("64%");
						}
						if (n==65) {
							persen.setText ("65%");
						}
						if (n==66) {
							persen.setText ("66%");
						}
						if (n==67) {
							persen.setText ("67%");
						}
						if (n==68) {
							persen.setText ("68%");
						}
						if (n==69) {
							persen.setText ("69%");
						}
						if (n==70) {
							persen.setText ("70%");
						}
						if (n==71) {
							persen.setText ("71%");
						}
						if (n==72) {
							persen.setText ("72%");
						}
						if (n==73) {
							persen.setText ("73%");
						}
						if (n==74) {
							persen.setText ("74%");
						}
						if (n==75) {
							persen.setText ("75%");
						}
						if (n==76) {
							persen.setText ("76%");
						}
						if (n==77) {
							persen.setText ("77%");
						}
						if (n==78) {
							persen.setText ("78%");
						}
						if (n==79) {
							persen.setText ("79%");
						}
						if (n==80) {
							persen.setText ("80%");
						}
						if (n==81) {
							persen.setText ("81%");
						}
						if (n==82) {
							persen.setText ("82%");
						}
						if (n==83) {
							persen.setText ("83%");
						}
						if (n==84) {
							persen.setText ("84%");
						}
						if (n==85) {
							persen.setText ("85%");
						}
						if (n==86) {
							persen.setText ("86%");
						}
						if (n==87) {
							persen.setText ("87%");
						}
						if (n==88) {
							persen.setText ("88%");
						}
						if (n==89) {
							persen.setText ("89%");
						}
						if (n==90) {
							persen.setText ("90%");
						}
						if (n==91) {
							persen.setText ("91%");
						}
						if (n==92) {
							persen.setText ("92%");
						}
						if (n==93) {
							persen.setText ("93%");
						}
						if (n==94) {
							persen.setText ("94%");
						}
						if (n==95) {
							persen.setText ("95%");
						}
						if (n==96) {
							persen.setText ("96%");
						}
						if (n==97) {
							persen.setText ("97%");
						}
						if (n==98) {
							persen.setText ("98%");
						}
						if (n==99) {
							persen.setText ("99%");
						}
						if (n==100) {
							persen.setText ("100%");
							Toast.makeText(getApplicationContext(), "Jangan lupa coli pake balsem :)", Toast.LENGTH_LONG).show();
							i.setClass(getApplicationContext(), HomeActivity.class);
							startActivity(i);
							load.setVisibility(View.GONE);
						}
						if (n == 101) {
							n = 1;
						}
						else {
							n++;
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(100), (int)(100));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
