package com.SKETCHit.zip.unzip;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout card1;
	private LinearLayout card2;
	private LinearLayout linear2;
	private TextView textview1;
	private EditText edittext1;
	private TextView textview2;
	private EditText edittext3;
	private Button button1;
	private TextView textview3;
	private EditText edittext4;
	private TextView textview4;
	private EditText edittext2;
	private Button button2;
	private TextView textview5;
	
	private TimerTask t;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		card1 = (LinearLayout) findViewById(R.id.card1);
		card2 = (LinearLayout) findViewById(R.id.card2);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		textview1 = (TextView) findViewById(R.id.textview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		textview2 = (TextView) findViewById(R.id.textview2);
		edittext3 = (EditText) findViewById(R.id.edittext3);
		button1 = (Button) findViewById(R.id.button1);
		textview3 = (TextView) findViewById(R.id.textview3);
		edittext4 = (EditText) findViewById(R.id.edittext4);
		textview4 = (TextView) findViewById(R.id.textview4);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		button2 = (Button) findViewById(R.id.button2);
		textview5 = (TextView) findViewById(R.id.textview5);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals(FileUtil.getExternalStorageDir().concat("/"))) {
					SketchwareUtil.showMessage(getApplicationContext(), "Import a folder or file to zip");
				}
				else {
					if (edittext3.getText().toString().equals(FileUtil.getExternalStorageDir().concat("/"))) {
						SketchwareUtil.showMessage(getApplicationContext(), "Plesase put a name for the new zipping file or folder eg:- test.zip");
					}
					else {
						if (!edittext3.getText().toString().endsWith(".zip")) {
							SketchwareUtil.showMessage(getApplicationContext(), "Plesase put a name for the new zipping file or folder eg:- test.zip");
						}
						else {
							if (!FileUtil.isExistFile(edittext1.getText().toString())) {
								SketchwareUtil.showMessage(getApplicationContext(), "The path : ".concat(edittext1.getText().toString().concat(" not existing!!")));
							}
							else {
								final ProgressDialog prog = new ProgressDialog(MainActivity.this);
								prog.setMax(100);
								prog.setMessage("Zipping Files....");
								prog.setIndeterminate(true);
								prog.setCancelable(false);
								prog.show();
								
								
								
								t = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												_zip(edittext1.getText().toString(), edittext3.getText().toString());
												SketchwareUtil.showMessage(getApplicationContext(), "Zipped to : ".concat(edittext3.getText().toString()));
												prog.hide();
											}
										});
									}
								};
								_timer.schedule(t, (int)(100));
							}
						}
					}
				}
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext4.getText().toString().equals(FileUtil.getExternalStorageDir().concat("/"))) {
					SketchwareUtil.showMessage(getApplicationContext(), "Import a zip file to unzip");
				}
				else {
					if (edittext2.getText().toString().equals(FileUtil.getExternalStorageDir().concat("/"))) {
						SketchwareUtil.showMessage(getApplicationContext(), "Plesase import a path to unzip ");
					}
					else {
						if (edittext2.getText().toString().equals("")) {
							SketchwareUtil.showMessage(getApplicationContext(), "Plesase import a path to unzip ");
						}
						else {
							if (!edittext4.getText().toString().endsWith(".zip")) {
								SketchwareUtil.showMessage(getApplicationContext(), "Please import a zip file");
							}
							else {
								if (!FileUtil.isExistFile(edittext4.getText().toString())) {
									SketchwareUtil.showMessage(getApplicationContext(), "The zip file : ".concat(edittext4.getText().toString().concat(" not existing!!")));
								}
								else {
									final ProgressDialog prog = new ProgressDialog(MainActivity.this);
									prog.setMax(100);
									prog.setMessage("Unzipping Files.....");
									prog.setIndeterminate(true);
									prog.setCancelable(false);
									prog.show();
									t = new TimerTask() {
										@Override
										public void run() {
											runOnUiThread(new Runnable() {
												@Override
												public void run() {
													_UnZip(edittext4.getText().toString(), edittext2.getText().toString());
													SketchwareUtil.showMessage(getApplicationContext(), "Unzipped to : ".concat(edittext2.getText().toString()));
													prog.hide();
												}
											});
										}
									};
									_timer.schedule(t, (int)(100));
								}
							}
						}
					}
				}
			}
		});
	}
	private void initializeLogic() {
		edittext1.setText(FileUtil.getExternalStorageDir().concat("/"));
		edittext3.setText(FileUtil.getExternalStorageDir().concat("/"));
		edittext4.setText(FileUtil.getExternalStorageDir().concat("/"));
		edittext2.setText(FileUtil.getExternalStorageDir().concat("/"));
		_radius_to(card1, 14, 8, "#FFFFFF");
		_radius_to(card2, 14, 8, "#FFFFFF");
		_radius_to(edittext4, 12, 1, "#EEEEEE");
		_radius_to(edittext2, 12, 1, "#EEEEEE");
		_radius_to(edittext1, 12, 1, "#EEEEEE");
		_radius_to(edittext3, 12, 1, "#EEEEEE");
		_radius_to(button1, 50, 1, "#2196F3");
		_radius_to(button2, 50, 1, "#2196F3");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _zip (final String _source, final String _destination) {
		FileUtil.writeFile("Don't Remove it Thanks.\nModified By: Manish Nirmal", "This Block Added for Manage Permission");
		try {
			java.util.zip.ZipOutputStream os = new java.util.zip.ZipOutputStream(new java.io.FileOutputStream(_destination));
					zip(os, _source, null);
					os.close();
		}
		
		catch(java.io.IOException e) {}
	}
	private void zip(java.util.zip.ZipOutputStream os, String filePath, String name) throws java.io.IOException
		{
				java.io.File file = new java.io.File(filePath);
				java.util.zip.ZipEntry entry = new java.util.zip.ZipEntry((name != null ? name + java.io.File.separator : "") + file.getName() + (file.isDirectory() ? java.io.File.separator : ""));
				os.putNextEntry(entry);
				
				if(file.isFile()) {
						java.io.InputStream is = new java.io.FileInputStream(file);
						int size = is.available();
						byte[] buff = new byte[size];
						int len = is.read(buff);
						os.write(buff, 0, len);
						return;
				}
				
				java.io.File[] fileArr = file.listFiles();
				for(java.io.File subFile : fileArr) {
						zip(os, subFile.getAbsolutePath(), entry.getName());
				}
	}
	
	
	private void _UnZip (final String _fileZip, final String _destDir) {
		try
		{
			java.io.File outdir = new java.io.File(_destDir);
			java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(_fileZip));
			java.util.zip.ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null)
			{
				name = entry.getName();
				if(entry.isDirectory())
				{
					mkdirs(outdir, name);
					continue;
				}
				
				/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (java.io.IOException e)
		{
			e.printStackTrace();
		}
	}
	private static void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
	{
		byte[] buffer = new byte[4096];
		java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(java.io.File outdir, String path)
	{
		java.io.File d = new java.io.File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name)
	{
		int s = name.lastIndexOf(java.io.File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
	
	
	private void _radius_to (final View _view, final double _radius, final double _shadow, final String _color) {
		/*Created by Manish Nirmal */
		android.graphics.drawable.GradientDrawable ab = new android.graphics.drawable.GradientDrawable();
		
		ab.setColor(Color.parseColor(_color));
		ab.setCornerRadius((float) _radius);
		_view.setElevation((float) _shadow);
		_view.setBackground(ab);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
