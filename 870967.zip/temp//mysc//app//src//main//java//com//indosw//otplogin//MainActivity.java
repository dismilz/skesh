package com.indosw.otplogin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private String phoneNumber = "";
	private String credential = "";
	private String verificationCode = "";
	private String otp = "";
	private double NumbCountDown = 0;
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear12;
	private ImageView imageview2;
	private LinearLayout linear8;
	private ImageView imageview3;
	private LinearLayout linear9;
	private ImageView imageview4;
	private LinearLayout linear10;
	private ImageView imageview5;
	private LinearLayout linear11;
	private ImageView imageview6;
	private LinearLayout linear13;
	private ImageView imageview7;
	private ImageView imageview1;
	private LinearLayout linearphone;
	private LinearLayout linear_kode;
	private LinearLayout linear4;
	private LinearLayout linearresend;
	private TextView kodenegara;
	private EditText phone;
	private EditText kode;
	private Button send;
	private Button verify;
	private TextView resend;
	private ImageView refresh;
	private TextView countdown;
	private TextView textview1;
	private TextView textview2;
	private TextView textview3;
	private TextView textview4;
	private TextView textview5;
	private TextView textview6;
	private TextView textview7;
	
	private Intent i = new Intent();
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private TimerTask tmr;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linearphone = (LinearLayout) findViewById(R.id.linearphone);
		linear_kode = (LinearLayout) findViewById(R.id.linear_kode);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linearresend = (LinearLayout) findViewById(R.id.linearresend);
		kodenegara = (TextView) findViewById(R.id.kodenegara);
		phone = (EditText) findViewById(R.id.phone);
		kode = (EditText) findViewById(R.id.kode);
		send = (Button) findViewById(R.id.send);
		verify = (Button) findViewById(R.id.verify);
		resend = (TextView) findViewById(R.id.resend);
		refresh = (ImageView) findViewById(R.id.refresh);
		countdown = (TextView) findViewById(R.id.countdown);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview7 = (TextView) findViewById(R.id.textview7);
		auth = FirebaseAuth.getInstance();
		
		phone.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				phoneNumber = kodenegara.getText().toString().concat(_charSeq);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		kode.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				otp = _charSeq;
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		send.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				com.google.firebase.auth.PhoneAuthProvider.getInstance().verifyPhoneNumber(phoneNumber, (long)60, java.util.concurrent.TimeUnit.SECONDS, MainActivity.this, mCallback);
			}
		});
		
		verify.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				com.google.firebase.auth.PhoneAuthCredential credential = com.google.firebase.auth.PhoneAuthProvider.getCredential(verificationCode, otp);
				auth.signInWithCredential(credential).addOnCompleteListener(MainActivity.this, _auth_sign_in_listener);
			}
		});
		
		resend.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				com.google.firebase.auth.PhoneAuthProvider.getInstance().verifyPhoneNumber(phoneNumber, (long)60, java.util.concurrent.TimeUnit.SECONDS, MainActivity.this, mCallback);
			}
		});
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					i.setAction(Intent.ACTION_VIEW);
					i.setClass(getApplicationContext(), HomeActivity.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
					finish();
				}
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		linearresend.setVisibility(View.GONE);
		linear_kode.setVisibility(View.GONE);
		verify.setVisibility(View.GONE);
		resend.setEnabled(false);
		NumbCountDown = 60;
		_radius_to(linearphone, 125, 10, "#FFFFFF");
		_radius_to(linear_kode, 125, 10, "#FFFFFF");
		_radius_to(linearresend, 125, 10, "#263238");
		_radius_to(send, 125, 10, "#2196F3");
		_radius_to(verify, 125, 10, "#2196F3");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _MBauthphone () {
	}
	com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallback = new com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
		@Override
		public void onVerificationCompleted(com.google.firebase.auth.PhoneAuthCredential phoneAuthCredential) {
			Toast.makeText(MainActivity.this,"Code Received",Toast.LENGTH_SHORT).show();
			
			linear_kode.setVisibility(View.VISIBLE);
			linearphone.setVisibility(View.GONE);
			send.setVisibility(View.GONE);
			verify.setVisibility(View.VISIBLE);
			linearresend.setVisibility(View.GONE);
			NumbCountDown = 60;
			tmr.cancel();
		}
		
		@Override
		public void onVerificationFailed(com.google.firebase.FirebaseException e) {
			//if verification failed Toast.makeText(MainActivity.this,"verification fialed",Toast.LENGTH_SHORT).show();
		}
		
		@Override
		public void onCodeSent(String s, com.google.firebase.auth.PhoneAuthProvider.ForceResendingToken forceResendingToken) {
			super.onCodeSent(s, forceResendingToken);
			verificationCode = s;
			//if success add your command here
			//If error
			
			linearresend.setVisibility(View.VISIBLE);
			refresh.setVisibility(View.VISIBLE);
			countdown.setVisibility(View.VISIBLE);
			resend.setVisibility(View.INVISIBLE);
			tmr = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							NumbCountDown--;
							countdown.setText(String.valueOf((long)(NumbCountDown)));
							if (Double.parseDouble(countdown.getText().toString()) == 0) {
								NumbCountDown = 60;
								resend.setEnabled(true);
								refresh.setVisibility(View.GONE);
								countdown.setVisibility(View.GONE);
								resend.setVisibility(View.VISIBLE);
								tmr.cancel();
							}
						}
					});
				}
			};
			_timer.scheduleAtFixedRate(tmr, (int)(1000), (int)(1000));
			linearphone.setVisibility(View.GONE);
			linear_kode.setVisibility(View.VISIBLE);
			send.setVisibility(View.GONE);
			verify.setVisibility(View.VISIBLE);
			Toast.makeText(MainActivity.this,"Code sent",Toast.LENGTH_SHORT).show();
		}
	};
	
	{
	}
	
	
	private void _radius_to (final View _view, final double _radius, final double _shadow, final String _color) {
		android.graphics.drawable.GradientDrawable ab = new android.graphics.drawable.GradientDrawable();
		
		ab.setColor(Color.parseColor(_color));
		ab.setCornerRadius((float) _radius);
		_view.setElevation((float) _shadow);
		_view.setBackground(ab);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
