package com.ovi.telme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.CompoundButton;
import com.bumptech.glide.Glide;

public class ProfileViewActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String fontName = "";
	private String typeace = "";
	private HashMap<String, Object> map = new HashMap<>();
	private double n = 0;
	private double fans = 0;
	private double stars = 0;
	private String userpost = "";
	private String selfpost = "";
	private HashMap<String, Object> mymap = new HashMap<>();
	private HashMap<String, Object> mymap2 = new HashMap<>();
	private String uid = "";
	
	private ArrayList<HashMap<String, Object>> info = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	private ArrayList<String> followers = new ArrayList<>();
	private ArrayList<String> following = new ArrayList<>();
	private ArrayList<String> allkeys = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> post_map = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear4;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private Switch switch1;
	private ImageView imageview1;
	private TextView textview1;
	private TextView textview2;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private TextView textview9;
	private TextView bio;
	private TextView textview11;
	private TextView gender;
	private TextView textview15;
	private TextView phone;
	private LinearLayout linear10;
	private LinearLayout linear3;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private TextView textview3;
	private TextView textview4;
	private TextView textview5;
	private TextView textview6;
	private TextView textview7;
	private TextView textview8;
	private Button button1;
	private Button button2;
	
	private DatabaseReference usersdata = _firebase.getReference("usersdata");
	private ChildEventListener _usersdata_child_listener;
	private FirebaseAuth Account;
	private OnCompleteListener<AuthResult> _Account_create_user_listener;
	private OnCompleteListener<AuthResult> _Account_sign_in_listener;
	private OnCompleteListener<Void> _Account_reset_password_listener;
	private Intent ed = new Intent();
	private DatabaseReference userposts = _firebase.getReference("+userposts+");
	private ChildEventListener _userposts_child_listener;
	private SharedPreferences mode;
	private DatabaseReference selfposts = _firebase.getReference("+selfposts+");
	private ChildEventListener _selfposts_child_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.profile_view);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		switch1 = (Switch) findViewById(R.id.switch1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		textview9 = (TextView) findViewById(R.id.textview9);
		bio = (TextView) findViewById(R.id.bio);
		textview11 = (TextView) findViewById(R.id.textview11);
		gender = (TextView) findViewById(R.id.gender);
		textview15 = (TextView) findViewById(R.id.textview15);
		phone = (TextView) findViewById(R.id.phone);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview8 = (TextView) findViewById(R.id.textview8);
		button1 = (Button) findViewById(R.id.button1);
		button2 = (Button) findViewById(R.id.button2);
		Account = FirebaseAuth.getInstance();
		mode = getSharedPreferences("mode", Activity.MODE_PRIVATE);
		
		switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					mode.edit().putString("night", "true").commit();
					linear1.setBackgroundColor(0xFF000000);
					_Shadow(12, 10, "#333333", linear2);
					_Shadow(5, 5, "#00BCD4", button1);
					_Shadow(5, 5, "#00BCD4", button2);
					linear4.setBackgroundColor(0xFF000000);
					switch1.setChecked(true);
				}
				else {
					mode.edit().putString("night", "false").commit();
					_Shadow(12, 10, "#FFFFFF", linear2);
					_Shadow(5, 5, "#00BCD4", button1);
					_Shadow(5, 5, "#00BCD4", button2);
				}
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ed.setClass(getApplicationContext(), EditProfileActivity.class);
				startActivity(ed);
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		_usersdata_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				usersdata.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						info = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								info.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							textview1.setText(_childValue.get("username").toString());
							textview2.setText(_childValue.get("email").toString());
							if (_childValue.containsKey("avatar")) {
								_curcle_igm_url(_childValue.get("avatar").toString(), imageview1);
							}
							else {
								imageview1.setImageResource(R.drawable.acc);
							}
							if (_childValue.containsKey("bio")) {
								bio.setText(_childValue.get("bio").toString());
							}
							else {
								bio.setText("Hey, I'm a new user of Telme Messanger. Follow me as Friendly. ");
							}
							if (_childValue.containsKey("gender")) {
								gender.setText(_childValue.get("gender").toString());
							}
							else {
								gender.setText("Male/Female");
							}
							if (_childValue.containsKey("phone")) {
								phone.setText(_childValue.get("phone").toString());
							}
							else {
								phone.setText("+xxxxxxxxxxxx");
							}
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				usersdata.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						info = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								info.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							textview1.setText(_childValue.get("username").toString());
							textview2.setText(_childValue.get("email").toString());
							if (_childValue.containsKey("avatar")) {
								_curcle_igm_url(_childValue.get("avatar").toString(), imageview1);
							}
							else {
								imageview1.setImageResource(R.drawable.acc);
							}
							if (_childValue.containsKey("bio")) {
								bio.setText(_childValue.get("bio").toString());
							}
							else {
								bio.setText("Hey, I'm a new user of Telme Messanger. Follow me as Friendly. ");
							}
							if (_childValue.containsKey("gender")) {
								gender.setText(_childValue.get("gender").toString());
							}
							else {
								gender.setText("Male/Female");
							}
							if (_childValue.containsKey("phone")) {
								phone.setText(_childValue.get("phone").toString());
							}
							else {
								phone.setText("+xxxxxxxxxxxx");
							}
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		usersdata.addChildEventListener(_usersdata_child_listener);
		
		_userposts_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				userposts.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						allkeys.add(_childKey);
						if (_childKey.equals("followers")) {
							SketchwareUtil.getAllKeysFromMap(_childValue, followers);
							n = 0;
							fans = 0;
							for(int _repeat20 = 0; _repeat20 < (int)(followers.size()); _repeat20++) {
								if (_childValue.get(followers.get((int)(n))).toString().equals("true")) {
									fans++;
								}
								else {
									
								}
								n++;
							}
							textview4.setText(String.valueOf((long)(fans)));
						}
						if (_childKey.equals("following")) {
							SketchwareUtil.getAllKeysFromMap(_childValue, following);
							n = 0;
							stars = 0;
							for(int _repeat40 = 0; _repeat40 < (int)(following.size()); _repeat40++) {
								if (_childValue.get(following.get((int)(n))).toString().equals("true")) {
									stars++;
								}
								else {
									
								}
								n++;
							}
							textview6.setText(String.valueOf((long)(stars)));
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				userposts.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						allkeys.add(_childKey);
						if (_childKey.equals("followers")) {
							SketchwareUtil.getAllKeysFromMap(_childValue, followers);
							n = 0;
							fans = 0;
							for(int _repeat20 = 0; _repeat20 < (int)(followers.size()); _repeat20++) {
								if (_childValue.get(followers.get((int)(n))).toString().equals("true")) {
									fans++;
								}
								else {
									
								}
								n++;
							}
							textview4.setText(String.valueOf((long)(fans)));
						}
						if (_childKey.equals("following")) {
							SketchwareUtil.getAllKeysFromMap(_childValue, following);
							n = 0;
							stars = 0;
							for(int _repeat40 = 0; _repeat40 < (int)(following.size()); _repeat40++) {
								if (_childValue.get(following.get((int)(n))).toString().equals("true")) {
									stars++;
								}
								else {
									
								}
								n++;
							}
							textview6.setText(String.valueOf((long)(stars)));
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		userposts.addChildEventListener(_userposts_child_listener);
		
		_selfposts_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		selfposts.addChildEventListener(_selfposts_child_listener);
		
		_Account_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_Account_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_Account_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		_changeActivityFont("com");
		if (mode.getString("night", "").equals("true")) {
			linear1.setBackgroundColor(0xFF000000);
			_Shadow(12, 10, "#333333", linear2);
			_Shadow(5, 5, "#00BCD4", button1);
			_Shadow(5, 5, "#00BCD4", button2);
			linear4.setBackgroundColor(0xFF000000);
			switch1.setChecked(true);
		}
		else {
			_Shadow(12, 10, "#FFFFFF", linear2);
			_Shadow(5, 5, "#00BCD4", button1);
			_Shadow(5, 5, "#00BCD4", button2);
		}
		userposts.removeEventListener(_userposts_child_listener);
		userpost = "userposts/".concat(getIntent().getStringExtra("uid"));
		selfposts.removeEventListener(_selfposts_child_listener);
		selfpost = "userposts/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid());
		userposts =
		_firebase.getReference(userpost);
		selfposts =
		_firebase.getReference(selfpost);
		userposts.addChildEventListener(_userposts_child_listener);
		selfposts.addChildEventListener(_selfposts_child_listener);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _changeActivityFont (final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				}
				else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					}
					else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	private void _Shadow (final double _sadw, final double _cru, final String _wc, final View _widgets) {
		android.graphics.drawable.GradientDrawable wd = new android.graphics.drawable.GradientDrawable();
		wd.setColor(Color.parseColor(_wc));
		wd.setCornerRadius((int)_cru);
		_widgets.setElevation((int)_sadw);
		_widgets.setBackground(wd);
	}
	
	
	private void _curcle_igm_url (final String _url, final ImageView _img_view) {
		
		Glide.with(getApplicationContext()).load(_url).asBitmap().centerCrop().into(new com.bumptech.glide.request.target.BitmapImageViewTarget(_img_view) {
			@Override protected void setResource(Bitmap resource) {
				android.support.v4.graphics.drawable.RoundedBitmapDrawable circularBitmapDrawable = android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory.create(getApplicationContext().getResources(), resource); circularBitmapDrawable.setCircular(true); _img_view.setImageDrawable(circularBitmapDrawable);
			}
		});
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
