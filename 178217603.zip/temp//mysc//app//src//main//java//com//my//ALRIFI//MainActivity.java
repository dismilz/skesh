package com.my.ALRIFI;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Button;
import android.widget.Switch;
import android.content.Intent;
import android.net.Uri;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.app.AlertDialog;
import android.content.DialogInterface;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Timer;
import java.util.TimerTask;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.CompoundButton;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private double nn = 0;
	private String a = "";
	private String b = "";
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private TextView textview1;
	private ImageView imageview1;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear15;
	private ImageView imageview2;
	private LinearLayout linear7;
	private LinearLayout linear9;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private Button button2;
	private Switch switch1;
	private Button button7;
	private Button button9;
	private Button button8;
	private Button button11;
	
	private Intent oo = new Intent();
	private ObjectAnimator nnn = new ObjectAnimator();
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	private Calendar s = Calendar.getInstance();
	private TimerTask e;
	private SharedPreferences v;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		textview1 = (TextView) findViewById(R.id.textview1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		button2 = (Button) findViewById(R.id.button2);
		switch1 = (Switch) findViewById(R.id.switch1);
		button7 = (Button) findViewById(R.id.button7);
		button9 = (Button) findViewById(R.id.button9);
		button8 = (Button) findViewById(R.id.button8);
		button11 = (Button) findViewById(R.id.button11);
		d = new AlertDialog.Builder(this);
		v = getSharedPreferences("v", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				nn++;
				if (nn == 1) {
					nnn.setTarget(linear6);
					nnn.setPropertyName("translationX");
					nnn.setFloatValues((float)(0), (float)(-480));
					nnn.setDuration((int)(300));
					nnn.setInterpolator(new LinearInterpolator());
					nnn.start();
				}
				else {
					if (nn == 2) {
						nnn.setTarget(linear6);
						nnn.setPropertyName("translationX");
						nnn.setFloatValues((float)(-480), (float)(0));
						nnn.setDuration((int)(300));
						nnn.setInterpolator(new LinearInterpolator());
						nnn.start();
						nn = 0;
					}
				}
			}
		});
		
		linear6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				oo.setClass(getApplicationContext(), RifiActivity.class);
				startActivity(oo);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			}
		});
		
		switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					v.edit().putString("v", "true").commit();
				}
				else {
					if (!_isChecked) {
						v.edit().putString("v", "false").commit();
					}
				}
				if (_isChecked) {
					button2.setText("ابدأ");
					button7.setText("حول");
					button8.setText("خروج");
					button9.setText("مشاركة");
					switch1.setText("Englisch");
				}
				else {
					button2.setText("Start");
					button7.setText("About");
					button8.setText("Exit");
					button9.setText("Share");
					switch1.setText("العربية");
				}
			}
		});
		
		button7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.setMessage("            𝑴𝑶𝑯𝑨𝑴𝑴𝑨𝑫 𝑨𝑳 𝑹𝑰𝑭𝑰\n\n                          😘😄😀");
				d.create().show();
			}
		});
		
		button9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				//First Put Below Code In OnCreate
				
				android.os.StrictMode.VmPolicy.Builder builder = new android.os.StrictMode.VmPolicy.Builder();
				 android.os.StrictMode.setVmPolicy(builder.build());
				
				//Now Use Below Code As Per Your Needs
				
				String apk = "";
				String uri = ("com.my.ALRIFI");
				
				try {
					android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(uri, android.content.pm.PackageManager.GET_ACTIVITIES);
					
					apk = pi.applicationInfo.publicSourceDir;
				} catch (Exception e) {
					showMessage(e.toString());
				}
				Intent iten = new Intent(Intent.ACTION_SEND);
				iten.setType("*/*");
				iten.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new java.io.File(apk)));
				
				startActivity(Intent.createChooser(iten, " APK")); 
			}
		});
		
		button8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finishAffinity( );
			}
		});
		
		button11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				oo.setClass(getApplicationContext(), MainActivity.class);
				startActivity(oo);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			}
		});
	}
	private void initializeLogic() {
		nn = 0;
		e = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						s = Calendar.getInstance();
						textview1.setText(new SimpleDateFormat("hh:mm:ss:aa").format(s.getTime()));
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(e, (int)(1), (int)(2));
		if (v.getString("v", "").equals("true")) {
			switch1.setChecked(true);
		}
		else {
			if (v.getString("v", "").equals("false")) {
				switch1.setChecked(false);
			}
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		finishAffinity( );
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
