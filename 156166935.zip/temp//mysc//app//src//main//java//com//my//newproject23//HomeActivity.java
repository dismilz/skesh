package com.my.newproject23;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.speech.SpeechRecognizer;
import android.speech.RecognizerIntent;
import android.speech.RecognitionListener;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Timer;
import java.util.TimerTask;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.view.View;
import android.widget.AdapterView;
import android.net.Uri;
import java.text.DecimalFormat;
import android.Manifest;
import android.content.pm.PackageManager;

public class HomeActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private String FilePath = "";
	private double rise = 0;
	private double count = 0;
	private double minute = 0;
	private double mappos = 0;
	private double z = 0;
	private double ok = 0;
	private String path = "";
	
	private ArrayList<HashMap<String, Object>> map = new ArrayList<>();
	private ArrayList<String> as = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ImageView imageview1;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private TextView textview1;
	private TextView textview2;
	private TextView textview4;
	private TextView textview3;
	private ListView listview1;
	
	private SpeechRecognizer talking;
	private Calendar ca = Calendar.getInstance();
	private TimerTask coun;
	private ObjectAnimator animation = new ObjectAnimator();
	private TimerTask ani;
	private AlertDialog.Builder d;
	private MediaPlayer mp;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.RECORD_AUDIO}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview3 = (TextView) findViewById(R.id.textview3);
		listview1 = (ListView) findViewById(R.id.listview1);
		talking = SpeechRecognizer.createSpeechRecognizer(this);
		d = new AlertDialog.Builder(this);
		
		linear1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				rise++;
				if (rise == 1) {
					ca = Calendar.getInstance();
					FilePath = FileUtil.getExternalStorageDir().concat("/".concat("My Recordings/")).concat("Record-".concat(new SimpleDateFormat("hh").format(ca.getTime()).concat("-".concat(new SimpleDateFormat("mm").format(ca.getTime()).concat("-".concat(new SimpleDateFormat("ss").format(ca.getTime()).concat("-")).concat(new SimpleDateFormat("dd-MM-yyyy").format(ca.getTime()))))))).concat(".ogg");
					myAudioRecorder = new MediaRecorder(); myAudioRecorder.setAudioSource(MediaRecorder.AudioSource.MIC); myAudioRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP); myAudioRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB); myAudioRecorder.setOutputFile(FilePath);
					try { myAudioRecorder.prepare(); myAudioRecorder.start(); } catch (Exception e) {}
					coun = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									count++;
									textview3.setText(String.valueOf((long)(count)));
									if (count == 60) {
										count = 0;
										minute++;
										textview2.setText(String.valueOf((long)(minute)));
										textview3.setText("00");
									}
									else {
										
									}
								}
							});
						}
					};
					_timer.scheduleAtFixedRate(coun, (int)(0), (int)(1000));
					SketchwareUtil.showMessage(getApplicationContext(), "Recording started");
					ani = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									animation.setTarget(imageview1);
									animation.setPropertyName("alpha");
									animation.setFloatValues((float)(0.4d), (float)(1));
									animation.setDuration((int)(3000));
									animation.setInterpolator(new BounceInterpolator());
									animation.start();
								}
							});
						}
					};
					_timer.scheduleAtFixedRate(ani, (int)(0), (int)(3000));
					textview1.setText("Recording");
				}
				else {
					if (rise == 2) {
						ani.cancel();
						coun.cancel();
						rise = 0;
						count = 0;
						try { myAudioRecorder.stop(); myAudioRecorder.release(); myAudioRecorder = null; } catch(Exception e) {}
						SketchwareUtil.showMessage(getApplicationContext(), "Saved recording");
						textview2.setText("0");
						textview3.setText("0");
						textview1.setText("Record");
						map.clear();
						FileUtil.listDir(FileUtil.getExternalStorageDir().concat("/My Recordings/"), as);
						z = 0;
						for(int _repeat136 = 0; _repeat136 < (int)(as.size()); _repeat136++) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("audio", Uri.parse(as.get((int)(z))).getLastPathSegment());
								map.add((int)z, _item);
							}
							
							z++;
						}
						listview1.setAdapter(new Listview1Adapter(map));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
				}
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				d.setMessage("Delete ".concat(map.get((int)_position).get("audio").toString()));
				d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						FileUtil.deleteFile(as.get((int)(_position)));
						map.remove((int)(_position));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
				});
				d.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				d.create().show();
				return true;
			}
		});
	}
	private void initializeLogic() {
		z = 0;
		_ref3();
		android.graphics.drawable.GradientDrawable CRNQQ = new android.graphics.drawable.GradientDrawable();
		CRNQQ.setColor(Color.parseColor("#263238"));
		CRNQQ.setCornerRadii(new float[]{ (float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10,(float) 10 });
		CRNQQ.setStroke((int) 3, Color.parseColor("#ffffff"));
		linear3.setElevation((float) 5);
		linear3.setBackground(CRNQQ);
		//Milz
		android.graphics.drawable.GradientDrawable CRNOG = new android.graphics.drawable.GradientDrawable();
		CRNOG.setColor(Color.parseColor("#2196f3"));
		CRNOG.setCornerRadii(new float[]{ (float) 0,(float) 0,(float) 0,(float) 0,(float) 0,(float) 0,(float) 0,(float) 0 });
		CRNOG.setStroke((int) 4, Color.parseColor("#000000"));
		linear4.setElevation((float) 5);
		linear4.setBackground(CRNOG);
		//Milz
		android.graphics.drawable.GradientDrawable CRNKK = new android.graphics.drawable.GradientDrawable();
		CRNKK.setColor(Color.parseColor("#2196f3"));
		CRNKK.setCornerRadii(new float[]{ (float) 0,(float) 0,(float) 0,(float) 0,(float) 0,(float) 0,(float) 0,(float) 0 });
		CRNKK.setStroke((int) 4, Color.parseColor("#000000"));
		linear3.setElevation((float) 5);
		linear3.setBackground(CRNKK);
		//Milz
		
	} private MediaRecorder myAudioRecorder; private void fo4o() {
		
		FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/My Recordings"));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (rise == 1) {
			SketchwareUtil.showMessage(getApplicationContext(), "Recording in progress");
		}
		else {
			finishAffinity();
		}
	}
	private void _Settext (final TextView _textview, final double _Minutes, final double _Seconds) {
		_textview.setText(String.valueOf((long)((_Minutes / 1000) / 60)).concat(":".concat(new DecimalFormat("00").format((_Seconds / 1000) % 60))));
	}
	
	
	private void _ref3 () {
		FileUtil.listDir(FileUtil.getExternalStorageDir().concat("/My Recordings/"), as);
		z = 0;
		for(int _repeat14 = 0; _repeat14 < (int)(as.size()); _repeat14++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("audio", Uri.parse(as.get((int)(z))).getLastPathSegment());
				map.add((int)z, _item);
			}
			
			z++;
		}
		listview1.setAdapter(new Listview1Adapter(map));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	
	private void _Share (final String _dat, final boolean _file, final String _des) {
		if (_file) {
			Intent shareIntent = new Intent(Intent.ACTION_SEND); shareIntent.setType("text/plain");
			shareIntent.putExtra(Intent.EXTRA_TEXT, (_des)); shareIntent.putExtra(Intent.EXTRA_STREAM, Uri.parse(_dat));
			startActivity(Intent.createChooser(shareIntent, "Share"));
			//By GiantMurloc\\
		}
		else {
			Intent shareIntent = new Intent(Intent.ACTION_SEND); shareIntent.setType("text/plain"); shareIntent.putExtra(Intent.EXTRA_TEXT, (_dat));
			startActivity(Intent.createChooser(shareIntent, "Share"));
		}
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.recordings, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final LinearLayout linear3 = (LinearLayout) _v.findViewById(R.id.linear3);
			final LinearLayout linear4 = (LinearLayout) _v.findViewById(R.id.linear4);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			final ImageView imageview2 = (ImageView) _v.findViewById(R.id.imageview2);
			
			textview1.setText(map.get((int)_position).get("audio").toString());
			linear4.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_Share(as.get((int)(_position)), true, "Recording");
				}
			});
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
