package com.SKETCHit.login.register;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;

public class SkresetpasswordActivity extends AppCompatActivity {
	
	
	private HashMap<String, Object> map = new HashMap<>();
	private String email = "";
	private String password = "";
	
	private LinearLayout head;
	private LinearLayout linear2;
	private ImageView imageview13;
	private LinearLayout linearcolor;
	private TextView textview_head;
	private TextView textview2;
	private TextView textview5;
	private TextView textview3;
	private LinearLayout linearlogo;
	private LinearLayout linear3;
	private LinearLayout linear5;
	private ImageView imageview2;
	private Button button2;
	
	private FirebaseAuth fbauth;
	private OnCompleteListener<AuthResult> _fbauth_create_user_listener;
	private OnCompleteListener<AuthResult> _fbauth_sign_in_listener;
	private OnCompleteListener<Void> _fbauth_reset_password_listener;
	private Intent join = new Intent();
	private AlertDialog.Builder dialog;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.skresetpassword);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		head = (LinearLayout) findViewById(R.id.head);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		imageview13 = (ImageView) findViewById(R.id.imageview13);
		linearcolor = (LinearLayout) findViewById(R.id.linearcolor);
		textview_head = (TextView) findViewById(R.id.textview_head);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview3 = (TextView) findViewById(R.id.textview3);
		linearlogo = (LinearLayout) findViewById(R.id.linearlogo);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		button2 = (Button) findViewById(R.id.button2);
		fbauth = FirebaseAuth.getInstance();
		dialog = new AlertDialog.Builder(this);
		
		imageview13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				email = edittext1.getText().toString();
				map = new HashMap<>();
				map.put("mail", email);
				textview2.setText(map.get("mail").toString());
				if (textview2.getText().toString().length() == 0) {
					edittext1.setError("Please enter your email");
				}
				else {
					if (!textview2.getText().toString().matches("[a-zA-Z0-9._-]+@[a-z]+.[a-z]+")) {
						edittext1.setError("Invalid Email!");
					}
					else {
						dialog.setTitle("Password Reset");
						dialog.setMessage("Are you sure to reset your password?");
						dialog.setCancelable(false);
						dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								fbauth.sendPasswordResetEmail(textview2.getText().toString()).addOnCompleteListener(_fbauth_reset_password_listener);
							}
						});
						dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						dialog.create().show();
					}
				}
			}
		});
		
		_fbauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fbauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fbauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				if (_success) {
					SketchwareUtil.showMessage(getApplicationContext(), "A link has been sent to your email to reset your password");
					finish();
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Oops, there was an error!");
				}
			}
		};
	}
	private void initializeLogic() {
		edittext1 = new EditText(this);
		edittext1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
		edittext1.setInputType(InputType.TYPE_CLASS_TEXT);
		edittext1.setHint("Email");
		/*This Code Is Migrate With [Sketch MigratorX App] Developed By Developer Partha*/com.google.android.material.textfield.TextInputLayout textinput1 = new com.google.android.material.textfield.TextInputLayout(this);
		textinput1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
		textinput1.addView(edittext1);
		linear3.addView(textinput1);/*This Code Is Migrate With [Sketch MigratorX App]

Download Now From Play Store :-
 https://play.google.com/store/apps/details?id=com.cubestudiodev.sketchmigratorx

Developed By Developer Partha*/
		android.graphics.drawable.GradientDrawable gdd = new android.graphics.drawable.GradientDrawable();
		gdd.setColor(Color.parseColor("#4DD0E1"));
		gdd.setCornerRadius(25);
		button2.setBackground(gdd);
		
		android.graphics.drawable.GradientDrawable ab = new android.graphics.drawable.GradientDrawable();
		
		ab.setColor(Color.parseColor("#FFFFFF"));
		
		head.setElevation(11);
		head.setBackground(ab);
		linearcolor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		textview2.setVisibility(View.INVISIBLE);
		textview5.setVisibility(View.INVISIBLE);
		textview3.setVisibility(View.INVISIBLE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _extra () {
	}
	EditText edittext1, edittext2;
	{
	}
	
	
	private void _ripple (final View _v) {
		android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}},new int[]{Color.parseColor("#b0bec5")});
		android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , null, null);
		_v.setBackground(ripdrb);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
