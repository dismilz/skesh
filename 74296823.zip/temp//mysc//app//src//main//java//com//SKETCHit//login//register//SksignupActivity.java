package com.SKETCHit.login.register;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;

public class SksignupActivity extends AppCompatActivity {
	
	
	private HashMap<String, Object> map = new HashMap<>();
	private String username = "";
	private String email = "";
	private String password = "";
	private String re_password = "";
	private String uid = "";
	private HashMap<String, Object> upload = new HashMap<>();
	
	private LinearLayout head;
	private LinearLayout linear2;
	private ImageView imageview13;
	private LinearLayout linearcolor;
	private TextView textview_head;
	private LinearLayout linear8;
	private LinearLayout linearlogo;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear5;
	private ImageView imageview2;
	private Button button2;
	private LinearLayout linear9;
	private TextView textview2;
	private TextView textview3;
	private TextView textview4;
	private TextView textview5;
	private TextView textview8;
	private TextView textview7;
	
	private FirebaseAuth fbauth;
	private OnCompleteListener<AuthResult> _fbauth_create_user_listener;
	private OnCompleteListener<AuthResult> _fbauth_sign_in_listener;
	private OnCompleteListener<Void> _fbauth_reset_password_listener;
	private SharedPreferences sharedata;
	private Intent home = new Intent();
	private Intent signin = new Intent();
	private Calendar date = Calendar.getInstance();
	private AlertDialog.Builder dialog;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.sksignup);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		head = (LinearLayout) findViewById(R.id.head);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		imageview13 = (ImageView) findViewById(R.id.imageview13);
		linearcolor = (LinearLayout) findViewById(R.id.linearcolor);
		textview_head = (TextView) findViewById(R.id.textview_head);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linearlogo = (LinearLayout) findViewById(R.id.linearlogo);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		button2 = (Button) findViewById(R.id.button2);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview8 = (TextView) findViewById(R.id.textview8);
		textview7 = (TextView) findViewById(R.id.textview7);
		fbauth = FirebaseAuth.getInstance();
		sharedata = getSharedPreferences("sharedata", Activity.MODE_PRIVATE);
		dialog = new AlertDialog.Builder(this);
		
		imageview13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				username = edittext1.getText().toString();
				email = edittext2.getText().toString();
				password = edittext3.getText().toString();
				re_password = edittext4.getText().toString();
				map = new HashMap<>();
				map.put("user1", username);
				map.put("mail1", email);
				map.put("pass1", password);
				map.put("repass1", re_password);
				textview2.setText(map.get("user1").toString());
				textview3.setText(map.get("mail1").toString());
				textview4.setText(map.get("pass1").toString());
				textview5.setText(map.get("repass1").toString());
				if (textview2.getText().toString().length() == 0) {
					edittext1.setError("Please enter a username");
					button2.setText("SIGN UP");
				}
				else {
					if (textview2.getText().toString().length() > 20) {
						edittext1.setError("Maximum 20 characters");
						button2.setText("SIGN UP");
					}
					else {
						if (textview2.getText().toString().length() < 4) {
							edittext1.setError("Username must be at least 5 characters");
							button2.setText("SIGN UP");
						}
						else {
							if (textview3.getText().toString().length() == 0) {
								edittext2.setError("Please enter your email");
								button2.setText("SIGN UP");
							}
							else {
								if (!textview3.getText().toString().matches("[a-zA-Z0-9._-]+@[a-z]+.[a-z]+")) {
									edittext2.setError("Invalid Email!");
									button2.setText("SIGN UP");
								}
								else {
									if (textview4.getText().toString().length() == 0) {
										edittext3.setError("Please enter a password");
										button2.setText("SIGN UP");
									}
									else {
										if (textview4.getText().toString().length() < 4) {
											edittext3.setError("Password must be at least 5 characters");
											button2.setText("SIGN UP");
										}
										else {
											if ((textview4.getText().toString().length() < 5) || (textview4.getText().toString().length() == 0)) {
												edittext3.setError("Please enter a password at least 6 characters");
												button2.setText("SIGN UP");
											}
											else {
												if (textview5.getText().toString().length() == 0) {
													edittext4.setError("Not matching with the previous password");
													button2.setText("SIGN UP");
												}
												else {
													if (!textview4.getText().toString().equals(textview5.getText().toString())) {
														edittext4.setError("Not matching with the previous password");
														button2.setText("SIGN UP");
													}
													else {
														if (textview4.getText().toString().equals(textview5.getText().toString())) {
															fbauth.createUserWithEmailAndPassword(textview3.getText().toString(), textview5.getText().toString()).addOnCompleteListener(SksignupActivity.this, _fbauth_create_user_listener);
															button2.setText("Please wait...");
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		});
		
		textview8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				signin.setAction(Intent.ACTION_VIEW);
				signin.setClass(getApplicationContext(), SkloginActivity.class);
				startActivity(signin);
			}
		});
		
		_fbauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
					sharedata.edit().putString("uid", uid).commit();
					sharedata.edit().putString("uid1", uid).commit();
					sharedata.edit().putString("temp_email", textview3.getText().toString()).commit();
					sharedata.edit().putString("temp_pass", textview2.getText().toString()).commit();
					upload = new HashMap<>();
					upload.put("user_uid", uid);
					upload.put("user_status", "developer");
					upload.put("user_mail", textview3.getText().toString());
					upload.put("user_img", "");
					upload.put("up_count", "0");
					upload.put("user_bio", "");
					upload.put("user_name", textview2.getText().toString());
					upload.put("key", uid);
					upload.put("latest_date_signin", new SimpleDateFormat("dd/MM/yyyy").format(date.getTime()));
					upload.put("registered_date", new SimpleDateFormat("dd/MM/yyyy").format(date.getTime()));
					upload.put("account", "enable");
					upload.put("last_online", new SimpleDateFormat("dd/MM/yyyy").format(date.getTime()));
					upload.put("user_reports", "0");
					
					sharedata.edit().putString("new_email", textview3.getText().toString()).commit();
					sharedata.edit().putString("new_pass", textview2.getText().toString()).commit();
					_EmailVerification_();
					dialog.setTitle("Verification");
					dialog.setMessage("A link has been sent to your email\nClick on the link in the email of your active SKETCHit account");
					dialog.setCancelable(false);
					dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							FirebaseAuth.getInstance().signOut();
							finish();
						}
					});
					dialog.setNegativeButton("Cancellation", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							FirebaseAuth.getInstance().signOut();
							finish();
						}
					});
					dialog.create().show();
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
					FirebaseAuth.getInstance().signOut();
					finish();
				}
			}
		};
		
		_fbauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fbauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		dialog = new AlertDialog.Builder(this,AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
		android.graphics.drawable.GradientDrawable ab = new android.graphics.drawable.GradientDrawable();
		
		ab.setColor(Color.parseColor("#FFFFFF"));
		
		head.setElevation(11);
		head.setBackground(ab);
		linearcolor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		edittext1 = new EditText(this);
		edittext1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
		edittext1.setInputType(InputType.TYPE_CLASS_TEXT);
		edittext1.setHint("Username");
		edittext2 = new EditText(this);
		edittext2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
		edittext2.setInputType(InputType.TYPE_CLASS_TEXT);
		edittext2.setHint("Email");
		edittext3 = new EditText(this);
		edittext3.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
		edittext3.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
		edittext3.setHint("Password");
		edittext4 = new EditText(this);
		edittext4.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
		edittext4.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
		edittext4.setHint("Repeat Password");
		/*This Code Is Migrate With [Sketch MigratorX App] Developed By Developer Partha*/com.google.android.material.textfield.TextInputLayout textinput1 = new com.google.android.material.textfield.TextInputLayout(this);
		textinput1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
		textinput1.addView(edittext1);
		linear3.addView(textinput1);/*This Code Is Migrate With [Sketch MigratorX App]

Download Now From Play Store :-
 https://play.google.com/store/apps/details?id=com.cubestudiodev.sketchmigratorx

Developed By Developer Partha*/
		/*This Code Is Migrate With [Sketch MigratorX App] Developed By Developer Partha*/com.google.android.material.textfield.TextInputLayout textinput2 = new com.google.android.material.textfield.TextInputLayout(this);
		textinput2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
		textinput2.addView(edittext2);
		linear4.addView(textinput2);/*This Code Is Migrate With [Sketch MigratorX App]

Download Now From Play Store :-
 https://play.google.com/store/apps/details?id=com.cubestudiodev.sketchmigratorx

Developed By Developer Partha*/
		/*This Code Is Migrate With [Sketch MigratorX App] Developed By Developer Partha*/com.google.android.material.textfield.TextInputLayout textinput3 = new com.google.android.material.textfield.TextInputLayout(this);
		textinput3.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
		textinput3.addView(edittext3);
		linear6.addView(textinput3);/*This Code Is Migrate With [Sketch MigratorX App]

Download Now From Play Store :-
 https://play.google.com/store/apps/details?id=com.cubestudiodev.sketchmigratorx

Developed By Developer Partha*/
		/*This Code Is Migrate With [Sketch MigratorX App] Developed By Developer Partha*/com.google.android.material.textfield.TextInputLayout textinput4 = new com.google.android.material.textfield.TextInputLayout(this);
		textinput4.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
		textinput4.addView(edittext4);
		linear7.addView(textinput4);/*This Code Is Migrate With [Sketch MigratorX App]

Download Now From Play Store :-
 https://play.google.com/store/apps/details?id=com.cubestudiodev.sketchmigratorx

Developed By Developer Partha*/
		android.graphics.drawable.GradientDrawable gdd = new android.graphics.drawable.GradientDrawable();
		gdd.setColor(Color.parseColor("#4DD0E1"));
		gdd.setCornerRadius(25);
		button2.setBackground(gdd);
		
		textview2.setVisibility(View.INVISIBLE);
		textview3.setVisibility(View.GONE);
		textview4.setVisibility(View.GONE);
		textview5.setVisibility(View.GONE);
		sharedata.edit().putString("temp_email", "").commit();
		sharedata.edit().putString("temp_pass", "").commit();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _extra () {
	}
	EditText edittext1, edittext2,edittext3,edittext4;
	{
	}
	
	
	private void _clear () {
		map.clear();
		username = "";
		email = "";
		password = "";
		re_password = "";
		edittext1.setText("");
		edittext2.setText("");
		edittext3.setText("");
		edittext4.setText("");
	}
	
	
	private void _rippleEffect (final View _view, final String _color) {
		_view.setBackground(Drawables.getSelectableDrawableFor(Color.parseColor(_color)));
		_view.setClickable(true);
	}
	
	
	private void _Moreblock () {
	}
	
	public static class Drawables {
		    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {
			        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
				            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_pressed},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_focused},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            return stateListDrawable;
				        } else {
				            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);
				            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"));
				            
				android.graphics.drawable.Drawable rippleColor = getRippleColor(color);
				            return new android.graphics.drawable.RippleDrawable(
				                pressedColor,
				                defaultColor,
				                rippleColor
				            );
				        }
			    }
		
		    private static android.graphics.drawable.Drawable getRippleColor(int color) {
			        float[] outerRadii = new float[8];
			        Arrays.fill(outerRadii, 0);
			        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);
			        
			android.graphics.drawable.ShapeDrawable shapeDrawable = new 
			android.graphics.drawable.ShapeDrawable(r);
			        shapeDrawable.getPaint().setColor(color);
			        return shapeDrawable;
			    }
		 
		    private static int lightenOrDarken(int color, double fraction) {
			        if (canLighten(color, fraction)) {
				            return lighten(color, fraction);
				        } else {
				            return darken(color, fraction);
				        }
			    }
		 
		    private static int lighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = lightenColor(red, fraction);
			        green = lightenColor(green, fraction);
			        blue = lightenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static int darken(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = darkenColor(red, fraction);
			        green = darkenColor(green, fraction);
			        blue = darkenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			 
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static boolean canLighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        return canLightenComponent(red, fraction)
			            && canLightenComponent(green, fraction)
			            && canLightenComponent(blue, fraction);
			    }
		 
		    private static boolean canLightenComponent(int colorComponent, double fraction) {
			        int red = Color.red(colorComponent);
			        int green = Color.green(colorComponent);
			        int blue = Color.blue(colorComponent);
			        return red + (red * fraction) < 255
			            && green + (green * fraction) < 255
			            && blue + (blue * fraction) < 255;
			    }
		 
		    private static int darkenColor(int color, double fraction) {
			        return (int) Math.max(color - (color * fraction), 0);
			    }
		 
		    private static int lightenColor(int color, double fraction) {
			        return (int) Math.min(color + (color * fraction), 255);
			    }
	}
	public static class CircleDrawables {
		    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {
			        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
				            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_pressed},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_focused},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            return stateListDrawable;
				        } else {
				            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);
				            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"));
				            
				android.graphics.drawable.Drawable rippleColor = getRippleColor(color);
				            return new android.graphics.drawable.RippleDrawable(
				                pressedColor,
				                defaultColor,
				                rippleColor
				            );
				        }
			    }
		
		    private static android.graphics.drawable.Drawable getRippleColor(int color) {
			        float[] outerRadii = new float[180];
			        Arrays.fill(outerRadii, 80);
			        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);
			        
			android.graphics.drawable.ShapeDrawable shapeDrawable = new 
			android.graphics.drawable.ShapeDrawable(r);
			        shapeDrawable.getPaint().setColor(color);
			        return shapeDrawable;
			    }
		 
		    private static int lightenOrDarken(int color, double fraction) {
			        if (canLighten(color, fraction)) {
				            return lighten(color, fraction);
				        } else {
				            return darken(color, fraction);
				        }
			    }
		 
		    private static int lighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = lightenColor(red, fraction);
			        green = lightenColor(green, fraction);
			        blue = lightenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static int darken(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = darkenColor(red, fraction);
			        green = darkenColor(green, fraction);
			        blue = darkenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			 
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static boolean canLighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        return canLightenComponent(red, fraction)
			            && canLightenComponent(green, fraction)
			            && canLightenComponent(blue, fraction);
			    }
		 
		    private static boolean canLightenComponent(int colorComponent, double fraction) {
			        int red = Color.red(colorComponent);
			        int green = Color.green(colorComponent);
			        int blue = Color.blue(colorComponent);
			        return red + (red * fraction) < 255
			            && green + (green * fraction) < 255
			            && blue + (blue * fraction) < 255;
			    }
		 
		    private static int darkenColor(int color, double fraction) {
			        return (int) Math.max(color - (color * fraction), 0);
			    }
		 
		    private static int lightenColor(int color, double fraction) {
			        return (int) Math.min(color + (color * fraction), 255);
		}
	}
	
	public void drawableclass() {
	}
	
	
	private void _SnackBar (final String _message) {
		/*This Code Is Migrate With [Sketch MigratorX App] Developed By Developer Partha*/ViewGroup parentLayout = (ViewGroup) ((ViewGroup) this .findViewById(android.R.id.content)).getChildAt(0);
		   com.google.android.material.snackbar.Snackbar.make(parentLayout, _message, com.google.android.material.snackbar.Snackbar.LENGTH_LONG) 
		        .setAction("OK", new View.OnClickListener() {
			            @Override 
			            public void onClick(View view) {
				
				            } 
			        }).show();/*This Code Is Migrate With [Sketch MigratorX App]

Download Now From Play Store :-
 https://play.google.com/store/apps/details?id=com.cubestudiodev.sketchmigratorx

Developed By Developer Partha*/
	}
	
	
	private void _EmailVerification_ () {
		FirebaseAuth auth = FirebaseAuth.getInstance();
		com.google.firebase.auth.FirebaseUser user = 
		auth.getCurrentUser();
		
		user.sendEmailVerification().addOnCompleteListener
		(new 
		OnCompleteListener<Void>()
		{ @Override
			public void onComplete(Task task)
			{ if (task.isSuccessful()) {
					
					SketchwareUtil.showMessage(getApplicationContext(), "Verification email sent!");
				} else {
					
					SketchwareUtil.showMessage(getApplicationContext(), "Error sending verification message");
				}
			}});
	}
	
	
	private void _ripple (final View _v) {
		android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}},new int[]{Color.parseColor("#b0bec5")});
		android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , null, null);
		_v.setBackground(ripdrb);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
