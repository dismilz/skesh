package com.SKETCHit.login.register;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.app.Activity;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;

public class SkloginActivity extends AppCompatActivity {
	
	
	private String email = "";
	private String password = "";
	private HashMap<String, Object> map = new HashMap<>();
	private double count = 0;
	private HashMap<String, Object> user_map = new HashMap<>();
	private String uid = "";
	private HashMap<String, Object> upload = new HashMap<>();
	private HashMap<String, Object> dateup = new HashMap<>();
	private HashMap<String, Object> map1 = new HashMap<>();
	private String encrypted = "";
	private String decrypted = "";
	private String var_em = "";
	private String var_pas = "";
	
	private ArrayList<HashMap<String, Object>> users = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> newuser = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> maintenance1 = new ArrayList<>();
	
	private LinearLayout linear1;
	private TextView textview1;
	private TextView textview5;
	private LinearLayout linearcolor;
	private TextView textview3;
	private TextView textview4;
	private LinearLayout linearlogo;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private Button button1;
	private TextView textview6;
	private LinearLayout linear4;
	private ImageView imageview1;
	private TextView textview7;
	private Button button2;
	
	private Intent join = new Intent();
	private FirebaseAuth fbauth;
	private OnCompleteListener<AuthResult> _fbauth_create_user_listener;
	private OnCompleteListener<AuthResult> _fbauth_sign_in_listener;
	private OnCompleteListener<Void> _fbauth_reset_password_listener;
	private Intent homepage = new Intent();
	private SharedPreferences sharedata;
	private Intent forget = new Intent();
	private AlertDialog.Builder dialog;
	private AlertDialog.Builder dialog1;
	private RequestNetwork internet;
	private RequestNetwork.RequestListener _internet_request_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.sklogin);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview5 = (TextView) findViewById(R.id.textview5);
		linearcolor = (LinearLayout) findViewById(R.id.linearcolor);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		linearlogo = (LinearLayout) findViewById(R.id.linearlogo);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		button1 = (Button) findViewById(R.id.button1);
		textview6 = (TextView) findViewById(R.id.textview6);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview7 = (TextView) findViewById(R.id.textview7);
		button2 = (Button) findViewById(R.id.button2);
		fbauth = FirebaseAuth.getInstance();
		sharedata = getSharedPreferences("sharedata", Activity.MODE_PRIVATE);
		dialog = new AlertDialog.Builder(this);
		dialog1 = new AlertDialog.Builder(this);
		internet = new RequestNetwork(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				internet.startRequestNetwork(RequestNetworkController.GET, "http://google.com", "ags", _internet_request_listener);
			}
		});
		
		textview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				forget.setAction(Intent.ACTION_VIEW);
				forget.setClass(getApplicationContext(), SkresetpasswordActivity.class);
				startActivity(forget);
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				join.setAction(Intent.ACTION_VIEW);
				join.setClass(getApplicationContext(), SksignupActivity.class);
				startActivity(join);
			}
		});
		
		_internet_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				email = edittext1.getText().toString();
				password = edittext2.getText().toString();
				map = new HashMap<>();
				map.put("mail11", email);
				map.put("pass11", password);
				textview1.setText(map.get("mail11").toString());
				textview5.setText(map.get("pass11").toString());
				if (textview1.getText().toString().equals("")) {
					edittext1.setError("Please enter your Email");
					button1.setText("sign in");
				}
				else {
					if (!textview1.getText().toString().matches("[a-zA-Z0-9._-]+@[a-z]+.[a-z]+")) {
						edittext1.setError("Invalid Email!");
						button1.setText("sign in");
					}
					else {
						if (textview5.getText().toString().equals("")) {
							edittext2.setError("Please enter your password");
							button1.setText("sign in");
						}
						else {
							fbauth.signInWithEmailAndPassword(textview1.getText().toString(), textview5.getText().toString()).addOnCompleteListener(SkloginActivity.this, _fbauth_sign_in_listener);
							button1.setText("Please wait ...");
						}
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "No internet connection!");
			}
		};
		
		_fbauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fbauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					FirebaseAuth auth = FirebaseAuth.getInstance();
					com.google.firebase.auth.FirebaseUser user = 
					auth.getCurrentUser();
					
					if (user.isEmailVerified()) {
						homepage.setAction(Intent.ACTION_VIEW);
						
						startActivity(homepage);
						SketchwareUtil.showMessage(getApplicationContext(), "Welcome back!");
						finish();
					}
					else {
						dialog.setTitle("Unverified user");
						dialog.setCancelable(false);
						dialog.setMessage("Sorry, this user has not been verified.\nPlease choose to resend verification.");
						dialog.setPositiveButton("Resend", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								FirebaseAuth auth = FirebaseAuth.getInstance();
								com.google.firebase.auth.FirebaseUser user = 
								auth.getCurrentUser();
								
								user.sendEmailVerification().addOnCompleteListener
								(new 
								OnCompleteListener<Void>()
								{ @Override
									public void onComplete(Task task)
									{ if (task.isSuccessful()) {
											showMessage("Verification mail sent!");
										} else {
											showMessage("Error sending verification message");
										}
									}});
							}
						});
						dialog.setNegativeButton("not now", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								FirebaseAuth.getInstance().signOut();
							}
						});
						dialog.create().show();
					}
				}
				else {
					button1.setText("sign in");
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
					edittext1.setText("");
					edittext2.setText("");
				}
			}
		};
		
		_fbauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		dialog = new AlertDialog.Builder(this,AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
		dialog1 = new AlertDialog.Builder(this,AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
		linearcolor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		edittext1 = new EditText(this);
		edittext1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
		edittext1.setInputType(InputType.TYPE_CLASS_TEXT);
		edittext1.setHint("Email");
		edittext2 = new EditText(this);
		edittext2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
		edittext2.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
		edittext2.setHint("Password");
		/*This Code Is Migrate With [Sketch MigratorX App] Developed By Developer Partha*/com.google.android.material.textfield.TextInputLayout textinput1 = new com.google.android.material.textfield.TextInputLayout(this);
		textinput1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
		textinput1.addView(edittext1);
		linear2.addView(textinput1);/*This Code Is Migrate With [Sketch MigratorX App]

Download Now From Play Store :-
 https://play.google.com/store/apps/details?id=com.cubestudiodev.sketchmigratorx

Developed By Developer Partha*/
		/*This Code Is Migrate With [Sketch MigratorX App] Developed By Developer Partha*/com.google.android.material.textfield.TextInputLayout textinput2 = new com.google.android.material.textfield.TextInputLayout(this);
		textinput2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
		textinput2.addView(edittext2);
		linear3.addView(textinput2);/*This Code Is Migrate With [Sketch MigratorX App]

Download Now From Play Store :-
 https://play.google.com/store/apps/details?id=com.cubestudiodev.sketchmigratorx

Developed By Developer Partha*/
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor("#FFEA00"));
		gd.setCornerRadius(25);
		button1.setBackground(gd);
		
		android.graphics.drawable.GradientDrawable gdd = new android.graphics.drawable.GradientDrawable();
		gdd.setColor(Color.parseColor("#4DD0E1"));
		gdd.setCornerRadius(25);
		button2.setBackground(gdd);
		
		textview1.setVisibility(View.INVISIBLE);
		textview5.setVisibility(View.INVISIBLE);
		textview3.setVisibility(View.INVISIBLE);
		textview4.setVisibility(View.INVISIBLE);
		sharedata.edit().putString("new_email", "").commit();
		sharedata.edit().putString("new_pass", "").commit();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		finishAffinity();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (sharedata.getString("new_email", "").equals("")) {
			var_em = "";
			edittext1.setText(var_em);
		}
		else {
			var_em = sharedata.getString("new_email", "");
			edittext1.setText(var_em);
		}
		if (sharedata.getString("new_pass", "").equals("")) {
			var_pas = "";
			edittext2.setText(var_pas);
		}
		else {
			var_pas = sharedata.getString("new_pass", "");
			edittext2.setText(var_pas);
		}
	}
	private void _extra () {
	}
	EditText edittext1, edittext2;
	{
	}
	
	
	private void _rippleEffect (final View _view, final String _color) {
		_view.setBackground(Drawables.getSelectableDrawableFor(Color.parseColor(_color)));
		_view.setClickable(true);
	}
	
	
	private void _Moreblock () {
	}
	
	public static class Drawables {
		    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {
			        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
				            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_pressed},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_focused},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            return stateListDrawable;
				        } else {
				            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);
				            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"));
				            
				android.graphics.drawable.Drawable rippleColor = getRippleColor(color);
				            return new android.graphics.drawable.RippleDrawable(
				                pressedColor,
				                defaultColor,
				                rippleColor
				            );
				        }
			    }
		
		    private static android.graphics.drawable.Drawable getRippleColor(int color) {
			        float[] outerRadii = new float[8];
			        Arrays.fill(outerRadii, 0);
			        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);
			        
			android.graphics.drawable.ShapeDrawable shapeDrawable = new 
			android.graphics.drawable.ShapeDrawable(r);
			        shapeDrawable.getPaint().setColor(color);
			        return shapeDrawable;
			    }
		 
		    private static int lightenOrDarken(int color, double fraction) {
			        if (canLighten(color, fraction)) {
				            return lighten(color, fraction);
				        } else {
				            return darken(color, fraction);
				        }
			    }
		 
		    private static int lighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = lightenColor(red, fraction);
			        green = lightenColor(green, fraction);
			        blue = lightenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static int darken(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = darkenColor(red, fraction);
			        green = darkenColor(green, fraction);
			        blue = darkenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			 
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static boolean canLighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        return canLightenComponent(red, fraction)
			            && canLightenComponent(green, fraction)
			            && canLightenComponent(blue, fraction);
			    }
		 
		    private static boolean canLightenComponent(int colorComponent, double fraction) {
			        int red = Color.red(colorComponent);
			        int green = Color.green(colorComponent);
			        int blue = Color.blue(colorComponent);
			        return red + (red * fraction) < 255
			            && green + (green * fraction) < 255
			            && blue + (blue * fraction) < 255;
			    }
		 
		    private static int darkenColor(int color, double fraction) {
			        return (int) Math.max(color - (color * fraction), 0);
			    }
		 
		    private static int lightenColor(int color, double fraction) {
			        return (int) Math.min(color + (color * fraction), 255);
			    }
	}
	public static class CircleDrawables {
		    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {
			        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
				            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_pressed},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_focused},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            return stateListDrawable;
				        } else {
				            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);
				            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"));
				            
				android.graphics.drawable.Drawable rippleColor = getRippleColor(color);
				            return new android.graphics.drawable.RippleDrawable(
				                pressedColor,
				                defaultColor,
				                rippleColor
				            );
				        }
			    }
		
		    private static android.graphics.drawable.Drawable getRippleColor(int color) {
			        float[] outerRadii = new float[180];
			        Arrays.fill(outerRadii, 80);
			        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);
			        
			android.graphics.drawable.ShapeDrawable shapeDrawable = new 
			android.graphics.drawable.ShapeDrawable(r);
			        shapeDrawable.getPaint().setColor(color);
			        return shapeDrawable;
			    }
		 
		    private static int lightenOrDarken(int color, double fraction) {
			        if (canLighten(color, fraction)) {
				            return lighten(color, fraction);
				        } else {
				            return darken(color, fraction);
				        }
			    }
		 
		    private static int lighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = lightenColor(red, fraction);
			        green = lightenColor(green, fraction);
			        blue = lightenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static int darken(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = darkenColor(red, fraction);
			        green = darkenColor(green, fraction);
			        blue = darkenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			 
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static boolean canLighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        return canLightenComponent(red, fraction)
			            && canLightenComponent(green, fraction)
			            && canLightenComponent(blue, fraction);
			    }
		 
		    private static boolean canLightenComponent(int colorComponent, double fraction) {
			        int red = Color.red(colorComponent);
			        int green = Color.green(colorComponent);
			        int blue = Color.blue(colorComponent);
			        return red + (red * fraction) < 255
			            && green + (green * fraction) < 255
			            && blue + (blue * fraction) < 255;
			    }
		 
		    private static int darkenColor(int color, double fraction) {
			        return (int) Math.max(color - (color * fraction), 0);
			    }
		 
		    private static int lightenColor(int color, double fraction) {
			        return (int) Math.min(color + (color * fraction), 255);
		}
	}
	
	public void drawableclass() {
	}
	
	
	private void _ripple (final View _v) {
		android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}},new int[]{Color.parseColor("#b0bec5")});
		android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , null, null);
		_v.setBackground(ripdrb);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
