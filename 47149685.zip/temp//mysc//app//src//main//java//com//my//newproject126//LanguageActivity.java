package com.my.newproject126;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.CheckBox;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.widget.CompoundButton;
import android.view.View;

public class LanguageActivity extends Activity {
	
	
	private LinearLayout linear1;
	private TextView select;
	private CheckBox english;
	private CheckBox hindi;
	private CheckBox bengali;
	private CheckBox checkbox1;
	private CheckBox checkbox2;
	private CheckBox checkbox3;
	private Button continueo;
	
	private Intent inte = new Intent();
	private SharedPreferences sp;
	private ObjectAnimator oa2 = new ObjectAnimator();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.language);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		select = (TextView) findViewById(R.id.select);
		english = (CheckBox) findViewById(R.id.english);
		hindi = (CheckBox) findViewById(R.id.hindi);
		bengali = (CheckBox) findViewById(R.id.bengali);
		checkbox1 = (CheckBox) findViewById(R.id.checkbox1);
		checkbox2 = (CheckBox) findViewById(R.id.checkbox2);
		checkbox3 = (CheckBox) findViewById(R.id.checkbox3);
		continueo = (Button) findViewById(R.id.continueo);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		english.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				english.setChecked(true);
			}
		});
		
		english.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					sp.edit().putString("language", "english").commit();
					select.setText("Select a language");
					continueo.setText("CONTINUE");
					hindi.setChecked(false);
					bengali.setChecked(false);
				}
			}
		});
		
		hindi.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				hindi.setChecked(true);
			}
		});
		
		hindi.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					sp.edit().putString("language", "हिंदी").commit();
					select.setText("अपना भाषा सिलेक्ट");
					continueo.setText("जारी रखें");
					english.setChecked(false);
					bengali.setChecked(false);
				}
			}
		});
		
		bengali.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				bengali.setChecked(true);
			}
		});
		
		bengali.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					sp.edit().putString("language", "বাংলা").commit();
					select.setText("ভাষা সিলেক্ট করো");
					continueo.setText("সেভ করো");
					english.setChecked(false);
					hindi.setChecked(false);
				}
			}
		});
		
		continueo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				oa2.setTarget(continueo);
				oa2.setPropertyName("scaleX");
				oa2.setFloatValues((float)(1.0d), (float)(0.9d));
				oa2.setDuration((int)(50));
				oa2.setRepeatMode(ValueAnimator.REVERSE);
				oa2.setRepeatCount((int)(1));
				oa2.start();
				inte.setClass(getApplicationContext(), SettingsActivity.class);
				startActivity(inte);
			}
		});
	}
	private void initializeLogic() {
		android.graphics.drawable.GradientDrawable EFDJBHD = new android.graphics.drawable.GradientDrawable();
		EFDJBHD.setColor(Color.parseColor("#FF3F51B5"));
		EFDJBHD.setCornerRadius(25);
		continueo.setBackground(EFDJBHD);
		if (sp.getString("language", "").equals("english")) {
			hindi.setChecked(false);
			bengali.setChecked(false);
			english.setChecked(true);
		}
		if (sp.getString("language", "").equals("हिंदी")) {
			english.setChecked(false);
			bengali.setChecked(false);
			hindi.setChecked(true);
		}
		if (sp.getString("language", "").equals("বাংলা")) {
			english.setChecked(false);
			hindi.setChecked(false);
			bengali.setChecked(true);
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
