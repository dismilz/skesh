package com.my.newproject126;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;
import android.content.ClipData;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.AdListener;
import android.view.View;
import android.Manifest;
import android.content.pm.PackageManager;

public class TxteditorActivity extends Activity {
	
	public final int REQ_CD_FP = 101;
	
	private String toasts = "";
	private String title = "";
	private String msg = "";
	private String ok = "";
	private String cancel = "";
	private String toastopen = "";
	private String entertitle = "";
	private String space = "";
	private String entertxt = "";
	
	private ArrayList<String> txt = new ArrayList<>();
	private ArrayList<String> list1 = new ArrayList<>();
	
	private LinearLayout lineartxt;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private EditText titletext;
	private HorizontalScrollView hscroll1;
	private Button save;
	private Button open;
	private TextView textview2;
	private LinearLayout linear3;
	private ImageView settings;
	private EditText txtedit;
	
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent in = new Intent();
	private AlertDialog.Builder d;
	private SharedPreferences sp;
	private ObjectAnimator oa = new ObjectAnimator();
	private InterstitialAd iad;
	private AdListener _iad_ad_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.txteditor);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		lineartxt = (LinearLayout) findViewById(R.id.lineartxt);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		titletext = (EditText) findViewById(R.id.titletext);
		hscroll1 = (HorizontalScrollView) findViewById(R.id.hscroll1);
		save = (Button) findViewById(R.id.save);
		open = (Button) findViewById(R.id.open);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		settings = (ImageView) findViewById(R.id.settings);
		txtedit = (EditText) findViewById(R.id.txtedit);
		fp.setType("text/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		d = new AlertDialog.Builder(this);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		save.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				oa.setTarget(save);
				oa.setPropertyName("scaleX");
				oa.setFloatValues((float)(1.0d), (float)(0.9d));
				oa.setDuration((int)(50));
				oa.setRepeatMode(ValueAnimator.REVERSE);
				oa.setRepeatCount((int)(1));
				oa.start();
				d.setTitle(title);
				d.setMessage(msg);
				d.setPositiveButton(ok, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						SketchwareUtil.showMessage(getApplicationContext(), toasts);
					}
				});
				d.setNeutralButton(cancel, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						SketchwareUtil.showMessage(getApplicationContext(), toasts);
					}
				});
				d.create().show();
			}
		});
		
		open.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				oa.setTarget(open);
				oa.setPropertyName("scaleX");
				oa.setFloatValues((float)(1.0d), (float)(0.9d));
				oa.setDuration((int)(50));
				oa.setRepeatMode(ValueAnimator.REVERSE);
				oa.setRepeatCount((int)(1));
				oa.start();
				SketchwareUtil.showMessage(getApplicationContext(), toastopen);
			}
		});
		
		settings.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), SettingsActivity.class);
				startActivity(in);
				finish();
			}
		});
		
		_iad_ad_listener = new AdListener() {
			@Override
			public void onAdLoaded() {
				
			}
			
			@Override
			public void onAdFailedToLoad(int _param1) {
				final int _errorCode = _param1;
				
			}
			
			@Override
			public void onAdOpened() {
				
			}
			
			@Override
			public void onAdClosed() {
				
			}
		};
	}
	private void initializeLogic() {
		getActionBar().setDisplayHomeAsUpEnabled(false);
		android.graphics.drawable.GradientDrawable IJFJDBI = new android.graphics.drawable.GradientDrawable();
		IJFJDBI.setColor(Color.parseColor("#FF3F51B5"));
		IJFJDBI.setCornerRadius(25);
		save.setBackground(IJFJDBI);
		android.graphics.drawable.GradientDrawable IGAFHIE = new android.graphics.drawable.GradientDrawable();
		IGAFHIE.setColor(Color.parseColor("#FFFFFFFF"));
		IGAFHIE.setCornerRadius(25);
		IGAFHIE.setStroke(5, Color.parseColor("#FF3F51B5"));
		open.setBackground(IGAFHIE);
		android.graphics.drawable.GradientDrawable GGHBGCA = new android.graphics.drawable.GradientDrawable();
		GGHBGCA.setColor(Color.parseColor("#FFFFFFFF"));
		GGHBGCA.setCornerRadius(25);
		GGHBGCA.setStroke(5, Color.parseColor("#FF3F51B5"));
		settings.setBackground(GGHBGCA);
		InputFilter[] editFilters = titletext.getFilters(); InputFilter[] newFilters = new InputFilter[editFilters.length + 1]; System.arraycopy(editFilters, 0, newFilters, 0, editFilters.length); newFilters[editFilters.length] = new InputFilter.LengthFilter(15); titletext.setFilters(newFilters);
		if (sp.getString("language", "").equals("english")) {
			toasts = "Saved to storage/emulated/0/TXT Editor";
			title = "WARNING";
			msg = "This file already exists, do you want to replace it?";
			ok = "SUBSTITUTE HIM";
			cancel = "CANCEL";
			toastopen = "You will lose your .txt you were editing.";
			entertitle = "Enter a title";
			space = "Title cannot contain spaces";
			entertxt = "Enter a txt";
		}
		if (sp.getString("language", "").equals("हिंदी")) {
			toasts = "भंडारण / उत्सर्जित / 0 / TXT संपादक में सहेजा गया";
			title = "चेतावनी";
			msg = "यह फ़ाइल पहले से मौजूद है, क्या आप इसे बदलना चाहते हैं?";
			ok = "SUBSTITUTE HIM";
			cancel = "रद्द करना";
			toastopen = "आप अपना .txt खो देंगे आप संपादन कर रहे थे।";
			entertitle = "एक शीर्षक दर्ज करें";
			space = "शीर्षक में रिक्त स्थान नहीं हो सकते";
			entertxt = "एक पाठ लिखें";
			save.setText("बचाना");
			open.setText("खुला हुआ");
			titletext.setHint("शीर्षक");
			textview2.setText("एक शीर्षक .txt दर्ज करें");
		}
		if (sp.getString("language", "").equals("বাংলা")) {
			toasts = "স্টোরেজ / এমুলেটেড / 0 / টিএক্সটি সম্পাদকে সংরক্ষিত";
			title = "সতর্কতামূলক";
			msg = "এই ফাইলটি ইতিমধ্যে বিদ্যমান, আপনি কি এটি প্রতিস্থাপন করতে চান?";
			ok = "এটা প্রতিস্থাপন করো";
			cancel = "বাতিল করা";
			toastopen = "আপনি সম্পাদনা করা .txt ফাইলটি হারাবেন।";
			entertitle = "একটি শিরোনাম লিখুন";
			space = "শিরোনামে স্পেস থাকতে পারে না";
			entertxt = "একটি txt রাখুন";
			save.setText("সংরক্ষণ");
			open.setText("খোলা");
			titletext.setHint("শিরোনাম");
			textview2.setText(".Txt একটি শিরোনাম লিখুন");
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
