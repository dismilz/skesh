package com.my.newproject126;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Switch;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.View;
import android.widget.CompoundButton;

public class SettingsActivity extends Activity {
	
	
	private String s_anim = "";
	private String s_animoff = "";
	
	private LinearLayout linear1;
	private TextView chooselanguage;
	private Button selectlanguage;
	private TextView actionbarhide;
	private CheckBox visibleactionbar;
	private CheckBox hideactionbar;
	private TextView animationoffon;
	private Switch s_animation;
	private LinearLayout linear2;
	private Button savesettings;
	
	private Intent inten = new Intent();
	private SharedPreferences sp;
	private ObjectAnimator oa3 = new ObjectAnimator();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.settings);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		chooselanguage = (TextView) findViewById(R.id.chooselanguage);
		selectlanguage = (Button) findViewById(R.id.selectlanguage);
		actionbarhide = (TextView) findViewById(R.id.actionbarhide);
		visibleactionbar = (CheckBox) findViewById(R.id.visibleactionbar);
		hideactionbar = (CheckBox) findViewById(R.id.hideactionbar);
		animationoffon = (TextView) findViewById(R.id.animationoffon);
		s_animation = (Switch) findViewById(R.id.s_animation);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		savesettings = (Button) findViewById(R.id.savesettings);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		selectlanguage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				oa3.setTarget(selectlanguage);
				oa3.setPropertyName("scaleX");
				oa3.setFloatValues((float)(1.0d), (float)(0.9d));
				oa3.setDuration((int)(50));
				oa3.setRepeatMode(ValueAnimator.REVERSE);
				oa3.setRepeatCount((int)(1));
				oa3.start();
				inten.setClass(getApplicationContext(), LanguageActivity.class);
				startActivity(inten);
			}
		});
		
		visibleactionbar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				visibleactionbar.setChecked(true);
			}
		});
		
		visibleactionbar.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					hideactionbar.setChecked(false);
				}
			}
		});
		
		hideactionbar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				hideactionbar.setChecked(true);
			}
		});
		
		hideactionbar.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					visibleactionbar.setChecked(false);
				}
			}
		});
		
		savesettings.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				oa3.setTarget(savesettings);
				oa3.setPropertyName("scaleX");
				oa3.setFloatValues((float)(1.0d), (float)(0.9d));
				oa3.setDuration((int)(50));
				oa3.setRepeatMode(ValueAnimator.REVERSE);
				oa3.setRepeatCount((int)(1));
				oa3.start();
				inten.setClass(getApplicationContext(), TxteditorActivity.class);
				startActivity(inten);
				finish();
			}
		});
	}
	private void initializeLogic() {
		android.graphics.drawable.GradientDrawable IFDAGEG = new android.graphics.drawable.GradientDrawable();
		IFDAGEG.setColor(Color.parseColor("#FFFFFFFF"));
		IFDAGEG.setCornerRadius(25);
		IFDAGEG.setStroke(5, Color.parseColor("#FF3F51B5"));
		savesettings.setBackground(IFDAGEG);
		android.graphics.drawable.GradientDrawable FEJHADD = new android.graphics.drawable.GradientDrawable();
		FEJHADD.setColor(Color.parseColor("#FF3F51B5"));
		FEJHADD.setCornerRadius(25);
		selectlanguage.setBackground(FEJHADD);
		if (sp.getString("language", "").equals("english")) {
			
		}
		if (sp.getString("language", "").equals("हिंदी")) {
			chooselanguage.setText("अपनी भाषा चुनिए");
			selectlanguage.setText("भाषा चुनें");
			actionbarhide.setText("एक्शनबार को छिपाएं या दिखाएं");
			visibleactionbar.setText("प्रदर्शन");
			hideactionbar.setText("छुपाना");
			animationoffon.setText("एनीमेशन पर क्लिक करें");
			savesettings.setText("बचाना");
		}
		if (sp.getString("language", "").equals("বাংলা")) {
			chooselanguage.setText("আপনার ভাষা নির্বাচন করুন");
			selectlanguage.setText("একটি ভাষা চয়ন করুন");
			actionbarhide.setText("অ্যাকশনবারটি লুকান বা দেখান");
			visibleactionbar.setText("প্রদর্শন");
			hideactionbar.setText("লুকান");
			animationoffon.setText("অ্যানিমেশন ক্লিক করুন");
			savesettings.setText("সংরক্ষণ");
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
