package com.my.newproject117;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import java.util.Timer;
import java.util.TimerTask;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.app.Activity;
import android.content.SharedPreferences;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class LuckywheelActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private double number = 0;
	private double counter = 0;
	private double net_rotation = 0;
	private String p = "";
	private HashMap<String, Object> map1 = new HashMap<>();
	private String coin = "";
	private String current_coin = "";
	private String buy = "";
	private HashMap<String, Object> upload_course = new HashMap<>();
	private String paytm = "";
	
	private ArrayList<String> key = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> map = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear5;
	private LinearLayout linear4;
	private LinearLayout linear10;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private ImageView imageview6;
	private TextView textview6;
	private LinearLayout linear16;
	private ImageView imageview3;
	private TextView textview2;
	private ImageView imageview4;
	private TextView textview3;
	private LinearLayout linear15;
	private ImageView imageview2;
	private ImageView tap;
	private LinearLayout linear11;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private LinearLayout linear20;
	private ImageView imageview5;
	private TextView textview4;
	private ImageView imageview7;
	private TextView textview7;
	private TextView textview5;
	private Button button1;
	private LinearLayout linear19;
	private Button button2;
	private Button button5;
	private Button button4;
	
	private TimerTask time;
	private TimerTask resetrotation;
	private DatabaseReference pro = _firebase.getReference("+p+");
	private ChildEventListener _pro_child_listener;
	private SharedPreferences sp;
	private SharedPreferences daily;
	private Calendar date = Calendar.getInstance();
	private AlertDialog.Builder dia;
	private AlertDialog.Builder withdraw;
	private DatabaseReference with = _firebase.getReference("withdraw");
	private ChildEventListener _with_child_listener;
	private AlertDialog.Builder d;
	private Intent share = new Intent();
	private Intent pc = new Intent();
	private AlertDialog.Builder dialogue;
	private DatabaseReference pay = _firebase.getReference("+pay+");
	private ChildEventListener _pay_child_listener;
	private DatabaseReference paytmapp = _firebase.getReference("+paytm+");
	private ChildEventListener _paytmapp_child_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.luckywheel);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		textview6 = (TextView) findViewById(R.id.textview6);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview2 = (TextView) findViewById(R.id.textview2);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		tap = (ImageView) findViewById(R.id.tap);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview4 = (TextView) findViewById(R.id.textview4);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview5 = (TextView) findViewById(R.id.textview5);
		button1 = (Button) findViewById(R.id.button1);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		button2 = (Button) findViewById(R.id.button2);
		button5 = (Button) findViewById(R.id.button5);
		button4 = (Button) findViewById(R.id.button4);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		daily = getSharedPreferences("daily", Activity.MODE_PRIVATE);
		dia = new AlertDialog.Builder(this);
		withdraw = new AlertDialog.Builder(this);
		d = new AlertDialog.Builder(this);
		dialogue = new AlertDialog.Builder(this);
		
		tap.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				date = Calendar.getInstance();
				if (daily.getString(new SimpleDateFormat("ddMMyyyy").format(date.getTime()), "").equals("")) {
					daily.edit().putString(new SimpleDateFormat("ddMMyyyy").format(date.getTime()), "true").commit();
					tap.setEnabled(false);
					tap.setRotation((float)(0));
					number = (45 * SketchwareUtil.getRandom((int)(8), (int)(25))) + 45;
					counter = 0;
					time = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									tap.setRotation((float)(tap.getRotation() + 15));
									counter++;
									if (counter == (number / 15)) {
										time.cancel();
										_spinlogic();
									}
								}
							});
						}
					};
					_timer.scheduleAtFixedRate(time, (int)(0), (int)(50));
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "You have used daily one spin");
				}
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if ((Double.parseDouble(current_coin) > 1000) || (Double.parseDouble(current_coin) == 1000)) {
					if (Double.parseDouble(buy) > 0) {
						d.setTitle("Enter Paytm Number ");
						final EditText edittextt1= new EditText(LuckywheelActivity.this);
						LinearLayout.LayoutParams lpar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
						edittextt1.setLayoutParams(lpar);
						d.setView(edittextt1);
						
						
						
						d.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								upload_course.clear();
								upload_course = new HashMap<>();
								upload_course.put("id", sp.getString("id", ""));
								upload_course.put("s", "pending");
								upload_course.put("c", edittextt1.getText().toString()); 
								if (upload_course.get("c").toString().equals("")) {
									SketchwareUtil.showMessage(getApplicationContext(), "This must be a name");
								}
								else {
									with.push().updateChildren(upload_course);
									SketchwareUtil.showMessage(getApplicationContext(), "Successfully Requested ");
									paytm = sp.getString("id", "").concat("/payments/".concat("".concat("")));
									paytmapp.push().updateChildren(upload_course);
									map1.clear();
									map1 = new HashMap<>();
									map1.put("coin", String.valueOf((long)(Double.parseDouble(current_coin) + -1000)));
									map1.put("buy", String.valueOf((long)(Double.parseDouble(buy) + -1)));
									pro.child(key.get((int)(0))).updateChildren(map1);
								}
							}
						});
						d.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						d.create().show();
					}
					else {
						d.setTitle("Enter Paytm Number ");
						final EditText edittextt1= new EditText(LuckywheelActivity.this);
						LinearLayout.LayoutParams lpar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
						edittextt1.setLayoutParams(lpar);
						d.setView(edittextt1);
						
						
						
						d.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								upload_course.clear();
								upload_course = new HashMap<>();
								upload_course.put("id", sp.getString("id", ""));
								upload_course.put("s", "pending");
								upload_course.put("c", edittextt1.getText().toString()); 
								if (upload_course.get("c").toString().equals("")) {
									SketchwareUtil.showMessage(getApplicationContext(), "This must be a name");
								}
								else {
									with.push().updateChildren(upload_course);
									SketchwareUtil.showMessage(getApplicationContext(), "Successfully Requested ");
									paytm = sp.getString("id", "").concat("/payments/".concat("".concat("")));
									paytmapp.push().updateChildren(upload_course);
									map1.clear();
									map1 = new HashMap<>();
									map1.put("coin", String.valueOf((long)(Double.parseDouble(current_coin) + -1000)));
									map1.put("buy", String.valueOf((long)(Double.parseDouble(buy) + -1)));
									pro.child(key.get((int)(0))).updateChildren(map1);
								}
							}
						});
						d.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						d.create().show();
						SketchwareUtil.showMessage(getApplicationContext(), "You have to buy at least one product from store");
					}
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Not enough Coin");
				}
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				dia.setMessage("Refer your Friend to get $2000 \nand spin daily to get more $\n\nOrder a product over Rs 100 to get 1 smiley \n\n\nTo Transfer $  in to your paytm wallet You must have at least 1 smiley...\n\nRefer More to earn More");
				dia.setPositiveButton("ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dia.create().show();
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pc.putExtra("p", paytm);
				
				startActivity(pc);
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		_pro_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				tap.setEnabled(true);
				key.add(_childKey);
				if (_childValue.containsKey("coin")) {
					textview2.setText(String.valueOf((long)(Double.parseDouble(_childValue.get("coin").toString()))));
					current_coin = _childValue.get("coin").toString();
					textview6.setText(String.valueOf((long)(Double.parseDouble(_childValue.get("buy").toString()))));
					buy = _childValue.get("buy").toString();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.containsKey("coin")) {
					textview2.setText(String.valueOf((long)(Double.parseDouble(_childValue.get("coin").toString()))));
					current_coin = _childValue.get("coin").toString();
					textview6.setText(String.valueOf((long)(Double.parseDouble(_childValue.get("buy").toString()))));
					buy = _childValue.get("buy").toString();
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		pro.addChildEventListener(_pro_child_listener);
		
		_with_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		with.addChildEventListener(_with_child_listener);
		
		_pay_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		pay.addChildEventListener(_pay_child_listener);
		
		_paytmapp_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		paytmapp.addChildEventListener(_paytmapp_child_listener);
	}
	private void initializeLogic() {
		tap.setEnabled(false);
		pro.removeEventListener(_pro_child_listener);
		p = sp.getString("id", "").concat("/profile");
		pro =
		_firebase.getReference(p);
		
		pro.addChildEventListener(_pro_child_listener);
		_radius_to(button4, 40, 20, "#7986CB");
		_radius_to(linear10, 40, 20, "#7986CB");
		_radius_to(button1, 40, 20, "#7986CB");
		_radius_to(button2, 40, 20, "#7986CB");
		_radius_to(button5, 40, 20, "#7986CB");
		paytmapp.removeEventListener(_paytmapp_child_listener);
		paytm = sp.getString("id", "").concat("/payments");
		paytmapp =
		_firebase.getReference(paytm);
		
		paytmapp.addChildEventListener(_paytmapp_child_listener);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _spinlogic () {
		net_rotation = tap.getRotation();
		for(int _repeat85 = 0; _repeat85 < (int)(15); _repeat85++) {
			if ((net_rotation == 360) || (net_rotation > 360)) {
				net_rotation = net_rotation - 360;
			}
			else {
				
			}
		}
		if ((net_rotation / 45) == 0) {
			SketchwareUtil.showMessage(getApplicationContext(), "10");
			coin = "10";
		}
		if ((net_rotation / 45) == 1) {
			SketchwareUtil.showMessage(getApplicationContext(), "100");
			coin = "100";
		}
		if ((net_rotation / 45) == 2) {
			SketchwareUtil.showMessage(getApplicationContext(), "1000");
			coin = "1000";
		}
		if ((net_rotation / 45) == 3) {
			SketchwareUtil.showMessage(getApplicationContext(), "Thanks");
			coin = "0";
		}
		if ((net_rotation / 45) == 4) {
			SketchwareUtil.showMessage(getApplicationContext(), "50");
			coin = "50";
		}
		if ((net_rotation / 45) == 5) {
			SketchwareUtil.showMessage(getApplicationContext(), "1");
			coin = "1";
		}
		if ((net_rotation / 45) == 6) {
			SketchwareUtil.showMessage(getApplicationContext(), "Thanks");
			coin = "0";
		}
		if ((net_rotation / 45) == 7) {
			SketchwareUtil.showMessage(getApplicationContext(), "5");
			coin = "5";
		}
		tap.setEnabled(true);
		map1 = new HashMap<>();
		map1.put("coin", String.valueOf((long)(Double.parseDouble(current_coin) + Double.parseDouble(coin))));
		pro.child(key.get((int)(0))).updateChildren(map1);
		dialogue.setMessage("You Have Got  \n\n".concat(coin));
		dialogue.setPositiveButton("ok", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		dialogue.create().show();
	}
	
	
	private void _radius_to (final View _view, final double _radius, final double _shadow, final String _color) {
		android.graphics.drawable.GradientDrawable ab = new android.graphics.drawable.GradientDrawable();
		
		ab.setColor(Color.parseColor(_color));
		ab.setCornerRadius((float) _radius);
		_view.setElevation((float) _shadow);
		_view.setBackground(ab);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
