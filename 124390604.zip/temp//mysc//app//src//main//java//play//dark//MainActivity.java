package play.dark;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.os.Build;
import androidx.core.content.FileProvider;
import java.io.File;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
	
	public final int REQ_CD_CAMERA = 101;
	
	private boolean flashLightStatus = false;
	private boolean hasCameraFlash = false;
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private AdView ad;
	private ImageView imageview1;
	private TextView textview1;
	private ImageView imageview2;
	
	private Intent Camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
	private File _file_Camera;
	private Intent intent = new Intent();
	private AlertDialog.Builder dialog;
	private Intent intent2 = new Intent();
	private Intent intent3 = new Intent();
	private Intent intent4 = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		ad = (AdView) findViewById(R.id.ad);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		_file_Camera = FileUtil.createNewPictureFile(getApplicationContext());
		Uri _uri_Camera = null;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
			_uri_Camera= FileProvider.getUriForFile(getApplicationContext(), getApplicationContext().getPackageName() + ".provider", _file_Camera);
		}
		else {
			_uri_Camera = Uri.fromFile(_file_Camera);
		}
		Camera.putExtra(MediaStore.EXTRA_OUTPUT, _uri_Camera);
		Camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
		dialog = new AlertDialog.Builder(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (hasCameraFlash) {
					if (flashLightStatus) {
						_flashLightOff();
						_customToast("Flasher Off");
					}
					else {
						_flashLightOn();
						_customToast("Flasher On");
					}
				}
				else {
					_customToast("No Flasher On this Device");
				}
			}
		});
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent4.setData(Uri.parse("https://www.youtube.com/c/dàrkfun"));
				startActivity(intent4);
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent3.setClass(getApplicationContext(), SettingsActivity.class);
				startActivity(intent3);
			}
		});
	}
	private void initializeLogic() {
		intent.setClass(getApplicationContext(), SpalshActivity.class);
		startActivity(intent);
		hasCameraFlash = getPackageManager(). hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);
		ad.loadAd(new AdRequest.Builder().addTestDevice("8661D80CE552B64D7A8D09DCF6C5E9EA")
		.build());
		dialog.setMessage("Subscribe Dàrk");
		dialog.setPositiveButton("SUBSCRIBE", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				intent2.setAction(Intent.ACTION_VIEW);
				intent2.setData(Uri.parse("https://www.youtube.com/channel/UCQ86trkTcwV0mtRgx32R59A"));
				_customToast("Thanks For Supporting 💖");
				startActivity(intent2);
			}
		});
		dialog.setNeutralButton("CANCEL", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				_customToast("Ok😥");
			}
		});
		dialog.create().show();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _flashLightOff () {
		android.hardware.camera2.CameraManager cameraManager = (android.hardware.camera2.CameraManager) getSystemService(Context.CAMERA_SERVICE);
		try {
			String cameraId = cameraManager.getCameraIdList()[0]; cameraManager.setTorchMode(cameraId, false);
			flashLightStatus = false; imageview1.setImageResource(R.drawable.ic_flash_off_black); } catch (android.hardware.camera2.CameraAccessException e) { }
	}
	
	
	private void _flashLightOn () {
		android.hardware.camera2.CameraManager cameraManager = (android.hardware.camera2.CameraManager) getSystemService(Context.CAMERA_SERVICE);
		try {
			String cameraId = cameraManager.getCameraIdList()[0]; cameraManager.setTorchMode(cameraId, true);
			flashLightStatus = true; imageview1.setImageResource(R.drawable.ic_flash_on_black); } catch (android.hardware.camera2.CameraAccessException e) { }
	}
	
	
	private void _customToast (final String _text) {
		LayoutInflater inflater = getLayoutInflater(); View toastLayout = inflater.inflate(R.layout.custom1, null);
		
		TextView textview1 = (TextView) toastLayout.findViewById(R.id.textview1);
		textview1.setText(_text);
		LinearLayout linear1 = (LinearLayout) toastLayout.findViewById(R.id.linear1);
		
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor("#000000"));
		gd.setCornerRadius(60);
		gd.setStroke(2, Color.parseColor("#ffffff"));
		linear1.setBackground(gd);
		
		Toast toast = new Toast(getApplicationContext()); toast.setDuration(Toast.LENGTH_SHORT);
		toast.setView(toastLayout);
		toast.show();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
