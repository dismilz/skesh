package com.my.leftbar;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Timer;
import java.util.TimerTask;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private double position = 0;
	private double finalSize = 0;
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout left_bar;
	private LinearLayout target;
	private ImageView item1;
	private ImageView item2;
	private ImageView item3;
	private ImageView item4;
	private ImageView item5;
	private ImageView item6;
	private LinearLayout linear7;
	private ImageView profile;
	private LinearLayout divider3;
	private ImageView exit;
	private ImageView terget_image;
	private TextView textview1;
	
	private TimerTask timer;
	private Intent intent = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		left_bar = (LinearLayout) findViewById(R.id.left_bar);
		target = (LinearLayout) findViewById(R.id.target);
		item1 = (ImageView) findViewById(R.id.item1);
		item2 = (ImageView) findViewById(R.id.item2);
		item3 = (ImageView) findViewById(R.id.item3);
		item4 = (ImageView) findViewById(R.id.item4);
		item5 = (ImageView) findViewById(R.id.item5);
		item6 = (ImageView) findViewById(R.id.item6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		profile = (ImageView) findViewById(R.id.profile);
		divider3 = (LinearLayout) findViewById(R.id.divider3);
		exit = (ImageView) findViewById(R.id.exit);
		terget_image = (ImageView) findViewById(R.id.terget_image);
		textview1 = (TextView) findViewById(R.id.textview1);
		
		item1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_targetMover(0);
				_FadeOut(item1, 200);
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								terget_image.setImageResource(R.drawable.home_white);
							}
						});
					}
				};
				_timer.schedule(timer, (int)(100));
				textview1.setText("Home");
			}
		});
		
		item2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_targetMover(1);
				_FadeOut(item2, 200);
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								terget_image.setImageResource(R.drawable.edit_white);
							}
						});
					}
				};
				_timer.schedule(timer, (int)(100));
				textview1.setText("Edit");
			}
		});
		
		item3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_targetMover(2);
				_FadeOut(item3, 200);
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								terget_image.setImageResource(R.drawable.duplicate_white);
							}
						});
					}
				};
				_timer.schedule(timer, (int)(100));
				textview1.setText("Duplicate");
			}
		});
		
		item4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_targetMover(3);
				_FadeOut(item4, 200);
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								terget_image.setImageResource(R.drawable.notification_white);
							}
						});
					}
				};
				_timer.schedule(timer, (int)(100));
				textview1.setText("Notification");
			}
		});
		
		item5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_targetMover(4);
				_FadeOut(item5, 200);
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								terget_image.setImageResource(R.drawable.message_white);
							}
						});
					}
				};
				_timer.schedule(timer, (int)(100));
				textview1.setText("Message");
			}
		});
		
		item6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_targetMover(5);
				_FadeOut(item6, 200);
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								terget_image.setImageResource(R.drawable.info_white);
							}
						});
					}
				};
				_timer.schedule(timer, (int)(100));
				textview1.setText("Info");
			}
		});
		
		profile.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), ProfileActivity.class);
				startActivity(intent);
			}
		});
		
		exit.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
	}
	private void initializeLogic() {
		_UI();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _UI () {
		_setBackground(left_bar, 15, 5, "#212121", false);
		_setBackground(target, 15, 5, "#00BFA5", true);
		_setBackground(item1, 15, 0, "#212121", true);
		_setBackground(item2, 15, 0, "#212121", true);
		_setBackground(item3, 15, 0, "#212121", true);
		_setBackground(item4, 15, 0, "#212121", true);
		_setBackground(item5, 15, 0, "#212121", true);
		_setBackground(item6, 15, 0, "#212121", true);
		_setBackground(profile, 50, 0, "#212121", true);
		_setBackground(exit, 50, 0, "#212121", true);
		_navigationBarColor("#424242");
	}
	
	
	private void _setBackground (final View _view, final double _radius, final double _shadow, final String _color, final boolean _ripple) {
		if (_ripple) {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			_view.setElevation((int)_shadow);
			android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#9e9e9e")});
			android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
			_view.setClickable(true);
			_view.setBackground(ripdrb);
		}
		else {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			_view.setBackground(gd);
			_view.setElevation((int)_shadow);
		}
	}
	
	
	private void _Animator (final View _view, final String _propertyName, final double _value, final double _duration) {
		ObjectAnimator anim = new ObjectAnimator();
		anim.setTarget(_view);
		anim.setPropertyName(_propertyName);
		anim.setFloatValues((float)_value);
		anim.setDuration((long)_duration);
		anim.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
		anim.start();
	}
	
	
	private void _targetMover (final double _position) {
		position = 48 * _position;
		_Animator(target, "translationY", SketchwareUtil.getDip(getApplicationContext(), (int)(position)), 200);
		_Animator(terget_image, "scaleX", 0, 100);
		_Animator(terget_image, "scaleY", 0, 100);
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						_Animator(terget_image, "scaleX", 1, 100);
						_Animator(terget_image, "scaleY", 1, 100);
					}
				});
			}
		};
		_timer.schedule(timer, (int)(100));
	}
	
	
	private void _FadeOut (final View _view, final double _duration) {
		ViewGroup viewgroup = (ViewGroup) _view.getParent();
		
		for (int i = 0; i < viewgroup.getChildCount(); i++)
		{
			    View nextChild = (View) viewgroup.getChildAt(i);
			ObjectAnimator anim = new ObjectAnimator();
			anim.setTarget(nextChild);
			anim.setPropertyName("scaleX");
			anim.setFloatValues(1f);
			anim.setDuration((long)200);
			anim.start();
			ObjectAnimator anim2 = new ObjectAnimator();
			anim2.setTarget(nextChild);
			anim2.setPropertyName("scaleY");
			anim2.setFloatValues(1f);
			anim2.setDuration((long)200);
			anim2.start();
		}
		_Animator(_view, "scaleX", 0, 200);
		_Animator(_view, "scaleY", 0, 200);
	}
	
	
	private void _navigationBarColor (final String _color) {
		if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { getWindow().setNavigationBarColor(Color.parseColor(_color)); }
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
