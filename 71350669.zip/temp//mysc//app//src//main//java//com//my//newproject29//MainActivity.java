package com.my.newproject29;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.Button;
import android.widget.TextView;
import java.util.Timer;
import java.util.TimerTask;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.content.Context;
import android.os.Vibrator;
import android.media.MediaPlayer;
import android.view.View;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private double random_hits = 0;
	private double sound_streams = 0;
	private double jump_sound = 0;
	
	private LinearLayout linear1;
	private LinearLayout linear3;
	private ImageView imageview1;
	private ImageView enem;
	private Button button3;
	private LinearLayout linear4;
	private Button button4;
	private TextView textview1;
	private LinearLayout linear5;
	private Button fight_btn;
	private Button button2;
	private Button button1;
	private ImageView imageview3;
	private ImageView imageview7;
	private ImageView imageview6;
	private ImageView imageview5;
	private ImageView imageview4;
	
	private TimerTask btn_animation;
	private TimerTask player_movement;
	private ObjectAnimator jump = new ObjectAnimator();
	private Vibrator hit_enemy;
	private MediaPlayer sound;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		enem = (ImageView) findViewById(R.id.enem);
		button3 = (Button) findViewById(R.id.button3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		button4 = (Button) findViewById(R.id.button4);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		fight_btn = (Button) findViewById(R.id.fight_btn);
		button2 = (Button) findViewById(R.id.button2);
		button1 = (Button) findViewById(R.id.button1);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		hit_enemy = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button3.setAlpha((float)(0.5d));
				btn_animation = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								button3.setAlpha((float)(1));
							}
						});
					}
				};
				_timer.schedule(btn_animation, (int)(100));
				imageview1.setImageResource(R.drawable.player_back);
				imageview1.setTranslationX((float)(imageview1.getTranslationX() - 25));
				player_movement = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								imageview1.setImageResource(R.drawable.player_normal);
							}
						});
					}
				};
				_timer.schedule(player_movement, (int)(250));
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button4.setAlpha((float)(0.5d));
				btn_animation = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								button4.setAlpha((float)(1));
							}
						});
					}
				};
				_timer.schedule(btn_animation, (int)(100));
				imageview1.setImageResource(R.drawable.player_move_left);
				imageview1.setTranslationX((float)(imageview1.getTranslationX() + 25));
				player_movement = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								imageview1.setImageResource(R.drawable.player_normal);
							}
						});
					}
				};
				_timer.schedule(player_movement, (int)(250));
			}
		});
		
		fight_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				fight_btn.setAlpha((float)(0.5d));
				btn_animation = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								fight_btn.setAlpha((float)(1));
							}
						});
					}
				};
				_timer.schedule(btn_animation, (int)(100));
				random_hits = SketchwareUtil.getRandom((int)(1), (int)(10));
				if (random_hits == 1) {
					imageview1.setImageResource(R.drawable.f_style_1);
					player_movement = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									imageview1.setImageResource(R.drawable.player_normal);
								}
							});
						}
					};
					_timer.schedule(player_movement, (int)(250));
				}
				if (random_hits == 2) {
					imageview1.setImageResource(R.drawable.f_style_2);
					player_movement = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									imageview1.setImageResource(R.drawable.player_normal);
								}
							});
						}
					};
					_timer.schedule(player_movement, (int)(250));
				}
				if (random_hits == 3) {
					imageview1.setImageResource(R.drawable.f_style_3);
					player_movement = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									imageview1.setImageResource(R.drawable.player_normal);
								}
							});
						}
					};
					_timer.schedule(player_movement, (int)(250));
				}
				if (random_hits == 4) {
					imageview1.setImageResource(R.drawable.f_style_4);
					player_movement = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									imageview1.setImageResource(R.drawable.player_normal);
								}
							});
						}
					};
					_timer.schedule(player_movement, (int)(250));
				}
				if (random_hits == 5) {
					imageview1.setImageResource(R.drawable.more_styles_1);
					player_movement = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									imageview1.setImageResource(R.drawable.player_normal);
								}
							});
						}
					};
					_timer.schedule(player_movement, (int)(250));
				}
				if (random_hits == 6) {
					imageview1.setImageResource(R.drawable.more_styles_2);
					player_movement = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									imageview1.setImageResource(R.drawable.player_normal);
								}
							});
						}
					};
					_timer.schedule(player_movement, (int)(250));
				}
				if (random_hits == 7) {
					imageview1.setImageResource(R.drawable.more_styles_3);
					player_movement = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									imageview1.setImageResource(R.drawable.player_normal);
								}
							});
						}
					};
					_timer.schedule(player_movement, (int)(250));
				}
				if (random_hits == 8) {
					imageview1.setImageResource(R.drawable.more_styles_4_1);
					player_movement = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									imageview1.setImageResource(R.drawable.player_normal);
								}
							});
						}
					};
					_timer.schedule(player_movement, (int)(250));
				}
				if (random_hits == 9) {
					imageview1.setImageResource(R.drawable.more_styles_4_2);
					player_movement = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									imageview1.setImageResource(R.drawable.player_normal);
								}
							});
						}
					};
					_timer.schedule(player_movement, (int)(250));
				}
				if (random_hits == 10) {
					imageview1.setImageResource(R.drawable.more_styles_4_3);
					player_movement = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									imageview1.setImageResource(R.drawable.player_normal);
								}
							});
						}
					};
					_timer.schedule(player_movement, (int)(250));
				}
				if (SketchwareUtil.getLocationX(imageview1) == (SketchwareUtil.getLocationX(enem) - 40)) {
					hit_enemy.vibrate((long)(1000));
					sound = MediaPlayer.create(getApplicationContext(), R.raw.punch_kick);
					sound.start();
				}
				if (SketchwareUtil.getLocationX(imageview1) == (SketchwareUtil.getLocationX(enem) - (540 - 525))) {
					hit_enemy.vibrate((long)(1000));
					sound = MediaPlayer.create(getApplicationContext(), R.raw.punch_kick);
					sound.start();
				}
				if (SketchwareUtil.getLocationX(imageview1) == (SketchwareUtil.getLocationX(enem) - (557 - 525))) {
					hit_enemy.vibrate((long)(1000));
					sound = MediaPlayer.create(getApplicationContext(), R.raw.punch_kick);
					sound.start();
				}
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button2.setAlpha((float)(0.5d));
				btn_animation = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								button2.setAlpha((float)(1));
							}
						});
					}
				};
				_timer.schedule(btn_animation, (int)(100));
				jump.setTarget(imageview1);
				imageview1.setImageResource(R.drawable.player_jump);
				sound = MediaPlayer.create(getApplicationContext(), R.raw.fly);
				sound.start();
				jump.setPropertyName("translationY");
				jump.setFloatValues((float)(-100));
				jump.setDuration((int)(400));
				jump.setInterpolator(new AccelerateInterpolator());
				jump.start();
				player_movement = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								jump.cancel();
								sound.reset();
								imageview1.setImageResource(R.drawable.player_normal);
								jump.setTarget(imageview1);
								jump.setPropertyName("translationY");
								jump.setFloatValues((float)(0));
								jump.setDuration((int)(1000));
								jump.setInterpolator(new DecelerateInterpolator());
								jump.start();
							}
						});
					}
				};
				_timer.schedule(player_movement, (int)(400 + 250));
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button1.setAlpha((float)(0.5d));
				btn_animation = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								button1.setAlpha((float)(1));
							}
						});
					}
				};
				_timer.schedule(btn_animation, (int)(100));
				imageview1.setImageResource(R.drawable.sit);
				player_movement = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								imageview1.setImageResource(R.drawable.player_normal);
							}
						});
					}
				};
				_timer.schedule(player_movement, (int)(500));
			}
		});
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
