package com.uptalks.listview.ads;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class MainActivity extends AppCompatActivity {
	
	
	private double COUNT = 0;
	private double REPLACE = 0;
	private double COUNT_NUM = 0;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private LinearLayout linear1;
	private ScrollView vscroll1;
	private LinearLayout linear2;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
	}
	private void initializeLogic() {
		COUNT_NUM = 0;
		COUNT = 0;
		REPLACE = 100;
		for(int _repeat12 = 0; _repeat12 < (int)(REPLACE); _repeat12++) {
			if ((COUNT == 10) || ((COUNT == 20) || ((COUNT == 30) || (COUNT == 40)))) {
				{
					HashMap<String, Object> _item = new HashMap<>();
					_item.put("i", "ad");
					listmap.add(_item);
				}
				
				REPLACE++;
				COUNT++;
			}
			else {
				{
					HashMap<String, Object> _item = new HashMap<>();
					_item.put("i", String.valueOf((long)(COUNT_NUM)));
					listmap.add(_item);
				}
				
				COUNT++;
				COUNT_NUM++;
			}
		}
		
		
		grid = new GridView(MainActivity.this);
				
				
					
				
					grid.setLayoutParams(new GridView.LayoutParams(GridView.AUTO_FIT, listmap.size()*(int)getDip(64)));
										
								
						
						grid.setNumColumns(1);
						
						grid.setVerticalSpacing(5);
						
						grid.setHorizontalSpacing(5);
						
						grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
						
						grid.setAdapter(new Gridview1Adapter(listmap));
						
						linear2.addView(grid);
						grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
									  @Override
									  public void onItemClick(AdapterView parent, View view, int _pos, long id) {
												showMessage(String.valueOf(_pos));
									}
						});
				
				}
				private GridView grid;
				
				public class Gridview1Adapter extends BaseAdapter {
										ArrayList<HashMap<String, Object>> _data;
										public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
															_data = _arr;
										}
										
										@Override
										public int getCount() {
															return _data.size();
										}
										
										@Override
										public HashMap<String, Object> getItem(int _index) {
															return _data.get(_index);
										}
										
										@Override
										public long getItemId(int _index) {
															return _index;
										}
										
										@Override
										public View getView(final int _position, View _view, ViewGroup _viewGroup) {
															LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
															View _v = _view;
															if (_v == null) {
																				_v = _inflater.inflate(R.layout.cst, null);
															}
															
															final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
									final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
									
															final com.google.android.gms.ads.AdView adview1 = (com.google.android.gms.ads.AdView) _v.findViewById(R.id.adview1);
												
									
									android.graphics.drawable.GradientDrawable ab = new android.graphics.drawable.GradientDrawable();
						
						ab.setColor(Color.parseColor("#ffffff"));
						ab.setCornerRadius((float) 10);
						linear2.setElevation((float) 10);
						linear2.setBackground(ab);
						
									if (_data.get((int)_position).get("i").toString().startsWith("ad")) {
												
													textview1.setVisibility(View.GONE);
												adview1.setVisibility(View.VISIBLE);
												adview1.loadAd(new com.google.android.gms.ads.AdRequest.Builder().build());
									}
									else {
												textview1.setVisibility(View.VISIBLE);
												textview1.setText(_data.get((int)_position).get("i").toString());
												adview1.setVisibility(View.GONE);
									}
															return _v;
										}
				
			
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
