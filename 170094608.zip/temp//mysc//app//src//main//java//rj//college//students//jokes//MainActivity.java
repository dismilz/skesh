package rj.college.students.jokes;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import java.util.Timer;
import java.util.TimerTask;
import android.content.Intent;
import android.net.Uri;
import android.media.MediaPlayer;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.widget.AdapterView;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private double exit = 0;
	private String b = "";
	private String jsondate = "";
	private String myitem = "";
	
	private ArrayList<String> list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private LinearLayout linear1;
	private ListView listview1;
	
	private TimerTask plash_time;
	private Intent plash_intent = new Intent();
	private TimerTask exit_timer;
	private Intent info_intent = new Intent();
	private MediaPlayer media_share;
	private MediaPlayer media_info;
	private AlertDialog.Builder exit_dialog;
	private Intent listview = new Intent();
	private AlertDialog.Builder dialog_add;
	private SharedPreferences sp;
	private SharedPreferences dk;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		listview1 = (ListView) findViewById(R.id.listview1);
		exit_dialog = new AlertDialog.Builder(this);
		dialog_add = new AlertDialog.Builder(this);
		sp = getSharedPreferences("spa", Activity.MODE_PRIVATE);
		dk = getSharedPreferences("dk", Activity.MODE_PRIVATE);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				listview.setClass(getApplicationContext(), AnekdotActivity.class);
				listview.putExtra("key", list.get((int)(_position)));
				startActivity(listview);
			}
		});
	}
	private void initializeLogic() {
		_menu();
		ActionBar ab = getActionBar();
		ab.setCustomView(R.layout.action);
		ab.setDisplayShowCustomEnabled(true);
		
		plash_intent.setClass(getApplicationContext(), PlashActivity.class);
		startActivity(plash_intent);
		list.add("सबसे ज्यादा नशा किस में होता है?\nशराब - नहीं\nप्यार - नहीं\nपैसा - नहीं\nसबसे ज्यादा नशा होता है \"\"किताब\"\" में,\nखोलते ही नींद आ जाती है।");
		list.add("वो मुड़-मुड़ के देख रहे थे हमें;\nहम मुड़-मुड़ के देख रहे थे उन्हें;\nवो हमें, हम उन्हें, हम उन्हें, वो हमें;\nक्योंकि परीक्षा में न उन्हें कुछ आता था, न हमें!");
		list.add("अगर कोई लड़का परीक्षा में फेल हो जाये तो माँ तीन शब्द कहती है, \"\"और जा घूमने\"\"।\nगर्लफ्रेंड भी तीन शब्द कहती है, \"\"शर्म नहीं आती\"\"।\nऔर दोस्त भी तीन शब्द ही कहते हैं लेकिन दिल जीत लेते हैं,\n.\n.\n.\n.\n.\n.\n.\n.\n.\n.\n.\n\"\"अबे तू भी\"\"।");
		list.add("अगर आप स्कूल की मीठी यादों में खोये हैं;\nकॉलेज की हसीन यादों को संजोये हैं;\nक्लास में दोस्तों के साथ की मस्ती को यादों में परोये हो;\nतो...\n.\n.\n.\n.\n.\n.\n.\n.\nमार्क-शीट निकाल कर देखो, सारा नशा उतर जायेगा।");
		list.add("रात को किताब मेरी मुझे देखती रही;\nनींद मुझे अपनी तरफ घसीटती रही;\nनींद का झोंका मेरा मन मोह गया;\nऔर एक रात फिर ये GENIUS बिना पढ़े सो गया।");
		list.add("भगवान का दिया हुआ सब कुछ है,\nकिताबें हैं, नोट्स हैं, समय है,\nऔर हौंसला तो इतना कि जब चाहूँ पढ़ कर टॉप कर लूँ, मगर...\n.\n.\n.\n.\n.\n.\nये साला मूड ही नहीं बन रहा।");
		list.add("लिखो तो EXAM में कुछ ऐसा लिखो;\nकि PEN भी रोने को मज़बूर हो जाये;\nहर ANSWER में भर दो दर्द इतना;\nकि चेक करने वाला भी DISPRIN खा कर सो जाये।");
		list.add("अगर प्यार साथ हो तो तन्हाई नहीं होती;\nसच्चे प्यार में कभी बेवफाई नहीं होती;\nपर अगर एक बार हो जाये प्यार;\n.\n.\n.\n.\n.\n.\nफिर कितनी भी रख लो टयूशन फिर पढाई नहीं होती।");
		list.add("परीक्षा के बाद बच्चे और ऑपरेशन के बाद डॉक्टर एक ही चीज़ कहते हैं,\n.\n.\n.\n.\n.\n.\n.\n\"\"कुछ कह नहीं सकते, बस दुआ करें\"\"।");
		list.add("अगर हम एक बार जीते हैं;\nएक ही बार मरते हैं;\nप्यार भी एक बार करते हैं;\nशादी भी एक बार करते हैं'\nतो फिर ये...\n.\n.\n.\n.\n.\n.\nएग्जाम बार-बार क्यों होते हैं।");
		list.add("काश कोई एग्जाम रिजल्ट का इंश्योरेंस करवा देते;\nतो हर एग्जाम से पहले प्रीमियम भरवा देते;\nअगर पास होते तो ठीक;\nवरना इंश्योरेंस का भी क्लेम करवा लेते।");
		list.add("हर सवाल से डट कर लड़ना;\nफैंकने में कमी मत करना;\nमौक़ा मिले तो पीछे भी देखना;\nऔर एक बात याद रखना;\nआगे वाले का पेपर भी अपने ही समझना।");
		list.add("अर्ज़ किया है:\nये परीक्षा से रिश्ता भी अजीब होता है;\nसब अपना-अपना नसीब होता है;\nरह जाता है निगाहों से जो दूर;\nसाला वही सवाल पेपर में ज़रूर होता है।");
		list.add("किसी की धड़कन तेज़ करने के लिए प्यार की ज़रुरत नहीं, बस इतना ही कह दो कि\n.\n.\n.\n.\n.\n.\n.\n.\n.\nभाई तेरा रिजल्ट आ गया है। चेक कर ले!");
		list.add("अध्यापक (क्लास मे पढाते हुए): बच्चो आयकर, बिक्रीकर, भूमिकर से मिलता झुलता कोइ और शब्द बताओ?\nविद्यार्थी: सर, एक नही तीन शब्द सुने, सुनील गावासकर, सचिन तेंदुलकर और दिलीप वेंगसरकर।");
		list.add("कह दो उन पढ़ने वालों से;\nकभी हम भी पढ़ा करते थे;\nजितना सिलेबस पढ़ कर वो टॉप करते हैं;\nउतना तो हम Choice पर छोड़ दिया करते थे।");
		list.add("हमने इसीलिए महफ़िलों में जाना छोड़ दिया दोस्त;\nकि कोई पूछ ना ले\n.\n..\n...\nकोई पूछ ना ले कि बेटा पेपर की तैयारी कैसी है।");
		list.add("दिन में चैन नहीं, रात में नींद नहीं;\nजी ना लगे कहीं, ऐ खुदा क्या यही प्यार है?\nखुदा: नहीं बेटा, सभी Exam वालों का यही हाल है।");
		list.add("पेपर की रोटी, टेंशन का अचार;\nलैंप की किरण, सवालों की बहार;\nपेपर leak की चांदी, सीनियर्स का प्यार;\nमुबारक हो आपको Exam का त्यौहार।");
		list.add("एक विद्यार्थी दुसरे से: आज कुछ खतरनाक काम करने का मन कर रहा है।\nदूसरा विद्यार्थी: तो फिर चलो थोड़ी पढ़ाई करते हैं।");
		list.add("हर तरफ पढ़ाई का साया है;\nहर पेपर में जीरो आया है;\nहम तो यूँ ही चले जाते हैं बिना मुँह धोए परीक्षा देने;\nऔर लोग कहते हैं साला रात भर पढ़ के आया है।");
		list.add("किसी ने सच ही कहा है:\nजो आँखों से हमेशा रहते हैं दूर;\nवाह-वाह!\nजो आँखों से हमेशा रहते हैं दूर;\nवो प्रशन Exam में आते हैं ज़रूर।");
		list.add("कोई किताब ऐसी मिलती जिस पर दिल लुटा देते;\nहर विषय ने दिमाग खाया, किसी एक को निपटा देते;\nअब सिलेबस देख कर सोचते हैं कि 1 महीना और होता तो दुनियां हिला देते।");
		list.add("जोर का झटका हाय जोरों से लगा;\nपढ़ाई बन गई उम्र कैद की सज़ा;\nये है उदासी जान की प्यासी;\nEXAM से अच्छा तुम दे दो फांसी।");
		list.add("चेन्नई स्टूडेंट: पेपर बहुत आसान था।\nबैंगलोर स्टूडेंट: पेपर ठीक था।\nदिल्ली स्टूडेंट: पेपर मुश्किल था।\nपंजाबी स्टूडेन्ट: ओये पेपर दी छड्ड, मैडम पूरी अग्ग सी!");
		list.add("उसको पाने के लिए मैं भगवान से भी लड़ जाता,\n.\n..\nपर फिर मैंने सोचा कि \"\"इम्तिहान का समय है, भगवान से पंगा ठीक नहीं!\"\"");
		list.add("टीचर: रजनीकांत की फ़िल्म 'रोबोट' से क्या सीखने को मिलता है?\nछात्र: यही कि लड़की सिर्फ इंसान का ही नहीं, मशीन का भी दिमाग खराब कर सकती है!");
		list.add("अगर इम्तिहान में पेपर कठिन हो तो आँखें बंद करो;\nगहराई से सांस लो और ज़ोर से कहो: \"\"ये विषय बहुत मज़ेदार है इसे अगले साल फिर से पढ़ेंगे।\"\"");
		list.add("अर्ज़ है, \"\"स्वर्ग सबको चाहिए पर मरना कोई नहीं चाहता;\nवाह! वाह\n\"\"स्वर्ग सबको चाहिए पर मरना कोई नहीं चाहता;\nटॉप (TOP) सबको करना है पर पढ़ना कोई नहीं चाहता।\nपढ़ो यारों।");
		list.add("पढ़ाई सिर्फ दो वजह से होती है?\nएक शौक से;\nऔर\nदूसरा खौफ़ से।\nफालतू के शौक हम रखते नहीं;\nऔर\nखौफ़ तो हमें किसी के बाप का भी नहीं।");
		list.add("कोई चीज़ बे-वाफाई से बढ़कर क्या होगी;\nगम-ए तन्हाई जुदाई से बढ़कर क्या होगी;\nकिसी को देनी हो जवानी में सजा;\nतो वो सजा 'पढ़ाई' से बढ़कर क्या होगी।");
		list.add("मौत और मोहब्बत तो बस नाम से बदनाम है;\nवर्ना;\nतकलीफ़ तो सबसे ज्यादा पढ़ाई ही देती है।");
		list.add("जब question पेपर हो आउट ऑफ़ कंट्रोल;\nआंसर शीट को करके फोल्ड;\nएयरोप्लेन बना के बोल;\nभैया \"\"आल इज़ फेल।\"\"");
		list.add("जो लोग उठाते हैं हाथों में इश्क का झंडा;\nवही अक्सर पाते हैं एग्जाम में 'अंडा'।");
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("key", "null");
			listmap.add(_item);
		}
		
		listview1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_list_item_1, list));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		exit_dialog.setIcon(R.drawable.exit);
		
		exit_dialog.setTitle("Exit?");
		exit_dialog.setMessage("Do you really want to leave us...");
		exit_dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finishAffinity();
			}
		});
		exit_dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		exit_dialog.create().show();
		media_info = MediaPlayer.create(getApplicationContext(), R.raw.button);
		media_info.setLooping(false);
		media_info.start();
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if (dk.getString("dark", "").equals("1")) {
			listview1.setBackgroundColor(0xFFBDBDBD);
		}
		if (dk.getString("dark", "").equals("2")) {
			listview1.setBackgroundColor(0xFFFFFFFF);
		}
	}
	private void _info () {
		info_intent.setClass(getApplicationContext(), InfoActivity.class);
		startActivity(info_intent);
		media_info = MediaPlayer.create(getApplicationContext(), R.raw.button);
		media_info.setLooping(false);
		media_info.start();
	}
	
	
	private void _share () {
		b = "test";
		 Intent i = new Intent(android.content.Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(android.content.Intent.EXTRA_SUBJECT, b); startActivity(Intent.createChooser(i,"Share using..."));
		media_share = MediaPlayer.create(getApplicationContext(), R.raw.button);
		media_share.setLooping(false);
		media_share.start();
	}
	
	
	private void _menu () {
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		menu.add("Info")
		.setIcon(R.drawable.ic_info_outline_white)
		    .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		menu.add("Share")
		.setIcon(R.drawable.ic_share_white)
		    .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		menu.add("dark")
		.setIcon(R.drawable.dark_b)
		    .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(final MenuItem item){
		    switch (item.getTitle().toString()) {
			case "Info":
			_info();
			
			break;
			case "Share":
			_share();
			
			break;
			case "Dark":
			_dark();
			return true;
		}
		        return super.onOptionsItemSelected(item);
	}
	
	
	private void _dark () {
		SketchwareUtil.showMessage(getApplicationContext(), "dark");
		media_info = MediaPlayer.create(getApplicationContext(), R.raw.button);
		media_info.setLooping(false);
		media_info.start();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
