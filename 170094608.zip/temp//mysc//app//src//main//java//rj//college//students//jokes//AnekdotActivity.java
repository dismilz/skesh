package rj.college.students.jokes;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.media.MediaPlayer;
import android.content.SharedPreferences;
import android.view.View;
import android.content.ClipData;
import android.content.ClipboardManager;

public class AnekdotActivity extends Activity {
	
	
	private String a = "";
	
	private ScrollView vscroll1;
	private LinearLayout linear4;
	private LinearLayout linear1;
	private LinearLayout linear5;
	private TextView textview1;
	private ImageView copy;
	private ImageView sharef;
	private ImageView home;
	private ImageView dark;
	private ImageView light;
	
	private MediaPlayer media_share;
	private SharedPreferences dk;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.anekdot);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		textview1 = (TextView) findViewById(R.id.textview1);
		copy = (ImageView) findViewById(R.id.copy);
		sharef = (ImageView) findViewById(R.id.sharef);
		home = (ImageView) findViewById(R.id.home);
		dark = (ImageView) findViewById(R.id.dark);
		light = (ImageView) findViewById(R.id.light);
		dk = getSharedPreferences("dk", Activity.MODE_PRIVATE);
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		copy.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview1.getText().toString().concat("Download this from this link:")));
				SketchwareUtil.showMessage(getApplicationContext(), "Copy success....\nNow you can share this to anyone.");
			}
		});
		
		sharef.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_share();
			}
		});
		
		home.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		dark.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Shadow(15, 15, "#BDBDBD", linear1);
				_Shadow(15, 15, "#BDBDBD", linear5);
				vscroll1.setBackgroundColor(0xFFBDBDBD);
				dk.edit().putString("dark", "1").commit();
				dark.setVisibility(View.GONE);
				light.setVisibility(View.VISIBLE);
			}
		});
		
		light.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Shadow(15, 15, "#FFFFFF", linear1);
				_Shadow(15, 15, "#FFFFFF", linear5);
				vscroll1.setBackgroundColor(0xFFFFFFFF);
				dk.edit().putString("dark", "2").commit();
				light.setVisibility(View.GONE);
				dark.setVisibility(View.VISIBLE);
			}
		});
	}
	private void initializeLogic() {
		textview1.setText(getIntent().getStringExtra("key"));
		_Shadow(15, 15, "#FFFFFF", linear1);
		_Shadow(15, 15, "#FFFFFF", linear5);
		ActionBar ab = getActionBar();
		ab.setTitle("College students");
		ab.setDisplayHomeAsUpEnabled(true);
		/* */} 
	@Override 
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		int itemId = item.getItemId(); 
		switch (itemId) {
			case android.R.id.home:
			finish();
			break;
		}
		return true;
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		light.setVisibility(View.GONE);
		if (dk.getString("dark", "").equals("1")) {
			_Shadow(15, 15, "#BDBDBD", linear1);
			_Shadow(15, 15, "#BDBDBD", linear5);
			vscroll1.setBackgroundColor(0xFFBDBDBD);
			dark.setVisibility(View.GONE);
			light.setVisibility(View.VISIBLE);
		}
		else {
			
		}
	}
	private void _share () {
		_shareText(textview1.getText().toString());
	}
	
	
	private void _shareText (final String _text) {
		Intent sendIntent = new Intent();
		
		sendIntent.setAction(Intent.ACTION_SEND);
		
		sendIntent.putExtra(Intent.EXTRA_TEXT, _text);
		
		sendIntent.setType("text/plain");
		
		Intent shareIntent = Intent.createChooser(sendIntent,"Share using...");
		
		
		startActivity(shareIntent);
	}
	
	
	private void _Shadow (final double _sadw, final double _cru, final String _wc, final View _widgets) {
		android.graphics.drawable.GradientDrawable wd = new android.graphics.drawable.GradientDrawable();
		wd.setColor(Color.parseColor(_wc));
		wd.setCornerRadius((int)_cru);
		_widgets.setElevation((int)_sadw);
		_widgets.setBackground(wd);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
