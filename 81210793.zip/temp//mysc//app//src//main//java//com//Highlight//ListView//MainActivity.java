package com.Highlight.ListView;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.AdapterView;

public class MainActivity extends Activity {
	
	
	private HashMap<String, Object> map1 = new HashMap<>();
	private String Name = "";
	private double index = 0;
	private String Number = "";
	private String term = "";
	
	private ArrayList<HashMap<String, Object>> maplist1 = new ArrayList<>();
	
	private EditText edittext1;
	private ListView listview1;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		edittext1 = (EditText) findViewById(R.id.edittext1);
		listview1 = (ListView) findViewById(R.id.listview1);
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				term = _charSeq;
				listview1.setAdapter(new Listview1Adapter(maplist1));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				
				return true;
			}
		});
	}
	private void initializeLogic() {
		map1 = new HashMap<>();
		map1.put("Name", "Sanjeev");
		map1.put("Number", "0055234512");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Bear Pao");
		map1.put("Number", "0123456789");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Aniket");
		map1.put("Number", "0066789253");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Ananth");
		map1.put("Number", "4728976801");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Amar");
		map1.put("Number", "2728292526");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Adarsh");
		map1.put("Number", "1725268488");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Parth");
		map1.put("Number", "8676945026");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Ajay");
		map1.put("Number", "8566987654");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Ahmed Hussein");
		map1.put("Number", "8795046245");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Masari");
		map1.put("Number", "8675876323");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Eneries");
		map1.put("Number", "9874320967");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Pratik");
		map1.put("Number", "7764326786");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Blue Tags");
		map1.put("Number", "6965742810");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Baba");
		map1.put("Number", "3877137111");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Ram Murthy");
		map1.put("Number", "3891282455");
		maplist1.add(map1);
		map1 = new HashMap<>();
		map1.put("Name", "Vijay Naik");
		map1.put("Number", "8253626256");
		maplist1.add(map1);
		listview1.setAdapter(new Listview1Adapter(maplist1));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.custom, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final TextView textview2 = (TextView) _v.findViewById(R.id.textview2);
			
			Name = maplist1.get((int)_position).get("Name").toString();
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
