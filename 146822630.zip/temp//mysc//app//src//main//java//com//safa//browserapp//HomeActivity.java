package com.safa.browserapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.AdListener;
import android.app.Activity;
import android.content.SharedPreferences;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import android.webkit.WebViewClient;
import com.google.gson.Gson;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class HomeActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String search = "";
	private HashMap<String, Object> browse = new HashMap<>();
	private double key = 0;
	private String email_address = "";
	private String passwordd = "";
	private boolean login = false;
	
	private ArrayList<HashMap<String, Object>> web_search = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> wb_search = new ArrayList<>();
	
	private LinearLayout main;
	private LinearLayout linear1;
	private LinearLayout linear3;
	private LinearLayout linear2;
	private LinearLayout error2;
	private WebView web;
	private LinearLayout noconnection;
	private WebView wb;
	private ImageView home;
	private EditText edittext1;
	private ProgressBar loading;
	private ImageView refresh;
	private ImageView more;
	private ImageView imageview1;
	private TextView textview2;
	private ImageView error;
	private TextView textview1;
	private ImageView back;
	private ImageView stop;
	private ImageView forward;
	
	private Intent i = new Intent();
	private TimerTask t;
	private InterstitialAd ads;
	private AdListener _ads_ad_listener;
	private SharedPreferences dark;
	private RequestNetwork searchg;
	private RequestNetwork.RequestListener _searchg_request_listener;
	private SharedPreferences wb_history;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		main = (LinearLayout) findViewById(R.id.main);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		error2 = (LinearLayout) findViewById(R.id.error2);
		web = (WebView) findViewById(R.id.web);
		web.getSettings().setJavaScriptEnabled(true);
		web.getSettings().setSupportZoom(true);
		noconnection = (LinearLayout) findViewById(R.id.noconnection);
		wb = (WebView) findViewById(R.id.wb);
		wb.getSettings().setJavaScriptEnabled(true);
		wb.getSettings().setSupportZoom(true);
		home = (ImageView) findViewById(R.id.home);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		loading = (ProgressBar) findViewById(R.id.loading);
		refresh = (ImageView) findViewById(R.id.refresh);
		more = (ImageView) findViewById(R.id.more);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		error = (ImageView) findViewById(R.id.error);
		textview1 = (TextView) findViewById(R.id.textview1);
		back = (ImageView) findViewById(R.id.back);
		stop = (ImageView) findViewById(R.id.stop);
		forward = (ImageView) findViewById(R.id.forward);
		dark = getSharedPreferences("mode", Activity.MODE_PRIVATE);
		searchg = new RequestNetwork(this);
		wb_history = getSharedPreferences("wb_history", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		
		web.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				loading.setVisibility(View.VISIBLE);
				refresh.setVisibility(View.GONE);
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				loading.setVisibility(View.GONE);
				refresh.setVisibility(View.VISIBLE);
				try{
					browse = new HashMap<>();
					browse.put("url", edittext1.getText().toString());
					browse.put("web", web.getUrl());
					wb_search.add((int)0, browse);
					wb_history.edit().putString(String.valueOf((long)(key)), new Gson().toJson(wb_search)).commit();
				}catch(Exception e){
					 
				}
				super.onPageFinished(_param1, _param2);
			}
		});
		
		wb.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		home.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				wb.loadUrl("https://google.com/");
			}
		});
		
		edittext1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				web.loadUrl("http://www.google.com/search?q=".concat(edittext1.getText().toString()));
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		refresh.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				web.loadUrl(web.getUrl());
			}
		});
		
		more.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				PopupMenu popup = new PopupMenu(HomeActivity.this, more);
				Menu menu = popup.getMenu();
				menu.add("Open in Browser");
				menu.add("Settings");
				popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener(){
					@Override
					public boolean onMenuItemClick(MenuItem item){
						switch (item.getTitle().toString()){
							case "Open in Browser":
							i.setAction(Intent.ACTION_VIEW);
							i.setData(Uri.parse(wb.getUrl().concat(edittext1.getText().toString())));
							startActivity(i);
							break;
							case "Settings":
							i.setClass(getApplicationContext(), SettingsActivity.class);
							i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							startActivity(i);
							break;}
						return true;
					}
				});
				popup.show();
			}
		});
		
		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				web.goBack();
			}
		});
		
		stop.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				web.stopLoading();
			}
		});
		
		forward.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				web.goForward();
			}
		});
		
		_searchg_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				if (dark.getString("a", "").equals("1")) {
					main.setBackgroundColor(0xFF37474F);
					error2.setBackgroundColor(0xFF37474F);
					edittext1.setTextColor(Color.TRANSPARENT);
					textview1.setTextColor(0xFFFFFFFF);
					home.setImageResource(R.drawable.ic_home_white);
					refresh.setImageResource(R.drawable.ic_refresh_white);
					more.setImageResource(R.drawable.ic_more_vert_white);
					back.setImageResource(R.drawable.ic_chevron_left_white);
					stop.setImageResource(R.drawable.ic_close_white);
					forward.setImageResource(R.drawable.ic_chevron_right_white);
					error.setImageResource(R.drawable.ic_cloud_off_white);
					web.setBackgroundColor(0xFF37474F);
					linear3.setBackgroundColor(0xFF263238);
					linear2.setBackgroundColor(0xFF263238);
					_CardView("#263238", 7, 5, linear3);
					_CardView("#263238", 0, 5, linear2);
					
				}
				else {
					linear2.setBackgroundColor(0xFFFFFFFF);
					linear3.setBackgroundColor(0xFFFFFFFF);
					main.setBackgroundColor(0xFFFFFFFF);
					error2.setBackgroundColor(0xFFECEFF1);
					edittext1.setTextColor(Color.TRANSPARENT);
					textview1.setTextColor(0xFF000000);
					home.setImageResource(R.drawable.ic_home_grey);
					refresh.setImageResource(R.drawable.ic_refresh_grey);
					more.setImageResource(R.drawable.ic_more_vert_grey);
					back.setImageResource(R.drawable.ic_chevron_left_grey);
					stop.setImageResource(R.drawable.ic_close_grey);
					forward.setImageResource(R.drawable.ic_chevron_right_grey);
					error.setImageResource(R.drawable.ic_cloud_off_grey);
					web.setBackgroundColor(Color.TRANSPARENT);
					_CardView("#FFFFFF", 7, 5, linear3);
					_CardView("#FFFFFF", 0, 5, linear2);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				error2.setVisibility(View.VISIBLE);
				if (dark.getString("a", "").equals("1")) {
					main.setBackgroundColor(0xFF37474F);
					error2.setBackgroundColor(0xFF37474F);
					edittext1.setTextColor(0xFFFFFFFF);
					textview1.setTextColor(0xFFFFFFFF);
					home.setImageResource(R.drawable.ic_home_white);
					refresh.setImageResource(R.drawable.ic_refresh_white);
					more.setImageResource(R.drawable.ic_more_vert_white);
					back.setImageResource(R.drawable.ic_chevron_left_white);
					stop.setImageResource(R.drawable.ic_close_white);
					forward.setImageResource(R.drawable.ic_chevron_right_white);
					error.setImageResource(R.drawable.ic_cloud_off_white);
					_CardView("#263238", 7, 5, linear3);
					_CardView("#263238", 0, 5, linear2);
					
				}
				else {
					linear1.setBackgroundColor(0xFFFFFFFF);
					error2.setBackgroundColor(0xFFECEFF1);
					edittext1.setTextColor(0xFF607D8B);
					textview1.setTextColor(0xFF000000);
					home.setImageResource(R.drawable.ic_home_grey);
					refresh.setImageResource(R.drawable.ic_refresh_grey);
					more.setImageResource(R.drawable.ic_more_vert_grey);
					back.setImageResource(R.drawable.ic_chevron_left_grey);
					stop.setImageResource(R.drawable.ic_close_grey);
					forward.setImageResource(R.drawable.ic_chevron_right_white);
					error.setImageResource(R.drawable.ic_cloud_off_grey);
					_CardView("#FFFFFF", 7, 5, linear3);
					_CardView("#FFFFFF", 0, 5, linear2);
				}
			}
		};
		
		_ads_ad_listener = new AdListener() {
			@Override
			public void onAdLoaded() {
				
			}
			
			@Override
			public void onAdFailedToLoad(int _param1) {
				final int _errorCode = _param1;
				
			}
			
			@Override
			public void onAdOpened() {
				
			}
			
			@Override
			public void onAdClosed() {
				ads.loadAd(new
				AdRequest.Builder().build());
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		if (!(FirebaseAuth.getInstance().getCurrentUser() != null)) {
			
		}
		else {
			_ShowSnackbar("You logged in as ".concat(FirebaseAuth.getInstance().getCurrentUser().getEmail()), "DISMISS", 1000);
		}
		searchg.startRequestNetwork(RequestNetworkController.GET, web.getUrl(), "a", _searchg_request_listener);
		_download("/Safari/Downloads/");
		web.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
				
				
				DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
				String cookies = CookieManager.getInstance().getCookie(url);
				request.addRequestHeader("cookie", cookies);
				request.addRequestHeader("User-Agent", userAgent);
				request.setDescription("Downloading file...");
				request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
				request.allowScanningByMediaScanner(); request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
				java.io.File aatv = new java.io.File(Environment.getExternalStorageDirectory().getPath() + "/Webview/Download");if(!aatv.exists()){if (!aatv.mkdirs()){ Log.e("TravellerLog ::","Problem creating Image folder");}} request.setDestinationInExternalPublicDir("/Safari/Downloads/", URLUtil.guessFileName(url, contentDisposition, mimetype));
				
				DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				manager.enqueue(request);
				showMessage("Downloading File....");
				BroadcastReceiver onComplete = new BroadcastReceiver() {
					public void onReceive(Context ctxt, Intent intent) {
						showMessage("Download Complete!");
						unregisterReceiver(this);
					}};
				registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
			}
		});
		web.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
		web.loadUrl("https://google.com/search?q=");
		web.setWebChromeClient(new CustomWebClient());
		loading.setVisibility(View.GONE);
		_CardView("#FFFFFF", 7, 5, linear3);
		_CardView("#F5F5F5", 0, 5, linear2);
		_RippleEffect("Grey", home);
		_RippleEffect("Grey", refresh);
		_RippleEffect("Grey", more);
		_RippleEffect("Grey", back);
		_RippleEffect("Grey", stop);
		_RippleEffect("Grey", forward);
		ads = new InterstitialAd(getApplicationContext());
		ads.setAdListener(_ads_ad_listener);
		ads.setAdUnitId("ca-app-pub-1252287720252625/6050429807");
		ads.loadAd(new AdRequest.Builder().addTestDevice("567F81686DFCACE1B6714BBDB7364351")
		.build());
		noconnection.setVisibility(View.GONE);
		error2.setVisibility(View.GONE);
		wb.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (web.canGoBack()) {
			web.goBack();
		}
		else {
			finishAffinity();
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (dark.getString("a", "").equals("1")) {
			main.setBackgroundColor(0xFF37474F);
			error2.setBackgroundColor(0xFF37474F);
			edittext1.setTextColor(0xFFFFFFFF);
			textview1.setTextColor(0xFFFFFFFF);
			home.setImageResource(R.drawable.ic_home_white);
			refresh.setImageResource(R.drawable.ic_refresh_white);
			more.setImageResource(R.drawable.ic_more_vert_white);
			back.setImageResource(R.drawable.ic_chevron_left_white);
			stop.setImageResource(R.drawable.ic_close_white);
			forward.setImageResource(R.drawable.ic_chevron_right_white);
			error.setImageResource(R.drawable.ic_cloud_off_white);
			web.setBackgroundColor(0xFF37474F);
			linear3.setBackgroundColor(0xFF263238);
			linear2.setBackgroundColor(0xFF263238);
			_CardView("#263238", 7, 5, linear3);
			_CardView("#263238", 0, 5, linear2);
			
		}
		else {
			linear2.setBackgroundColor(0xFFFFFFFF);
			linear3.setBackgroundColor(0xFFFFFFFF);
			main.setBackgroundColor(0xFFFFFFFF);
			error2.setBackgroundColor(0xFFECEFF1);
			edittext1.setTextColor(0xFF607D8B);
			textview1.setTextColor(0xFF000000);
			home.setImageResource(R.drawable.ic_home_grey);
			refresh.setImageResource(R.drawable.ic_refresh_grey);
			more.setImageResource(R.drawable.ic_more_vert_grey);
			back.setImageResource(R.drawable.ic_chevron_left_grey);
			stop.setImageResource(R.drawable.ic_close_grey);
			forward.setImageResource(R.drawable.ic_chevron_right_grey);
			error.setImageResource(R.drawable.ic_cloud_off_grey);
			web.setBackgroundColor(0xFFFAFAFA);
			_CardView("#FFFFFF", 7, 5, linear3);
			_CardView("#FFFFFF", 0, 5, linear2);
		}
	}
	private void _extra () {
	}
	public class CustomWebClient extends WebChromeClient {
		private View mCustomView;
		private WebChromeClient.CustomViewCallback mCustomViewCallback;
		protected FrameLayout frame;
		
		// Initially mOriginalOrientation is set to Landscape
		private int mOriginalOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
		private int mOriginalSystemUiVisibility;
		
		// Constructor for CustomWebClient
		public CustomWebClient() {}
		
		public Bitmap getDefaultVideoPoster() {
			if (HomeActivity.this == null) {
				return null; }
			return BitmapFactory.decodeResource(HomeActivity.this.getApplicationContext().getResources(), 2130837573); }
		
		public void onShowCustomView(View paramView, WebChromeClient.CustomViewCallback viewCallback) {
			if (this.mCustomView != null) {
				onHideCustomView();
				return; }
			this.mCustomView = paramView;
			this.mOriginalSystemUiVisibility = HomeActivity.this.getWindow().getDecorView().getSystemUiVisibility();
			// When CustomView is shown screen orientation changes to mOriginalOrientation (Landscape).
			HomeActivity.this.setRequestedOrientation(this.mOriginalOrientation);
			// After that mOriginalOrientation is set to portrait.
			this.mOriginalOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
			this.mCustomViewCallback = viewCallback; ((FrameLayout)HomeActivity.this.getWindow().getDecorView()).addView(this.mCustomView, new FrameLayout.LayoutParams(-1, -1)); HomeActivity.this.getWindow().getDecorView().setSystemUiVisibility(3846);
		}
		
		public void onHideCustomView() {
			((FrameLayout)HomeActivity.this.getWindow().getDecorView()).removeView(this.mCustomView);
			this.mCustomView = null;
			HomeActivity.this.getWindow().getDecorView().setSystemUiVisibility(this.mOriginalSystemUiVisibility);
			// When CustomView is hidden, screen orientation is set to mOriginalOrientation (portrait).
			HomeActivity.this.setRequestedOrientation(this.mOriginalOrientation);
			// After that mOriginalOrientation is set to landscape.
			this.mOriginalOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE; this.mCustomViewCallback.onCustomViewHidden();
			this.mCustomViewCallback = null;
		}
	}
	{
	}
	
	
	private void _CardView (final String _color, final double _radius, final double _shadow, final View _view) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_radius);
		_view.setBackground(gd);
		
		try {
			if(Build.VERSION.SDK_INT >= 21) {
				_view.setElevation((int)_shadow);
			}
		} catch (Exception e) {}
	}
	
	
	private void _RippleEffect (final String _color, final View _view) {
		android.content.res.ColorStateList clr = new android.content.res.ColorStateList(new int[][]{new int[]{}},new int[]{Color.parseColor(_color)}); android.graphics.drawable.RippleDrawable ripdr = new android.graphics.drawable.RippleDrawable(clr, null, null); _view.setBackground(ripdr);
	}
	
	
	private void _download (final String _path) {
		if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat(_path))) {
			
		}
		else {
			FileUtil.makeDir(FileUtil.getExternalStorageDir().concat(_path));
		}
	}
	
	
	private void _ShowSnackbar (final String _message, final String _buttonText, final double _duration) {
		String ButtonText = "OK";
		if (!_buttonText.equals("")) {
			ButtonText= _buttonText;
		}
		ViewGroup parentLayout = (ViewGroup) ((ViewGroup) this .findViewById(android.R.id.content)).getChildAt(0);
		
		com.google.android.material.snackbar.Snackbar snackbar =
		com.google.android.material.snackbar.Snackbar.make(parentLayout, _message, com.google.android.material.snackbar.Snackbar.LENGTH_INDEFINITE).setAction(ButtonText, new View.OnClickListener() {
			 @Override 
			public void onClick(View view) {
			} 
		});
		if (!(_duration == 0)) {
			snackbar.setDuration((int)_duration*1000);
		}
		snackbar.show();
		/*default duration is 1 sec, and default button text is OK*/
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
