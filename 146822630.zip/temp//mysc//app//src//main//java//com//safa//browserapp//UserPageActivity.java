package com.safa.browserapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import java.util.Timer;
import java.util.TimerTask;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class UserPageActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> save_data = new HashMap<>();
	
	private LinearLayout linear1;
	private ImageView imageview1;
	private LinearLayout linear3;
	private LinearLayout view;
	private TextView textview1;
	private EditText edittext1;
	private LinearLayout linear2;
	private EditText edittext2;
	private Button button1;
	private Button button2;
	private Button button3;
	
	private TimerTask fade;
	private FirebaseAuth authentication;
	private OnCompleteListener<AuthResult> _authentication_create_user_listener;
	private OnCompleteListener<AuthResult> _authentication_sign_in_listener;
	private OnCompleteListener<Void> _authentication_reset_password_listener;
	private Calendar user_time_and_date = Calendar.getInstance();
	private DatabaseReference safari_user = _firebase.getReference("safari_user");
	private ChildEventListener _safari_user_child_listener;
	private Intent main_home = new Intent();
	private TimerTask sign_in;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.user_page);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		view = (LinearLayout) findViewById(R.id.view);
		textview1 = (TextView) findViewById(R.id.textview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		button1 = (Button) findViewById(R.id.button1);
		button2 = (Button) findViewById(R.id.button2);
		button3 = (Button) findViewById(R.id.button3);
		authentication = FirebaseAuth.getInstance();
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (0 < edittext1.getText().toString().length()) {
					fade = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
									button1.setVisibility(View.GONE);
									edittext1.setVisibility(View.GONE);
									edittext2.setVisibility(View.VISIBLE);
									button2.setVisibility(View.VISIBLE);
									button3.setVisibility(View.VISIBLE);
								}
							});
						}
					};
					_timer.schedule(fade, (int)(1500));
				}
				else {
					_Error(edittext1, "Please enter your email.");
				}
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (0 < edittext2.getText().toString().length()) {
					_prog(true, "", "Please wait...");
					sign_in = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									authentication.signInWithEmailAndPassword(edittext1.getText().toString(), edittext2.getText().toString()).addOnCompleteListener(UserPageActivity.this, _authentication_sign_in_listener);
									_prog(false, "", "Please wait...");
								}
							});
						}
					};
					_timer.schedule(sign_in, (int)(2500));
				}
				else {
					_Error(edittext2, "Please enter your password.");
				}
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (0 < edittext2.getText().toString().length()) {
					_prog(true, "", "Please wait...");
					sign_in = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									authentication.createUserWithEmailAndPassword(edittext1.getText().toString(), edittext2.getText().toString()).addOnCompleteListener(UserPageActivity.this, _authentication_create_user_listener);
									_prog(false, "", "Please wait...");
								}
							});
						}
					};
					_timer.schedule(sign_in, (int)(2500));
				}
				else {
					_ShowSnackbar("Please enter your password.", "DISMISS", 0);
				}
			}
		});
		
		_safari_user_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		safari_user.addChildEventListener(_safari_user_child_listener);
		
		_authentication_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					main_home.setAction(Intent.ACTION_VIEW);
					main_home.setClass(getApplicationContext(), HomeActivity.class);
					main_home.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(main_home);
					user_time_and_date = Calendar.getInstance();
					save_data = new HashMap<>();
					save_data.put("email", edittext1.getText().toString());
					save_data.put("password", edittext2.getText().toString());
					save_data.put("time", new SimpleDateFormat("hh:mm a").format(user_time_and_date.getTime()));
					save_data.put("date", new SimpleDateFormat("MM/dd/yyyy").format(user_time_and_date.getTime()));
					safari_user.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(save_data);
					save_data.clear();
					finish();
				}
				else {
					_ShowSnackbar("Email is already used.", "DISMISS", 0);
				}
			}
		};
		
		_authentication_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					main_home.setAction(Intent.ACTION_VIEW);
					main_home.setClass(getApplicationContext(), HomeActivity.class);
					main_home.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(main_home);
					user_time_and_date = Calendar.getInstance();
					save_data = new HashMap<>();
					save_data.put("email", edittext1.getText().toString());
					save_data.put("password", edittext2.getText().toString());
					save_data.put("time", new SimpleDateFormat("hh:mm a").format(user_time_and_date.getTime()));
					save_data.put("date", new SimpleDateFormat("MM/dd/yyyy").format(user_time_and_date.getTime()));
					safari_user.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(save_data);
					save_data.clear();
					finish();
				}
				else {
					_ShowSnackbar("User not registered.", "DISMISS", 0);
				}
			}
		};
		
		_authentication_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		edittext2.setVisibility(View.GONE);
		button2.setVisibility(View.GONE);
		button3.setVisibility(View.GONE);
		_CornerRadius("#E0E0E0", 7, 0, edittext1);
		_CornerRadius("#E0E0E0", 7, 0, edittext2);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _prog (final boolean _ifShow, final String _t, final String _m) {
		if (_ifShow) {
			if (prog == null){
				prog = new ProgressDialog(this);
				prog.setMax(100);
				prog.setIndeterminate(true);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
			}
			prog.setTitle(_t);
			prog.setMessage(_m);
			prog.show();
		}
		else {
			if (prog != null){
				prog.dismiss();
			}
		}
	}
	private ProgressDialog prog;
	{
	}
	
	
	private void _CornerRadius (final String _color, final double _radius, final double _shadow, final View _view) {
		android.graphics.drawable.GradientDrawable STRING = new android.graphics.drawable.GradientDrawable();
		STRING.setColor(Color.parseColor(_color));
		STRING.setCornerRadius((int)_radius);
		_view.setBackground(STRING);
		if(Build.VERSION.SDK_INT >= 21) { 
			_view.setElevation((int)_shadow);}
	}
	
	
	private void _Error (final TextView _view, final String _message) {
		_view.setError(_message);
	}
	
	
	private void _ShowSnackbar (final String _message, final String _buttonText, final double _duration) {
		String ButtonText = "OK";
		if (!_buttonText.equals("")) {
			ButtonText= _buttonText;
		}
		ViewGroup parentLayout = (ViewGroup) ((ViewGroup) this .findViewById(android.R.id.content)).getChildAt(0);
		
		com.google.android.material.snackbar.Snackbar snackbar =
		com.google.android.material.snackbar.Snackbar.make(parentLayout, _message, com.google.android.material.snackbar.Snackbar.LENGTH_INDEFINITE).setAction(ButtonText, new View.OnClickListener() {
			 @Override 
			public void onClick(View view) {
			} 
		});
		if (!(_duration == 0)) {
			snackbar.setDuration((int)_duration*1000);
		}
		snackbar.show();
		/*default duration is 1 sec, and default button text is OK*/
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
