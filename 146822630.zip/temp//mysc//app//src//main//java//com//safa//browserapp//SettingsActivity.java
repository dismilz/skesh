package com.safa.browserapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Switch;
import android.app.Activity;
import android.content.SharedPreferences;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import java.util.Timer;
import java.util.TimerTask;
import android.widget.CompoundButton;
import android.view.View;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class SettingsActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> browse = new HashMap<>();
	private double key = 0;
	private String package_name = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String your_version = "";
	private String latest_version = "";
	
	private ArrayList<HashMap<String, Object>> web = new ArrayList<>();
	private ArrayList<String> web_url = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> wb_search = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> version_check = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear6;
	private LinearLayout linear4;
	private ListView listview1;
	private LinearLayout linear5;
	private ImageView imageview1;
	private TextView textview1;
	private TextView textview2;
	private Switch switch1;
	private TextView textview5;
	private TextView email;
	private TextView textview3;
	private TextView textview4;
	
	private SharedPreferences dark;
	private SharedPreferences wb_history;
	private DatabaseReference Var = _firebase.getReference("version");
	private ChildEventListener _Var_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private Intent login = new Intent();
	private AlertDialog.Builder sign_out;
	private TimerTask sign_out_user;
	private Intent profile = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.settings);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		listview1 = (ListView) findViewById(R.id.listview1);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		switch1 = (Switch) findViewById(R.id.switch1);
		textview5 = (TextView) findViewById(R.id.textview5);
		email = (TextView) findViewById(R.id.email);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		dark = getSharedPreferences("mode", Activity.MODE_PRIVATE);
		wb_history = getSharedPreferences("wb_history", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		sign_out = new AlertDialog.Builder(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		switch1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					dark.edit().putString("a", "1").commit();
					linear1.setBackgroundColor(0xFF546E7A);
					textview1.setTextColor(0xFFFFFFFF);
					textview5.setTextColor(0xFFFFFFFF);
					email.setTextColor(0xFFFFFFFF);
					textview3.setTextColor(0xFFFFFFFF);
					imageview1.setImageResource(R.drawable.ic_arrow_back_white);
					linear4.setBackgroundColor(0xFF78909C);
					linear6.setBackgroundColor(0xFF78909C);
					_CardView("#263238", 0, 5, linear2);
					_CornerRadius("#37474F", 7, 5, linear3);
				}
				else {
					dark.edit().putString("a", "0").commit();
					linear1.setBackgroundColor(0xFFFAFAFA);
					textview1.setTextColor(0xFF000000);
					email.setTextColor(0xFF000000);
					textview5.setTextColor(0xFF000000);
					textview3.setTextColor(0xFF000000);
					imageview1.setImageResource(R.drawable.ic_arrow_back_grey);
					linear4.setBackgroundColor(0xFFCFD8DC);
					linear6.setBackgroundColor(0xFFCFD8DC);
					_CardView("#FFFFFF", 0, 5, linear2);
					_CornerRadius("#FFFFFF", 7, 5, linear3);
				}
			}
		});
		
		email.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!(FirebaseAuth.getInstance().getCurrentUser() != null)) {
					login.setAction(Intent.ACTION_VIEW);
					login.setClass(getApplicationContext(), UserPageActivity.class);
					login.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(login);
				}
				else {
					profile.setAction(Intent.ACTION_VIEW);
					profile.setClass(getApplicationContext(), AccountActivity.class);
					profile.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(profile);
				}
			}
		});
		
		_Var_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Var.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						version_check = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								version_check.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						latest_version = version_check.get((int)0).get("v").toString();
						if (Double.parseDouble(latest_version) > Double.parseDouble(your_version)) {
							SketchwareUtil.showMessage(getApplicationContext(), "New Version is Available");
						}
						else {
							if (Double.parseDouble(your_version) > Double.parseDouble(latest_version)) {
								Var.child("safari").child("version").setValue(your_version);
							}
							else {
								SketchwareUtil.showMessage(getApplicationContext(), "Latest Version is Installed");
							}
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Var.addChildEventListener(_Var_child_listener);
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		_CardView("#FFFFFF", 0, 5, linear2);
		_CornerRadius("#FFFFFF", 7, 5, linear3);
		_CornerRadius("#CFD8DC", 7, 5, linear6);
		_CornerRadius("#CFD8DC", 7, 5, linear4);
		if (!wb_history.getString(String.valueOf((long)(key)), "").equals("")) {
			wb_search = new Gson().fromJson(wb_history.getString(String.valueOf((long)(key)), ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		}
		listview1.setAdapter(new Listview1Adapter(wb_search));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
			email.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
			textview5.setVisibility(View.VISIBLE);
		}
		else {
			email.setText("None".concat("/Not Logged In"));
			textview5.setVisibility(View.GONE);
		}
		_version();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (dark.getString("a", "").equals("1")) {
			linear1.setBackgroundColor(0xFF607D8B);
			textview1.setTextColor(0xFFFFFFFF);
			textview5.setTextColor(0xFFFFFFFF);
			email.setTextColor(0xFFFFFFFF);
			textview3.setTextColor(0xFFFFFFFF);
			imageview1.setImageResource(R.drawable.ic_arrow_back_white);
			linear4.setBackgroundColor(0xFF78909C);
			linear6.setBackgroundColor(0xFF78909C);
			_CardView("#263238", 0, 5, linear2);
			_CornerRadius("#37474F", 7, 5, linear3);
			switch1.setChecked(true);
		}
		else {
			linear1.setBackgroundColor(0xFFFFFFFF);
			linear4.setBackgroundColor(0xFFCFD8DC);
			linear6.setBackgroundColor(0xFFCFD8DC);
			textview1.setTextColor(0xFF000000);
			email.setTextColor(0xFF000000);
			textview5.setTextColor(0xFF000000);
			textview3.setTextColor(0xFF000000);
			imageview1.setImageResource(R.drawable.ic_arrow_back_grey);
			_CardView("#FFFFFF", 0, 5, linear2);
			_CornerRadius("#FFFFFF", 7, 5, linear3);
		}
	}
	private void _CardView (final String _color, final double _radius, final double _shadow, final View _view) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_radius);
		_view.setBackground(gd);
		
		try {
			if(Build.VERSION.SDK_INT >= 21) {
				_view.setElevation((int)_shadow);
			}
		} catch (Exception e) {}
	}
	
	
	private void _CornerRadius (final String _color, final double _radius, final double _shadow, final View _view) {
		android.graphics.drawable.GradientDrawable STRING = new android.graphics.drawable.GradientDrawable();
		STRING.setColor(Color.parseColor(_color));
		STRING.setCornerRadius((int)_radius);
		_view.setBackground(STRING);
		if(Build.VERSION.SDK_INT >= 21) { 
			_view.setElevation((int)_shadow);}
	}
	
	
	private void _RippleEffect (final String _color, final View _view) {
		android.content.res.ColorStateList clr = new android.content.res.ColorStateList(new int[][]{new int[]{}},new int[]{Color.parseColor(_color)}); android.graphics.drawable.RippleDrawable ripdr = new android.graphics.drawable.RippleDrawable(clr, null, null); _view.setBackground(ripdr);
	}
	
	
	private void _getData () {
		if (!wb_history.getString(String.valueOf((long)(key)), "").equals("")) {
			wb_search = new Gson().fromJson(wb_history.getString(String.valueOf((long)(key)), ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		}
		listview1.setAdapter(new Listview1Adapter(wb_search));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	
	private void _version () {
		package_name = "com.safa.browserapp";
		try {
			android.content.pm.PackageInfo pinfo = getPackageManager().getPackageInfo( package_name, android.content.pm.PackageManager.GET_ACTIVITIES);
			your_version = pinfo.versionName;  
		}
		catch (Exception e){ showMessage(e.toString()); }
		DatabaseReference rootRef = _firebase.getReference(); rootRef.child("version").addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot snapshot) {
				if (snapshot.exists()) { } else {
					map = new HashMap<>();
					map.put("version", your_version);
					Var.child("safari").updateChildren(map);
					map.clear();
				} }
			@Override
			public void onCancelled(DatabaseError _error) { } });
	}
	
	
	private void _prog (final boolean _ifShow, final String _t, final String _m) {
		if (_ifShow) {
			if (prog == null){
				prog = new ProgressDialog(this);
				prog.setMax(100);
				prog.setIndeterminate(true);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
			}
			prog.setTitle(_t);
			prog.setMessage(_m);
			prog.show();
		}
		else {
			if (prog != null){
				prog.dismiss();
			}
		}
	}
	private ProgressDialog prog;
	{
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.history, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final TextView textview2 = (TextView) _v.findViewById(R.id.textview2);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			
			textview1.setText(_data.get((int)_position).get("url").toString());
			textview2.setText(_data.get((int)_position).get("web").toString());
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_data.remove((int)(_position));
					wb_history.edit().putString(String.valueOf((long)(key)), new Gson().toJson(wb_search)).commit();
					_getData();
					SketchwareUtil.showMessage(getApplicationContext(), "Deleted!");
				}
			});
			_RippleEffect("Grey", imageview1);
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
