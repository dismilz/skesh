package com.chat.app.sal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import java.util.Timer;
import java.util.TimerTask;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.ClipData;
import android.view.View;
import android.animation.Animator;
import android.widget.AdapterView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import android.content.ClipboardManager;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
	
	public final int REQ_CD_IMAGES = 101;
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> mapv = new HashMap<>();
	private double n = 0;
	private String str = "";
	private boolean isImage = false;
	private double image = 0;
	private String imagepath = "";
	private String imagename = "";
	private String nick = "";
	
	private ArrayList<HashMap<String, Object>> list = new ArrayList<>();
	private ArrayList<String> sts = new ArrayList<>();
	private ArrayList<String> path = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear_bg;
	private TextView textview2;
	private LinearLayout linear6;
	private ImageView imageview4;
	private ImageView imageview_setting;
	private LinearLayout linear8;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear_refresh;
	private ListView listpesan;
	private EditText edittext1;
	private TextView textview_refresh;
	private LinearLayout linear_editpesan;
	private LinearLayout linear9;
	private EditText edit_pesan;
	private ImageView imageview2;
	private ImageView imageview1;
	
	private SharedPreferences user;
	private Intent a = new Intent();
	private Calendar c = Calendar.getInstance();
	private DatabaseReference chat = _firebase.getReference(" chat");
	private ChildEventListener _chat_child_listener;
	private AlertDialog.Builder i;
	private ObjectAnimator animat = new ObjectAnimator();
	private TimerTask tem;
	private RequestNetwork neet;
	private RequestNetwork.RequestListener _neet_request_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private AlertDialog.Builder ggg;
	private Intent images = new Intent(Intent.ACTION_GET_CONTENT);
	private SharedPreferences bg;
	private Intent loading = new Intent();
	private AlertDialog.Builder signOut;
	private AlertDialog.Builder Delete;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear_bg = (LinearLayout) findViewById(R.id.linear_bg);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		imageview_setting = (ImageView) findViewById(R.id.imageview_setting);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear_refresh = (LinearLayout) findViewById(R.id.linear_refresh);
		listpesan = (ListView) findViewById(R.id.listpesan);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		textview_refresh = (TextView) findViewById(R.id.textview_refresh);
		linear_editpesan = (LinearLayout) findViewById(R.id.linear_editpesan);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		edit_pesan = (EditText) findViewById(R.id.edit_pesan);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		user = getSharedPreferences("user", Activity.MODE_PRIVATE);
		i = new AlertDialog.Builder(this);
		neet = new RequestNetwork(this);
		auth = FirebaseAuth.getInstance();
		ggg = new AlertDialog.Builder(this);
		images.setType("image/*");
		images.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		bg = getSharedPreferences("bg", Activity.MODE_PRIVATE);
		signOut = new AlertDialog.Builder(this);
		Delete = new AlertDialog.Builder(this);
		
		textview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				edittext1 = new EditText(MainActivity.this); edittext1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)); 
				edittext1.setHint("Masukkan Nickname"); 
				
				android.support.design.widget.TextInputLayout textinput1 = new android.support.design.widget.TextInputLayout(MainActivity.this);
				textinput1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
				textinput1.setCounterEnabled(true);
				textinput1.setCounterMaxLength(20);
				textinput1.addView(edittext1);
				ggg.setView(textinput1); 
				ggg.setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						nick = edittext1.getText().toString();
						textview2.setText(nick);
					}
				});
				ggg.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				ggg.create().show();
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				signOut.setTitle("Sign Out");
				signOut.setPositiveButton("YES", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						a.setClass(getApplicationContext(), LoginActivity.class);
						FirebaseAuth.getInstance().signOut();
						startActivity(a);
					}
				});
				signOut.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				signOut.create().show();
			}
		});
		
		imageview_setting.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				a.setClass(getApplicationContext(), SettingsActivity.class);
				startActivity(a);
			}
		});
		
		listpesan.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", list.get((int)_position).get("pesan").toString()));
				SketchwareUtil.showMessage(getApplicationContext(), "Message Copied...👍");
			}
		});
		
		listpesan.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (user.getString("email", "").equals(list.get((int)_position).get("email").toString())) {
					i.setTitle("REMOVE MESSAGE?");
					i.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							chat.child(sts.get((int)(_position))).removeValue();
						}
					});
					i.setNegativeButton("NO", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					i.create().show();
				}
				return true;
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Refresh..");
				((BaseAdapter)listpesan.getAdapter()).notifyDataSetChanged();
				neet.startRequestNetwork(RequestNetworkController.GET, "http://www.muskfoundation.org", "g", _neet_request_listener);
				animat.setTarget(imageview2);
				animat.setPropertyName("rotation");
				animat.setFloatValues((float)(0), (float)(360));
				animat.setRepeatMode(ValueAnimator.RESTART);
				animat.setRepeatCount((int)(2));
				animat.setDuration((int)(2500));
				animat.start();
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (0 < edit_pesan.getText().toString().length()) {
					c = Calendar.getInstance();
					mapv = new HashMap<>();
					mapv.put("name", user.getString("name", ""));
					mapv.put("pesan", edit_pesan.getText().toString());
					mapv.put("time", new SimpleDateFormat("hh:mm EEE, d MMM").format(c.getTime()));
					mapv.put("email", user.getString("email", ""));
					chat.push().updateChildren(mapv);
					edit_pesan.setText("");
					mapv.clear();
				}
			}
		});
		
		_chat_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				chat.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						list = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								list.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						sts.add(_childKey);
						listpesan.setAdapter(new ListpesanAdapter(list));
						((BaseAdapter)listpesan.getAdapter()).notifyDataSetChanged();
						textview_refresh.setVisibility(View.GONE);
						linear_refresh.setVisibility(View.GONE);
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				chat.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						list = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								list.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listpesan.setAdapter(new ListpesanAdapter(list));
						((BaseAdapter)listpesan.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		chat.addChildEventListener(_chat_child_listener);
		
		animat.addListener(new Animator.AnimatorListener() {
			@Override
			public void onAnimationStart(Animator _param1) {
				neet.startRequestNetwork(RequestNetworkController.GET, "http://www.muskfoundation.org", "g", _neet_request_listener);
				listpesan.setAdapter(new ListpesanAdapter(list));
				((BaseAdapter)listpesan.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void onAnimationEnd(Animator _param1) {
				
			}
			
			@Override
			public void onAnimationCancel(Animator _param1) {
				
			}
			
			@Override
			public void onAnimationRepeat(Animator _param1) {
				
			}
		});
		
		_neet_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "Interrupted Internet Connection");
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task){
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		if (!bg.getString("wallpaper", "").equals("")) {
			_setBackground(linear_bg, bg.getString("wallpaper", ""));
		}
		else {
			linear_bg.setBackgroundResource(R.drawable.spruce_art_forest_131371_480x854);
		}
		textview_refresh.setVisibility(View.VISIBLE);
		linear_refresh.setVisibility(View.VISIBLE);
		if (!user.getString("backup", "").equals("")) {
			list = new Gson().fromJson(user.getString("backup", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			listpesan.setAdapter(new ListpesanAdapter(list));
		}
		listpesan.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
		listpesan.setStackFromBottom(true);
		listpesan.setDivider(null); listpesan.setDividerHeight(2);
		android.graphics.drawable.GradientDrawable l = new android.graphics.drawable.GradientDrawable(); l.setColor(Color.parseColor("#FF0000AA")); l.setCornerRadius(45); linear9.setBackground(l);
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable(); s.setColor(Color.parseColor("#FFFFFF")); s.setCornerRadius(45); linear_editpesan.setBackground(s);
		edittext1.setVisibility(View.GONE);
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
			textview2.setText(user.getString("name", ""));
			chat.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					list = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							list.add(_map);
						}
					}
					catch (Exception _e) {
						_e.printStackTrace();
					}
					((BaseAdapter)listpesan.getAdapter()).notifyDataSetChanged();
					textview_refresh.setVisibility(View.GONE);
					linear_refresh.setVisibility(View.GONE);
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
		}
		else {
			a.setClass(getApplicationContext(), LoginActivity.class);
			startActivity(a);
		}
		loading.setClass(getApplicationContext(), LoadingActivity.class);
		startActivity(loading);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		i.setTitle("Exit");
		i.setMessage("Are you sure you want to leave?");
		i.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				tem = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								user.edit().putString("backup", new Gson().toJson(list)).commit();
								finish();
							}
						});
					}
				};
				_timer.schedule(tem, (int)(150));
			}
		});
		i.setNegativeButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		i.create().show();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		animat.setTarget(textview_refresh);
		animat.setPropertyName("alpha");
		animat.setFloatValues((float)(1), (float)(0.05d));
		animat.setDuration((int)(2000));
		animat.setRepeatMode(ValueAnimator.REVERSE);
		animat.setRepeatCount((int)(99999));
		animat.start();
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		finish();
	}
	private void _setBackground (final View _view, final String _path) {
		_view.setBackground(new android.graphics.drawable.BitmapDrawable(getResources(), FileUtil.decodeSampleBitmapFromPath(_path, 1024, 1024)));
	}
	
	
	private void _Elevation (final View _view, final double _number) {
		
		_view.setElevation((int)_number);
	}
	
	
	public class ListpesanAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public ListpesanAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.cust, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final LinearLayout linear4 = (LinearLayout) _v.findViewById(R.id.linear4);
			final LinearLayout linear7 = (LinearLayout) _v.findViewById(R.id.linear7);
			final TextView textview_msg = (TextView) _v.findViewById(R.id.textview_msg);
			final LinearLayout linear3 = (LinearLayout) _v.findViewById(R.id.linear3);
			final TextView textview_name = (TextView) _v.findViewById(R.id.textview_name);
			final TextView textview_mail = (TextView) _v.findViewById(R.id.textview_mail);
			final TextView textview_time = (TextView) _v.findViewById(R.id.textview_time);
			
			n = Math.round(SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) * 0.70d);
			LinearLayout.LayoutParams lp = new
			LinearLayout.LayoutParams((int)n,
			LinearLayout.LayoutParams.WRAP_CONTENT);
			linear4.setLayoutParams(lp);
			if (user.getString("email", "").equals(list.get((int)_position).get("email").toString())) {
				linear1.setGravity(Gravity.RIGHT);
				android.graphics.drawable.GradientDrawable ip = new android.graphics.drawable.GradientDrawable(); ip.setColor(Color.parseColor("#FFE1FFC7")); ip.setCornerRadius(15); linear4.setBackground(ip);
				_Elevation(linear4, 10);
				textview_name.setTextColor(0xFF009688);
			}
			else {
				linear1.setGravity(Gravity.LEFT);
				android.graphics.drawable.GradientDrawable p = new android.graphics.drawable.GradientDrawable(); p.setColor(Color.parseColor("#FFFFFF")); p.setCornerRadius(15); linear4.setBackground(p);
				_Elevation(linear4, 10);
				textview_name.setTextColor(0xFF26C6DA);
			}
			textview_name.setText(list.get((int)_position).get("name").toString());
			textview_mail.setText(list.get((int)_position).get("email").toString());
			textview_msg.setText(list.get((int)_position).get("pesan").toString());
			textview_time.setText(list.get((int)_position).get("time").toString());
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
