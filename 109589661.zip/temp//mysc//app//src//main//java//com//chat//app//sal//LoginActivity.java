package com.chat.app.sal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ImageView;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.Intent;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;
import android.app.Activity;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;

public class LoginActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private LinearLayout linear1;
	private LinearLayout linear_login;
	private LinearLayout linear_signup;
	private LinearLayout linear_reset;
	private TextView textview1;
	private EditText edittext_username;
	private EditText edittext_email_login;
	private LinearLayout linear5;
	private Button button_login;
	private LinearLayout linear2;
	private EditText edittext_pass_login;
	private ImageView imageview1;
	private ImageView imageview2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private TextView textview4;
	private TextView textview_signup;
	private TextView textview3;
	private EditText editext_email_signup;
	private LinearLayout linear6;
	private Button button_signup;
	private TextView textview_login;
	private EditText edittext_pass_signup;
	private ImageView imageview3;
	private ImageView imageview4;
	private TextView textview5;
	private EditText edit_reset;
	private Button button1;
	private TextView textview6;
	
	private FirebaseAuth auth;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private Intent c = new Intent();
	private TimerTask time;
	private SharedPreferences user;
	private AlertDialog.Builder dial;
	private SharedPreferences walk;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.login);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear_login = (LinearLayout) findViewById(R.id.linear_login);
		linear_signup = (LinearLayout) findViewById(R.id.linear_signup);
		linear_reset = (LinearLayout) findViewById(R.id.linear_reset);
		textview1 = (TextView) findViewById(R.id.textview1);
		edittext_username = (EditText) findViewById(R.id.edittext_username);
		edittext_email_login = (EditText) findViewById(R.id.edittext_email_login);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		button_login = (Button) findViewById(R.id.button_login);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		edittext_pass_login = (EditText) findViewById(R.id.edittext_pass_login);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview_signup = (TextView) findViewById(R.id.textview_signup);
		textview3 = (TextView) findViewById(R.id.textview3);
		editext_email_signup = (EditText) findViewById(R.id.editext_email_signup);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		button_signup = (Button) findViewById(R.id.button_signup);
		textview_login = (TextView) findViewById(R.id.textview_login);
		edittext_pass_signup = (EditText) findViewById(R.id.edittext_pass_signup);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		edit_reset = (EditText) findViewById(R.id.edit_reset);
		button1 = (Button) findViewById(R.id.button1);
		textview6 = (TextView) findViewById(R.id.textview6);
		auth = FirebaseAuth.getInstance();
		user = getSharedPreferences("user", Activity.MODE_PRIVATE);
		dial = new AlertDialog.Builder(this);
		walk = getSharedPreferences("bg", Activity.MODE_PRIVATE);
		
		button_login.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext_email_login.getText().toString().concat(edittext_pass_login.getText().toString()).equals("") && edittext_username.getText().toString().equals("")) {
					dial.setTitle("Login Error!!!");
					dial.setMessage("Fill in All Blank Data");
					dial.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dial.create().show();
				}
				else {
					user.edit().putString("name", edittext_username.getText().toString()).commit();
					user.edit().putString("email", edittext_email_login.getText().toString()).commit();
					auth.signInWithEmailAndPassword(edittext_email_login.getText().toString(), edittext_pass_login.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_sign_in_listener);
				}
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				edittext_pass_login.setTransformationMethod(android.text.method.HideReturnsTransformationMethod.getInstance());
				imageview1.setVisibility(View.GONE);
				imageview2.setVisibility(View.VISIBLE);
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				edittext_pass_login.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
				imageview1.setVisibility(View.VISIBLE);
				imageview2.setVisibility(View.GONE);
			}
		});
		
		textview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_login.setVisibility(View.GONE);
				linear_reset.setVisibility(View.VISIBLE);
			}
		});
		
		textview_signup.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_login.setVisibility(View.GONE);
				linear_signup.setVisibility(View.VISIBLE);
			}
		});
		
		button_signup.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (editext_email_signup.getText().toString().concat(edittext_pass_signup.getText().toString()).equals("")) {
					dial.setTitle("SignUp Error!!!");
					dial.setMessage("Email / Pass Do not Leave blank");
					dial.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dial.create().show();
				}
				else {
					auth.createUserWithEmailAndPassword(editext_email_signup.getText().toString(), edittext_pass_signup.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_create_user_listener);
				}
			}
		});
		
		textview_login.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_login.setVisibility(View.VISIBLE);
				linear_signup.setVisibility(View.GONE);
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				edittext_pass_signup.setTransformationMethod(android.text.method.HideReturnsTransformationMethod.getInstance());
				imageview3.setVisibility(View.GONE);
				imageview4.setVisibility(View.VISIBLE);
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				edittext_pass_signup.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
				imageview3.setVisibility(View.VISIBLE);
				imageview4.setVisibility(View.GONE);
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edit_reset.getText().toString().equals("")) {
					dial.setTitle("Reset Password Error!!!");
					dial.setMessage("Email Do not leave blank");
					dial.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dial.create().show();
				}
				else {
					auth.sendPasswordResetEmail(edit_reset.getText().toString()).addOnCompleteListener(_auth_reset_password_listener);
				}
			}
		});
		
		textview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_login.setVisibility(View.VISIBLE);
				linear_reset.setVisibility(View.GONE);
			}
		});
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task){
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					SketchwareUtil.showMessage(getApplicationContext(), "Welcome..!!!");
					time = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									linear_login.setVisibility(View.VISIBLE);
									linear_signup.setVisibility(View.GONE);
								}
							});
						}
					};
					_timer.schedule(time, (int)(500));
				}
				else {
					dial.setTitle("User Signup Error!!!");
					dial.setMessage(_errorMessage);
					dial.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dial.create().show();
				}
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					SketchwareUtil.showMessage(getApplicationContext(), "Welcome..!!!");
					time = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									c.setClass(getApplicationContext(), MainActivity.class);
									startActivity(c);
									finish();
								}
							});
						}
					};
					_timer.schedule(time, (int)(500));
				}
				else {
					dial.setTitle("User SignIn Error!!!");
					dial.setMessage(_errorMessage);
					dial.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dial.create().show();
				}
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				if (_success) {
					dial.setTitle("Password Reset Successfully");
					dial.setMessage(" ");
					dial.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							linear_login.setVisibility(View.VISIBLE);
							linear_reset.setVisibility(View.GONE);
							finish();
						}
					});
					dial.create().show();
				}
				else {
					dial.setTitle("Reset Failed");
					dial.setMessage("Make sure the email address is correct");
					dial.setPositiveButton("OK", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dial.create().show();
				}
			}
		};
	}
	private void initializeLogic() {
		_setBackground(linear1, walk.getString("wallpaper", ""));
		linear_signup.setVisibility(View.GONE);
		linear_reset.setVisibility(View.GONE);
		linear_login.setVisibility(View.VISIBLE);
		imageview2.setVisibility(View.GONE);
		imageview4.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _setBackground (final View _view, final String _path) {
		_view.setBackground(new android.graphics.drawable.BitmapDrawable(getResources(), FileUtil.decodeSampleBitmapFromPath(_path, 1024, 1024)));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
