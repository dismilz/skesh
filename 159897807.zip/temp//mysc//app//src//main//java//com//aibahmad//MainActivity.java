package com.aibahmad;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ProgressBar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.Intent;
import android.net.Uri;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.graphics.Typeface;

public class MainActivity extends AppCompatActivity {
	
	
	private String Edittext1 = "";
	private String Edittext2 = "";
	
	private LinearLayout main;
	private TextView textview1;
	private EditText edittext1;
	private EditText edittext2;
	private Button button1;
	private LinearLayout linear12;
	private LinearLayout linear2;
	private ProgressBar cpb;
	private TextView textview2;
	private LinearLayout linear9;
	private LinearLayout linear7;
	private LinearLayout linear10;
	private TextView textview6;
	private TextView textview9;
	private LinearLayout linear8_line_left;
	private TextView textview7;
	private LinearLayout linear9_line_right;
	private TextView textview8;
	private TextView textview10;
	
	private FirebaseAuth login;
	private OnCompleteListener<AuthResult> _login_create_user_listener;
	private OnCompleteListener<AuthResult> _login_sign_in_listener;
	private OnCompleteListener<Void> _login_reset_password_listener;
	private Intent i = new Intent();
	private Calendar c = Calendar.getInstance();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		main = (LinearLayout) findViewById(R.id.main);
		textview1 = (TextView) findViewById(R.id.textview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		button1 = (Button) findViewById(R.id.button1);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		cpb = (ProgressBar) findViewById(R.id.cpb);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview9 = (TextView) findViewById(R.id.textview9);
		linear8_line_left = (LinearLayout) findViewById(R.id.linear8_line_left);
		textview7 = (TextView) findViewById(R.id.textview7);
		linear9_line_right = (LinearLayout) findViewById(R.id.linear9_line_right);
		textview8 = (TextView) findViewById(R.id.textview8);
		textview10 = (TextView) findViewById(R.id.textview10);
		login = FirebaseAuth.getInstance();
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				_SingleLineComment("This whole method is new");
				Edittext2 = edittext2.getText().toString();
				if (_charSeq.trim().length() > 0) {
					if (Edittext2.trim().length() > 0) {
						button1.setEnabled(true);
						button1.setBackgroundColor(0xFF3897F0);
						_RoundedCorners(button1, "#3897f0");
					}
					else {
						button1.setEnabled(false);
						button1.setBackgroundColor(0xFF90CAF9);
						_RoundedCorners(button1, "#90CAF9");
					}
				}
				else {
					button1.setEnabled(false);
					button1.setBackgroundColor(0xFF90CAF9);
					_RoundedCorners(button1, "#90CAF9");
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		edittext2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				_SingleLineComment("this whole method is new");
				Edittext1 = edittext1.getText().toString();
				if (_charSeq.trim().length() > 0) {
					if (Edittext1.trim().length() > 0) {
						button1.setEnabled(true);
						button1.setBackgroundColor(0xFF3897F0);
						_RoundedCorners(button1, "#3897f0");
					}
					else {
						button1.setEnabled(false);
						button1.setBackgroundColor(0xFF90CAF9);
						_RoundedCorners(button1, "#90CAF9");
					}
				}
				else {
					button1.setEnabled(false);
					button1.setBackgroundColor(0xFF90CAF9);
					_RoundedCorners(button1, "#90CAF9");
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_SingleLineComment("this is new method");
				if (edittext1.getText().toString().trim().length() > 0) {
					if (edittext2.getText().toString().trim().length() > 0) {
						edittext1.setEnabled(false);
						edittext2.setEnabled(false);
						linear12.setVisibility(View.VISIBLE);
						button1.setVisibility(View.GONE);
						login.signInWithEmailAndPassword(edittext1.getText().toString(), edittext2.getText().toString()).addOnCompleteListener(MainActivity.this, _login_sign_in_listener);
					}
				}
			}
		});
		
		linear9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_SingleLineComment("this method is new ");
				i.setClass(getApplicationContext(), ForgotActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
				startActivity(i);
			}
		});
		
		linear10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_SingleLineComment("this is new method");
				i.setClass(getApplicationContext(), SignupActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
				startActivity(i);
			}
		});
		
		_login_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_login_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					edittext1.setEnabled(true);
					edittext2.setEnabled(true);
					linear12.setVisibility(View.GONE);
					button1.setVisibility(View.VISIBLE);
					i.setClass(getApplicationContext(), HomeActivity.class);
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
					finish();
				}
				else {
					_ErrorChecker(_errorMessage);
				}
			}
		};
		
		_login_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				if (_success) {
					_iDialog("Email Sent", "We sent an email to ".concat(edittext1.getText().toString().concat(" with a link to get back into your account.")), "OK", "2D6FDE", "G");
				}
				else {
					_iDialog("Error", "An unknown error has occurred please try again later.", "Try Again", "000000", "G");
				}
			}
		};
	}
	private void initializeLogic() {
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/pacifico.ttf"), 0);
		_round_stock(10, 10, 10, 10, "#fafafa", edittext1, 3, "#dbdbdb");
		_round_stock(10, 10, 10, 10, "#fafafa", edittext2, 3, "#dbdbdb");
		_SingleLineComment("Everything is new below this block");
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
			i.setClass(getApplicationContext(), HomeActivity.class);
			i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(i);
			finish();
		}
		linear12.setVisibility(View.GONE);
		_RoundedCorners(linear12, "#90CAF9");
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
		edittext1.setShowSoftInputOnFocus(true);
		edittext2.setShowSoftInputOnFocus(true);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {cpb.getIndeterminateDrawable().setColorFilter(  Color.parseColor("#ffffff"), android.graphics.PorterDuff.Mode.SRC_IN); }
		button1.setBackgroundColor(0xFF90CAF9);
		button1.setEnabled(false);
		_RoundedCorners(button1, "#90CAF9");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _round_stock (final double _one, final double _two, final double _three, final double _four, final String _color, final View _view, final double _swidth, final String _scolor) {
		Double left_top = _one;
		Double right_top = _two;
		Double left_bottom = _three;
		Double right_bottom = _four;
		Double sw = _swidth;
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable();
		s.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		s.setCornerRadii(new float[] {left_top.floatValue(),left_top.floatValue(), right_top.floatValue(),right_top.floatValue(), left_bottom.floatValue(),left_bottom.floatValue(), right_bottom.floatValue(),right_bottom.floatValue()});
		s.setColor(Color.parseColor(_color));
		_view.setBackground(s);
		s.setStroke(sw.intValue(), Color.parseColor(_scolor));
	}
	
	
	private void _RoundedCorners (final View _view, final String _color) {
		android.graphics.drawable.GradientDrawable line = new android.graphics.drawable.GradientDrawable();  line.setColor(Color.parseColor(_color));  line.setCornerRadius(10);  _view.setBackground(line);
	}
	
	
	private void _SingleLineComment (final String _comment) {
		"//".concat(_comment);
	}
	
	
	private void _ErrorChecker (final String _error) {
		if (_error.equals("A network error (such as timeout, interrupted connection or unreachable host) has occurred.")) {
			_iDialog("Error", "An unknown network error has occurred.", "Dismiss", "2D6FDE", "G");
		}
		else {
			if (_error.equals("The email address is badly formatted.")) {
				_iDialog("Incorrect Email", "The email you entered doesn't appear to belong to an account.\nPlease check your email and try again.", "Try Again", "000000", "G");
			}
			else {
				if (_error.equals("There is no user record corresponding to this identifier. The user may have been deleted.")) {
					_iDialog("Incorrect Email", "The email you entered doesn't appear to belong to an account.\nPlease check your email and try again.", "Try Again", "000000", "G");
				}
				else {
					if (_error.equals("The password is invalid or the user does not have a password.")) {
						_iDialog("Forgotten password for ".concat(edittext1.getText().toString().concat("?")), "We can send you an email to help you get back into your account.", "Try Again", "000000", "V");
					}
					else {
						_iDialog("Something went wrong! ", _error, "OK", "2D6FDE", "G");
					}
				}
			}
		}
		edittext1.setEnabled(true);
		edittext2.setEnabled(true);
		linear12.setVisibility(View.GONE);
		button1.setVisibility(View.VISIBLE);
	}
	
	
	private void _iDialog (final String _title, final String _message, final String _btntxt, final String _color, final String _value) {
		int num = Integer.parseInt(_color, 16)+0xFF000000;
		final AlertDialog d = new AlertDialog.Builder(MainActivity.this).create();
		LayoutInflater inflater = getLayoutInflater();
		View convertVie = (View) inflater.inflate(R.layout.infodialog, null);
		
		LinearLayout linearLayout = (LinearLayout) convertVie.findViewById(R.id.chip);
		
		if (_value.equals("G")) {
			linearLayout.setVisibility(View.GONE);
		}
		if (_value.equals("V")) {
			linearLayout.setVisibility(View.VISIBLE);
		}
		
		TextView text1 = (TextView) convertVie.findViewById(R.id.textview1);
		text1.setText(_title);
		
		TextView text2 = (TextView) convertVie.findViewById(R.id.textview2);
		text2.setText(_message);
		
		TextView text3 = (TextView) convertVie.findViewById(R.id.textview3);
		text3.setTextColor(num);
		text3.setText(_btntxt);
		
		TextView text4 = (TextView) convertVie.findViewById(R.id.textview4);
		
		text3.setOnClickListener(new View.OnClickListener(){
			    public void onClick(View v){
				d.dismiss();
			}
		});
		
		text4.setOnClickListener(new View.OnClickListener(){
			    public void onClick(View v){
				
				login.sendPasswordResetEmail(edittext1.getText().toString()).addOnCompleteListener(_login_reset_password_listener);
				d.dismiss();
			}
		});
		
		
		LinearLayout inear = (LinearLayout) convertVie.findViewById(R.id.box);
		
		android.graphics.drawable.GradientDrawable ine = new android.graphics.drawable.GradientDrawable();  ine.setColor(Color.parseColor("#ffffff"));
		ine.setCornerRadius(20);
		inear.setBackground(ine);
		
		
		d.setView(convertVie);
		d.setCancelable(false);
		d.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
		d.show();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
