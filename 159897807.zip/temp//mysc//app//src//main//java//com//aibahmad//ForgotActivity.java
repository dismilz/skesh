package com.aibahmad;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ProgressBar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

public class ForgotActivity extends AppCompatActivity {
	
	
	private LinearLayout linear2;
	private LinearLayout linear3;
	private TextView textview3;
	private TextView textview4;
	private TextView textview5;
	private EditText edittext1;
	private Button button1;
	private LinearLayout linear12;
	private ProgressBar cpb;
	
	private FirebaseAuth forgot;
	private OnCompleteListener<AuthResult> _forgot_create_user_listener;
	private OnCompleteListener<AuthResult> _forgot_sign_in_listener;
	private OnCompleteListener<Void> _forgot_reset_password_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.forgot);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		button1 = (Button) findViewById(R.id.button1);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		cpb = (ProgressBar) findViewById(R.id.cpb);
		forgot = FirebaseAuth.getInstance();
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.trim().length() > 0) {
					button1.setEnabled(true);
					button1.setBackgroundColor(0xFF3897F0);
					_RoundedCorners(button1, "#3897f0");
				}
				else {
					button1.setEnabled(false);
					button1.setBackgroundColor(0xFF90CAF9);
					_RoundedCorners(button1, "#90CAF9");
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().trim().length() > 0) {
					edittext1.setEnabled(false);
					button1.setVisibility(View.GONE);
					linear12.setVisibility(View.VISIBLE);
					forgot.sendPasswordResetEmail(edittext1.getText().toString()).addOnCompleteListener(_forgot_reset_password_listener);
				}
			}
		});
		
		_forgot_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_forgot_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_forgot_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				if (_success) {
					_iDialog("Email Sent", "we have sent an email to ".concat(edittext1.getText().toString().concat(" with a link to get back into your account.")), "OK", "2D6FDE", "G");
				}
				else {
					_iDialog("Something went wrong!", "The email you entered doesn't exist, please chech your email again and Try again or it may be a network error.", "Try Again", "000000", "G");
				}
				edittext1.setEnabled(true);
				linear12.setVisibility(View.GONE);
				button1.setVisibility(View.VISIBLE);
			}
		};
	}
	private void initializeLogic() {
		linear2.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			    Window w = ForgotActivity.this.getWindow();
			    w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			    w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			    w.setStatusBarColor(Color.parseColor("#efefef"));
		}
		_round_stock(10, 10, 10, 10, "#fafafa", edittext1, 3, "#dbdbdb");
		_setElevation(linear2);
		linear12.setVisibility(View.GONE);
		_RoundedCorners(linear12, "#90CAF9");
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
		edittext1.setShowSoftInputOnFocus(true);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {cpb.getIndeterminateDrawable().setColorFilter(  Color.parseColor("#ffffff"), android.graphics.PorterDuff.Mode.SRC_IN); }
		button1.setBackgroundColor(0xFF90CAF9);
		button1.setEnabled(false);
		_RoundedCorners(button1, "#90CAF9");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		finish();
	}
	private void _setElevation (final View _view) {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { _view.setElevation(10f);}
	}
	
	
	private void _RoundedCorners (final View _view, final String _color) {
		android.graphics.drawable.GradientDrawable line = new android.graphics.drawable.GradientDrawable();  line.setColor(Color.parseColor(_color));  line.setCornerRadius(10);  _view.setBackground(line);
	}
	
	
	private void _round_stock (final double _one, final double _two, final double _three, final double _four, final String _color, final View _view, final double _swidth, final String _scolor) {
		Double left_top = _one;
		Double right_top = _two;
		Double left_bottom = _three;
		Double right_bottom = _four;
		Double sw = _swidth;
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable();
		s.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		s.setCornerRadii(new float[] {left_top.floatValue(),left_top.floatValue(), right_top.floatValue(),right_top.floatValue(), left_bottom.floatValue(),left_bottom.floatValue(), right_bottom.floatValue(),right_bottom.floatValue()});
		s.setColor(Color.parseColor(_color));
		_view.setBackground(s);
		s.setStroke(sw.intValue(), Color.parseColor(_scolor));
	}
	
	
	private void _iDialog (final String _title, final String _message, final String _btntxt, final String _color, final String _value) {
		int num = Integer.parseInt(_color, 16)+0xFF000000;
		final AlertDialog d = new AlertDialog.Builder(ForgotActivity.this).create();
		LayoutInflater inflater = getLayoutInflater();
		View convertVie = (View) inflater.inflate(R.layout.infodialog, null);
		
		LinearLayout linearLayout = (LinearLayout) convertVie.findViewById(R.id.chip);
		
		if (_value.equals("G")) {
			linearLayout.setVisibility(View.GONE);
		}
		if (_value.equals("V")) {
			linearLayout.setVisibility(View.VISIBLE);
		}
		
		TextView text1 = (TextView) convertVie.findViewById(R.id.textview1);
		text1.setText(_title);
		
		TextView text2 = (TextView) convertVie.findViewById(R.id.textview2);
		text2.setText(_message);
		
		TextView text3 = (TextView) convertVie.findViewById(R.id.textview3);
		text3.setTextColor(num);
		text3.setText(_btntxt);
		
		TextView text4 = (TextView) convertVie.findViewById(R.id.textview4);
		
		text3.setOnClickListener(new View.OnClickListener(){
			    public void onClick(View v){
				d.dismiss();
			}
		});
		
		text4.setOnClickListener(new View.OnClickListener(){
			    public void onClick(View v){
				
				forgot.sendPasswordResetEmail(edittext1.getText().toString()).addOnCompleteListener(_forgot_reset_password_listener);
				d.dismiss();
			}
		});
		
		
		LinearLayout inear = (LinearLayout) convertVie.findViewById(R.id.box);
		
		android.graphics.drawable.GradientDrawable ine = new android.graphics.drawable.GradientDrawable();  ine.setColor(Color.parseColor("#ffffff"));
		ine.setCornerRadius(20);
		inear.setBackground(ine);
		
		
		d.setView(convertVie);
		d.setCancelable(false);
		d.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
		d.show();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
