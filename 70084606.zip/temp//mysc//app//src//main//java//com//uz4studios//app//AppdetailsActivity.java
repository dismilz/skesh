package com.uz4studios.app;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Continuation;
import java.io.File;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.view.View;
import android.widget.AdapterView;
import com.bumptech.glide.Glide;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class AppdetailsActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private double doy = 0;
	private String ddd = "";
	private String fr = "";
	private String fontName = "";
	private String typeace = "";
	private HashMap<String, Object> map = new HashMap<>();
	private double pos = 0;
	
	private ArrayList<String> str = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ImageView imageview1;
	private LinearLayout linear3;
	private ImageView imageview2;
	private ScrollView vscroll1;
	private LinearLayout linear8;
	private LinearLayout linear4;
	private LinearLayout linear9;
	private LinearLayout scrback;
	private LinearLayout linear15;
	private LinearLayout image_back;
	private TextView link;
	private LinearLayout linear5;
	private ImageView icon_png;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private TextView textview1;
	private TextView textview2;
	private LinearLayout linear20;
	private Button button1;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear11;
	private LinearLayout scr1;
	private LinearLayout scr2;
	private ImageView imageview5;
	private ImageView imageview4;
	private LinearLayout linear16;
	private TextView textview4;
	private LinearLayout rate;
	private TextView textview3;
	private LinearLayout linear17;
	private ImageView imageview6;
	private TextView textview5;
	private LinearLayout rate_linear;
	private LinearLayout linear18;
	private TextView textview6;
	private ListView listview1;
	
	private Intent i = new Intent();
	private StorageReference fs = _firebase_storage.getReference("fs");
	private OnCompleteListener<Uri> _fs_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fs_download_success_listener;
	private OnSuccessListener _fs_delete_success_listener;
	private OnProgressListener _fs_upload_progress_listener;
	private OnProgressListener _fs_download_progress_listener;
	private OnFailureListener _fs_failure_listener;
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private DatabaseReference uyu = _firebase.getReference("uyu");
	private ChildEventListener _uyu_child_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.appdetails);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		scrback = (LinearLayout) findViewById(R.id.scrback);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		image_back = (LinearLayout) findViewById(R.id.image_back);
		link = (TextView) findViewById(R.id.link);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		icon_png = (ImageView) findViewById(R.id.icon_png);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		button1 = (Button) findViewById(R.id.button1);
		hscroll1 = (HorizontalScrollView) findViewById(R.id.hscroll1);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		scr1 = (LinearLayout) findViewById(R.id.scr1);
		scr2 = (LinearLayout) findViewById(R.id.scr2);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		textview4 = (TextView) findViewById(R.id.textview4);
		rate = (LinearLayout) findViewById(R.id.rate);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		textview5 = (TextView) findViewById(R.id.textview5);
		rate_linear = (LinearLayout) findViewById(R.id.rate_linear);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		textview6 = (TextView) findViewById(R.id.textview6);
		listview1 = (ListView) findViewById(R.id.listview1);
		net = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Ripple_Drawable(image_back, "#BDBDBD");
				i.setClass(getApplicationContext(), StoreActivity.class);
				startActivity(i);
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Ripple_Drawable(imageview2, "#BDBDBD");
				i.setClass(getApplicationContext(), AppviewActivity.class);
				startActivity(i);
			}
		});
		
		linear20.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), HhfgActivity.class);
				startActivity(i);
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/PlayStore/"))) {
					ddd = Uri.parse(Uri.parse(link.getText().toString()).getLastPathSegment()).getLastPathSegment();
					fr = "/PlayStore/".concat(ddd);
					_Download(link.getText().toString(), fr);
				}
				else {
					FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/PlayStore/"));
					ddd = Uri.parse(Uri.parse(link.getText().toString()).getLastPathSegment()).getLastPathSegment();
					fr = "/PlayStore/".concat(ddd);
					_Download(link.getText().toString(), fr);
				}
			}
		});
		
		scr1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), VisualActivity.class);
				i.putExtra("yuyu", getIntent().getStringExtra("rasm1"));
				startActivity(i);
			}
		});
		
		scr2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), VisualActivity.class);
				i.putExtra("yuyu", getIntent().getStringExtra("rasm2"));
				startActivity(i);
			}
		});
		
		rate_linear.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_pickColor();
			}
		});
		
		textview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), RateActivity.class);
				startActivity(i);
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				
				return true;
			}
		});
		
		_fs_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fs_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				SketchwareUtil.showMessage(getApplicationContext(), "جاري التحميل    ".concat(String.valueOf((long)(_progressValue)).concat("%")));
			}
		};
		
		_fs_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_fs_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				SketchwareUtil.showMessage(getApplicationContext(), "Download successful\nstorage/emulated/Downloads/".concat(ddd));
			}
		};
		
		_fs_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fs_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_uyu_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		uyu.addChildEventListener(_uyu_child_listener);
	}
	private void initializeLogic() {
		_lightStatusBar(true);
		_radius("#FFFFFF", "#FFFFFF", 20, 20, 10, image_back);
		_setElavation(image_back, 10);
		_radius("#FFFFFF", "#FFFFFF", 20, 20, 8, scr1);
		_radius("#FFFFFF", "#FFFFFF", 20, 20, 8, scr2);
		_Ripple_Drawable(image_back, "#BDBDBD");
		_Ripple_Drawable(imageview2, "#BDBDBD");
		textview1.setText(getIntent().getStringExtra("nomi"));
		textview4.setText(getIntent().getStringExtra("haqida"));
		textview2.setText(getIntent().getStringExtra("nomer"));
		link.setText(getIntent().getStringExtra("oppo"));
		Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("rasm2"))).into(imageview4);
		Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("rasm1"))).into(imageview5);
		Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("icon"))).into(icon_png);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _lightStatusBar (final boolean _shouldchange) {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) { View decor = getWindow().getDecorView();
			if (_shouldchange) { decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); } else { decor.setSystemUiVisibility(0); } }
	}
	
	
	private void _Ripple_Drawable (final View _view, final String _c) {
		android.content.res.ColorStateList clr = new android.content.res.ColorStateList(new int[][]{new int[]{}},new int[]{Color.parseColor(_c)}); android.graphics.drawable.RippleDrawable ripdr = new android.graphics.drawable.RippleDrawable(clr, null, null); _view.setBackground(ripdr);
	}
	
	
	private void _radius (final String _color, final String _strokeColor, final double _stroke, final double _radius, final double _shadow, final View _view) {
		android.graphics.drawable.GradientDrawable gd1 = new android.graphics.drawable.GradientDrawable();
		gd1.setColor(Color.parseColor(_strokeColor));
		gd1.setCornerRadius((int)_stroke);
		_view.setBackground(gd1);
		
		try {
			if(Build.VERSION.SDK_INT >= 21) {
				_view.setElevation((int)_shadow);
			}
		} catch (Exception e) {}
	}
	
	
	private void _pickColor () {
		final AlertDialog cpDialog = new AlertDialog.Builder(AppdetailsActivity.this).create();
		
		View convertView = (View) getLayoutInflater().inflate(R.layout.rateus, null);
		
		cpDialog.setView(convertView);
		
		cpDialog.show();
		final Button rate = (Button)convertView.findViewById(R.id.button1);
		
		rate.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View a) {
				
				_on();
				cpDialog.dismiss();
			}
		});
		final Button cancel = (Button)convertView.findViewById(R.id.button2);
		
		cancel.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View a) {
				
				_cancel();
				cpDialog.dismiss();
			}
		});
		final LinearLayout colorLayout = (LinearLayout)
		convertView.findViewById(R.id.linear2);
		
		
		rb = new RatingBar(this); rb.setNumStars(5); rb.setStepSize(0.5f); rb.setRating(0.0f); colorLayout.addView(rb); rb.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener(){ @Override public void onRatingChanged(RatingBar rating, float r,boolean user){ 
				doy = rb.getRating();
				 } }); } 
	
	RatingBar rb; private void nothing() {
	}
	
	
	private void _on () {
		if (doy < 1.0d) {
			map = new HashMap<>();
			map.put("etar", "0.5»»★");
			map.put("lolo", textview1.getText().toString());
			uyu.push().updateChildren(map);
			map.clear();
		}
		else {
			if (doy == 1.0d) {
				map = new HashMap<>();
				map.put("etar", "1.0»»★");
				map.put("lolo", textview1.getText().toString());
				uyu.push().updateChildren(map);
				map.clear();
			}
			else {
				if (doy < 2.0d) {
					map = new HashMap<>();
					map.put("etar", "1.5»»★");
					map.put("lolo", textview1.getText().toString());
					uyu.push().updateChildren(map);
					map.clear();
				}
				else {
					if (doy == 2.0d) {
						map = new HashMap<>();
						map.put("etar", "2.0»»★");
						map.put("lolo", textview1.getText().toString());
						uyu.push().updateChildren(map);
						map.clear();
					}
					else {
						if (doy < 3.0d) {
							map = new HashMap<>();
							map.put("etar", "2.5»»★");
							map.put("lolo", textview1.getText().toString());
							uyu.push().updateChildren(map);
							map.clear();
						}
						else {
							if (doy == 3.0d) {
								map = new HashMap<>();
								map.put("etar", "3.0»»★");
								map.put("lolo", textview1.getText().toString());
								uyu.push().updateChildren(map);
								map.clear();
							}
							else {
								if (doy < 4.0d) {
									map = new HashMap<>();
									map.put("etar", "3.5»»★");
									map.put("lolo", textview1.getText().toString());
									uyu.push().updateChildren(map);
									map.clear();
								}
								else {
									if (doy == 4.0d) {
										map = new HashMap<>();
										map.put("etar", "4.0»»★");
										map.put("lolo", textview1.getText().toString());
										uyu.push().updateChildren(map);
										map.clear();
									}
									else {
										if (doy < 5.0d) {
											map = new HashMap<>();
											map.put("etar", "4.5»»★");
											map.put("lolo", textview1.getText().toString());
											uyu.push().updateChildren(map);
											map.clear();
										}
										else {
											if (doy == 5.0d) {
												map = new HashMap<>();
												map.put("etar", "5.0»»★");
												map.put("lolo", textview1.getText().toString());
												uyu.push().updateChildren(map);
												map.clear();
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	
	private void _cancel () {
		
	}
	
	
	private void _setElavation (final View _view, final double _num) {
		_view.setElevation((float)_num);
	}
	
	
	private void _Download (final String _url, final String _path) {
		try{
			
			FileUtil.makeDir(FileUtil.getPackageDataDir(getApplicationContext()));
			android.net.ConnectivityManager connMgr = (android.net.ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
			android.net.NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
			if (networkInfo != null && networkInfo.isConnected()) {
				
				
				final String urlDownload = _url;
				
				DownloadManager.Request request = new DownloadManager.Request(Uri.parse(urlDownload));
				
				final String fileName = URLUtil.guessFileName(urlDownload, null, null);
				
				request.setDescription("URL - " + urlDownload);
				
				request.setTitle(fileName);
				
				request.allowScanningByMediaScanner();
				
				request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
				//App by Uz4studios
				request.setDestinationInExternalPublicDir(_path, fileName);
				
				final DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				
				final long downloadId = manager.enqueue(request);
				
				final ProgressDialog prog = new ProgressDialog(this);
				prog.setMax(100);
				prog.setIndeterminate(true);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
				
				prog.setTitle("downloading...");
				prog.setMessage("Downloading the " + fileName + ".\n\nProgress  0%");
				prog.show();
				
				new Thread(new Runnable() {
					@Override
					public void run() {
						
						boolean downloading = true;
						
						while (downloading) {
							
							DownloadManager.Query q = new DownloadManager.Query();
							
							q.setFilterById(downloadId);
							
							android.database.Cursor cursor = manager.query(q);
							
							cursor.moveToFirst();
							
							int bytes_downloaded = cursor.getInt(cursor .getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
							
							int bytes_total = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
							
							if (cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL) {
								
								downloading = false;
								
							}
							
							final int dl_progress = (int) ((bytes_downloaded * 100l) / bytes_total);
							
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									
									prog.setTitle("downloading...");
									prog.setMessage("Downloading the " + fileName + ".\n\nProgress  " + dl_progress + "%");
									prog.show();
									
									if (dl_progress == 100) {
										prog.dismiss();
										
									}
									
								} });
						} } }).start();
				
				
			} else {
				showMessage("No Internet Connection.");
			}
		}
		catch(Exception _e){
			//do something if error occurs
			//To know error use _e.toString()
			
			FileUtil.makeDir(FileUtil.getPackageDataDir(getApplicationContext()));
			android.net.ConnectivityManager connMgr = (android.net.ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
			android.net.NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
			if (networkInfo != null && networkInfo.isConnected()) {
				
				
				final String urlDownload = _url;
				
				DownloadManager.Request request = new DownloadManager.Request(Uri.parse(urlDownload));
				
				final String fileName = URLUtil.guessFileName(urlDownload, null, null);
				
				request.setDescription("URL - " + urlDownload);
				
				request.setTitle(fileName);
				
				request.allowScanningByMediaScanner();
				
				request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
				
				request.setDestinationInExternalPublicDir(_path, fileName);
				
				final DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				
				final long downloadId = manager.enqueue(request);
				
				final ProgressDialog prog = new ProgressDialog(this);
				prog.setMax(100);
				prog.setIndeterminate(true);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
				
				prog.setTitle("downloading...");
				prog.setMessage("Downloading the " + fileName + ".\n\nProgress  0%");
				prog.show();
				
				new Thread(new Runnable() {
					@Override
					public void run() {
						
						boolean downloading = true;
						
						while (downloading) {
							
							DownloadManager.Query q = new DownloadManager.Query();
							
							q.setFilterById(downloadId);
							
							android.database.Cursor cursor = manager.query(q);
							
							cursor.moveToFirst();
							
							int bytes_downloaded = cursor.getInt(cursor .getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
							
							int bytes_total = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
							
							if (cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL) {
								
								downloading = false;
								
							}
							
							final int dl_progress = (int) ((bytes_downloaded * 100l) / bytes_total);
							
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									
									prog.setTitle("downloading...");
									prog.setMessage("Downloading the " + fileName + ".\n\nProgress  " + dl_progress + "%");
									prog.show();
									
									if (dl_progress == 100) {
										prog.dismiss();
										
										SketchwareUtil.showMessage(getApplicationContext(), "Failed to download this app");
									}
									
								} });
						} } }).start();
				
				
			} else {
				showMessage("No Internet Connection.");
			}
		}
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.ratee, null);
			}
			
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final TextView textview2 = (TextView) _v.findViewById(R.id.textview2);
			final TextView textview3 = (TextView) _v.findViewById(R.id.textview3);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			
			pos = _position;
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
