package com.uz4studios.app;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import com.bumptech.glide.Glide;

public class AppviewActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private double r = 0;
	private double map_length = 0;
	private String fontName = "";
	private String typeace = "";
	private double numlike = 0;
	private HashMap<String, Object> nn = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> maplist_view_in = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lmap = new ArrayList<>();
	private ArrayList<String> lstr = new ArrayList<>();
	
	private LinearLayout actionbar;
	private LinearLayout linear2;
	private ImageView back;
	private EditText edittext1;
	private ListView listview1;
	
	private Intent i = new Intent();
	private DatabaseReference fadb = _firebase.getReference("fadb");
	private ChildEventListener _fadb_child_listener;
	private Intent in = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.appview);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		actionbar = (LinearLayout) findViewById(R.id.actionbar);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		back = (ImageView) findViewById(R.id.back);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		listview1 = (ListView) findViewById(R.id.listview1);
		
		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Ripple_Drawable(back, "#BDBDBD");
				i.setClass(getApplicationContext(), StoreActivity.class);
				_TransitionManager(back, "back", i);
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.equals("")) {
					listview1.setAlpha((float)(0));
				}
				else {
					listview1.setAlpha((float)(1));
				}
				fadb.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						maplist_view_in = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								maplist_view_in.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						if (_charSeq.length() > 0) {
							r = maplist_view_in.size() - 1;
							map_length = maplist_view_in.size();
							for(int _repeat25 = 0; _repeat25 < (int)(map_length); _repeat25++) {
								if (maplist_view_in.get((int)r).get("nomi").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
									
								}
								else {
									maplist_view_in.remove((int)(r));
								}
								r--;
							}
						}
						listview1.setAdapter(new Listview1Adapter(maplist_view_in));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_fadb_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				fadb.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						maplist_view_in = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								maplist_view_in.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						lstr.add(_childKey);
						listview1.setAdapter(new Listview1Adapter(maplist_view_in));
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				fadb.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						maplist_view_in = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								maplist_view_in.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listview1.setAdapter(new Listview1Adapter(maplist_view_in));
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fadb.addChildEventListener(_fadb_child_listener);
	}
	private void initializeLogic() {
		_lightStatusBar(true);
		_setElavation(actionbar, 10);
		_Ripple_Drawable(back, "#BDBDBD");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _lightStatusBar (final boolean _shouldchange) {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) { View decor = getWindow().getDecorView();
			if (_shouldchange) { decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); } else { decor.setSystemUiVisibility(0); } }
	}
	
	
	private void _setElavation (final View _view, final double _num) {
		_view.setElevation((float)_num);
	}
	
	
	private void _Ripple_Drawable (final View _view, final String _c) {
		android.content.res.ColorStateList clr = new android.content.res.ColorStateList(new int[][]{new int[]{}},new int[]{Color.parseColor(_c)}); android.graphics.drawable.RippleDrawable ripdr = new android.graphics.drawable.RippleDrawable(clr, null, null); _view.setBackground(ripdr);
	}
	
	
	private void _TransitionManager (final View _view, final String _transitionName, final Intent _intent) {
		overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
		_view.setTransitionName(_transitionName); android.app.ActivityOptions optionsCompat = android.app.ActivityOptions.makeSceneTransitionAnimation(AppviewActivity.this, _view, _transitionName); startActivity(_intent, optionsCompat.toBundle());
	}
	
	
	private void _radius (final String _color, final String _strokeColor, final double _stroke, final double _radius, final double _shadow, final View _view) {
		android.graphics.drawable.GradientDrawable gd1 = new android.graphics.drawable.GradientDrawable();
		gd1.setColor(Color.parseColor(_strokeColor));
		gd1.setCornerRadius((int)_stroke);
		_view.setBackground(gd1);
		
		try {
			if(Build.VERSION.SDK_INT >= 21) {
				_view.setElevation((int)_shadow);
			}
		} catch (Exception e) {}
	}
	
	
	private void _changeActivityFont (final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				}
				else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					}
					else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	private void _TransitionManager2 (final View _view, final String _transitionName) {
		_view.setTransitionName(_transitionName);
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.store_list_main_com, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final LinearLayout image_back = (LinearLayout) _v.findViewById(R.id.image_back);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final ImageView icon_png = (ImageView) _v.findViewById(R.id.icon_png);
			final LinearLayout name_back = (LinearLayout) _v.findViewById(R.id.name_back);
			final LinearLayout linear3 = (LinearLayout) _v.findViewById(R.id.linear3);
			final TextView raiting = (TextView) _v.findViewById(R.id.raiting);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final TextView zvezd = (TextView) _v.findViewById(R.id.zvezd);
			final TextView name_application = (TextView) _v.findViewById(R.id.name_application);
			final TextView size = (TextView) _v.findViewById(R.id.size);
			
			name_application.setText(maplist_view_in.get((int)_position).get("nomi").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(maplist_view_in.get((int)_position).get("banner").toString())).into(icon_png);
			raiting.setText(String.valueOf((long)(numlike)));
			zvezd.setText(maplist_view_in.get((int)_position).get("narxi").toString());
			_radius("#FFFFFF", "#FFFFFF", 20, 20, 5, image_back);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), AppdetailsActivity.class);
					i.putExtra("nomer", maplist_view_in.get((int)_position).get("nomer").toString());
					i.putExtra("nomi", maplist_view_in.get((int)_position).get("nomi").toString());
					i.putExtra("oppo", maplist_view_in.get((int)_position).get("narxi").toString());
					i.putExtra("haqida", maplist_view_in.get((int)_position).get("haqida").toString());
					i.putExtra("rasm1", maplist_view_in.get((int)_position).get("rasm1").toString());
					i.putExtra("rasm2", maplist_view_in.get((int)_position).get("rasm2").toString());
					i.putExtra("icon", maplist_view_in.get((int)_position).get("banner").toString());
					i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					numlike = Double.parseDouble(maplist_view_in.get((int)_position).get("like").toString());
					numlike++;
					nn = new HashMap<>();
					nn.put("like", String.valueOf((long)(numlike)));
					fadb.child(lstr.get((int)(_position))).updateChildren(nn);
					startActivity(i);
				}
			});
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
