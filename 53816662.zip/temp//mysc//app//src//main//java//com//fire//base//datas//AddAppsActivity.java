package com.fire.base.datas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.content.Intent;
import android.content.ClipData;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Continuation;
import android.net.Uri;
import java.io.File;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.view.View;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class AddAppsActivity extends AppCompatActivity {
	
	public final int REQ_CD_PICKER = 101;
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private String path = "";
	private String packageName = "";
	private String appName = "";
	private String versionName = "";
	private String fileSize = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String userapps_path = "";
	private String imageString = "";
	
	private ArrayList<String> list = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear7;
	private ImageView imageview1;
	private TextView textview7;
	private EditText filename;
	private TextView textview8;
	private EditText appname;
	private TextView textview10;
	private EditText package_name;
	private TextView textview11;
	private EditText version;
	private TextView textview12;
	private EditText size;
	private ProgressBar progressbar1;
	private TextView textview13;
	private TextView textview_cancel;
	private TextView textview_save;
	
	private Intent picker = new Intent(Intent.ACTION_GET_CONTENT);
	private FirebaseAuth fauth;
	private OnCompleteListener<AuthResult> _fauth_create_user_listener;
	private OnCompleteListener<AuthResult> _fauth_sign_in_listener;
	private OnCompleteListener<Void> _fauth_reset_password_listener;
	private DatabaseReference apps = _firebase.getReference("apks");
	private ChildEventListener _apps_child_listener;
	private StorageReference fstore = _firebase_storage.getReference("apk_store");
	private OnCompleteListener<Uri> _fstore_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fstore_download_success_listener;
	private OnSuccessListener _fstore_delete_success_listener;
	private OnProgressListener _fstore_upload_progress_listener;
	private OnProgressListener _fstore_download_progress_listener;
	private OnFailureListener _fstore_failure_listener;
	private Calendar cal = Calendar.getInstance();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.add_apps);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview7 = (TextView) findViewById(R.id.textview7);
		filename = (EditText) findViewById(R.id.filename);
		textview8 = (TextView) findViewById(R.id.textview8);
		appname = (EditText) findViewById(R.id.appname);
		textview10 = (TextView) findViewById(R.id.textview10);
		package_name = (EditText) findViewById(R.id.package_name);
		textview11 = (TextView) findViewById(R.id.textview11);
		version = (EditText) findViewById(R.id.version);
		textview12 = (TextView) findViewById(R.id.textview12);
		size = (EditText) findViewById(R.id.size);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		textview13 = (TextView) findViewById(R.id.textview13);
		textview_cancel = (TextView) findViewById(R.id.textview_cancel);
		textview_save = (TextView) findViewById(R.id.textview_save);
		picker.setType("application/vnd.android.package-archive");
		picker.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		fauth = FirebaseAuth.getInstance();
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(picker, REQ_CD_PICKER);
			}
		});
		
		textview_cancel.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				path = "";
				filename.setText("");
				appname.setText("");
				package_name.setText("");
				version.setText("");
				size.setText("");
				imageview1.setImageResource(R.drawable.apk_select);
			}
		});
		
		textview_save.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (path.equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Select an apk for uploading.");
				}
				else {
					_disable_upload();
					fstore.child(Uri.parse(path).getLastPathSegment()).putFile(Uri.fromFile(new File(path))).addOnFailureListener(_fstore_failure_listener).addOnProgressListener(_fstore_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
						@Override
						public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
							return fstore.child(Uri.parse(path).getLastPathSegment()).getDownloadUrl();
						}}).addOnCompleteListener(_fstore_upload_success_listener);
				}
			}
		});
		
		_apps_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				_enable_upload();
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		apps.addChildEventListener(_apps_child_listener);
		
		_fstore_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fstore_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fstore_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
				
				Bitmap bm = ((android.graphics.drawable.BitmapDrawable) imageview1.getDrawable()).getBitmap();
				
				bm.compress(Bitmap.CompressFormat.JPEG, 100, baos);
				
				byte[] imageBytes = baos.toByteArray();
				
				imageString = android.util.Base64.encodeToString(imageBytes, android.util.Base64.DEFAULT);
				cal = Calendar.getInstance();
				map = new HashMap<>();
				map.put("app_icon", imageString);
				map.put("app_name", appname.getText().toString());
				map.put("app_version", version.getText().toString());
				map.put("app_package", package_name.getText().toString());
				map.put("app_size", size.getText().toString());
				map.put("app_url", _downloadUrl);
				map.put("time", String.valueOf((long)(cal.getTimeInMillis())));
				map.put("publisher_id", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map.put("publisher_mail", FirebaseAuth.getInstance().getCurrentUser().getEmail());
				map.put("validate", "false");
				apps.push().updateChildren(map);
				SketchwareUtil.showMessage(getApplicationContext(), "App uploaded. Pending verification.");
				finish();
			}
		};
		
		_fstore_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_fstore_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fstore_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				SketchwareUtil.showMessage(getApplicationContext(), _message);
				_enable_upload();
			}
		};
		
		_fauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		filename.setEnabled(false);
		appname.setEnabled(false);
		package_name.setEnabled(false);
		version.setEnabled(false);
		size.setEnabled(false);
		_enable_upload();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_PICKER:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				path = _filePath.get((int)(0));
				filename.setText(Uri.parse(path).getLastPathSegment());
				PackageManager pm = getPackageManager();
				
				android.content.pm.PackageInfo pi = pm.getPackageArchiveInfo(path, 0);
				
				pi.applicationInfo.sourceDir = path; pi.applicationInfo.publicSourceDir = path;
				
				android.graphics.drawable.Drawable appIcon = pi.applicationInfo.loadIcon(pm); appName = (String)pi.applicationInfo.loadLabel(pm);
				packageName = pi.packageName;
				versionName = pi.versionName;
				imageview1.setImageDrawable(appIcon);
				appname.setText(appName);
				package_name.setText(packageName);
				version.setText(versionName);
				try {
					fileSize = String.valueOf((new java.io.File(path)).length()/1024);
				} catch (Exception e) {
					showMessage (e.toString());
				}
				size.setText(fileSize.concat(" kb"));
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	private void _disable_upload () {
		progressbar1.setVisibility(View.VISIBLE);
		textview13.setVisibility(View.VISIBLE);
		textview_save.setVisibility(View.GONE);
		textview_cancel.setVisibility(View.GONE);
		imageview1.setEnabled(false);
	}
	
	
	private void _enable_upload () {
		progressbar1.setVisibility(View.GONE);
		textview13.setVisibility(View.GONE);
		textview_save.setVisibility(View.VISIBLE);
		textview_cancel.setVisibility(View.VISIBLE);
		imageview1.setEnabled(true);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
