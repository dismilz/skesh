package sem.sketch.cloud;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.app.Activity;
import android.content.SharedPreferences;
import java.util.Timer;
import java.util.TimerTask;
import android.content.Intent;
import android.content.ClipData;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.net.Uri;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.View;
import android.widget.AdapterView;
import android.text.Editable;
import android.text.TextWatcher;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
	
	public final int REQ_CD_ZIPF = 101;
	private Timer _timer = new Timer();
	
	private String buildGradle = "";
	private String name = "";
	private double position = 0;
	private String id = "";
	private String sat = "";
	private double searchnum = 0;
	private HashMap<String, Object> map = new HashMap<>();
	private String zip_to = "";
	private String Sketchware = "";
	private String zip_from = "";
	private String final_destination = "";
	private String path1 = "";
	private String from = "";
	private String to = "";
	private String idd = "";
	private String path = "";
	private double mfirstVisibleItem = 0;
	private double firstVisibleItem = 0;
	private String save = "";
	private double length = 0;
	private double r = 0;
	private String value1 = "";
	private double position_number = 0;
	private double n = 0;
	private double tv = 0;
	private String PackageName = "";
	private String pathApk = "";
	private String apk = "";
	private String search = "";
	private String hmin = "";
	
	private ArrayList<String> liststring = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	private ArrayList<String> project_name = new ArrayList<>();
	private ArrayList<String> list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> temp_listmap1 = new ArrayList<>();
	
	private LinearLayout main_board;
	private LinearLayout base;
	private LinearLayout trash;
	private LinearLayout mainn;
	private LinearLayout main;
	private LinearLayout tablayout;
	private LinearLayout linear27;
	private LinearLayout menu;
	private TextView title;
	private LinearLayout share;
	private ImageView menu_a;
	private ImageView share_a;
	private LinearLayout layout1;
	private LinearLayout layout2;
	private LinearLayout search_bar;
	private ListView listview1;
	private ImageView image;
	private EditText text;
	private ImageView cancel;
	private LinearLayout linear2;
	private ListView listview2;
	private ImageView imageview1;
	private EditText edittext1;
	private ImageView imageview2;
	
	private SharedPreferences sharedata;
	private TimerTask t;
	private Intent zipf = new Intent(Intent.ACTION_GET_CONTENT);
	private TimerTask r1;
	private TimerTask r2;
	private AlertDialog.Builder d;
	private TimerTask delay;
	private Intent in = new Intent();
	private SharedPreferences f;
	private SharedPreferences data;
	private Intent Change = new Intent();
	private AlertDialog.Builder dialog;
	private AlertDialog.Builder exit;
	private ObjectAnimator animation = new ObjectAnimator();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		main_board = (LinearLayout) findViewById(R.id.main_board);
		base = (LinearLayout) findViewById(R.id.base);
		trash = (LinearLayout) findViewById(R.id.trash);
		mainn = (LinearLayout) findViewById(R.id.mainn);
		main = (LinearLayout) findViewById(R.id.main);
		tablayout = (LinearLayout) findViewById(R.id.tablayout);
		linear27 = (LinearLayout) findViewById(R.id.linear27);
		menu = (LinearLayout) findViewById(R.id.menu);
		title = (TextView) findViewById(R.id.title);
		share = (LinearLayout) findViewById(R.id.share);
		menu_a = (ImageView) findViewById(R.id.menu_a);
		share_a = (ImageView) findViewById(R.id.share_a);
		layout1 = (LinearLayout) findViewById(R.id.layout1);
		layout2 = (LinearLayout) findViewById(R.id.layout2);
		search_bar = (LinearLayout) findViewById(R.id.search_bar);
		listview1 = (ListView) findViewById(R.id.listview1);
		image = (ImageView) findViewById(R.id.image);
		text = (EditText) findViewById(R.id.text);
		cancel = (ImageView) findViewById(R.id.cancel);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		listview2 = (ListView) findViewById(R.id.listview2);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		sharedata = getSharedPreferences("sharedata", Activity.MODE_PRIVATE);
		zipf.setType("*/*");
		zipf.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		d = new AlertDialog.Builder(this);
		f = getSharedPreferences("f", Activity.MODE_PRIVATE);
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		dialog = new AlertDialog.Builder(this);
		exit = new AlertDialog.Builder(this);
		
		menu.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				delay = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								final com.google.android.material.bottomsheet.BottomSheetDialog bs_base = new com.google.android.material.bottomsheet.BottomSheetDialog(MainActivity.this);
								
								View layBase = getLayoutInflater().inflate(R.layout.bottom_sheet, null);
								
								bs_base.setContentView(layBase);
								
								bs_base.show();
							}
						});
					}
				};
				_timer.schedule(delay, (int)(350));
			}
		});
		
		share.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				PackageName = "sem.sketch.cloud";
				pathApk = FileUtil.getExternalStorageDir().concat("/".concat(PackageName.concat(".apk")));
				String apk = "";
				String uri = PackageName;
				
				try {
					android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(uri, android.content.pm.PackageManager.GET_ACTIVITIES);
					
					apk = pi.applicationInfo.publicSourceDir;
					
					FileUtil.copyFile(apk, pathApk);
				} catch (Exception e) {
					SketchwareUtil.showMessage(getApplicationContext(), e.toString());
				}
				
				Intent iten = new Intent(Intent.ACTION_SEND);
				iten.setType("*/*");
				iten.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new java.io.File(pathApk)));
				
				startActivity(Intent.createChooser(iten, "Share APK with..."));
				animation.setTarget(share_a);
				animation.setPropertyName("alpha");
				animation.setFloatValues((float)(0), (float)(1));
				animation.setDuration((int)(3000));
				animation.setInterpolator(new LinearInterpolator());
				animation.start();
			}
		});
		
		text.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (text.getText().toString().equals("")) {
					cancel.setVisibility(View.INVISIBLE);
				}
				else {
					cancel.setVisibility(View.VISIBLE);
				}
				temp_listmap1 = new Gson().fromJson(search, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				length = temp_listmap1.size();
				n = length - 1;
				for(int _repeat26 = 0; _repeat26 < (int)(length); _repeat26++) {
					hmin = temp_listmap1.get((int)n).get("my_app_name").toString();
					if (!(_charSeq.length() > hmin.length()) && hmin.toLowerCase().contains(_charSeq.toLowerCase())) {
						
					}
					else {
						temp_listmap1.remove((int)(n));
					}
					n--;
				}
				listview1.setAdapter(new Listview1Adapter(temp_listmap1));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		cancel.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_circleRipple("Grey", cancel);
				text.setText("");
				SketchwareUtil.showMessage(getApplicationContext(), "Text cleared !!!");
			}
		});
		
		listview2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				final android.transition.ChangeBounds transition = new android.transition.ChangeBounds(); transition.setDuration(350L);
				android.transition.TransitionManager.beginDelayedTransition(listview2, transition);
				Change.setClass(getApplicationContext(), OpenActivity.class);
				Change.putExtra("A", listmap.get((int)_position).get("ctm").toString());
				Change.putExtra("B", f.getString(listmap.get((int)_position).get("ctm").toString(), ""));
				startActivity(Change);
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (edittext1.getText().toString().equals("")) {
					imageview2.setVisibility(View.INVISIBLE);
				}
				else {
					imageview2.setVisibility(View.VISIBLE);
				}
				listmap.clear();
				n = 0;
				while(true) {
					if (f.getString(String.valueOf((long)(n)), "").equals("")) {
						break;
					}
					else {
						if (_charSeq.length() > f.getString(String.valueOf((long)(n)), "").length()) {
							
						}
						else {
							if (f.getString(String.valueOf((long)(n)), "").toLowerCase().contains(_charSeq.toLowerCase())) {
								{
									HashMap<String, Object> _item = new HashMap<>();
									_item.put("ctm", f.getString(String.valueOf((long)(n)), ""));
									listmap.add(_item);
								}
								
							}
						}
						n++;
					}
				}
				listview2.setAdapter(new Listview2Adapter(listmap));
				((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_circleRipple("Grey", imageview2);
				edittext1.setText("");
				SketchwareUtil.showMessage(getApplicationContext(), "Text cleared !!!");
			}
		});
	}
	private void initializeLogic() {
		main_board.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		android.graphics.drawable.GradientDrawable CRNOH = new android.graphics.drawable.GradientDrawable();
		CRNOH.setColor(Color.parseColor("#ffffff"));
		CRNOH.setCornerRadii(new float[]{ (float) 0,(float) 0,(float) 0,(float) 0,(float) 0,(float) 0,(float) 0,(float) 0 });
		CRNOH.setStroke((int) 0, Color.parseColor("#000000"));
		main_board.setElevation((float) 10);
		main_board.setBackground(CRNOH);
		//Milz
		android.graphics.drawable.GradientDrawable CRNFM = new android.graphics.drawable.GradientDrawable();
		CRNFM.setColor(Color.parseColor("#ffffff"));
		CRNFM.setCornerRadii(new float[]{ (float) 100,(float) 100,(float) 100,(float) 100,(float) 100,(float) 100,(float) 100,(float) 100 });
		CRNFM.setStroke((int) 1, Color.parseColor("#000000"));
		linear2.setElevation((float) 4);
		linear2.setBackground(CRNFM);
		//Milz
		android.graphics.drawable.GradientDrawable CRNF = new android.graphics.drawable.GradientDrawable();
		CRNF.setColor(Color.parseColor("#ffffff"));
		CRNF.setCornerRadii(new float[]{ (float) 100,(float) 100,(float) 100,(float) 100,(float) 100,(float) 100,(float) 100,(float) 100 });
		CRNF.setStroke((int) 1, Color.parseColor("#000000"));
		search_bar.setElevation((float) 4);
		search_bar.setBackground(CRNF);
		//Milz
		FileUtil.listDir(FileUtil.getExternalStorageDir().concat("/.sketchware/data/"), liststring);
				Collections.sort(liststring, String.CASE_INSENSITIVE_ORDER);
				position = 0;
				for(int _repeat15 = 0; _repeat15 < (int)(liststring.size()); _repeat15++) {
						{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("key", liststring.get((int)(position)));
								listmap.add(_item);
						}
						
						position++;
				}
				position = 0;
				for(int _repeat119 = 0; _repeat119 < (int)(liststring.size()); _repeat119++) {
						id = Uri.parse(liststring.get((int)(position))).getLastPathSegment();
						sat = "";
						try { java.io.File folder = new java.io.File(Environment.getExternalStorageDirectory(), ".sketchware/mysc/" + id + "/bin");
								java.io.File[] listOfFiles = folder.listFiles();
								
								for(int b = 0; b < listOfFiles.length; b++) {
										    if (listOfFiles[b].getName().endsWith(".apk.res")) {
												        sat = listOfFiles[b].getName();
												sat = sat.substring((int)(0), (int)(sat.indexOf(".apk")));
												break;
												    }
								} } catch(Exception e) {}
						if (sat.equals("")) {
								project_name.add("Unknow Project");
						}
						else {
								project_name.add(sat);
						}
						position++;
				}
				listview1.setAdapter(new Listview1Adapter(listmap));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud"))) {
						
				}
				else {
						FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud"));
				}
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/temp"))) {
						final_destination = FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/temp");
				}
				else {
						FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/temp"));
				}
		
		DisplayMetrics dm = new DisplayMetrics(); getWindowManager().getDefaultDisplay().getMetrics(dm); int width = dm.widthPixels; int height = dm.heightPixels;
		listview2.setDivider(null);
		_Codes();
		tv = 0;
		if (f.getString("0", "").equals("")) {
			_Codes();
			f.edit().putString("0", "0").commit();
		}
		else {
			
		}
		listmap.clear();
		n = 0;
		while(true) {
			if (f.getString(String.valueOf((long)(n)), "").equals("")) {
				break;
			}
			else {
				if (f.getString(String.valueOf((long)(n)), "").length() > 0) {
					{
						HashMap<String, Object> _item = new HashMap<>();
						_item.put("ctm", f.getString(String.valueOf((long)(n)), ""));
						listmap.add(_item);
					}
					
				}
				n++;
			}
		}
		listview2.setAdapter(new Listview2Adapter(listmap));
		((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
		viewPager = new androidx.viewpager.widget.ViewPager(this); viewPager.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)); MyPagerAdapter adapter = new MyPagerAdapter(); viewPager.setAdapter(adapter); viewPager.setCurrentItem(0); 
		
		base.
		
		addView(viewPager); viewPager.addOnPageChangeListener(new androidx.viewpager.widget.ViewPager.OnPageChangeListener() { public void onPageSelected(int position) { position_number = position; 
				if (position_number == 0) {
					
				}
				else {
					if (position_number == 1) {
						
					}
				}
			} @Override public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) { } @Override public void onPageScrollStateChanged(int state) { } }); tabLayout = new com.google.android.material.tabs.TabLayout(this); tabLayout.setTabGravity(tabLayout.GRAVITY_FILL); tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#01579B")); tabLayout.setTabTextColors(Color.parseColor("#757575"),
		Color.parseColor("#01579B")); tabLayout.setupWithViewPager(viewPager); tablayout.addView(tabLayout); } private class MyPagerAdapter extends androidx.viewpager.widget.PagerAdapter { public int getCount() { return
			
			 2
			
			
			
			; } @Override public Object instantiateItem(ViewGroup collection, int position)
		
		
		 {
			
			LayoutInflater inflater = (LayoutInflater) getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View v = inflater.inflate(R.layout.empty, null);
			
			LinearLayout container = (LinearLayout) v.findViewById(R.id.linear1);
			
			if (position == 0) {
				ViewGroup parent = (ViewGroup) layout1.getParent();
				if (parent != null) {
					parent.removeView(layout1);
				}container.addView(layout1);}
			
			
			
			else if (position == 1) {
				ViewGroup parent = (ViewGroup) layout2.getParent();
				if (parent != null) {
					parent.removeView(layout2);
				}container.addView(layout2);}
			
			
			
			collection.addView(v, 0);
			return v;
		}
		@Override public void destroyItem(ViewGroup collection, int position, Object view) {
			collection.removeView((View) view);
			trash.addView((View) view);
		}
		@Override public CharSequence getPageTitle(int position) {
			switch (position) {
				
				
				
				
				
				case 0:
				return "SK PROJECTS";
				
				case 1:
				return "J CODES";
				
				default:
				return null;
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		@Override public boolean isViewFromObject(View arg0, Object arg1) { return arg0 == ((View) arg1);} @Override public Parcelable saveState() { return null; } } androidx.viewpager.widget.ViewPager viewPager; com.google.android.material.tabs.TabLayout tabLayout; private void foo() {
		base.setVisibility(View.GONE);
		trash.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_ZIPF:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				idd = sharedata.getString("idzip", "");
								path = _filePath.get((int)(0));
								final ProgressDialog prog = new ProgressDialog(MainActivity.this);prog.setMax(100);prog.setMessage("Coping Files....");prog.setIndeterminate(true);prog.setCancelable(false);prog.show();
								r1 = new TimerTask() {
										@Override
										public void run() {
												runOnUiThread(new Runnable() {
														@Override
														public void run() {
																FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/zip/"));
																FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/zip/"));
																_UnZip(path, FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/zip/"));
																FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(idd.concat("/file"))));
																FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(idd.concat("/library"))));
																FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(idd.concat("/logic"))));
																FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(idd.concat("/resource"))));
																FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(idd.concat("/view"))));
																if (!Uri.parse(path).getLastPathSegment().endsWith(".zip")) {
																		SketchwareUtil.showMessage(getApplicationContext(), "Not SEM Sketch Cloud file!");
																		finish();
																}
																else {
																		if (!FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/zip/temp"))) {
																				SketchwareUtil.showMessage(getApplicationContext(), "Not SEM Sketch Cloud file!");
																				finish();
																		}
																		else {
																				_Copy(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/zip/temp/data/"), FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(idd.concat("/"))));
																				if (!FileUtil.isExistFile("/.sketchware/mysc/".concat(idd.concat("/")))) {
																						FileUtil.makeDir("/.sketchware/mysc/".concat(idd.concat("/")));
																						_Copy(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/zip/temp/mysc/"), FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/".concat(idd.concat("/"))));
																				}
																				else {
																						FileUtil.deleteFile("/.sketchware/mysc/".concat(idd.concat("/app")));
																						FileUtil.deleteFile("/.sketchware/mysc/".concat(idd.concat("/bin")));
																						FileUtil.deleteFile("/.sketchware/mysc/".concat(idd.concat("/gen")));
																						FileUtil.deleteFile("/.sketchware/mysc/".concat(idd.concat("/build.gradle")));
																						FileUtil.deleteFile("/.sketchware/mysc/".concat(idd.concat("/settings.gradle")));
																						_Copy(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/zip/temp/mysc/"), FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/".concat(idd.concat("/"))));
																				}
																				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(idd)));
																				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(idd)));
																				_Copy(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/zip/temp/resources/icons/"), FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(idd.concat("/"))));
																				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/images/".concat(idd)));
																				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/images/".concat(idd)));
																				_Copy(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/zip/temp/resources/images/"), FileUtil.getExternalStorageDir().concat("/.sketchware/resources/images/".concat(idd.concat("/"))));
																				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/sounds/".concat(idd)));
																				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/sounds/".concat(idd)));
																				_Copy(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/zip/temp/resources/sounds/"), FileUtil.getExternalStorageDir().concat("/.sketchware/resources/sounds/".concat(idd.concat("/"))));
																				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/fonts/".concat(idd)));
																				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/fonts/".concat(idd)));
																				_Copy(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/zip/temp/resources/fonts/"), FileUtil.getExternalStorageDir().concat("/.sketchware/resources/fonts/".concat(idd.concat("/"))));
																				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/comment/".concat(idd)))) {
																						FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/comment/".concat(idd)));
																						FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/comment/".concat(idd)));
																						_Copy(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/zip/temp/resources/comment/"), FileUtil.getExternalStorageDir().concat("/.sketchware/resources/comment/".concat(idd)));
																				}
																				prog.hide();
																				SketchwareUtil.showMessage(getApplicationContext(), "Successfully Restored!");
										Toast.makeText(MainActivity.this, "Made By SEM Tech Hub ™", Toast.LENGTH_SHORT).show();
										
																		}
																}
														}
												});
										}
								};
								_timer.schedule(r1, (int)(100));
					
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
		StrictMode.setVmPolicy(builder.build());
		
		if(Build.VERSION.SDK_INT>=24){
			
			try{
				java.lang.reflect.Method m = StrictMode.class.getMethod("disableDeathOnFileUriExposure");
				m.invoke(null);
				
			}
			catch(Exception e){
				showMessage(e.toString());
			}
		}
		_circleRipple("Grey", menu_a);
		_circleRipple("Grey", share_a);
		cancel.setVisibility(View.INVISIBLE);
		imageview2.setVisibility(View.INVISIBLE);
	}
	
	@Override
	public void onBackPressed() {
		exit.setTitle("EXIT");
		exit.setMessage("Do you want to exit ?");
		exit.setPositiveButton("YES", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finishAffinity();
			}
		});
		exit.setNegativeButton("NO", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				SketchwareUtil.showMessage(getApplicationContext(), "Thanks for not quitting😊");
			}
		});
		exit.create().show();
	}
	private void _Elevation (final View _view, final double _number) {
		
		_view.setElevation((int)_number);
	}
	
	
	private void _gd (final View _view, final double _numb, final String _color) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_numb);
		_view.setBackground(gd);
	}
	
	
	private void _click_effect (final View _view, final String _c) {
		_view.setBackground(Drawables.getSelectableDrawableFor(Color.parseColor(_c)));
		_view.setClickable(true);
		
	}
	
	public static class Drawables {
		    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {
			        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
				            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_pressed},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_focused},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            return stateListDrawable;
				        } else {
				            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);
				            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"));
				            
				android.graphics.drawable.Drawable rippleColor = getRippleColor(color);
				            return new android.graphics.drawable.RippleDrawable(
				                pressedColor,
				                defaultColor,
				                rippleColor
				            );
				        }
			    }
		
		    private static android.graphics.drawable.Drawable getRippleColor(int color) {
			        float[] outerRadii = new float[8];
			        Arrays.fill(outerRadii, 0);
			        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);
			        
			android.graphics.drawable.ShapeDrawable shapeDrawable = new 
			android.graphics.drawable.ShapeDrawable(r);
			        shapeDrawable.getPaint().setColor(color);
			        return shapeDrawable;
			    }
		 
		    private static int lightenOrDarken(int color, double fraction) {
			        if (canLighten(color, fraction)) {
				            return lighten(color, fraction);
				        } else {
				            return darken(color, fraction);
				        }
			    }
		 
		    private static int lighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = lightenColor(red, fraction);
			        green = lightenColor(green, fraction);
			        blue = lightenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static int darken(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = darkenColor(red, fraction);
			        green = darkenColor(green, fraction);
			        blue = darkenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			 
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static boolean canLighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        return canLightenComponent(red, fraction)
			            && canLightenComponent(green, fraction)
			            && canLightenComponent(blue, fraction);
			    }
		 
		    private static boolean canLightenComponent(int colorComponent, double fraction) {
			        int red = Color.red(colorComponent);
			        int green = Color.green(colorComponent);
			        int blue = Color.blue(colorComponent);
			        return red + (red * fraction) < 255
			            && green + (green * fraction) < 255
			            && blue + (blue * fraction) < 255;
			    }
		 
		    private static int darkenColor(int color, double fraction) {
			        return (int) Math.max(color - (color * fraction), 0);
			    }
		 
		    private static int lightenColor(int color, double fraction) {
			        return (int) Math.min(color + (color * fraction), 255);
			    }
	}
	public static class CircleDrawables {
		    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {
			        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
				            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_pressed},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_focused},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            return stateListDrawable;
				        } else {
				            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);
				            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"));
				            
				android.graphics.drawable.Drawable rippleColor = getRippleColor(color);
				            return new android.graphics.drawable.RippleDrawable(
				                pressedColor,
				                defaultColor,
				                rippleColor
				            );
				        }
			    }
		
		    private static android.graphics.drawable.Drawable getRippleColor(int color) {
			        float[] outerRadii = new float[180];
			        Arrays.fill(outerRadii, 80);
			        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);
			        
			android.graphics.drawable.ShapeDrawable shapeDrawable = new 
			android.graphics.drawable.ShapeDrawable(r);
			        shapeDrawable.getPaint().setColor(color);
			        return shapeDrawable;
			    }
		 
		    private static int lightenOrDarken(int color, double fraction) {
			        if (canLighten(color, fraction)) {
				            return lighten(color, fraction);
				        } else {
				            return darken(color, fraction);
				        }
			    }
		 
		    private static int lighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = lightenColor(red, fraction);
			        green = lightenColor(green, fraction);
			        blue = lightenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static int darken(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = darkenColor(red, fraction);
			        green = darkenColor(green, fraction);
			        blue = darkenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			 
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static boolean canLighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        return canLightenComponent(red, fraction)
			            && canLightenComponent(green, fraction)
			            && canLightenComponent(blue, fraction);
			    }
		 
		    private static boolean canLightenComponent(int colorComponent, double fraction) {
			        int red = Color.red(colorComponent);
			        int green = Color.green(colorComponent);
			        int blue = Color.blue(colorComponent);
			        return red + (red * fraction) < 255
			            && green + (green * fraction) < 255
			            && blue + (blue * fraction) < 255;
			    }
		 
		    private static int darkenColor(int color, double fraction) {
			        return (int) Math.max(color - (color * fraction), 0);
			    }
		 
		    private static int lightenColor(int color, double fraction) {
			        return (int) Math.min(color + (color * fraction), 255);
		}
	}
	
	public void drawableclass() {
	}
	
	
	private void _check () {
		FileUtil.makeDir(zip_to.concat(id));
		zip_from = zip_to.concat(id);
		FileUtil.copyFile(Sketchware.concat("data/".concat(id)), zip_from);
		FileUtil.copyFile(Sketchware.concat("mysc/list/".concat(id)), zip_from);
		FileUtil.copyFile(Sketchware.concat("resources/comment/".concat(id)), zip_from);
		FileUtil.copyFile(Sketchware.concat("resources/fonts/".concat(id)), zip_from);
		FileUtil.copyFile(Sketchware.concat("resources/icons/".concat(id)), zip_from);
		FileUtil.copyFile(Sketchware.concat("resources/images/".concat(id)), zip_from);
		FileUtil.copyFile(Sketchware.concat("resources/sounds/".concat(id)), zip_from);
		FileUtil.makeDir(final_destination.concat(id));
		SketchwareUtil.showMessage(getApplicationContext(), "Zipped");
	}
	
	
	private void _copy2 (final String _sfrom, final String _sto) {
		FileUtil.writeFile("Its For Request Permission", "Don't Remove This Block");
		copydir cp = new copydir();
		cp.copydirectory(_sfrom,_sto);
	}
	public static class copydir {
		public static void copydirectory(String src, String dest) {
			java.io.File srcFolder = new java.io.File(src);
			java.io.File destFolder = new java.io.File(dest);
			if(!srcFolder.exists()) {
				System.out.println("Directory does not exist.");
				//just exit
				System.exit(0);
			} else {
				try{
					copyDirectory(srcFolder,destFolder);
				} catch(java.io.IOException e) {
					e.printStackTrace();
					//error, just exit
					System.exit(0);
				}
			}
			System.out.println("Done");
		}
		public static void copyDirectory(java.io.File src , java.io.File target) throws java.io.IOException {
			if (src.isDirectory()) {
				if (!target.exists()) {
					target.mkdir();
				}
				String[] children = src.list();
				for (int i=0; i<children.length; i++) {
					copyDirectory(new java.io.File(src, children[i]),new java.io.File(target, children[i]));
				}
			} else {
				java.io.InputStream in = new java.io.FileInputStream(src);
				java.io.OutputStream out = new java.io.FileOutputStream(target);
				// Copy the bits from instream to outstream
				byte[] buf = new byte[1024];
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
				in.close();
				out.close();
			}
		} 
	}
	{
	}
	
	
	private void _Copy_data (final String _project_no) {
		FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/data/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/data/"));
				_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/data/"));
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/mysc/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/mysc/"));
				_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/mysc/"));
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/mysc/bin/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/mysc/bin/"));
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/list/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/list/"));
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/list/".concat(_project_no.concat("/"))))) {
						_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/list/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/list/"));
				}
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/icons/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/icons/"));
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(_project_no.concat("/"))))) {
						_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/icons/"));
				}
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/images/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/images/"));
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/images/".concat(_project_no.concat("/"))))) {
						_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/images/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/images/"));
				}
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/sounds/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/sounds/"));
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/sounds/".concat(_project_no.concat("/"))))) {
						_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/sounds/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/sounds/"));
				}
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/fonts/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/fonts/"));
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/fonts/".concat(_project_no.concat("/"))))) {
						_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/fonts/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/fonts/"));
				}
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/comment/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/comment/"));
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/comment/".concat(_project_no.concat("/"))))) {
						_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/comment/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/resources/comment/"));
				}
		
	}
	
	
	private void _zip (final String _source, final String _destination) {
		FileUtil.writeFile("Don't Remove it Thanks.\nApp created by: SEM Tech Hub ™", "This Block Added for Manage Permission");
		try {
			java.util.zip.ZipOutputStream os = new java.util.zip.ZipOutputStream(new java.io.FileOutputStream(_destination));
					zip(os, _source, null);
					os.close();
		}
		
		catch(java.io.IOException e) {}
	}
	private void zip(java.util.zip.ZipOutputStream os, String filePath, String name) throws java.io.IOException
		{
				java.io.File file = new java.io.File(filePath);
				java.util.zip.ZipEntry entry = new java.util.zip.ZipEntry((name != null ? name + java.io.File.separator : "") + file.getName() + (file.isDirectory() ? java.io.File.separator : ""));
				os.putNextEntry(entry);
				
				if(file.isFile()) {
						java.io.InputStream is = new java.io.FileInputStream(file);
						int size = is.available();
						byte[] buff = new byte[size];
						int len = is.read(buff);
						os.write(buff, 0, len);
						return;
				}
				
				java.io.File[] fileArr = file.listFiles();
				for(java.io.File subFile : fileArr) {
						zip(os, subFile.getAbsolutePath(), entry.getName());
				}
	}
	
	
	private void _backup () {
		final ProgressDialog prog = new ProgressDialog(MainActivity.this);prog.setMax(100);prog.setMessage("Backuping Projects Files...... ");prog.setIndeterminate(true);prog.setCancelable(false);prog.show();
				t = new TimerTask() {
						@Override
						public void run() {
								runOnUiThread(new Runnable() {
										@Override
										public void run() {
												_Copy_data(sharedata.getString("id", ""));
												if (!FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/SEM Sketch Cloud/Backuped Projects/".concat("")))) {
														FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/SEM Sketch Cloud/Backuped Projects/".concat("")));
												}
												from = FileUtil.getExternalStorageDir().concat("/.SEM Sketch Cloud/data/temp/");
												to = FileUtil.getExternalStorageDir().concat("/SEM Sketch Cloud/Backuped Projects/".concat(sharedata.getString("id", "").concat(".zip")));
												_zip(from, to);
												prog.hide();
												SketchwareUtil.showMessage(getApplicationContext(), "Successfully Backuped!");
										}
								});
						}
				};
				_timer.schedule(t, (int)(100));
			
	}
	
	
	private void _UnZip (final String _fileZip, final String _destDir) {
		try
		{
			java.io.File outdir = new java.io.File(_destDir);
			java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(_fileZip));
			java.util.zip.ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null)
			{
				name = entry.getName();
				if(entry.isDirectory())
				{
					mkdirs(outdir, name);
					continue;
				}
				
				/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (java.io.IOException e)
		{
			e.printStackTrace();
		}
	}
	private static void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
	{
		byte[] buffer = new byte[4096];
		java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(java.io.File outdir, String path)
	{
		java.io.File d = new java.io.File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name)
	{
		int s = name.lastIndexOf(java.io.File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
	
	
	private void _Copy (final String _path, final String _pathto) {
		copy(new java.io.File(_path), new java.io.File(_pathto));
		 } public void copy(java.io.File sourceLocation, java.io.File targetLocation)
	 {
		  try {
			  if (sourceLocation.isDirectory())
			  {
				   copyDirectory(sourceLocation, targetLocation);
				  }
			  else
			  {
				   copyFile(sourceLocation, targetLocation);
				  }
			  } catch(Exception e){ throw new RuntimeException(e); }
		 }
	 private void copyDirectory(java.io.File source, java.io.File target)
	 {
		  if (!target.exists())
		  {
			   target.mkdir();
			  }
		  for (String f : source.list())
		  {
			   copy(new java.io.File(source, f), new java.io.File(target, f));
			  }
		 }
	 private void copyFile(java.io.File source, java.io.File target)
	 {
		  try {
			  try ( java.io.InputStream in = new java.io.FileInputStream(source); java.io.OutputStream out = new java.io.FileOutputStream(target) )
			  {
				   byte[] buf = new byte[1024]; int length; while ((length = in.read(buf)) > 0)
				   {
					    out.write(buf, 0, length);
					   }
				  }
			  } catch(Exception e) { throw new RuntimeException(e); }
		
	}
	
	
	private void _RippleEffects (final String _color, final View _view) {
		android.content.res.ColorStateList clr = new android.content.res.ColorStateList(new int[][]{new int[]{}},new int[]{Color.parseColor(_color)});
		android.graphics.drawable.RippleDrawable ripdr = new android.graphics.drawable.RippleDrawable(clr, null, null);
		_view.setBackground(ripdr);
	}
	
	
	private void _Shadow (final View _v, final double _n) {
		_v.setElevation((float)_n);
	}
	
	
	private void _Add (final double _post, final String _word, final String _meaning) {
		f.edit().putString(String.valueOf((long)(_post)), _word).commit();
		f.edit().putString(_word, _meaning).commit();
	}
	
	
	private void _Codes () {
		_Add(0, "Introduction", "Hello User, all the codes in SEM Sketch Could can be copied and pasted in Add Source Directly (ASD) block in the sketchware App to function well\n\nMore Information About Sketchware App And Add Source Directly Block;\n\nSketchware: Is an android software or app which allows android users to create their own apps on their android phones and share it...\nYou can download Sketchware App on playstore.\n\nAdd Source Directly Block: Is not an App unlike Sketchware, It's a block which allows android users to add codes or java codes in sketchware to function. Note that Add Source Directly is found on Sketchware App and know that all this codes on this app will be paste on Add Source Directly block to work well...\n\n>> Powered by : SEM Tech Hub ™");
		_Add(1, "Close App(Close All Activity)", "//This code is use when you want to close all activity at once.\n\nfinishAffinity();");
		_Add(2, "ActionBar Show", "//Use Below Code When Support Library Is Not Active//\n\n//show actionbar code\n getActionBar().show();\n\n\n//Use Below Codes When Support Library Is Active//\n\n//show actionbar code\n getSupportActionBar().show();\n");
		_Add(3, "ActionBar Hide", "//Use Below Two Codes When Support Library Is Not Active//\n\n//hide ActionBar code\n getActionBar().hide();\n\n\n//Use Below Two Codes When Support Library Is Active//\n\n//hide ActionBar code\n getSupportActionBar().hide();\n");
		_Add(4, "Fix Errors(Try Block)", "try {\n    //code that may crash\n} catch(Exception _e){\n\n    //here do something when try detects error\n    Log.e(\"try/catch error\", _e.toString());\n}");
		_Add(5, "ActionBar Fullscreen", "//This code is use If you want to get fullscreen of your project.\n\n//full screen\ngetWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);");
		_Add(6, "ActionBar Unfullscreen", "//This code is use when you want your app to be normal size screen.\n\n//unfullscreen\ngetWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);");
		_Add(7, "Block Screenshot", "//This code is use when you don't want you and others to screenshot in your project.\n\ngetWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);\n");
		_Add(8, "Screen Orientation", "//To make custom orientation such as Protrait and Landscape.\n\n//Landscape orientation code\nsetRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);\n\n//Portrait orientation code\nsetRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);");
		_Add(9, "Enable Java Script", "//This codes is use when you want to enable java script on webview project.\n\n//To Enable Java Script Code\nwebview1.getSettings().setJavaScriptEnabled(true);");
		_Add(10, "Disable Java Script", "//This codes is use when you want to disable java script on webview project.\n\n//To Disable Java Script Code\nwebview1.getSettings().setJavaScriptEnabled(false);");
		_Add(11, "Enable zoom in webview", "//This code is use when you want to add zoom in and out in your webview project.\n\nwebview1.getSettings().setBuiltInZoomControls(true);webview1.getSettings().setDisplayZoomControls(false);");
		_Add(12, "Disable zoom in webview", "//This code is use when you want to block zoom in and out in your webview project.\n\nwebview1.getSettings().setBuiltInZoomControls(false);webview1.getSettings().setDisplayZoomControls(true);");
		_Add(13, "Webview Support Desktop mode", "//This code is use when you want your webview project to support Desktop mode(behave like Computer).\n\nwebview1.getSettings().setLoadWithOverviewMode(true); webview1.getSettings().setUseWideViewPort(true); final WebSettings webSettings = webview1.getSettings(); final String newUserAgent; newUserAgent = \"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36\"; webSettings.setUserAgentString(newUserAgent);");
		_Add(14, "Webview Support Mobile mode", " //This code is use when you want your webview project to views Mobile websites(Android Mode).\n\nwebview1.getSettings().setLoadWithOverviewMode(true); webview1.getSettings().setUseWideViewPort(true); final WebSettings webSettings = webview1.getSettings(); final String newUserAgent; newUserAgent = \"Mozilla/5.0 (Android) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36\"; webSettings.setUserAgentString(newUserAgent);");
		_Add(15, "Long Click on button", "//This codes is use when you want to set a button on click long before button start action.\n\nbutton1.setOnLongClickListener(new View.OnLongClickListener() {@Override public boolean onLongClick(View v){ Toast.makeText(getApplicationContext(),\"Long Clicked!\",Toast.LENGTH_LONG).show();return false;}});");
		_Add(16, "Uninstall App", "//This codes is use when you want to uninstall your app in your project.\nNote:Insert your packagae name there\n\n Uri packageURI = Uri.parse(\"package:\".concat(\"com.package.name\")); Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageURI); startActivity(uninstallIntent);");
		_Add(17, "ActionBar Subtitle", "//This code is use when you want to set name for your Activity bar on your project.\n\ngetActionBar().setSubtitle(\"Subtitle\");");
		_Add(18, "ActionBar Title", "//This code is use when you want to set a name under the App name as subtitle\n\ngetActionBar().setTitle(\"Title\");");
		_Add(19, "ActionBar Title RGBG", "//To set a Title on Actionbar(RGBG).\n\nString Int_title = String.format(Locale.US, \"#%06X\", (0xFFFFFF & Color.argb(120,50,90,10)));\n\ngetActionBar().setTitle(Html.fromHtml(\"<font color=\\\\\"\" + Int_title + \"\\\\\">Gabriel</font>\"));");
		_Add(20, "ActionBar Color", "\n//To set ActionBar Color.\n\nActionBar actionBar = getActionBar(); actionBar.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.parseColor(\"#191919\")));\nif (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {\n    Window w = MainActivity.this.getWindow();\n    w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);\n    w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);\n    w.setStatusBarColor(Color.parseColor(\"#000000\"));\n}\n\n//Change ActionBar Title Color\n\ngetActionBar().setTitle(Html.fromHtml(\"<font color='#FF0000'>Color Tools</font>\"));\n\n/*Change In Action Bar Header / Statues Bar */\n\ntry {\nif (Build.VERSION.SDK_INT >= 21) {\ngetWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);\ngetWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);\ngetWindow().setStatusBarColor(0xFF263238);\nheaders.setElevation(10f); //your actionbar linear\n}\n}\ncatch (Exception e) {\n};");
		_Add(21, "Text Color", "//To set a textview colour.\n\ntextview1.setTextColor(Color.parseColor(\"#000000\"));");
		_Add(22, "Get Webview Title", "//This code is use when you want to get your webview/webpage title on textview.\n\ntextview1.setText(webview1.getTitle());");
		_Add(23, "Move Task to Background", "//This code like pressing home button of your phone.\n//This code use when you want to move task to background action.\n\nmoveTaskToBack(true);");
		_Add(24, "Youtube downloder", "//This codes is use when you want to create a youtube downloader project.\nNote:Insert 2 button and rename one to \"btn\" and rename one to \"button_container\" and set webview to \"web\". You will do all this changes on ID name.\n\nfinal List<Video> videos = new ArrayList<Video>();\nbutton_container.setVisibility(View.GONE);\nweb.setWebViewClient(new WebViewClient(){\n@Override\npublic android.webkit.WebResourceResponse shouldInterceptRequest(android.webkit.WebView view, android.webkit.WebResourceRequest request) {\nif(request.getUrl().toString().matches(\".*googlevideo.com/videoplayback.*\")){\nVideo vid=new Video(request.getUrl().toString());\nboolean isExists = false;\nfor(Video v:videos){\nif(v.size==vid.size) isExists=true;\n}\nif(!isExists) videos.add(vid);\nnew Handler(Looper.getMainLooper()).post(new Runnable(){\n@Override\npublic void run(){\nbutton_container.setVisibility(View.VISIBLE);\n}\n});\nreturn new WebResourceResponse(\"\", \"\", null);\n}\nreturn super.shouldInterceptRequest(view, request);\n}\n@Override\npublic void onPageFinished(android.webkit.WebView view, java.lang.String url) {\nvideos.clear();\nif(url.contains(\"watch?v=\"))\nnew Handler().postDelayed(new Runnable(){\n@Override\npublic void run() {\nweb.loadUrl(\"javascript:document.getElementsByTagName('video')[0].play();\");\n}\n}, 1000);\n//Toast.makeText(WVYoutubeDl.this, \"Play Video First to Enable Download\",0).show();\n}\n});\nweb.setWebChromeClient(new WebChromeClient(){\n@Override\npublic void onProgressChanged(WebView view, int progress) {\nnew Handler(Looper.getMainLooper()).post(new Runnable(){\n@Override\npublic void run(){\nbutton_container.setVisibility(View.GONE);\n}\n});\n}\n});\nweb.loadUrl(\"https://youtube.com/\");\nbtn.setText(\"Download Video\");\nbtn.setOnClickListener(new View.OnClickListener(){\n@Override\npublic void onClick(View p1) {\nString[] vids=new String[videos.size()];\nfor(int i=0;i<videos.size();i++){\nVideo v=videos.get(i);\nvids[i]=(v.isAudioOnly?\"Audio\":\"Video\")+\" (\"+v.readableSize+\")\";\n}\nAlertDialog.Builder dlg=new AlertDialog.Builder(MainActivity.this);\ndlg.setTitle(\"Download\");\ndlg.setItems(vids, new android.content.DialogInterface.OnClickListener(){\n@Override\npublic void onClick(android.content.DialogInterface p1, int p2) {\ndownload_(videos.get(p2).url);\n}\n});\ndlg.show();\n}\n});\nshowAlert();\n}\n@Override\npublic void onBackPressed() {\nif(web.canGoBack())\nweb.goBack();\nelse\nsuper.onBackPressed();\n}\nprivate void showAlert(){\nnew AlertDialog.Builder(this).setTitle(\"WARNING\").setMessage(\"Downloading Youtube videos is against Google Terms of Service, do with your own risk.\").show();\n}\nprivate String readableFileSize(long size) {\nif(size <= 0) return \"0\";\nfinal String[] units = new String[] { \"B\", \"kB\", \"MB\", \"GB\", \"TB\" };\nint digitGroups = (int) (Math.log10(size)/Math.log10(1024));\nreturn new java.text.DecimalFormat(\"#,##0.#\").format(size/Math.pow(1024, digitGroups)) + \" \" + units[digitGroups];\n}\nprivate void download_(String url){\nDownloadManager dmgr = (DownloadManager) this.getSystemService(DOWNLOAD_SERVICE);\nDownloadManager.Request request = new DownloadManager.Request(android.net.Uri.parse(url));\nrequest.setAllowedNetworkTypes(\nDownloadManager.Request.NETWORK_WIFI\n| DownloadManager.Request.NETWORK_MOBILE)\n.setAllowedOverRoaming(false).setTitle(\"Download\")\n.setDescription(\"Downloading Video...\")\n.setDestinationInExternalPublicDir(\"/Download/\", System.currentTimeMillis()+\".mp4\");\ndmgr.enqueue(request);\n}\npublic class Video{\npublic String url;\npublic boolean isAudioOnly;\npublic long size;\npublic String readableSize;\npublic Video(String s){\nString ss=s.replaceAll(\"&range=[\\\\d-]*&\",\"&\");\nurl=ss;\nisAudioOnly=ss.contains(\"mime=audio\");\nsize=Long.parseLong( ss.split(\"&clen=\")[1].split(\"&\")[0]);\nreadableSize=readableFileSize(size);\n}");
		_Add(25, "To Save Image to Gallery", "//This code is use when you want to save an image in your project.\nNote:Add view moreblock,if not this code will not work\n\nBitmap returnedBitmap = Bitmap.createBitmap(_view.getWidth(), _view.getHeight(),Bitmap.Config.ARGB_8888); Canvas canvas = new Canvas(returnedBitmap); android.graphics.drawable.Drawable bgDrawable =_view.getBackground(); if (bgDrawable!=null) { bgDrawable.draw(canvas); } else { canvas.drawColor(Color.WHITE); } _view.draw(canvas); java.io.File pictureFile = new java.io.File(Environment.getExternalStorageDirectory() + \"/Download/myimage.png\"); if (pictureFile == null) { showMessage(\"Error creating media file, check storage permissions: \"); return; } try { java.io.FileOutputStream fos = new java.io.FileOutputStream(pictureFile); returnedBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos); fos.close(); showMessage(\"Image Saved in /Download/ folder\"); } catch (java.io.FileNotFoundException e) { showMessage(\"File not found: \" + e.getMessage()); } catch (java.io.IOException e) { showMessage(\"Error accessing file: \" + e.getMessage()); }");
		_Add(26, "ActionBar Set Icon", "//To set Actionbar icon.\n\ngetActionBar().setIcon(r.drawable.icon_name);");
		_Add(27, "Set Dialog Icon", "//To set or insert or add an image to a dialog.\n\nDialog.setIcon(R.drawable.ic_add image name_here);");
		_Add(28, "Dialog Uncancel", "//This code is use when you do not want dialog to cancel when touch any part of the screen.\n\nDialog.setCancelable(false);");
		_Add(29, "Battery Level Show", "//To set your phone battery level on textview in your project, use this codes below.\n\nBatteryManager bm = (BatteryManager)getSystemService(BATTERY_SERVICE);\nint batLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);\ntextview1.setText(Integer.toString(batLevel));");
		_Add(30, "Textview - Click to Copy", "//To set allows people to copy words in your project.\n\ntextview1.setTextIsSelectable(true);");
		_Add(31, "Set Textview to Capital words", "//This codes will automatically set your textview1 to capitals.\n\ntextview1.setAllCaps(true);");
		_Add(32, "Linkify - Links in Textview", "//This code is use when you want to set textview as link direct.\n\ntextview1.setClickable(true);\nandroid.text.util.Linkify.addLinks(textview1, android.text.util.Linkify.ALL);\ntextview1.setLinkTextColor(Color.parseColor(\"#009688\"));\ntextview1.setLinksClickable(true);");
		_Add(33, "Download Webview In External", "//This code will automatically direct you to another browser on your phone to download files.\n\nwebview1.setDownloadListener(new DownloadListener() {\npublic void onDownloadStart(String url, String userAgent,\nString contentDisposition, String mimetype,long contentLength) {\nIntent i = new Intent(Intent.ACTION_VIEW);\ni.setData(Uri.parse(url));\nstartActivity(i);\n}\n});");
		_Add(34, "Download Webview Internal", "//This code is use when you want to  download files on your own webivew project.\n\nwebview1.setDownloadListener(new DownloadListener() {\npublic void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {\nDownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));\nString cookies = CookieManager.getInstance().getCookie(url);\nrequest.addRequestHeader(\"cookie\", cookies);\nrequest.addRequestHeader(\"User-Agent\", userAgent);\nrequest.setDescription(\"Downloading file...\");\nrequest.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));\nrequest.allowScanningByMediaScanner(); request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);\njava.io.File aatv = new java.io.File(Environment.getExternalStorageDirectory().getPath() + \"/Webview/Download\");\nif(!aatv.exists()){if (!aatv.mkdirs()){ Log.e(\"TravellerLog ::\",\"Problem creating Image folder\");}} request.setDestinationInExternalPublicDir(\"/Webview/Download\", URLUtil.guessFileName(url, contentDisposition, mimetype));\nDownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);\nmanager.enqueue(request);\nshowMessage(\"Downloading File....\");\n//Notif if success\nBroadcastReceiver onComplete = new BroadcastReceiver() {\npublic void onReceive(Context ctxt, Intent intent) {\nshowMessage(\"Download Complete!\");\nunregisterReceiver(this);\n}};\nregisterReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));\n}\n});");
		_Add(35, "Rounded Layout like Whatsapp", "//This code will automatically make your linear rounded like whatsapp.\n\nandroid.graphics.drawable.GradientDrawable ed = new android.graphics.drawable.GradientDrawable();\ned.setColor(Color.parseColor(\"#FFFFFF\"));\ned.setCornerRadius(110);\nlinear1.setBackground(ed);");
		_Add(36, "Menu in Actionbar", "//Use this code to create menu bar on actionbar.\n\n}\n@Override\npublic boolean onCreateOptionsMenu (Menu menu){\nmenu.add(0, 0, 0, \"Item 1\");\nmenu.add(0, 1, 1, \"Item 2\");\nmenu.add(0, 2, 2, \"Item 3\");\nreturn true;\n}\n\n@Override\npublic boolean onOptionsItemSelected(MenuItem item){\nswitch (item.getItemId()){\ncase 0:\nshowMessage(\"Item 1 Clicked\");//codes when item1 clicked\nbreak;\ncase 1:\nshowMessage(\"Item 2 Clicked\");//codes when item2 clicked\nbreak;\ncase 2:\nshowMessage(\"Item 3 Clicked\");//codes when item3 clicked\nbreak;\n\n}\nreturn super.onOptionsItemSelected(item);");
		_Add(37, "Long press on Image in Webview to Download", "//This codes is use when you want to insert long press on image to download in your webview project.\n\n//paste the below code in onCreate\nwebview1.getSettings().setJavaScriptEnabled(true); webview1.setWebViewClient(new WebViewClient()); registerForContextMenu(webview1);\nwebview1.loadUrl(\"https://www.google.com\");\n\n\n//paste the below code in a moreblock nothing\n//Below code will download images in a Webview/Download folder\n}\n@Override public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo){ super.onCreateContextMenu(contextMenu, view, contextMenuInfo); final WebView.HitTestResult webViewHitTestResult = webview1.getHitTestResult(); if (webViewHitTestResult.getType() == WebView.HitTestResult.IMAGE_TYPE || webViewHitTestResult.getType() == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) { contextMenu.setHeaderTitle(\"Download Image From Below\"); contextMenu.add(0, 1, 0, \"Save - Download Image\") .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() { @Override public boolean onMenuItemClick(MenuItem menuItem) { String DownloadImageURL = webViewHitTestResult.getExtra(); if(URLUtil.isValidUrl(DownloadImageURL)){ DownloadManager.Request request = new DownloadManager.Request(Uri.parse(DownloadImageURL)); request.allowScanningByMediaScanner();\nrequest.setTitle(\"download.png\");\nrequest.setDestinationInExternalPublicDir(\"/Webview/Download\", \"download.png\"); request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); DownloadManager downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE); downloadManager.enqueue(request); Toast.makeText(MainActivity.this,\"Image Downloaded Successfully.\",Toast.LENGTH_LONG).show(); } else { Toast.makeText(MainActivity.this,\"Sorry.. Something Went Wrong.\",Toast.LENGTH_LONG).show(); } return false; } }); }");
		_Add(38, "Status Bar Transparancy", "//This code is use to make status transparancy.\n\nif (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {  Window w = this.getWindow();w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF008375); w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS); }");
		_Add(39, "Circle Image(Rounded Imageview)", "//This code is use to make image circle(Rounded).\n\n//put below code in onCreate event\nBitmap bm = ((android.graphics.drawable.BitmapDrawable) imageview1.getDrawable()).getBitmap(); imageview1.setImageBitmap(getRoundedCornerBitmap(bm, 360)); \n\n\n//put below code in a more block \n\n} public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) { Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888); Canvas canvas = new Canvas(output); final int color = 0xff424242; final Paint paint = new Paint(); final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight()); final RectF rectF = new RectF(rect); final float roundPx = pixels; paint.setAntiAlias(true); canvas.drawARGB(0, 0, 0, 0); paint.setColor(color); canvas.drawRoundRect(rectF, roundPx, roundPx, paint); paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN)); canvas.drawBitmap(bitmap, rect, rect, paint); return output;");
		_Add(40, "App list with icons(Launch)", "//This code will displays your phone apps with icons and the purpose of launch them there.\n\n\nIntent startupIntent = new Intent(Intent.ACTION_MAIN); 		startupIntent.addCategory(Intent.CATEGORY_LAUNCHER);  		final android.content.pm.PackageManager pm = getPackageManager(); 		List<android.content.pm.ResolveInfo> activities = pm.queryIntentActivities(startupIntent,0);   		Collections.sort(activities, new Comparator<android.content.pm.ResolveInfo>() {  				public int compare(android.content.pm.ResolveInfo a, android.content.pm.ResolveInfo b) {  					android.content.pm.PackageManager pm = getPackageManager();  					return String.CASE_INSENSITIVE_ORDER.compare(  						a.loadLabel(pm).toString(),  						b.loadLabel(pm).toString());  				}  			});   		ArrayAdapter<android.content.pm.ResolveInfo> adapter = new ArrayAdapter<android.content.pm.ResolveInfo>(  			this, android.R.layout.simple_list_item_1, activities) {  			public View getView(int pos, View convertView, ViewGroup parent) { TextView tv = new TextView(MainActivity.this);  				android.content.pm.ResolveInfo ri = getItem(pos);  			tv.setText(ri.loadLabel(pm));  	LinearLayout lin = new LinearLayout(MainActivity.this);ImageView iv = new ImageView(MainActivity.this);iv.setImageDrawable(ri.loadIcon(pm));lin.addView(iv);lin.addView(tv);tv.setGravity(Gravity.CENTER_VERTICAL);tv.setPadding(16,0,0,0);tv.setTextSize(16);tv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT ));LinearLayout.LayoutParams p =	new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.MATCH_PARENT);p.width = 70;p.height = 70;p.bottomMargin = 4;p.topMargin = 4;iv.setLayoutParams(p);lin.setPadding(6,6,6,6);return lin;  			}  		};  		listview1.setAdapter(adapter); 		 		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {  				@Override 				public void onItemClick(AdapterView adapter, View v, int position, long id) 				{ 					android.content.pm.ResolveInfo resolveInfo = (android.content.pm.ResolveInfo)adapter.getItemAtPosition(position);  					android.content.pm.ActivityInfo activityInfo = resolveInfo.activityInfo;  					if (activityInfo == null) return;  					Intent i = new Intent(Intent.ACTION_MAIN);  					i.setClassName(activityInfo.applicationInfo.packageName, activityInfo.name);  					startActivity(i); 				}  			 		});;");
		_Add(41, "App list with icons(Uninstall)", "//This code will displays your phone apps with icons and the purpose of Uninstall them there.\n\nIntent startupIntent = new Intent(Intent.ACTION_MAIN); 		startupIntent.addCategory(Intent.CATEGORY_LAUNCHER);  		final android.content.pm.PackageManager pm = getPackageManager(); 		List<android.content.pm.ResolveInfo> activities = pm.queryIntentActivities(startupIntent,0);   		Collections.sort(activities, new Comparator<android.content.pm.ResolveInfo>() {  				public int compare(android.content.pm.ResolveInfo a, android.content.pm.ResolveInfo b) {  					android.content.pm.PackageManager pm = getPackageManager();  					return String.CASE_INSENSITIVE_ORDER.compare(  						a.loadLabel(pm).toString(),  						b.loadLabel(pm).toString());  				}  			});   		ArrayAdapter<android.content.pm.ResolveInfo> adapter = new ArrayAdapter<android.content.pm.ResolveInfo>(  			this, android.R.layout.simple_list_item_1, activities) {  			public View getView(int pos, View convertView, ViewGroup parent) { TextView tv = new TextView(MainActivity.this);  				android.content.pm.ResolveInfo ri = getItem(pos);  			tv.setText(ri.loadLabel(pm));  	LinearLayout lin = new LinearLayout(MainActivity.this);ImageView iv = new ImageView(MainActivity.this);iv.setImageDrawable(ri.loadIcon(pm));lin.addView(iv);lin.addView(tv);tv.setGravity(Gravity.CENTER_VERTICAL);tv.setPadding(16,0,0,0);tv.setTextSize(16);tv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT ));LinearLayout.LayoutParams p =	new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.MATCH_PARENT);p.width = 70;p.height = 70;p.bottomMargin = 4;p.topMargin = 4;iv.setLayoutParams(p);lin.setPadding(6,6,6,6);return lin;  			}  		};  		listview1.setAdapter(adapter); 		 		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {  				@Override 				public void onItemClick(AdapterView adapter, View v, int position, long id) 				{ 					android.content.pm.ResolveInfo resolveInfo = (android.content.pm.ResolveInfo)adapter.getItemAtPosition(position);  					android.content.pm.ActivityInfo activityInfo = resolveInfo.activityInfo;  					if (activityInfo == null) return;  					Uri packageURI = Uri.parse(\"package:\".concat(activityInfo.applicationInfo.packageName)); Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageURI); startActivity(uninstallIntent); 				}  			 		});;");
		_Add(42, "App list without icons(Launch)", "//This code will displays your phone apps without icons and the purpose of Launch them there.\n\nIntent startupIntent = new Intent(Intent.ACTION_MAIN); 		startupIntent.addCategory(Intent.CATEGORY_LAUNCHER);  		final android.content.pm.PackageManager pm = getPackageManager(); 		List<android.content.pm.ResolveInfo> activities = pm.queryIntentActivities(startupIntent,0);   		Collections.sort(activities, new Comparator<android.content.pm.ResolveInfo>() {  				public int compare(android.content.pm.ResolveInfo a, android.content.pm.ResolveInfo b) {  					android.content.pm.PackageManager pm = getPackageManager();  					return String.CASE_INSENSITIVE_ORDER.compare(  						a.loadLabel(pm).toString(),  						b.loadLabel(pm).toString());  				}  			});   		ArrayAdapter<android.content.pm.ResolveInfo> adapter = new ArrayAdapter<android.content.pm.ResolveInfo>(  			this, android.R.layout.simple_list_item_1, activities) {  			public View getView(int pos, View convertView, ViewGroup parent) {  				View v = super.getView(pos, convertView, parent);  				TextView tv = (TextView)v;  				android.content.pm.ResolveInfo ri = getItem(pos);  				tv.setText(ri.loadLabel(pm));  				return v;  			}  		};  		listview1.setAdapter(adapter); 		 		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {  				@Override 				public void onItemClick(AdapterView adapter, View v, int position, long id) 				{ 					android.content.pm.ResolveInfo resolveInfo = (android.content.pm.ResolveInfo)adapter.getItemAtPosition(position);  					android.content.pm.ActivityInfo activityInfo = resolveInfo.activityInfo;  					if (activityInfo == null) return;  Uri packageURI = Uri.parse(\"package:\".concat(activityInfo.applicationInfo.packageName)); Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageURI); startActivity(uninstallIntent);  				}  			 		});;");
		_Add(43, "App list without icons(Uninstall)", "//This code will displays your phone apps without icons and the purpose of Uninstall them there.\n\nIntent startupIntent = new Intent(Intent.ACTION_MAIN); 		startupIntent.addCategory(Intent.CATEGORY_LAUNCHER);  		final android.content.pm.PackageManager pm = getPackageManager(); 		List<android.content.pm.ResolveInfo> activities = pm.queryIntentActivities(startupIntent,0);   		Collections.sort(activities, new Comparator<android.content.pm.ResolveInfo>() {  				public int compare(android.content.pm.ResolveInfo a, android.content.pm.ResolveInfo b) {  					android.content.pm.PackageManager pm = getPackageManager();  					return String.CASE_INSENSITIVE_ORDER.compare(  						a.loadLabel(pm).toString(),  						b.loadLabel(pm).toString());  				}  			});   		ArrayAdapter<android.content.pm.ResolveInfo> adapter = new ArrayAdapter<android.content.pm.ResolveInfo>(  			this, android.R.layout.simple_list_item_1, activities) {  			public View getView(int pos, View convertView, ViewGroup parent) {  				View v = super.getView(pos, convertView, parent);  				TextView tv = (TextView)v;  				android.content.pm.ResolveInfo ri = getItem(pos);  				tv.setText(ri.loadLabel(pm));  				return v;  			}  		};  		listview1.setAdapter(adapter); 		 		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {  				@Override 				public void onItemClick(AdapterView adapter, View v, int position, long id) 				{ 					android.content.pm.ResolveInfo resolveInfo = (android.content.pm.ResolveInfo)adapter.getItemAtPosition(position);  					android.content.pm.ActivityInfo activityInfo = resolveInfo.activityInfo;  					if (activityInfo == null) return;  					Intent i = new Intent(Intent.ACTION_MAIN);  					i.setClassName(activityInfo.applicationInfo.packageName, activityInfo.name);  					startActivity(i); 				}  			 		});;");
		_Add(44, "Create Notification", "//This code is use to create a notification in project.\n\n Notification.Builder mBuilder = new Notification.Builder(MainActivity.this);mBuilder.setSmallIcon(R.drawable.default_image);mBuilder.setContentTitle(_title);mBuilder.setContentText(_message);NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);int onx = 1;notificationManager.notify(onx, mBuilder.build());");
		_Add(45, "Date Picker", "//This code is use to make date picker in project.\n\n DatePicker dp=new DatePicker (MainActivity.this);ln.addView(dp);Calendar calendar=Calendar.getInstance(); dp.init(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH),new DatePicker.OnDateChangedListener(){@Override public void onDateChanged(DatePicker datePicker, int i, int i1, int i2) {Toast.makeText(getApplicationContext(),datePicker.getDayOfMonth() + \"-\" +datePicker.getMonth() + \"-\"+datePicker.getYear(),Toast.LENGTH_SHORT).show(); } });");
		_Add(46, "Root Checkup", "//This code is use when you want to check your phone weather it root or not.\n\n//code by Franco Calderazo\ntry {\n\nRuntime.getRuntime().exec(\"su\"); \n\nresultado.setText(\"Root user\");\n\n} catch (Exception e ) {\n\nresultado.setText(\"Normal user\");\nshowMessage(e.toString());\n\n}");
		_Add(47, "Enable Webview Cookies", "//This code is use to add browser Cookies in your webview project.\n\nCookieManager.getInstance().setAcceptCookie(true);");
		_Add(48, "Disable Webview Cookies", "//This code is use to denied browser Cookies in your webview project.\n\nCookieManager.getInstance().setAcceptCookie(false);");
		_Add(49, "Text to Speech", "//This codes allows you to create text to speech in your project.\n\n\nfinal android.speech.tts.TextToSpeech t1 = new android.speech.tts.TextToSpeech(getApplicationContext(), new android.speech.tts.TextToSpeech.OnInitListener() {\n@Override\npublic void onInit(int status) {  		\nif(status == android.speech.tts.TextToSpeech.ERROR) {	Toast.makeText(getApplicationContext(), \"Error\",Toast.LENGTH_SHORT).show();\n}\n}\n});\nbutton1.setOnClickListener(new View.OnClickListener() {\n@Override\npublic void onClick(View _v) {\nString sentence = edittext1.getText().toString();  		Toast.makeText(getApplicationContext(), sentence,Toast.LENGTH_SHORT).show(); 		t1.speak(sentence,android.speech.tts.TextToSpeech.QUEUE_FLUSH, null);  	}  } );");
		_Add(50, "Search in Listview", "//This code is use to allows you to search items on your listview project.\n\n((ArrayAdapter)listview1.getAdapter()).getFilter().filter(edittext1.getText().toString());");
		_Add(51, "Launch App", "//This code is use to launch an app in your project.\n\n Intent launchIntent = getPackageManager().getLaunchIntentForPackage(\"com.package.address\");  { startActivity(launchIntent);}");
		_Add(52, "Create Edittext", "//This code is use to create edittext in a project.\n\nfinal EditText myedit = new EditText(MainActivity.this); myedit.setHint(\"Your Hint\"); myedit.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)); linear1.addView(myedit);");
		_Add(53, "Create button", "//This code is use to create button in a project.\n\nfinal Button mybutton = new Button(ProjectinActivity.this); mybutton.setText(\"Your Button\"); mybutton.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)); linear1.addView(mybutton);");
		_Add(54, "Create Textview", "//This code is use to create textview in a project.\n\nfinal TextView mytext = new TextView(ProjectinActivity.this); mytext.setText(\"Your Text\"); mytext.setTextColor(0xFF000000); mytext.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)); linear1.addView(mytext);");
		_Add(55, "Clipboad get text", "//This code allows you to paste text from clipboad onto edittext.\n\nClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE); \nwidgethere.setText(clipboard.getText());\n// widgethere is a TextView, EditText, or something");
		_Add(56, "Popup Menu", "//This codes allow you to create a popup dialog in a project.\n\n\nPopupMenu popup = new PopupMenu(MainActivity.this, button1);\n\nMenu menu = popup.getMenu();\nmenu.add(\"Aan\");\nmenu.add(\"Gabriel\");\n\n\npopup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {\n\npublic boolean onMenuItemClick(MenuItem item) {\nswitch (item.getTitle().toString()) {\ncase \"Aan\":\nshowMessage(\"Aan clicked\");\nreturn true;\n\ncase \"Gabriel\":\nshowMessage(\"Gabriel Clicked\");\nreturn true;\n\ndefault: return false;\n}\n}\n});\n\n\npopup.show();");
		_Add(57, "Speech to Text", "//This code is use to create speech text in a project.\n\n//Create more block and name it extra . insert this codes below\n}\npublic static final int REQ_CODE_SPEECH_INPUT = 1;\n{\n\n//Add a file picker and insert this code below.\n\n}\nbreak;\ncase REQ_CODE_SPEECH_INPUT:\nif (_resultCode == RESULT_OK && null != _data) {\nArrayList<String> result = _data.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS);\nedittext1.setText(result.get(0));\n\n//Add edittext 1 and button in the background of sketchware.\n\n//In the button one add this codes below.\n\nIntent intent = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH); intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault()); intent.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, \"Speak Now\");\ntry { startActivityForResult(intent, REQ_CODE_SPEECH_INPUT); }\ncatch (ActivityNotFoundException a) {\nToast.makeText(getApplicationContext(), \"There was an error\", Toast.LENGTH_SHORT).show(); }\n\n//Finished");
		_Add(58, "Imageview from - Url", "//This code is use for imageview from url in a webview project\n\nurl =\"https://google.com\";\nGlide.with(getApplicationContext()).load(Uri.parse(url)).into(imageview1);");
		_Add(59, "Dialog Themes", "//To set your dialog theme.\n\n//Gingerbread theme code\nyour_dialog = new AlertDialog.Builder(this,AlertDialog.THEME_TRADITIONAL);\n\n//Holo dark theme code\ndialog = new AlertDialog.Builder(this,AlertDialog.THEME_DEVICE_DEFAULT_DARK);\n\n//Holo light theme code\ndialog = new AlertDialog.Builder(this,AlertDialog.THEME_HOLO_LIGHT);\n\n//Material dark theme code\nsetTheme(android.R.style.Theme_Material);\n\n//Material light theme code\nsetTheme(android.R.style.Theme_Material_Light);\n\n//Device default dark theme code\ndialog = new AlertDialog.Builder(this,AlertDialog.THEME_DEVICE_DEFAULT_DARK);\n\n//Device default light theme code\ndialog = new AlertDialog.Builder(this,AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);");
		_Add(60, "Enable/Disable Keyboard", "//This code is use to disable/enable keyboard in a project.\n\n//Enable keyboard code\nedittext1.setShowSoftInputOnFocus(true);\n\n//Disable keyboard code\nedittext1.setShowSoftInputOnFocus(false);");
		_Add(61, "Password Show/Hide", "//This code is use to show/hide password on eddittext in a project.\n\n//Password Hide code\nedittext1.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());\n\n\n//Password Show code\nedittext1.setTransformationMethod(android.text.method.HideReturnsTransformationMethod.getInstance());");
		_Add(62, "Text Shadow", "//To set Textview with shadow mode.\n\n textview1.setShadowLayer(3,1,1, Color.BLACK);");
		_Add(63, "Drag Linear", "//This code is use when you want to make linear can move from one to another(Drag).\n//Note:The drag linear depends on ID name.\n\n\nlinear1.setOnTouchListener(new OnTouchListener() {\nPointF DownPT = new PointF();\nPointF StartPT = new PointF();\n@Override public boolean onTouch(View v, MotionEvent event) {\nint eid = event.getAction();\nswitch (eid) {\ncase MotionEvent.ACTION_MOVE:PointF mv = new PointF(event.getX() - DownPT.x, event.getY() - DownPT.y);\nlinear1.setX((int)(StartPT.x+mv.x));\nlinear1.setY((int)(StartPT.y+mv.y));\nStartPT = new PointF(linear1.getX(), linear1.getY());\nbreak;\ncase MotionEvent.ACTION_DOWN : DownPT.x = event.getX();\nDownPT.y = event.getY();\nStartPT = new PointF(linear1.getX(), linear1.getY());\nbreak;\ncase MotionEvent.ACTION_UP : break;\ndefault : break;\n}\nreturn true;\n}\n});");
		_Add(64, "Check Internet Connection", "//To check internet connection in a project.\n\n//put in moreblock\n\n//put this code first\n\ntry {\n\n//this is the second code\n\nconnected = (Runtime.getRuntime().exec (command).waitFor() == 0); } catch (Exception e){ showMessage(e.toString());}\n\n//create 2 variables, one with the name \"connected\" and the other variable with name \"command\"\n\n//put this code in variable set \"command\" to \n\nping -c 1 google.com\n\n//put one if then else block, and in the if place the \"connected\" variable and place your blocks or codes in \"then\" and \"else\" of the if block");
		_Add(65, "Show Edittext dialog", "//This code is use to create dialog with edittext in a project.\n\n LinearLayout mylayout = new LinearLayout(this); LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); mylayout.setLayoutParams(params); mylayout.setOrientation(LinearLayout.VERTICAL); final EditText myedittext = new EditText(this);  myedittext.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)); mylayout.addView(myedittext); dialog.setView(mylayout);");
		_Add(66, "Dialog Rounded", "//To set dialog rounded in a project.\n\nfinal AlertDialog dialog = new AlertDialog.Builder(VerificationActivity.this).create();\nLayoutInflater inflater = getLayoutInflater();\n\nView convertView = (View) inflater.inflate(R.layout.mylayout, null);\ndialog.setView(convertView);\n\n\n\ndialog.requestWindowFeature(Window.FEATURE_NO_TITLE);  dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));\n\n\n\ndailog.show();");
		_Add(67, "Set Gravity", "//To set a textview,button,linear and etc gravity in a project,copy code below.\n textview1.setGravity(Gravity.RIGHT); textview1.setTextDirection(View.TEXT_DIRECTION_LTR);");
		_Add(68, "Progress Dialog(Loading)", "//This code is use to create progress loading in dialog in a project.\n\n final ProgressDialog prog = new ProgressDialog(MainActivity.this);prog.setMax(100);prog.setTitle(\"Hello\");prog.setMessage(\"Message\");prog.setIndeterminate(true);prog.setCancelable(false);prog.show();");
		_Add(69, "Create Progressbar(Circle)", "//To create a circle progressbar in a project.\n\nProgressBar msg = new ProgressBar(MainActivity.this);  linear1.addView(msg);\n\n//linear1 is an LinearLayout and MainActivity is your activity");
		_Add(70, "Create Ratingbar", "//This code is use to create ratebar in a project.\n\n RatingBar tp = new RatingBar(this); linear1.addView(tp);");
		_Add(71, "Webview Password Save", "//To set webview to save websites passwords when you sign up or in.\n webview.getSettings().setSavePassword(true);");
		_Add(72, "Webview Block Password Save", "//To set webview don't save websites passwords when you sign up or in.\n webview.getSettings().setSavePassword(false);");
		_Add(73, "Image Zoom In", "//To set imageview zoom in in a project.\n\n  float x=preview.getScaleX(), y=preview.getScaleY(),yenix=x+1,yeniy=y+1; preview.setScaleX(yenix);preview.setScaleY(yeniy);");
		_Add(74, "Imageview Zoom Out", "//To set Imageview Zoom out in a project.\n\n float x=preview.getScaleX(), y=preview.getScaleY(),yenix=x-1,yeniy=y-1; preview.setScaleX(yenix);preview.setScaleY(yeniy);");
		_Add(75, "Share App", "//This code is use when you want to an app can be share on it own without using any share app to share.\n\nString apk = \"\";\nString uri = (getPackageName);\ntry {\nandroid.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(uri, android.content.pm.PackageManager.GET_ACTIVITIES);\napk = pi.applicationInfo.publicSourceDir;\n} catch (Exception e) {\nshowMessage(e.toString());\n}\nIntent iten = new Intent(Intent.ACTION_SEND);\niten.setType(\"*/*\");\niten.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new java.io.File(apk)));\nstartActivity(Intent.createChooser(iten, \"Send APK\"));");
		_Add(76, "Digital Clock", "//This code is use to make digitatal time or Clock in project.\n\n//Code by Md Tausif Iqbal//\nfinal DigitalClock dc = new DigitalClock(this);\nlinear1.addView (dc);");
		_Add(77, "Set Checkbox Icon", "//To set a checkbox icon in a project.\nor to create custom checkbox.\n\ncheckbox1.setButtonDrawable(R.drawable.iconname);\n\n//iconname is an image");
		_Add(78, "Flashlight On", "//This code is use to turn ON flashlight of your phone in a project .\n\nandroid.hardware.camera2.CameraManager cameraManager = (android.hardware.camera2.CameraManager) getSystemService(Context.CAMERA_SERVICE);\ntry {\nString cameraId = cameraManager.getCameraIdList()[0]; cameraManager.setTorchMode(cameraId, true); } catch (android.hardware.camera2.CameraAccessException e) { }");
		_Add(79, "Flashlight Off", "//This code is use to turn Off flashlight of your phone in a project..\n\nandroid.hardware.camera2.CameraManager cameraManager = (android.hardware.camera2.CameraManager) getSystemService(Context.CAMERA_SERVICE);\ntry {\nString cameraId = cameraManager.getCameraIdList()[0]; cameraManager.setTorchMode(cameraId, false); } catch (android.hardware.camera2.CameraAccessException e) { }");
		_Add(80, "Feedback Button", "//To add feedback button on your project.\n\nButton button01 = (Button) findViewById(R.id.rate); button01.setOnClickListener(new OnClickListener() { public void onClick(View v) { try{ Intent intent = new Intent (Intent.ACTION_VIEW , Uri.parse(\"mailto:\" + \"your_acc_here@gmail.com\")); intent.putExtra(Intent.EXTRA_SUBJECT, \"AndroidDev - Basic Codes\"); intent.putExtra(Intent.EXTRA_TEXT, \"Enter your Message Here\"); startActivity(intent); }catch(ActivityNotFoundException e){ Toast.makeText(getApplicationContext(), \"Oopps No Mailer Install on your devices. \nInstall Gmail or Email Application first\", Toast.LENGTH_LONG).show(); } } });");
		_Add(81, "Webview - Favicon", "//To create or set webview favicon in a project.\n\nimageview1.setImageBitmap(webview1.getFavicon());");
		_Add(82, "Listview - Swipe to Refresh", "//This code is use when you want to add swipe to refresh on listview in a project.\n//Note On Appcompat and design.\n\nfinal android.support.v4.widget.SwipeRefreshLayout sl = new android.support.v4.widget.SwipeRefreshLayout(MainActivity.this); sl.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.MATCH_PARENT)); linear1.addView(sl); linear1.removeView(listview1); sl.addView(listview1); sl.setOnRefreshListener( new android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener() { @Override public void onRefresh() {  } } );");
		_Add(83, "Set Text Size", "//This code is use when you want to set text size in a project.\n\ntextview1.setTextSize((float)14);");
		_Add(84, "To Set Screen Size", "//To set Screen size in your project.\n\n DisplayMetrics dm = new DisplayMetrics(); getWindowManager().getDefaultDisplay().getMetrics(dm); int width = dm.widthPixels; int height = dm.heightPixels;");
		_Add(85, "Fab Hide", "//To set fab hide in a project.\n\n_fab.setVisibility(View.GONE);");
		_Add(86, "Fab Show", "// To set Show fab in project.\n\n_fab.setVisibility(View.VISIBLE);");
		_Add(87, "Chromometer", "Chronometer cho = new Chronometer(this); linear1.addView (cho); ");
		_Add(88, "Radio Button", "//To make radio button in a project.\n\n//Horizontal\n\nfinal RadioButton[] rb = new RadioButton[5];\nfinal RadioButton[] gg = new RadioButton[5];\n    RadioGroup rg = new RadioGroup(this); \n\n\n\n\n\n// Vertical\n\nfinal RadioButton[] rb = new RadioButton[5];\nfinal RadioButton[] gg = new RadioButton[5];\n    RadioGroup rg = new RadioGroup(this); \n");
		_Add(89, "Listview Text Color", "//To change or set listview text color in a project.\n\nfinal ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String> (this, android.R.layout.simple_list_item_1,listview1){ @Override public View getView(int position, View convertView, ViewGroup parent){ View view = super.getView(position, convertView, parent);TextView tv = (TextView) view.findViewById(android.R.id.text1); tv.setTextColor(Color.WHITE); return view; } }; listview1.setAdapter(arrayAdapter);");
		_Add(90, "Text Rotation", "//To create text rotation in a project use this codes belows.\n\nRotateAnimation rotateAnimation = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f); rotateAnimation.setInterpolator(new LinearInterpolator()); rotateAnimation.setDuration(3000); text.startAnimation(rotateAnimation);");
		_Add(91, "Webview - Support HTML", "//To set your webview project to support HTML 100percent.\n\nWebSettings webSettings = webview1.getSettings(); webSettings.setJavaScriptEnabled(true); webSettings.setJavaScriptCanOpenWindowsAutomatically(true); if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) { webSettings.setAllowFileAccessFromFileURLs(true); webSettings.setAllowUniversalAccessFromFileURLs(true); }");
		_Add(92, "Intent - Share Text", "//This code is use when you want share text in a project.\n\nIntent shareIntent = new Intent(Intent.ACTION_SEND); shareIntent.setType(\"text/plain\"); shareIntent.putExtra(Intent.EXTRA_TEXT, \"*Contents*\"); shareIntent.putExtra(Intent.EXTRA_SUBJECT, \"*title*\"); startActivity(Intent.createChooser(shareIntent, \"*Window name*\"));");
		_Add(93, "Textview - HTML formatting", "textview1.setText(Html.fromHtml(\"Your HTML Codes\"));");
		_Add(94, "Edittext IME option", "edittext1.setOnEditorActionListener(new EditText.OnEditorActionListener() { public boolean onEditorAction(TextView v, int actionId, KeyEvent event) { if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_GO) { button1.performClick(); return true; } return false; } });");
		_Add(95, "Video Thumbnail path", "filepath = \"path/to/video\";\n\n//Below code is for Small thumbnail\nBitmap bMap = ThumbnailUtils.createVideoThumbnail(filepath, android.provider.MediaStore.Video.Thumbnails.MICRO_KIND);\nimageview1.setImageBitmap(bMap);\n\n\n//Below code is for Medium thumbnail\nBitmap bMap = ThumbnailUtils.createVideoThumbnail(filepath, android.provider.MediaStore.Video.Thumbnails.MINI_KIND);\nimageview1.setImageBitmap(bMap);");
		_Add(96, "Draw Canvas in linear", "//paste this code in onCreate event\n\nDrawingView dv = new DrawingView(MainActivity.this);linear1.addView(dv); mPaint = new Paint(); mPaint.setAntiAlias(true); mPaint.setDither(true); mPaint.setColor(Color.BLACK); mPaint.setStyle(Paint.Style.STROKE); mPaint.setStrokeJoin(Paint.Join.ROUND); mPaint.setStrokeCap(Paint.Cap.ROUND); mPaint.setStrokeWidth(12); }\n\nDrawingView dv ; private Paint mPaint;\n\npublic class DrawingView extends View { public int width;\npublic int height;\nprivate Bitmap mBitmap;\nprivate Canvas mCanvas;\nprivate Path mPath;\nprivate Paint mBitmapPaint;\nContext context; private Paint circlePaint; private Path circlePath;\n\npublic DrawingView(Context c) { super(c); context=c; mPath = new Path(); mBitmapPaint = new Paint(Paint.DITHER_FLAG); circlePaint = new Paint(); circlePath = new Path(); circlePaint.setAntiAlias(true); circlePaint.setColor(Color.BLUE); circlePaint.setStyle(Paint.Style.STROKE); circlePaint.setStrokeJoin(Paint.Join.MITER); circlePaint.setStrokeWidth(4f); }\n\n@Override protected void onSizeChanged(int w, int h, int oldw, int oldh) { super.onSizeChanged(w, h, oldw, oldh); mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); mCanvas = new Canvas(mBitmap); }\n\n@Override protected void onDraw(Canvas canvas) { super.onDraw(canvas); canvas.drawBitmap( mBitmap, 0, 0, mBitmapPaint);\ncanvas.drawPath( mPath, mPaint); canvas.drawPath( circlePath, circlePaint); } private float mX, mY;\nprivate static final float TOUCH_TOLERANCE = 4;\nprivate void touch_start(float x, float y) { mPath.reset(); mPath.moveTo(x, y); mX = x; mY = y; }\n\nprivate void touch_move(float x, float y) { float dx = Math.abs(x - mX); float dy = Math.abs(y - mY); if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) { mPath.quadTo(mX, mY, (x + mX)/2, (y + mY)/2); mX = x; mY = y; circlePath.reset(); circlePath.addCircle(mX, mY, 30, Path.Direction.CW); } }\nprivate void touch_up() { mPath.lineTo(mX, mY); circlePath.reset();\nmCanvas.drawPath(mPath, mPaint);\nmPath.reset(); }\n\n@Override public boolean onTouchEvent(MotionEvent event) {\nfloat x = event.getX(); float y = event.getY();\nswitch (event.getAction()) {\ncase MotionEvent.ACTION_DOWN: touch_start(x, y); invalidate(); break;\ncase MotionEvent.ACTION_MOVE: touch_move(x, y); invalidate(); break;\ncase MotionEvent.ACTION_UP: touch_up(); invalidate(); break; } return true; }\n");
		_Add(97, "Password Validator", "//paste the below code in a moreblock nothing\n}\npublic boolean pwdValidator(String pwd) \n{\n\nfinal String allowedChars = \"^(?=.*[@$%&#_()=+?»«<>£§€{}\\\\[\\\\]-])(?=.*[A-Z])(?=.*[a-z])(?=.*\\\\d).*(?<=.{6,10})$\";\n//this code will check for special character, upper, lower case and a number\n//with minimum 6 and maximum 10\n    java.util.regex.Pattern pattern;\n    java.util.regex.Matcher matcher;\n   \n    pattern = java.util.regex.Pattern.compile(allowedChars);\n    matcher = pattern.matcher(pwd);\n    return matcher.matches();\n\n\n\n//onButton1 clicked\n//create a String variable pwd and set it to the password\nif (pwdValidator(pwd))\n{\n//code for successful validation\n}else{\n//code for error message\n}");
		_Add(98, "Email Validator", "//paste the below code in a moreblock nothing\n}\npublic boolean emailValidator(String email) \n{\n    java.util.regex.Pattern pattern;\n    java.util.regex.Matcher matcher;\n    final String EMAIL_PATTERN = \"^[_A-Za-z0-9-]+(\\\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\\\.[A-Za-z0-9]+)*(\\\\.[A-Za-z]{2,})$\";\n    pattern = java.util.regex.Pattern.compile(EMAIL_PATTERN);\n    matcher = pattern.matcher(email);\n    return matcher.matches();\n\n\n\n//onButton1 clicked\n//create a String variable email and set it to the email address\nif (emailValidator(email))\n{\n//code for successful validation\n}else{\n//code for error message\n}");
		_Add(99, "Gridview with custom view", "\n//code By Gymkhana Studio\n\n\n\n//Add OnCreate\n{\nHashMap<String, Object> _item = new HashMap<>();\n_item.put(\"name\", \"google\");\nlistmap.add(_item);\n}\n\n{\nHashMap<String, Object> _item = new HashMap<>();\n_item.put(\"name\", \"facebook\");\nlistmap.add(_item);\n}\n\n{\nHashMap<String, Object> _item = new HashMap<>();\n_item.put(\"name\", \"youtube\");\nlistmap.add(_item);\n}\n\nGridView grid = new GridView(this);\ngrid.setLayoutParams(new GridView.LayoutParams(GridLayout.LayoutParams.MATCH_PARENT, GridLayout.LayoutParams.WRAP_CONTENT));\ngrid.setBackgroundColor(Color.WHITE);\ngrid.setNumColumns(3);\ngrid.setColumnWidth(GridView.AUTO_FIT);\ngrid.setVerticalSpacing(5);\ngrid.setHorizontalSpacing(5);\ngrid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);\ngrid.setAdapter(new Listview1Adapter(listmap));\nlinear1.addView(grid);\n\n//click listener\ngrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {\n@Override\npublic void onItemClick(AdapterView parent, View view, int position, long id) {\nshowMessage(Integer.toString(position));\n}});\n\n\n}\nprivate String name = \"\";\nprivate ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();\npublic class Listview1Adapter extends BaseAdapter {\nArrayList<HashMap<String, Object>> _data;\npublic Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {\n_data = _arr;\n}\n\n@Override\npublic int getCount() {\nreturn _data.size();\n}\n\n@Override\npublic HashMap<String, Object> getItem(int _i) {\nreturn _data.get(_i);\n}\n\n@Override\npublic long getItemId(int _i) {\nreturn _i;\n}\n//method like in bindcustom view\n@Override\npublic View getView(final int _position, View _view, ViewGroup _viewGroup) {\nLayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);\nView _v = _view;\nif (_v == null) {\n_v = _inflater.inflate(R.layout.custom, null);\n}\n\nfinal ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);\nfinal TextView textview1 = (TextView) _v.findViewById(R.id.textview1);\n\nname = _data.get((int)_position).get(\"name\").toString();\ntextview1.setText(name);\n\nreturn _v;\n}");
		_Add(100, "Fade Activity transition", "overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);");
		_Add(101, "File Util Write File", "FileUtil.writeFile(FileUtil.getExternalStorageDir().concat(\"/file.txt\"), \"some value\");");
		_Add(102, "Listview Clear Text Filter", "listview1.clearTextFilter();");
		_Add(103, "Now Streaming", "final VideoView vd = new VideoView(WatchActivity.this);\nvd.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));\nlinear1.addView(vd);\nvd.setVideoURI(Uri.parse(s));\nvd.setMediaController(new MediaController(this));\nvd.requestFocus();\nvd.start();");
		_Add(104, "Open Url", "startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(\"https://site.ru\")));");
		_Add(105, "SeekBar Set Color", "seekbar1.getProgressDrawable().setColorFilter(Color.parseColor(\"#FF00FF\"), PorterDuff.Mode.SRC_IN); seekbar1.getThumb().setColorFilter(Color.parseColor(\"#FF00FF\"), PorterDuff.Mode.SRC_IN); \n\n//seekbar1 is your seekbar ID \n//#FF00FF is your RRGGBB color ");
	}
	
	
	private void _Ripple (final View _v) {
		int[] attrs = new int[]{android.R.attr.selectableItemBackgroundBorderless};
				android.content.res.TypedArray typedArray = this.obtainStyledAttributes(attrs);
				int backgroundResource = typedArray.getResourceId(0, 0);
				_v.setBackgroundResource(backgroundResource);
		
		_v.setClickable(true);
	}
	
	
	private void _circleRipple (final String _color, final View _v) {
		android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor(_color)});
		android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , null, null);
		_v.setBackground(ripdrb);
	}
	
	
	private void _saerch_list (final String _charSeq) {
		temp_listmap1 = new Gson().fromJson(search, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		length = temp_listmap1.size();
		n = length - 1;
		for(int _repeat17 = 0; _repeat17 < (int)(length); _repeat17++) {
			hmin = temp_listmap1.get((int)n).get("my_app_name").toString();
			if (!(_charSeq.length() > hmin.length()) && hmin.toLowerCase().contains(_charSeq.toLowerCase())) {
				
			}
			else {
				temp_listmap1.remove((int)(n));
			}
			n--;
		}
		listview1.setAdapter(new Listview1Adapter(temp_listmap1));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	
	private void _search_bar1 () {
		temp_listmap1 = new Gson().fromJson(search, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		length = temp_listmap1.size();
		n = length - 1;
		for(int _repeat17 = 0; _repeat17 < (int)(length); _repeat17++) {
			hmin = temp_listmap1.get((int)n).get("my_app_name").toString();
			if (!("".length() > hmin.length()) && hmin.toLowerCase().contains("".toLowerCase())) {
				
			}
			else {
				temp_listmap1.remove((int)(n));
			}
			n--;
		}
		listview1.setAdapter(new Listview1Adapter(temp_listmap1));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.cus, null);
			}
			
			final LinearLayout back = (LinearLayout) _v.findViewById(R.id.back);
			final LinearLayout clickl = (LinearLayout) _v.findViewById(R.id.clickl);
			final LinearLayout line_show = (LinearLayout) _v.findViewById(R.id.line_show);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final LinearLayout linear3 = (LinearLayout) _v.findViewById(R.id.linear3);
			final LinearLayout linear10 = (LinearLayout) _v.findViewById(R.id.linear10);
			final ImageView i = (ImageView) _v.findViewById(R.id.i);
			final TextView t = (TextView) _v.findViewById(R.id.t);
			final TextView p = (TextView) _v.findViewById(R.id.p);
			final ImageView dropdown = (ImageView) _v.findViewById(R.id.dropdown);
			final LinearLayout backup_btn = (LinearLayout) _v.findViewById(R.id.backup_btn);
			final LinearLayout restore_btn = (LinearLayout) _v.findViewById(R.id.restore_btn);
			final LinearLayout info_btn = (LinearLayout) _v.findViewById(R.id.info_btn);
			final ImageView imageview3 = (ImageView) _v.findViewById(R.id.imageview3);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final ImageView imageview2 = (ImageView) _v.findViewById(R.id.imageview2);
			final TextView textview2 = (TextView) _v.findViewById(R.id.textview2);
			final ImageView imageview4 = (ImageView) _v.findViewById(R.id.imageview4);
			final TextView textview3 = (TextView) _v.findViewById(R.id.textview3);
			
			android.graphics.drawable.GradientDrawable BACK = new android.graphics.drawable.GradientDrawable();
			BACK.setColor(Color.parseColor("#EEEEEE"));
			BACK.setCornerRadii(new float[]{ (float) 25,(float) 25,(float) 25,(float) 25,(float) 25,(float) 25,(float) 25,(float) 25 });
			BACK.setStroke((int) 1, Color.parseColor("#EEEEEE"));
			back.setElevation((float) 10);
			back.setBackground(BACK);
			//SEM Tech Hub ™
			android.graphics.drawable.GradientDrawable LINESHOW = new android.graphics.drawable.GradientDrawable();
			LINESHOW.setColor(Color.parseColor("#EEEEEE"));
			LINESHOW.setCornerRadii(new float[]{ (float) 0,(float) 0,(float) 0,(float) 0,(float) 25,(float) 25,(float) 25,(float) 25 });
			LINESHOW.setStroke((int) 0, Color.parseColor("#EEEEEE"));
			line_show.setElevation((float) 0);
			line_show.setBackground(LINESHOW);
			//SEM Tech Hub ™
			Sketchware = FileUtil.getExternalStorageDir().concat("/.sketchware/");
						_Elevation(back, 5);
						_click_effect(clickl, "#F5F5F5");
						if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/").concat(Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment()).concat("/icon.png"))) {
								i.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/").concat(Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment()).concat("/icon.png"), 1024, 1024));
						}
						else {
								i.setImageResource(R.drawable.android_icon);
						}
						if (FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/").concat(Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment().concat("/app/build.gradle"))).equals("")) {
								p.setText("No Package");
						}
						else {
								buildGradle = FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/").concat(Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment().concat("/app/build.gradle")));
								name = buildGradle.substring((int)(buildGradle.indexOf("applicationId")), (int)(buildGradle.indexOf("minSdkVersion")));
								name = name.replace("applicationId \"", "");
								name = name.replace("\"", "");
								p.setText(name);
						}
						t.setText(project_name.get((int)((project_name.size() - _position) - 1)));
						clickl.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										if (line_show.isEnabled()) {
												line_show.setVisibility(View.GONE);
												dropdown.setImageResource(R.drawable.ic_expand_more_grey);
												line_show.setEnabled(false);
										}
										else {
												line_show.setVisibility(View.VISIBLE);
												dropdown.setImageResource(R.drawable.ic_expand_less_grey);
												line_show.setEnabled(true);
										}
								}
						});
						line_show.setVisibility(View.GONE);
						dropdown.setImageResource(R.drawable.ic_expand_more_grey);
						line_show.setEnabled(false);
						_click_effect(backup_btn, "#F5F5F5");
						_click_effect(restore_btn, "#F5F5F5");
						_click_effect(info_btn, "#F5F5F5");
						backup_btn.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										sharedata.edit().putString("id", Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment()).commit();
								}
						});
						restore_btn.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										sharedata.edit().putString("idzip", Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment()).commit();
										startActivityForResult(zipf, REQ_CD_ZIPF);
								}
						});
						info_btn.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
					Toast.makeText(MainActivity.this, "Made By SEM Tech Hub ™", Toast.LENGTH_SHORT).show();
										d.setTitle("Project Information");
										d.setMessage("Project ID :- ".concat(liststring.get((int)((liststring.size() - _position) - 1))));
										d.setPositiveButton("OKAY", new DialogInterface.OnClickListener() {
												@Override
												public void onClick(DialogInterface _dialog, int _which) {
														
												}
										});
										d.create().show();
								}
						});
			_RippleEffects("Grey", dropdown);
			_RippleEffects("Grey", imageview3);
			_RippleEffects("Grey", imageview2);
			_RippleEffects("Grey", imageview4);
			
			return _v;
		}
	}
	
	public class Listview2Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.ctm, null);
			}
			
			final LinearLayout back = (LinearLayout) _v.findViewById(R.id.back);
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			
			android.graphics.drawable.GradientDrawable BACK = new android.graphics.drawable.GradientDrawable();
			BACK.setColor(Color.parseColor("#EEEEEE"));
			BACK.setCornerRadii(new float[]{ (float) 25,(float) 25,(float) 25,(float) 25,(float) 25,(float) 25,(float) 25,(float) 25 });
			BACK.setStroke((int) 1, Color.parseColor("#EEEEEE"));
			back.setElevation((float) 6);
			back.setBackground(BACK);
			//SEM Tech Hub ™
			textview1.setText(listmap.get((int)_position).get("ctm").toString());
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
