package sem.tech.hubb;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.View;
import android.content.ClipData;
import android.content.ClipboardManager;

public class OpenActivity extends AppCompatActivity {
	
	
	private LinearLayout main;
	private ScrollView vscroll1;
	private LinearLayout linear29;
	private LinearLayout back;
	private TextView title;
	private LinearLayout copyy;
	private ImageView back_a;
	private ImageView copyy_a;
	private LinearLayout linear3;
	private TextView code_title;
	private TextView textview2;
	private TextView textview1;
	private TextView textview14;
	private TextView textview15;
	
	private Intent go = new Intent();
	private ObjectAnimator animation = new ObjectAnimator();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.open);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		main = (LinearLayout) findViewById(R.id.main);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear29 = (LinearLayout) findViewById(R.id.linear29);
		back = (LinearLayout) findViewById(R.id.back);
		title = (TextView) findViewById(R.id.title);
		copyy = (LinearLayout) findViewById(R.id.copyy);
		back_a = (ImageView) findViewById(R.id.back_a);
		copyy_a = (ImageView) findViewById(R.id.copyy_a);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		code_title = (TextView) findViewById(R.id.code_title);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview14 = (TextView) findViewById(R.id.textview14);
		textview15 = (TextView) findViewById(R.id.textview15);
		
		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				go.setClass(getApplicationContext(), MainActivity.class);
				startActivity(go);
				finish();
			}
		});
		
		copyy.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				animation.setTarget(copyy_a);
				animation.setPropertyName("alpha");
				animation.setFloatValues((float)(0), (float)(1));
				animation.setDuration((int)(3000));
				animation.setInterpolator(new LinearInterpolator());
				animation.start();
				_copy();
			}
		});
	}
	private void initializeLogic() {
		vscroll1.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		android.graphics.drawable.GradientDrawable CRNOH = new android.graphics.drawable.GradientDrawable();
		CRNOH.setColor(Color.parseColor("#ffffff"));
		CRNOH.setCornerRadii(new float[]{ (float) 0,(float) 0,(float) 0,(float) 0,(float) 0,(float) 0,(float) 0,(float) 0 });
		CRNOH.setStroke((int) 0, Color.parseColor("#000000"));
		main.setElevation((float) 10);
		main.setBackground(CRNOH);
		//Milz
		DisplayMetrics dm = new DisplayMetrics(); getWindowManager().getDefaultDisplay().getMetrics(dm); int width = dm.widthPixels; int height = dm.heightPixels;
		textview1.setTextIsSelectable(true);
		textview1.setText(getIntent().getStringExtra("B"));
		code_title.setText(getIntent().getStringExtra("A"));
		_circleRipple("Grey", copyy_a);
		_circleRipple("Grey", back_a);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		go.setClass(getApplicationContext(), MainActivity.class);
		startActivity(go);
		finish();
	}
	private void _copy () {
		((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview1.getText().toString()));
		com.google.android.material.snackbar.Snackbar sb = com.google.android.material.snackbar.Snackbar.make(linear3, "Copied to Clipboard !!!", com.google.android.material.snackbar.Snackbar.LENGTH_LONG); sb.show();
	}
	
	
	private void _circleRipple (final String _color, final View _v) {
		android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor(_color)});
		android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , null, null);
		_v.setBackground(ripdrb);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
