package com.my.newproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.ClipData;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Continuation;
import java.io.File;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.AdapterView;
import com.bumptech.glide.Glide;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class ChatActivity extends AppCompatActivity {
	
	public final int REQ_CD_PICK = 101;
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private FloatingActionButton _fab;
	private double attach = 0;
	private HashMap<String, Object> map = new HashMap<>();
	private String path = "";
	
	private ArrayList<HashMap<String, Object>> chatmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> onlinemap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> statusmap = new ArrayList<>();
	private ArrayList<String> crn = new ArrayList<>();
	private ArrayList<String> catup = new ArrayList<>();
	private ArrayList<String> statup = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout chat_list;
	private LinearLayout status_list;
	private LinearLayout online_list;
	private LinearLayout chat_holder;
	private LinearLayout status_holder;
	private LinearLayout online_holder;
	private LinearLayout chat;
	private ImageView imageview1;
	private TextView textview1;
	private LinearLayout status;
	private ImageView imageview2;
	private TextView textview2;
	private LinearLayout linear3;
	private ImageView imageview3;
	private TextView textview3;
	private ListView listview1;
	private LinearLayout linear6;
	private LinearLayout send_holder;
	private LinearLayout linear5;
	private LinearLayout linear7;
	private EditText edittext1;
	private ImageView imageview5;
	private ImageView send;
	private ListView listview2;
	private ListView listview3;
	
	private Intent go = new Intent();
	private AlertDialog.Builder d;
	private DatabaseReference chat_group = _firebase.getReference("chat_group");
	private ChildEventListener _chat_group_child_listener;
	private Calendar ca = Calendar.getInstance();
	private SharedPreferences name;
	private Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
	private DatabaseReference online = _firebase.getReference("online");
	private ChildEventListener _online_child_listener;
	private DatabaseReference stat = _firebase.getReference("stat");
	private ChildEventListener _stat_child_listener;
	private StorageReference today = _firebase_storage.getReference("today");
	private OnCompleteListener<Uri> _today_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _today_download_success_listener;
	private OnSuccessListener _today_delete_success_listener;
	private OnProgressListener _today_upload_progress_listener;
	private OnProgressListener _today_download_progress_listener;
	private OnFailureListener _today_failure_listener;
	private SharedPreferences animation;
	private SharedPreferences image;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.chat);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_fab = (FloatingActionButton) findViewById(R.id._fab);
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		chat_list = (LinearLayout) findViewById(R.id.chat_list);
		status_list = (LinearLayout) findViewById(R.id.status_list);
		online_list = (LinearLayout) findViewById(R.id.online_list);
		chat_holder = (LinearLayout) findViewById(R.id.chat_holder);
		status_holder = (LinearLayout) findViewById(R.id.status_holder);
		online_holder = (LinearLayout) findViewById(R.id.online_holder);
		chat = (LinearLayout) findViewById(R.id.chat);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		status = (LinearLayout) findViewById(R.id.status);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview3 = (TextView) findViewById(R.id.textview3);
		listview1 = (ListView) findViewById(R.id.listview1);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		send_holder = (LinearLayout) findViewById(R.id.send_holder);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		send = (ImageView) findViewById(R.id.send);
		listview2 = (ListView) findViewById(R.id.listview2);
		listview3 = (ListView) findViewById(R.id.listview3);
		d = new AlertDialog.Builder(this);
		name = getSharedPreferences("name", Activity.MODE_PRIVATE);
		pick.setType("image/*");
		pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		animation = getSharedPreferences("animation", Activity.MODE_PRIVATE);
		image = getSharedPreferences("image", Activity.MODE_PRIVATE);
		
		chat_holder.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				chat_list.setVisibility(View.VISIBLE);
				status_list.setVisibility(View.GONE);
				online_list.setVisibility(View.GONE);
				chat_holder.setBackgroundColor(0xFF3F51B5);
				online_holder.setBackgroundColor(0xFFFFFFFF);
				status_holder.setBackgroundColor(0xFFFFFFFF);
				_fab.hide(); //hide
			}
		});
		
		status_holder.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				chat_list.setVisibility(View.GONE);
				status_list.setVisibility(View.VISIBLE);
				online_list.setVisibility(View.GONE);
				chat_holder.setBackgroundColor(0xFFFFFFFF);
				online_holder.setBackgroundColor(0xFFFFFFFF);
				status_holder.setBackgroundColor(0xFF3F51B5);
				_fab.show(); //show
				_hideKeyboard(chat_holder);
			}
		});
		
		online_holder.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				chat_list.setVisibility(View.GONE);
				status_list.setVisibility(View.GONE);
				online_list.setVisibility(View.VISIBLE);
				chat_holder.setBackgroundColor(0xFFFFFFFF);
				online_holder.setBackgroundColor(0xFF3F51B5);
				status_holder.setBackgroundColor(0xFFFFFFFF);
				_fab.hide(); //hide
				_hideKeyboard(linear6);
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (name.getString("name", "").equals(chatmap.get((int)_position).get("name").toString())) {
					d.setMessage("Delete message?");
					d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							chat_group.child(catup.get((int)(_position))).removeValue();
							chatmap.remove((int)(_position));
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						}
					});
					d.setNegativeButton("No", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					d.create().show();
				}
				else {
					
				}
				return true;
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (edittext1.getText().toString().length() > 0) {
					send.setVisibility(View.VISIBLE);
				}
				else {
					send.setVisibility(View.GONE);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		send.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().length() > 0) {
					if (attach > 0) {
						
					}
					else {
						ca = Calendar.getInstance();
						map = new HashMap<>();
						map.put("message", edittext1.getText().toString());
						map.put("name", name.getString("name", ""));
						map.put("date", new SimpleDateFormat("HH:mm dd-MM-yy").format(ca.getTime()));
						chat_group.push().updateChildren(map);
						map.clear();
						edittext1.setText("");
					}
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Enter message");
				}
			}
		});
		
		listview2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				image.edit().putString("image", statusmap.get((int)_position).get("url").toString()).commit();
				go.setClass(getApplicationContext(), FullviewActivity.class);
				startActivity(go);
			}
		});
		
		listview2.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (name.getString("name", "").equals(statusmap.get((int)_position).get("name").toString())) {
					d.setMessage("Delete status?");
					d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							statusmap.remove((int)(_position));
							_firebase_storage.getReferenceFromUrl(statusmap.get((int)_position).get("url").toString()).delete().addOnSuccessListener(_today_delete_success_listener).addOnFailureListener(_today_failure_listener);
							stat.child(statup.get((int)(_position))).removeValue();
							((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
						}
					});
					d.setNegativeButton("No", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					d.create().show();
				}
				else {
					
				}
				return true;
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(pick, REQ_CD_PICK);
			}
		});
		
		_chat_group_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				chat_group.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						chatmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								chatmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						catup.add(_childKey);
						listview1.setAdapter(new Listview1Adapter(chatmap));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				chat_group.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						chatmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								chatmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						catup.add(_childKey);
						listview1.setAdapter(new Listview1Adapter(chatmap));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		chat_group.addChildEventListener(_chat_group_child_listener);
		
		_online_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				online.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						onlinemap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								onlinemap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listview3.setAdapter(new Listview3Adapter(onlinemap));
						((BaseAdapter)listview3.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				online.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						onlinemap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								onlinemap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listview3.setAdapter(new Listview3Adapter(onlinemap));
						((BaseAdapter)listview3.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		online.addChildEventListener(_online_child_listener);
		
		_stat_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				stat.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						statusmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								statusmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						statup.add(_childKey);
						listview2.setAdapter(new Listview2Adapter(statusmap));
						((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				stat.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						statusmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								statusmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						statup.add(_childKey);
						listview2.setAdapter(new Listview2Adapter(statusmap));
						((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				stat.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						statusmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								statusmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listview2.setAdapter(new Listview2Adapter(statusmap));
						((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		stat.addChildEventListener(_stat_child_listener);
		
		_today_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_today_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_today_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				map = new HashMap<>();
				map.put("url", _downloadUrl);
				map.put("name", name.getString("name", ""));
				stat.push().updateChildren(map);
				map.clear();
				SketchwareUtil.showMessage(getApplicationContext(), "Status updated");
			}
		};
		
		_today_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_today_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				stat.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						statusmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								statusmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listview1.setAdapter(new Listview1Adapter(statusmap));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
		};
		
		_today_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
	}
	private void initializeLogic() {
		_Shadow(chat_holder, 4);
		_Shadow(status_holder, 4);
		_Shadow(linear1, 4);
		_Capitalize_(edittext1);
		status_holder.setBackgroundColor(0xFFFFFFFF);
		online_holder.setBackgroundColor(0xFFFFFFFF);
		status_list.setVisibility(View.GONE);
		online_list.setVisibility(View.GONE);
		send.setVisibility(View.GONE);
		listview1.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
		listview1.setStackFromBottom(true);
		android.graphics.drawable.GradientDrawable CRNJY = new android.graphics.drawable.GradientDrawable();
		CRNJY.setColor(Color.parseColor("#ffffff"));
		CRNJY.setCornerRadii(new float[]{ (float) 360,(float) 360,(float) 360,(float) 360,(float) 360,(float) 360,(float) 360,(float) 360 });
		CRNJY.setStroke((int) 0, Color.parseColor("#000000"));
		send_holder.setElevation((float) 3);
		send_holder.setBackground(CRNJY);
		//Milz
		android.graphics.drawable.GradientDrawable CRNKP = new android.graphics.drawable.GradientDrawable();
		CRNKP.setColor(Color.parseColor("#ffffff"));
		CRNKP.setCornerRadii(new float[]{ (float) 360,(float) 360,(float) 360,(float) 360,(float) 360,(float) 360,(float) 360,(float) 360 });
		CRNKP.setStroke((int) 0, Color.parseColor("#000000"));
		linear5.setElevation((float) 5);
		linear5.setBackground(CRNKP);
		//Milz
		_fab.hide(); //hide
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_PICK:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				path = _filePath.get((int)(0));
				if (path.endsWith(".png") || path.endsWith(".jpg")) {
					today.child(Uri.parse(path).getLastPathSegment()).putFile(Uri.fromFile(new File(path))).addOnFailureListener(_today_failure_listener).addOnProgressListener(_today_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
						@Override
						public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
							return today.child(Uri.parse(path).getLastPathSegment()).getDownloadUrl();
						}}).addOnCompleteListener(_today_upload_success_listener);
					SketchwareUtil.showMessage(getApplicationContext(), "Uploading status");
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Only jpg and png format allowed");
				}
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		d.setMessage("Exit application?");
		d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finishAffinity();
			}
		});
		d.setNegativeButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		d.create().show();
	}
	private void _Shadow (final View _v, final double _n) {
		_v.setElevation((float)_n);
	}
	
	
	private void _Capitalize_ (final TextView _This) {
		_This.setRawInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
	}
	
	
	private void _hideKeyboard (final View _view) {
		if(_view.requestFocus()){
			android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(_view.getWindowToken(),0);
		}
	}
	
	
	private void _Round (final double _one, final double _two, final double _three, final double _four, final String _color, final View _view) {
		Double left_top = _one;
		Double right_top = _two;
		Double left_bottom = _three;
		Double right_bottom = _four;
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable();
		s.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		s.setCornerRadii(new float[] {left_top.floatValue(),left_top.floatValue(), right_top.floatValue(),right_top.floatValue(), left_bottom.floatValue(),left_bottom.floatValue(), right_bottom.floatValue(),right_bottom.floatValue()});
		s.setColor(Color.parseColor(_color));
		_view.setBackground(s);
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.chatroom, null);
			}
			
			final LinearLayout main = (LinearLayout) _v.findViewById(R.id.main);
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final TextView textview2 = (TextView) _v.findViewById(R.id.textview2);
			final TextView textview3 = (TextView) _v.findViewById(R.id.textview3);
			
			textview1.setText(chatmap.get((int)_position).get("name").toString());
			textview2.setText(chatmap.get((int)_position).get("message").toString());
			textview3.setText(chatmap.get((int)_position).get("date").toString());
			textview3.setTextSize((float)6);
			if (textview1.getText().toString().equals(name.getString("name", ""))) {
				_Shadow(linear1, 4);
				_Round(20, 20, 20, 20, "#ffffff", linear1);
				main.setGravity(Gravity.LEFT);
			}
			else {
				_Shadow(linear1, 4);
				_Round(20, 20, 20, 20, "#c5cae9", linear1);
				main.setGravity(Gravity.RIGHT);
			}
			
			return _v;
		}
	}
	
	public class Listview2Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.state, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			
			Glide.with(getApplicationContext()).load(Uri.parse(statusmap.get((int)_position).get("url").toString())).into(imageview1);
			textview1.setText(statusmap.get((int)_position).get("name").toString());
			
			return _v;
		}
	}
	
	public class Listview3Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview3Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.online, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			
			textview1.setText(onlinemap.get((int)_position).get("name").toString());
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
