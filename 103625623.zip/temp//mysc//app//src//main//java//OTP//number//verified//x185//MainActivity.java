package OTP.number.verified.x185;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.support.v7.app.AppCompatActivity;
import java.util.HashMap;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import java.util.Timer;
import java.util.TimerTask;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import android.support.v4.content.ContextCompat;
import android.support.v4.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String fontName = "";
	private String typeace = "";
	private String phoneNumber = "";
	private String otp = "";
	private HashMap<String, Object> UN_Map_var = new HashMap<>();
	private HashMap<String, Object> UN_API = new HashMap<>();
	private HashMap<String, Object> UN_CurrentVersion = new HashMap<>();
	private String verificationCode = "";
	private double number = 0;
	private HashMap<String, Object> map = new HashMap<>();
	
	private ScrollView linear1;
	private LinearLayout linear4;
	private LinearLayout login;
	private LinearLayout verification;
	private LinearLayout linear2;
	private ImageView imageview3;
	private TextView textview2;
	private LinearLayout linear7;
	private Button button1;
	private ProgressBar progressbar1;
	private TextView textview1;
	private ImageView imageview1;
	private TextView textview11;
	private EditText edittext1;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private ImageView imageview4;
	private TextView textview5;
	private LinearLayout linear10;
	private Button button2;
	private ProgressBar progressbar2;
	private LinearLayout linear11;
	private ImageView imageview5;
	private TextView textview7;
	private EditText edittext2;
	private TextView textview8;
	private TextView textview10;
	private TextView textview9;
	
	private Intent i = new Intent();
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private TimerTask t;
	private RequestNetwork ip;
	private RequestNetwork.RequestListener _ip_request_listener;
	private AlertDialog.Builder dialog;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (ScrollView) findViewById(R.id.linear1);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		login = (LinearLayout) findViewById(R.id.login);
		verification = (LinearLayout) findViewById(R.id.verification);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		button1 = (Button) findViewById(R.id.button1);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		textview1 = (TextView) findViewById(R.id.textview1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview11 = (TextView) findViewById(R.id.textview11);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		button2 = (Button) findViewById(R.id.button2);
		progressbar2 = (ProgressBar) findViewById(R.id.progressbar2);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview7 = (TextView) findViewById(R.id.textview7);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		textview8 = (TextView) findViewById(R.id.textview8);
		textview10 = (TextView) findViewById(R.id.textview10);
		textview9 = (TextView) findViewById(R.id.textview9);
		auth = FirebaseAuth.getInstance();
		ip = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		
		login.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().trim().equals("")) {
					
				}
				else {
					dialog.setMessage("Please confirm your phone number : ".concat(phoneNumber));
					dialog.setPositiveButton("confirm", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							button1.setVisibility(View.GONE);
							progressbar1.setVisibility(View.VISIBLE);
							phoneNumber = textview11.getText().toString().concat(edittext1.getText().toString());
							
							 
							com.google.firebase.auth.PhoneAuthProvider.getInstance().verifyPhoneNumber(
							                phoneNumber,   
							                (long)60, java.util.concurrent.TimeUnit.SECONDS, 
							MainActivity.this,
							              mCallback
							    
							);
						}
					});
					dialog.setNegativeButton("Edit", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dialog.create().show();
				}
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.trim().equals("")) {
					_Shadow(3, 8, "#E0E0E0", button1);
					button1.setTextColor(0xFF000000);
				}
				else {
					_Shadow(3, 8, "#2196F3", button1);
					button1.setTextColor(0xFFFFFFFF);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext2.getText().toString().trim().equals("")) {
					
				}
				else {
					button2.setVisibility(View.GONE);
					progressbar2.setVisibility(View.VISIBLE);
					otp = edittext2.getText().toString();
					com.google.firebase.auth.PhoneAuthCredential credential = com.google.firebase.auth.PhoneAuthProvider.getCredential(verificationCode, otp);
					auth.signInWithCredential(credential).addOnCompleteListener(MainActivity.this, _auth_sign_in_listener);
				}
				
				
			}
		});
		
		imageview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				login.setVisibility(View.VISIBLE);
				verification.setVisibility(View.GONE);
			}
		});
		
		edittext2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.trim().equals("")) {
					_Shadow(3, 8, "#E0E0E0", button2);
					button2.setTextColor(0xFF000000);
				}
				else {
					_Shadow(3, 8, "#2196F3", button2);
					button2.setTextColor(0xFFFFFFFF);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		textview8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!(Double.parseDouble(textview9.getText().toString()) == 0)) {
					SketchwareUtil.showMessage(getApplicationContext(), "Please wait 60 seconds");
				}
				else {
					
					 
					com.google.firebase.auth.PhoneAuthProvider.getInstance().verifyPhoneNumber(
					                phoneNumber,   
					                (long)60, java.util.concurrent.TimeUnit.SECONDS, 
					MainActivity.this,
					              mCallback
					    
					);
					textview9.setText("60");
				}
			}
		});
		
		_ip_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				textview11.setText(_response);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					i.setClass(getApplicationContext(), ProfileActivity.class);
					startActivity(i);
					finish();
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					i.setClass(getApplicationContext(), ProfileActivity.class);
					startActivity(i);
					finish();
				}
				else {
					button2.setVisibility(View.VISIBLE);
					progressbar2.setVisibility(View.GONE);
					SketchwareUtil.showMessage(getApplicationContext(), "Verification code invalid!");
				}
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		linear1.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		
		_gd(linear7, "#EEEEEE", "#E0E0E0", 8);
		_gd(linear10, "#EEEEEE", "#E0E0E0", 8);
		_Shadow(3, 8, "#E0E0E0", button1);
		button1.setTextColor(0xFF000000);
		_Shadow(3, 8, "#E0E0E0", button2);
		button2.setTextColor(0xFF000000);
		progressbar1.setVisibility(View.GONE);
		progressbar2.setVisibility(View.GONE);
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
			i.setClass(getApplicationContext(), HomeActivity.class);
			startActivity(i);
			finish();
		}
		_removeScollBar(linear1);
		ip.startRequestNetwork(RequestNetworkController.GET, "https://ipapi.co/country_calling_code", "Calling_Code", _ip_request_listener);
		_LengthOfEditText(edittext2, 6);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _Shadow (final double _sadw, final double _cru, final String _wc, final View _widgets) {
		android.graphics.drawable.GradientDrawable wd = new android.graphics.drawable.GradientDrawable();
		wd.setColor(Color.parseColor(_wc));
		wd.setCornerRadius((int)_cru);
		_widgets.setElevation((int)_sadw);
		_widgets.setBackground(wd);
	}
	
	
	private void _gd (final View _view, final String _c, final String _sc, final double _r) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		
		gd.setColor(Color.parseColor(_c));
		gd.setCornerRadius((float)_r);
		gd.setStroke(2, Color.parseColor(_sc));
		
		_view.setBackground(gd);
	}
	
	
	private void _StartFirebaseLogin () {
	}
	com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallback = new com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
		        
		        @Override
		        public void onVerificationCompleted(com.google.firebase.auth.PhoneAuthCredential phoneAuthCredential) {
			            Toast.makeText(MainActivity.this,"Code Received",Toast.LENGTH_SHORT).show();
			        }
		
		        @Override
		        public void onVerificationFailed(com.google.firebase.FirebaseException e) {
			            Toast.makeText(MainActivity.this,"verification fialed",Toast.LENGTH_SHORT).show();
			button1.setVisibility(View.VISIBLE);		progressbar1.setVisibility(View.GONE);
			        }
		
		        @Override
		        public void onCodeSent(String s, com.google.firebase.auth.PhoneAuthProvider.ForceResendingToken forceResendingToken) {
			            super.onCodeSent(s, forceResendingToken);
			            verificationCode = s;
			            
			login.setVisibility(View.GONE);
			verification.setVisibility(View.VISIBLE);
			button1.setVisibility(View.VISIBLE);
			progressbar1.setVisibility(View.GONE);
			number = Double.parseDouble(textview9.getText().toString());
			textview9.setText(String.valueOf((long)(number)));
			t = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							number--;
							textview9.setText(String.valueOf((long)(number)));
							if (number == 0) {
								textview9.setText("00");
								t.cancel();
							}
						}
					});
				}
			};
			_timer.scheduleAtFixedRate(t, (int)(0), (int)(1000));
			Toast.makeText(MainActivity.this,"Code sent",Toast.LENGTH_SHORT).show();
			        }
		    };
	{
	}
	
	
	private void _removeScollBar (final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	private void _LengthOfEditText (final TextView _editText, final double _value_character) {
		InputFilter[] gb = _editText.getFilters(); InputFilter[] newFilters = new InputFilter[gb.length + 1]; System.arraycopy(gb, 0, newFilters, 0, gb.length); newFilters[gb.length] = new InputFilter.LengthFilter((int)_value_character); _editText.setFilters(newFilters);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
