package com.store.kimo.Android1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.widget.LinearLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.app.Activity;
import android.content.SharedPreferences;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.app.AlertDialog;
import android.content.DialogInterface;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Continuation;
import java.io.File;
import android.widget.AdapterView;
import android.view.View;
import com.bumptech.glide.Glide;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class HomeActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private DrawerLayout _drawer;
	
	private ArrayList<HashMap<String, Object>> map = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear3;
	private ListView listview1;
	private AdView adview1;
	private ImageView imageview1;
	private TextView textview1;
	private LinearLayout linear2;
	private TextView v0;
	private TextView textview2;
	private TextView textview3;
	private ProgressBar progressbar1;
	private LinearLayout _drawer_linear3;
	private ScrollView _drawer_vscroll1;
	private ImageView _drawer_imageview3;
	private TextView _drawer_textview3;
	private TextView _drawer_textview4;
	private LinearLayout _drawer_linear5;
	private LinearLayout _drawer_linear1_home;
	private LinearLayout _drawer_linear2_upload;
	private LinearLayout _drawer_linear6_editprof;
	private LinearLayout _drawer_linear4_about;
	private LinearLayout _drawer_linear6;
	private ImageView _drawer_imageview1_home;
	private TextView _drawer_textview2_home;
	private ImageView _drawer_imageview2_upload;
	private TextView _drawer_textview1_upload;
	private ImageView _drawer_imageview4_editprof;
	private TextView _drawer_textview5_editprof;
	private ImageView _drawer_imageview4_about;
	private TextView _drawer_textview5_about;
	private ImageView _drawer_imageview4;
	private TextView _drawer_textview5;
	
	private SharedPreferences name;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private SharedPreferences profile;
	private Intent logcheck = new Intent();
	private DatabaseReference fb = _firebase.getReference("fb");
	private ChildEventListener _fb_child_listener;
	private Intent upload = new Intent();
	private Intent editin = new Intent();
	private Intent pu = new Intent();
	private AlertDialog.Builder d_delete;
	private AlertDialog.Builder exit_d;
	private AlertDialog.Builder di_about;
	private Intent h = new Intent();
	private Intent contact_in = new Intent();
	private StorageReference fbsgupapp = _firebase_storage.getReference("fbsgupapp");
	private OnCompleteListener<Uri> _fbsgupapp_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fbsgupapp_download_success_listener;
	private OnSuccessListener _fbsgupapp_delete_success_listener;
	private OnProgressListener _fbsgupapp_upload_progress_listener;
	private OnProgressListener _fbsgupapp_download_progress_listener;
	private OnFailureListener _fbsgupapp_failure_listener;
	private RequestNetwork check_re;
	private RequestNetwork.RequestListener _check_re_request_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = (DrawerLayout) findViewById(R.id._drawer);ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(HomeActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view);
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		listview1 = (ListView) findViewById(R.id.listview1);
		adview1 = (AdView) findViewById(R.id.adview1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		v0 = (TextView) findViewById(R.id.v0);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		_drawer_linear3 = (LinearLayout) _nav_view.findViewById(R.id.linear3);
		_drawer_vscroll1 = (ScrollView) _nav_view.findViewById(R.id.vscroll1);
		_drawer_imageview3 = (ImageView) _nav_view.findViewById(R.id.imageview3);
		_drawer_textview3 = (TextView) _nav_view.findViewById(R.id.textview3);
		_drawer_textview4 = (TextView) _nav_view.findViewById(R.id.textview4);
		_drawer_linear5 = (LinearLayout) _nav_view.findViewById(R.id.linear5);
		_drawer_linear1_home = (LinearLayout) _nav_view.findViewById(R.id.linear1_home);
		_drawer_linear2_upload = (LinearLayout) _nav_view.findViewById(R.id.linear2_upload);
		_drawer_linear6_editprof = (LinearLayout) _nav_view.findViewById(R.id.linear6_editprof);
		_drawer_linear4_about = (LinearLayout) _nav_view.findViewById(R.id.linear4_about);
		_drawer_linear6 = (LinearLayout) _nav_view.findViewById(R.id.linear6);
		_drawer_imageview1_home = (ImageView) _nav_view.findViewById(R.id.imageview1_home);
		_drawer_textview2_home = (TextView) _nav_view.findViewById(R.id.textview2_home);
		_drawer_imageview2_upload = (ImageView) _nav_view.findViewById(R.id.imageview2_upload);
		_drawer_textview1_upload = (TextView) _nav_view.findViewById(R.id.textview1_upload);
		_drawer_imageview4_editprof = (ImageView) _nav_view.findViewById(R.id.imageview4_editprof);
		_drawer_textview5_editprof = (TextView) _nav_view.findViewById(R.id.textview5_editprof);
		_drawer_imageview4_about = (ImageView) _nav_view.findViewById(R.id.imageview4_about);
		_drawer_textview5_about = (TextView) _nav_view.findViewById(R.id.textview5_about);
		_drawer_imageview4 = (ImageView) _nav_view.findViewById(R.id.imageview4);
		_drawer_textview5 = (TextView) _nav_view.findViewById(R.id.textview5);
		name = getSharedPreferences("name", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		profile = getSharedPreferences("profile", Activity.MODE_PRIVATE);
		d_delete = new AlertDialog.Builder(this);
		exit_d = new AlertDialog.Builder(this);
		di_about = new AlertDialog.Builder(this);
		check_re = new RequestNetwork(this);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				pu.putExtra("name", map.get((int)_position).get("owner").toString());
				pu.putExtra("profile", map.get((int)_position).get("profile").toString());
				pu.putExtra("appname", map.get((int)_position).get("appname").toString());
				pu.putExtra("appicon", map.get((int)_position).get("appicon").toString());
				pu.putExtra("appdescription", map.get((int)_position).get("appdescription").toString());
				pu.putExtra("url", map.get((int)_position).get("url").toString());
				pu.putExtra("screen1", map.get((int)_position).get("screen1").toString());
				pu.putExtra("screen2", map.get((int)_position).get("screen2").toString());
				pu.putExtra("screen3", map.get((int)_position).get("screen3").toString());
				pu.setClass(getApplicationContext(), DownloadActivity.class);
				startActivity(pu);
			}
		});
		
		_fb_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				linear3.setVisibility(View.GONE);
				fb.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						map = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								map.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listview1.setAdapter(new Listview1Adapter(map));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
				v0.setText(String.valueOf((long)(Double.parseDouble(v0.getText().toString()) + Double.parseDouble("1"))));
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				fb.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						map = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								map.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listview1.setAdapter(new Listview1Adapter(map));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						SketchwareUtil.showMessage(getApplicationContext(), "someone added New App , Now refreshing the list..");
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				fb.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						map = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								map.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listview1.setAdapter(new Listview1Adapter(map));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						SketchwareUtil.showMessage(getApplicationContext(), "refreshing list for some changes...");
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fb.addChildEventListener(_fb_child_listener);
		
		_fbsgupapp_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fbsgupapp_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fbsgupapp_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_fbsgupapp_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_fbsgupapp_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fbsgupapp_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_check_re_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				progressbar1.setVisibility(View.VISIBLE);
				textview3.setText("Loading Apps...");
				textview3.setTextColor(0xFF3F51B5);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				progressbar1.setVisibility(View.GONE);
				textview3.setTextColor(0xFFF44336);
				textview3.setText("No internet connection...");
			}
		};
		
		_drawer_imageview1_home.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_drawer.closeDrawer(GravityCompat.START);
			}
		});
		
		_drawer_textview2_home.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_drawer.closeDrawer(GravityCompat.START);
			}
		});
		
		_drawer_imageview2_upload.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				upload.setClass(getApplicationContext(), UploadActivity.class);
				startActivity(upload);
			}
		});
		
		_drawer_textview1_upload.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				upload.setClass(getApplicationContext(), UploadActivity.class);
				startActivity(upload);
			}
		});
		
		_drawer_imageview4_editprof.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				editin.setClass(getApplicationContext(), UserprofActivity.class);
				startActivity(editin);
			}
		});
		
		_drawer_textview5_editprof.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				editin.setClass(getApplicationContext(), UserprofActivity.class);
				startActivity(editin);
			}
		});
		
		_drawer_imageview4_about.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				di_about.setTitle("about Android Store");
				di_about.setMessage("Android store is a simple store app and You can upload OR download apps from it And Android store Made By Kimo Android");
				di_about.setPositiveButton("my channel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						h.setData(Uri.parse("https://www.youtube.com/c/kimoandroid"));
						startActivity(h);
					}
				});
				di_about.setNegativeButton("got it", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				di_about.create().show();
				SketchwareUtil.showMessage(getApplicationContext(), "this app by kimo Android");
			}
		});
		
		_drawer_textview5_about.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				di_about.setTitle("about Android Store");
				di_about.setMessage("Android store is a simple store app and You can upload OR download apps from it And Android store Made By Kimo Android");
				di_about.setPositiveButton("my channel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						h.setData(Uri.parse("https://www.youtube.com/c/kimoandroid"));
						startActivity(h);
					}
				});
				di_about.setNegativeButton("got it", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				di_about.create().show();
			}
		});
		
		_drawer_imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				contact_in.setData(Uri.parse("mailto:kimospprt@gmail.com"));
				startActivity(contact_in);
			}
		});
		
		_drawer_textview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				contact_in.setData(Uri.parse("mailto:kimospprt@gmail.com"));
				startActivity(contact_in);
			}
		});
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		adview1.loadAd(new AdRequest.Builder().addTestDevice("5C73353DA47FF2EF2D6D00C770C113F1")
		.build());
		setTitle("Android Store");
		linear3.setVisibility(View.VISIBLE);
		check_re.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com", "A", _check_re_request_listener);
		if (!(FirebaseAuth.getInstance().getCurrentUser() != null) && name.getString("name", "").equals("")) {
			SketchwareUtil.showMessage(getApplicationContext(), "you must login First");
			logcheck.setClass(getApplicationContext(), LoginSignupActivity.class);
			startActivity(logcheck);
			finish();
		}
		else {
			textview1.setText(name.getString("name", ""));
			Glide.with(getApplicationContext()).load(Uri.parse(profile.getString("profile", ""))).into(imageview1);
		}
		fb.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				map = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						map.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				listview1.setAdapter(new Listview1Adapter(map));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		textview1.setText(name.getString("name", ""));
		Glide.with(getApplicationContext()).load(Uri.parse(profile.getString("profile", ""))).into(imageview1);
	}
	
	@Override
	public void onBackPressed() {
		exit_d.setTitle("exit !");
		exit_d.setMessage("do you want to close Android store App ?!");
		exit_d.setPositiveButton("yes !", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				SketchwareUtil.showMessage(getApplicationContext(), "See you Later My friend ❤❤");
				finish();
			}
		});
		exit_d.setNegativeButton("no", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				SketchwareUtil.showMessage(getApplicationContext(), "Thanks for your stay !");
			}
		});
		exit_d.create().show();
	}
	private void _radius (final String _color, final double _numb, final View _view) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_numb);
		_view.setBackground(gd);
		_view.setElevation((int)_numb);
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.custom_home, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final TextView textview2_owner = (TextView) _v.findViewById(R.id.textview2_owner);
			
			if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/Android Store/"))) {
				
			}
			else {
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/Android Store/"));
			}
			_radius("#FFFFFF", 8, linear1);
			textview1.setText(map.get((int)_position).get("appname").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(map.get((int)_position).get("appicon").toString())).into(imageview1);
			textview2_owner.setText(map.get((int)_position).get("owner").toString());
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
