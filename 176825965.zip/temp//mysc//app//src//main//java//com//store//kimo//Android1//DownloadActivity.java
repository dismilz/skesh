package com.store.kimo.Android1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.view.View;
import com.bumptech.glide.Glide;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class DownloadActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String url = "";
	private String dataLocation = "";
	private String fileName = "";
	
	private ArrayList<HashMap<String, Object>> lmap = new ArrayList<>();
	
	private LinearLayout linear2;
	private ScrollView vscroll1;
	private LinearLayout linear8;
	private TextView textview2;
	private TextView textview7;
	private LinearLayout linear4;
	private LinearLayout linear1;
	private LinearLayout linear11;
	private AdView adview1;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear10;
	private ImageView imageview1_appicon;
	private LinearLayout linear9;
	private TextView textview1_appname;
	private TextView owner_1;
	private TextView textview4;
	private TextView textvie_description;
	private LinearLayout linear6;
	private ImageView screen1;
	private ImageView screen2;
	private ImageView screen3;
	private TextView textview6;
	private ImageView imageview1_owner;
	private TextView textview7_owner;
	private Button button1;
	
	private Intent in_down = new Intent();
	private DatabaseReference fb = _firebase.getReference("fb");
	private ChildEventListener _fb_child_listener;
	private Intent trans = new Intent();
	private RequestNetwork network_re;
	private RequestNetwork.RequestListener _network_re_request_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.download);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview7 = (TextView) findViewById(R.id.textview7);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		adview1 = (AdView) findViewById(R.id.adview1);
		hscroll1 = (HorizontalScrollView) findViewById(R.id.hscroll1);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		imageview1_appicon = (ImageView) findViewById(R.id.imageview1_appicon);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		textview1_appname = (TextView) findViewById(R.id.textview1_appname);
		owner_1 = (TextView) findViewById(R.id.owner_1);
		textview4 = (TextView) findViewById(R.id.textview4);
		textvie_description = (TextView) findViewById(R.id.textvie_description);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		screen1 = (ImageView) findViewById(R.id.screen1);
		screen2 = (ImageView) findViewById(R.id.screen2);
		screen3 = (ImageView) findViewById(R.id.screen3);
		textview6 = (TextView) findViewById(R.id.textview6);
		imageview1_owner = (ImageView) findViewById(R.id.imageview1_owner);
		textview7_owner = (TextView) findViewById(R.id.textview7_owner);
		button1 = (Button) findViewById(R.id.button1);
		network_re = new RequestNetwork(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				network_re.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com", "download", _network_re_request_listener);
			}
		});
		
		_fb_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				fb.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						lmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								lmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						
						
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
				textview1_appname.setText(getIntent().getStringExtra("appname"));
				textvie_description.setText(getIntent().getStringExtra("appdescription"));
				Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("appicon"))).into(imageview1_appicon);
				Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("screen1"))).into(screen1);
				Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("screen2"))).into(screen2);
				Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("screen3"))).into(screen3);
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				fb.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						lmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								lmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				fb.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						lmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								lmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fb.addChildEventListener(_fb_child_listener);
		
		_network_re_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/Android Store/"))) {
					fileName = Uri.parse(Uri.parse(textview7.getText().toString()).getLastPathSegment()).getLastPathSegment();
					dataLocation = "/Android Store/".concat(fileName);
					_Download(textview7.getText().toString(), dataLocation);
				}
				else {
					FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/Android Store/"));
					fileName = Uri.parse(Uri.parse(textview7.getText().toString()).getLastPathSegment()).getLastPathSegment();
					dataLocation = "/Android Store/".concat(fileName);
					_Download(textview7.getText().toString(), dataLocation);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "can't download , please check your connection !");
			}
		};
	}
	private void initializeLogic() {
		adview1.loadAd(new AdRequest.Builder().addTestDevice("5C73353DA47FF2EF2D6D00C770C113F1")
		.build());
		android.graphics.drawable.GradientDrawable l = new android.graphics.drawable.GradientDrawable();
		l.setColor(Color.parseColor("#E0E0E0"));
		l.setCornerRadius(40);
		button1.setBackground(l);
		textview7.setVisibility(View.GONE);
		textview7.setText(getIntent().getStringExtra("url"));
		textview7_owner.setText(getIntent().getStringExtra("name"));
		owner_1.setText(getIntent().getStringExtra("name"));
		Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("profile"))).into(imageview1_owner);
		textview1_appname.setText(getIntent().getStringExtra("appname"));
		textvie_description.setText(getIntent().getStringExtra("appdescription"));
		Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("appicon"))).into(imageview1_appicon);
		Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("screen1"))).into(screen1);
		Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("screen2"))).into(screen2);
		Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("screen3"))).into(screen3);
		_radius("#FFFFFF", 8, linear1);
		_radius("#FFFFFF", 8, linear11);
		_radius("#FFFFFF", 8, hscroll1);
		_radius("#FFFFFF", 8, linear10);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _Download (final String _url, final String _path) {
		try{
			
			FileUtil.makeDir(FileUtil.getPackageDataDir(getApplicationContext()));
			android.net.ConnectivityManager connMgr = (android.net.ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
			android.net.NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
			if (networkInfo != null && networkInfo.isConnected()) {
				
				
				final String urlDownload = _url;
				
				DownloadManager.Request request = new DownloadManager.Request(Uri.parse(urlDownload));
				
				final String fileName = URLUtil.guessFileName(urlDownload, null, null);
				
				request.setDescription("URL - " + urlDownload);
				
				request.setTitle(fileName);
				
				request.allowScanningByMediaScanner();
				
				request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
				//App by kimo Android
				request.setDestinationInExternalPublicDir(_path, fileName);
				
				final DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				
				final long downloadId = manager.enqueue(request);
				
				final ProgressDialog prog = new ProgressDialog(this);
				prog.setMax(100);
				prog.setIndeterminate(true);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
				
				prog.setTitle("downloading...");
				prog.setMessage("Downloading the " + fileName + ".\n\nProgress  0%");
				prog.show();
				
				new Thread(new Runnable() {
					@Override
					public void run() {
						
						boolean downloading = true;
						
						while (downloading) {
							
							DownloadManager.Query q = new DownloadManager.Query();
							
							q.setFilterById(downloadId);
							
							android.database.Cursor cursor = manager.query(q);
							
							cursor.moveToFirst();
							
							int bytes_downloaded = cursor.getInt(cursor .getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
							
							int bytes_total = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
							
							if (cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL) {
								
								downloading = false;
								
							}
							
							final int dl_progress = (int) ((bytes_downloaded * 100l) / bytes_total);
							
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									
									prog.setTitle("downloading...");
									prog.setMessage("Downloading the " + fileName + ".\n\nProgress  " + dl_progress + "%");
									prog.show();
									
									if (dl_progress == 100) {
										prog.dismiss();
										
									}
									
								} });
						} } }).start();
				
				
			} else {
				showMessage("No Internet Connection.");
			}
		}
		catch(Exception _e){
			//do something if error occurs
			//To know error use _e.toString()
			
			FileUtil.makeDir(FileUtil.getPackageDataDir(getApplicationContext()));
			android.net.ConnectivityManager connMgr = (android.net.ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
			android.net.NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
			if (networkInfo != null && networkInfo.isConnected()) {
				
				
				final String urlDownload = _url;
				
				DownloadManager.Request request = new DownloadManager.Request(Uri.parse(urlDownload));
				
				final String fileName = URLUtil.guessFileName(urlDownload, null, null);
				
				request.setDescription("URL - " + urlDownload);
				
				request.setTitle(fileName);
				
				request.allowScanningByMediaScanner();
				
				request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
				
				request.setDestinationInExternalPublicDir(_path, fileName);
				
				final DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
				
				final long downloadId = manager.enqueue(request);
				
				final ProgressDialog prog = new ProgressDialog(this);
				prog.setMax(100);
				prog.setIndeterminate(true);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
				
				prog.setTitle("downloading...");
				prog.setMessage("Downloading the " + fileName + ".\n\nProgress  0%");
				prog.show();
				
				new Thread(new Runnable() {
					@Override
					public void run() {
						
						boolean downloading = true;
						
						while (downloading) {
							
							DownloadManager.Query q = new DownloadManager.Query();
							
							q.setFilterById(downloadId);
							
							android.database.Cursor cursor = manager.query(q);
							
							cursor.moveToFirst();
							
							int bytes_downloaded = cursor.getInt(cursor .getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
							
							int bytes_total = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
							
							if (cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL) {
								
								downloading = false;
								
							}
							
							final int dl_progress = (int) ((bytes_downloaded * 100l) / bytes_total);
							
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									
									prog.setTitle("downloading...");
									prog.setMessage("Downloading the " + fileName + ".\n\nProgress  " + dl_progress + "%");
									prog.show();
									
									if (dl_progress == 100) {
										prog.dismiss();
										
										SketchwareUtil.showMessage(getApplicationContext(), "Failed to download this app");
									}
									
								} });
						} } }).start();
				
				
			} else {
				showMessage("No Internet Connection.");
			}
		}
	}
	
	
	private void _radius (final String _color, final double _numb, final View _view) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_numb);
		_view.setBackground(gd);
		_view.setElevation((int)_numb);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
