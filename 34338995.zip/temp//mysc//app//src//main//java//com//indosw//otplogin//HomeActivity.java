package com.indosw.otplogin;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.Intent;
import android.net.Uri;
import android.content.ClipData;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.app.Activity;
import android.content.SharedPreferences;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Continuation;
import java.io.File;
import android.view.View;
import android.content.ClipboardManager;
import android.graphics.Typeface;
import com.bumptech.glide.Glide;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class HomeActivity extends AppCompatActivity {
	
	public final int REQ_CD_FP = 101;
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private FloatingActionButton _fab;
	private HashMap<String, Object> map = new HashMap<>();
	private String fontName = "";
	private String typeace = "";
	private String filePath = "";
	private String fileName = "";
	private double postTime = 0;
	private double deference = 0;
	private HashMap<String, Object> postLikes = new HashMap<>();
	private double n = 0;
	private double likes = 0;
	private HashMap<String, Object> mapvar = new HashMap<>();
	private String user = "";
	private String userss = "";
	private String commentpath = "";
	
	private ArrayList<HashMap<String, Object>> info = new ArrayList<>();
	private ArrayList<String> list = new ArrayList<>();
	private ArrayList<String> userUID = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> post_map = new ArrayList<>();
	private ArrayList<String> postKeys = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> users = new ArrayList<>();
	private ArrayList<String> allkeys = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> com = new ArrayList<>();
	private ArrayList<String> usercomment = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ListView listview1;
	private ImageView imageview1;
	private TextView textview1;
	private ImageView imageview3;
	
	private DatabaseReference usersdata = _firebase.getReference("usersdata");
	private ChildEventListener _usersdata_child_listener;
	private FirebaseAuth Account;
	private OnCompleteListener<AuthResult> _Account_create_user_listener;
	private OnCompleteListener<AuthResult> _Account_sign_in_listener;
	private OnCompleteListener<Void> _Account_reset_password_listener;
	private Intent in = new Intent();
	private Intent intent = new Intent();
	private Intent post = new Intent();
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private Calendar cal = Calendar.getInstance();
	private SharedPreferences mode;
	private DatabaseReference comments = _firebase.getReference("+comments+");
	private ChildEventListener _comments_child_listener;
	private StorageReference image = _firebase_storage.getReference("image");
	private OnCompleteListener<Uri> _image_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _image_download_success_listener;
	private OnSuccessListener _image_delete_success_listener;
	private OnProgressListener _image_upload_progress_listener;
	private OnProgressListener _image_download_progress_listener;
	private OnFailureListener _image_failure_listener;
	private DatabaseReference Post = _firebase.getReference("Post");
	private ChildEventListener _Post_child_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_fab = (FloatingActionButton) findViewById(R.id._fab);
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		listview1 = (ListView) findViewById(R.id.listview1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		Account = FirebaseAuth.getInstance();
		fp.setType("image/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		mode = getSharedPreferences("mode", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), ProfileViewActivity.class);
				in.putExtra("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				startActivity(in);
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), DiscoverActivity.class);
				intent.putExtra("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				startActivity(intent);
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(fp, REQ_CD_FP);
			}
		});
		
		_usersdata_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				usersdata.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						info = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								info.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							if (_childValue.containsKey("avatar")) {
								_curcle_igm_url(_childValue.get("avatar").toString(), imageview1);
							}
							else {
								imageview1.setImageResource(R.drawable.default_image);
							}
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				usersdata.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						info = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								info.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							if (_childValue.containsKey("avatar")) {
								_curcle_igm_url(_childValue.get("avatar").toString(), imageview1);
							}
							else {
								imageview1.setImageResource(R.drawable.default_image);
							}
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		usersdata.addChildEventListener(_usersdata_child_listener);
		
		_comments_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		comments.addChildEventListener(_comments_child_listener);
		
		_image_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_image_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_image_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_image_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_image_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_image_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_Post_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Post.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						post_map = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								post_map.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						userUID.add(_childKey);
						listview1.setAdapter(new Listview1Adapter(post_map));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Post.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						post_map = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								post_map.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						userUID.add(_childKey);
						listview1.setAdapter(new Listview1Adapter(post_map));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Post.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						post_map = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								post_map.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						userUID.add(_childKey);
						listview1.setAdapter(new Listview1Adapter(post_map));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Post.addChildEventListener(_Post_child_listener);
		
		_Account_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_Account_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_Account_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/com.ttf"), 1);
		_changeActivityFont("com");
		HomeActivity.this.getWindow().setSoftInputMode( WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN );
		listview1.setOverScrollMode(View.OVER_SCROLL_NEVER);listview1.setVerticalScrollBarEnabled(false);
		listview1.setDivider(null);listview1.setDividerHeight(0); listview1.setSelector(android.R.color.transparent);
		_Elevation(linear2, 3);
		if (mode.getString("night", "").equals("true")) {
			_SetStatusBarColor("#333333");
			linear2.setBackgroundColor(0xFF333333);
			listview1.setBackgroundColor(0xFF000000);
		}
		else {
			_SetStatusBarColor("#FFFFFF");
			linear1.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				filePath = _filePath.get((int)(0));
				fileName = Uri.parse(filePath).getLastPathSegment();
				post.setClass(getApplicationContext(), CreatePostActivity.class);
				post.putExtra("path", filePath);
				post.putExtra("name", fileName);
				startActivity(post);
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (mode.getString("night", "").equals("true")) {
			_SetStatusBarColor("#333333");
			linear2.setBackgroundColor(0xFF333333);
			listview1.setBackgroundColor(0xFF000000);
		}
		else {
			_SetStatusBarColor("#FFFFFF");
			linear1.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		}
	}
	private void _Elevation (final View _view, final double _number) {
		
		_view.setElevation((int)_number);
	}
	
	
	private void _curcle_igm_url (final String _url, final ImageView _img_view) {
		_img_view
		Glide.with(getApplicationContext()).load(_url).asBitmap().centerCrop().into(new com.bumptech.glide.request.target.BitmapImageViewTarget(_img_view) {
			@Override protected void setResource(Bitmap resource) {
				android.support.v4.graphics.drawable.RoundedBitmapDrawable circularBitmapDrawable = android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory.create(getApplicationContext().getResources(), resource); circularBitmapDrawable.setCircular(true); _img_view.setImageDrawable(circularBitmapDrawable);
			}
		});
	}
	
	
	private void _SetStatusBarColor (final String _color) {
		Window w = this.getWindow();w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(Color.parseColor(_color));
	}
	
	
	private void _changeActivityFont (final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				}
				else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					}
					else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	private void _Shadow (final double _sadw, final double _cru, final String _wc, final View _widgets) {
		android.graphics.drawable.GradientDrawable wd = new android.graphics.drawable.GradientDrawable();
		wd.setColor(Color.parseColor(_wc));
		wd.setCornerRadius((int)_cru);
		_widgets.setElevation((int)_sadw);
		_widgets.setBackground(wd);
	}
	
	
	private void _Time (final double _position, final TextView _textview) {
		if (post_map.get((int)_position).containsKey("time")) {
			postTime = Double.parseDouble(post_map.get((int)_position).get("time").toString());
			cal = Calendar.getInstance();
			deference = cal.getTimeInMillis() - postTime;
			if (deference < 60000) {
				_textview.setText(String.valueOf((long)(deference / 1000)).concat("sec"));
			}
			else {
				if (deference < (60 * 60000)) {
					_textview.setText(String.valueOf((long)(deference / 60000)).concat("min"));
				}
				else {
					if (deference < (24 * (60 * 60000))) {
						_textview.setText(String.valueOf((long)(deference / (60 * 60000))).concat("hr"));
					}
					else {
						_textview.setText(String.valueOf((long)(deference / (24 * (60 * 60000)))).concat("d"));
					}
				}
			}
		}
	}
	
	
	private void _Fab_Color (final String _color) {
		_fab.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor(_color)));
	}
	
	
	private void _optionMenu (final double _position) {
		final AlertDialog dialog2 = new AlertDialog.Builder(HomeActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.option, null);
		dialog2.setView(inflate);
		dialog2.setCanceledOnTouchOutside(false);
		dialog2.setCancelable(false);
		
		dialog2.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		
		final TextView copy = (TextView) inflate.findViewById(R.id.textview1);
		
		final TextView edit = (TextView) inflate.findViewById(R.id.textview2);
		
		final TextView delete = (TextView) inflate.findViewById(R.id.textview3);
		
		final TextView share = (TextView) inflate.findViewById(R.id.textview4);
		
		final TextView report = (TextView) inflate.findViewById(R.id.textview5);
		
		final LinearLayout one = (LinearLayout) inflate.findViewById(R.id.lin1);
		
		final LinearLayout two = (LinearLayout) inflate.findViewById(R.id.lin2);
		
		final LinearLayout three = (LinearLayout) inflate.findViewById(R.id.lin3);
		
		final LinearLayout four = (LinearLayout) inflate.findViewById(R.id.lin4);
		
		final LinearLayout five = (LinearLayout) inflate.findViewById(R.id.lin5);
		
		final TextView cancel = (TextView) inflate.findViewById(R.id.textview6);
		final LinearLayout main = (LinearLayout) inflate.findViewById(R.id.linear1);
		if (mode.getString("night", "").equals("true")) {
			_Shadow(5, 15, "#000000", main);
			one.setBackgroundColor(0x607D8B);
			two.setBackgroundColor(0x607D8B);
			three.setBackgroundColor(0x607D8B);
			four.setBackgroundColor(0x607D8B);
			five.setBackgroundColor(0x607D8B);
		}
		else {
			_Shadow(5, 15, "#FFFFFF", main);
		}
		if (post_map.get((int)_position).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
			report.setVisibility(View.GONE);
			four.setVisibility(View.GONE);
			edit.setVisibility(View.VISIBLE);
			delete.setVisibility(View.VISIBLE);
		}
		else {
			one.setVisibility(View.GONE);
			two.setVisibility(View.GONE);
			edit.setVisibility(View.GONE);
			delete.setVisibility(View.GONE);
			report.setVisibility(View.VISIBLE);
		}
		copy.setOnClickListener(new OnClickListener() { public void onClick(View view) {
				if (post_map.get((int)_position).containsKey("msg")) {
					((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", post_map.get((int)_position).get("msg").toString()));
				}
				SketchwareUtil.showMessage(getApplicationContext(), "Copied! ");
				dialog2.dismiss(); } });
		edit.setOnClickListener(new OnClickListener() { public void onClick(View view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Edit");
				dialog2.dismiss(); } });
		delete.setOnClickListener(new OnClickListener() { public void onClick(View view) {
				Post.child(userUID.get((int)(_position))).removeValue();
				userUID.remove((int)(_position));
				if (post_map.get((int)_position).containsKey("img")) {
					_firebase_storage.getReferenceFromUrl(post_map.get((int)_position).get("img").toString()).delete().addOnSuccessListener(_image_delete_success_listener).addOnFailureListener(_image_failure_listener);
				}
				SketchwareUtil.showMessage(getApplicationContext(), "Post Deleted!");
				dialog2.dismiss(); } });
		share.setOnClickListener(new OnClickListener() { public void onClick(View view) {
				SketchwareUtil.showMessage(getApplicationContext(), "share");
				dialog2.dismiss(); } });
		report.setOnClickListener(new OnClickListener() { public void onClick(View view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Post reported the admin will review soon! ");
				dialog2.dismiss(); } });
		cancel.setOnClickListener(new OnClickListener() { public void onClick(View view) {
				dialog2.dismiss(); } });
		dialog2.show();
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.posts, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final TextView message = (TextView) _v.findViewById(R.id.message);
			final ImageView display_pic = (ImageView) _v.findViewById(R.id.display_pic);
			final LinearLayout linear4 = (LinearLayout) _v.findViewById(R.id.linear4);
			final ImageView avatar = (ImageView) _v.findViewById(R.id.avatar);
			final LinearLayout linear3 = (LinearLayout) _v.findViewById(R.id.linear3);
			final ImageView more = (ImageView) _v.findViewById(R.id.more);
			final TextView username = (TextView) _v.findViewById(R.id.username);
			final TextView time = (TextView) _v.findViewById(R.id.time);
			final LinearLayout linear5 = (LinearLayout) _v.findViewById(R.id.linear5);
			final LinearLayout comm = (LinearLayout) _v.findViewById(R.id.comm);
			final ImageView like = (ImageView) _v.findViewById(R.id.like);
			final TextView like_num = (TextView) _v.findViewById(R.id.like_num);
			final ImageView comment = (ImageView) _v.findViewById(R.id.comment);
			final TextView comments_num = (TextView) _v.findViewById(R.id.comments_num);
			
			if (mode.getString("night", "").equals("true")) {
				_Shadow(5, 10, "#333333", linear1);
			}
			else {
				_Shadow(5, 10, "#FFFFFF", linear1);
			}
			_Elevation(linear2, 3);
			_Elevation(linear4, 3);
			if (post_map.get((int)_position).containsKey("name")) {
				username.setText(post_map.get((int)_position).get("name").toString());
			}
			if (post_map.get((int)_position).get("avatar").toString().equals("default")) {
				avatar.setImageResource(R.drawable.default_image);
			}
			else {
				_curcle_igm_url(post_map.get((int)_position).get("avatar").toString(), avatar);
			}
			if (post_map.get((int)_position).containsKey("msg")) {
				message.setVisibility(View.VISIBLE);
				message.setText(post_map.get((int)_position).get("msg").toString());
			}
			else {
				message.setVisibility(View.GONE);
			}
			if (post_map.get((int)_position).containsKey("img")) {
				display_pic.setVisibility(View.VISIBLE);
				Glide.with(getApplicationContext()).load(Uri.parse(post_map.get((int)_position).get("img").toString())).into(display_pic);
			}
			_Time(_position, time);
			more.setColorFilter(0xFF00BCD4, PorterDuff.Mode.MULTIPLY);
			like.setColorFilter(0xFFE91E63, PorterDuff.Mode.MULTIPLY);
			comment.setColorFilter(0xFFFFC107, PorterDuff.Mode.MULTIPLY);
			postLikes = post_map.get((int)_position);
			SketchwareUtil.getAllKeysFromMap(postLikes, postKeys);
			n = 0;
			likes = 0;
			for(int _repeat60 = 0; _repeat60 < (int)(postKeys.size()); _repeat60++) {
				if (postLikes.get(postKeys.get((int)(n))).toString().equals("true")) {
					likes++;
				}
				else {
					
				}
				n++;
			}
			like_num.setText(String.valueOf((long)(likes)));
			if (post_map.get((int)_position).containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
				if (post_map.get((int)_position).get(FirebaseAuth.getInstance().getCurrentUser().getUid()).toString().equals("true")) {
					like.setImageResource(R.drawable.default_image);
				}
				else {
					if (post_map.get((int)_position).get(FirebaseAuth.getInstance().getCurrentUser().getUid()).toString().equals("false")) {
						like.setImageResource(R.drawable.default_image);
					}
				}
			}
			else {
				like.setImageResource(R.drawable.default_image);
			}
			like.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (post_map.get((int)_position).containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						if (post_map.get((int)_position).get(FirebaseAuth.getInstance().getCurrentUser().getUid()).toString().equals("true")) {
							mapvar = new HashMap<>();
							mapvar.put(FirebaseAuth.getInstance().getCurrentUser().getUid(), "false");
							Post.child(userUID.get((int)(_position))).updateChildren(mapvar);
						}
						else {
							if (post_map.get((int)_position).get(FirebaseAuth.getInstance().getCurrentUser().getUid()).toString().equals("false")) {
								mapvar = new HashMap<>();
								mapvar.put(FirebaseAuth.getInstance().getCurrentUser().getUid(), "true");
								Post.child(userUID.get((int)(_position))).updateChildren(mapvar);
							}
						}
					}
					else {
						mapvar = new HashMap<>();
						mapvar.put(FirebaseAuth.getInstance().getCurrentUser().getUid(), "true");
						Post.child(userUID.get((int)(_position))).updateChildren(mapvar);
					}
				}
			});
			comm.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					intent.setClass(getApplicationContext(), CommentsActivity.class);
					intent.putExtra("key", userUID.get((int)(_position)));
					startActivity(intent);
				}
			});
			comments_num.setText("0");
			commentpath = userUID.get((int)(_position));
			comments =
			_firebase.getReference(commentpath);
			comments.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					com = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							com.add(_map);
						}
					}
					catch (Exception _e) {
						_e.printStackTrace();
					}
					comments_num.setText(String.valueOf((long)(com.size())));
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
			more.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_optionMenu(_position);
				}
			});
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
