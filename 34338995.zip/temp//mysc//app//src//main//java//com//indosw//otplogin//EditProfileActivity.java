package com.indosw.otplogin;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Button;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.content.Intent;
import android.content.ClipData;
import java.util.Timer;
import java.util.TimerTask;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Continuation;
import android.net.Uri;
import java.io.File;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.AdapterView;
import android.text.Editable;
import android.text.TextWatcher;
import com.bumptech.glide.Glide;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class EditProfileActivity extends AppCompatActivity {
	
	public final int REQ_CD_FP = 101;
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private String fontName = "";
	private String typeace = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String Gender = "";
	private String Webster = "";
	private String Profile = "";
	private String ProfileName = "";
	private double choose_profile = 0;
	private String phonenum = "";
	private String biodata = "";
	
	private ArrayList<String> item = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> info = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private TextView textview1;
	private ImageView profile;
	private TextView textview2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private ImageView imageview2;
	private EditText name;
	private ImageView imageview3;
	private TextView gender;
	private Spinner spinner1;
	private ImageView imageview5;
	private EditText phone;
	private EditText bio;
	private Button button1;
	private Button button2;
	
	private DatabaseReference usersdata = _firebase.getReference("usersdata");
	private ChildEventListener _usersdata_child_listener;
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private TimerTask t;
	private FirebaseAuth Account;
	private OnCompleteListener<AuthResult> _Account_create_user_listener;
	private OnCompleteListener<AuthResult> _Account_sign_in_listener;
	private OnCompleteListener<Void> _Account_reset_password_listener;
	private StorageReference avatar = _firebase_storage.getReference("avatar");
	private OnCompleteListener<Uri> _avatar_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _avatar_download_success_listener;
	private OnSuccessListener _avatar_delete_success_listener;
	private OnProgressListener _avatar_upload_progress_listener;
	private OnProgressListener _avatar_download_progress_listener;
	private OnFailureListener _avatar_failure_listener;
	private SharedPreferences mode;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.edit_profile);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		textview1 = (TextView) findViewById(R.id.textview1);
		profile = (ImageView) findViewById(R.id.profile);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		name = (EditText) findViewById(R.id.name);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		gender = (TextView) findViewById(R.id.gender);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		phone = (EditText) findViewById(R.id.phone);
		bio = (EditText) findViewById(R.id.bio);
		button1 = (Button) findViewById(R.id.button1);
		button2 = (Button) findViewById(R.id.button2);
		fp.setType("image/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		Account = FirebaseAuth.getInstance();
		mode = getSharedPreferences("mode", Activity.MODE_PRIVATE);
		
		profile.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(fp, REQ_CD_FP);
			}
		});
		
		spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (_position == 0) {
					Gender = "Male";
				}
				if (_position == 1) {
					Gender = "Female";
				}
				if (_position == 2) {
					Gender = "Others";
				}
			}
			
			@Override
			public void onNothingSelected(AdapterView<?> _param1) {
				
			}
		});
		
		phone.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.trim().equals("")) {
					phonenum = "+xxxxxxxxxx";
				}
				else {
					phonenum = phone.getText().toString();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (name.getText().toString().trim().equals("")) {
					_SnackBar("Please enter username! ");
				}
				else {
					if (name.getText().toString().length() < 5) {
						_SnackBar("Name must be 6 Characters! ");
					}
					else {
						if (name.getText().toString().length() > 12) {
							_SnackBar("Name not more than 12 Characters! ");
						}
						else {
							if (bio.getText().toString().trim().equals("")) {
								biodata = "Hey, I'm a new user of Telme. Follow me as Friendly. ";
							}
							else {
								if (bio.getText().toString().length() < 12) {
									_SnackBar("Bio must be 12 Characters");
								}
								else {
									if (bio.getText().toString().length() > 101) {
										_SnackBar("Bio not more than 101 characters");
									}
									else {
										biodata = bio.getText().toString();
										if (choose_profile == 0) {
											_Prog_Dialogue_show(true, "", "Saving...");
											t = new TimerTask() {
												@Override
												public void run() {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															map = new HashMap<>();
															map.put("username", name.getText().toString());
															map.put("gender", Gender);
															map.put("phone", phonenum);
															map.put("bio", biodata);
															usersdata.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
															map.clear();
															_Prog_Dialogue_show(false, "", "");
															finish();
														}
													});
												}
											};
											_timer.schedule(t, (int)(2000));
										}
										else {
											_Prog_Dialogue_show(true, "", "Uploading profile... ");
											avatar.child(ProfileName).putFile(Uri.fromFile(new File(Profile))).addOnFailureListener(_avatar_failure_listener).addOnProgressListener(_avatar_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
												@Override
												public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
													return avatar.child(ProfileName).getDownloadUrl();
												}}).addOnCompleteListener(_avatar_upload_success_listener);
										}
									}
								}
							}
						}
					}
				}
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		_usersdata_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				usersdata.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						info = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								info.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							name.setText(_childValue.get("username").toString());
							if (_childValue.containsKey("avatar")) {
								_curcle_igm_url(_childValue.get("avatar").toString(), profile);
							}
							else {
								profile.setImageResource(R.drawable.default_image);
							}
							if (_childValue.containsKey("bio")) {
								bio.setText(_childValue.get("bio").toString());
							}
							else {
								bio.setText("Hey, I'm a new user of Telme Messanger. ");
							}
							if (_childValue.containsKey("gender")) {
								if (_childValue.get("gender").toString().equals("Male")) {
									spinner1.setSelection((int)(0));
								}
								else {
									if (_childValue.get("gender").toString().equals("Female")) {
										spinner1.setSelection((int)(1));
									}
									else {
										spinner1.setSelection((int)(2));
									}
								}
							}
							else {
								spinner1.setSelection((int)(0));
							}
							if (_childValue.containsKey("phone")) {
								phone.setText(_childValue.get("phone").toString());
							}
							else {
								phone.setText("+xxxxxxxxxxxx");
							}
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				usersdata.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						info = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								info.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							name.setText(_childValue.get("username").toString());
							if (_childValue.containsKey("avatar")) {
								_curcle_igm_url(_childValue.get("avatar").toString(), profile);
							}
							else {
								profile.setImageResource(R.drawable.default_image);
							}
							if (_childValue.containsKey("bio")) {
								bio.setText(_childValue.get("bio").toString());
							}
							else {
								bio.setText("Hey, I'm a new user of Telme Messanger. ");
							}
							if (_childValue.containsKey("gender")) {
								if (_childValue.get("gender").toString().equals("Male")) {
									spinner1.setSelection((int)(0));
								}
								else {
									if (_childValue.get("gender").toString().equals("Female")) {
										spinner1.setSelection((int)(1));
									}
									else {
										spinner1.setSelection((int)(2));
									}
								}
							}
							else {
								spinner1.setSelection((int)(0));
							}
							if (_childValue.containsKey("phone")) {
								phone.setText(_childValue.get("phone").toString());
							}
							else {
								phone.setText("+xxxxxxxxxxxx");
							}
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		usersdata.addChildEventListener(_usersdata_child_listener);
		
		_avatar_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_avatar_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_avatar_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				_Prog_Dialogue_show(true, "", "Saving...");
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								map = new HashMap<>();
								map.put("username", name.getText().toString());
								map.put("avatar", _downloadUrl);
								map.put("phone", phonenum);
								map.put("gender", Gender);
								map.put("bio", biodata);
								usersdata.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
								map.clear();
								_Prog_Dialogue_show(false, "", "");
								finish();
							}
						});
					}
				};
				_timer.schedule(t, (int)(500));
			}
		};
		
		_avatar_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_avatar_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_avatar_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_Account_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_Account_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_Account_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		_changeActivityFont("com");
		item.add("Male");
		item.add("Female");
		item.add("Others");
		spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, item));
		if (mode.getString("night", "").equals("true")) {
			linear1.setBackgroundColor(0xFF000000);
			linear2.setBackgroundColor(0xFF000000);
			_SetStatusBarColor("#000000");
			imageview2.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
			imageview3.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
			imageview5.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
			_gd(linear3, "#333333", "#333333", 5);
			_gd(linear4, "#333333", "#333333", 5);
			_gd(linear6, "#333333", "#333333", 5);
			_gd(linear7, "#333333", "#333333", 5);
			_Shadow(5, 5, "#00BCD4", button1);
			_Shadow(5, 5, "#00ACC1", button2);
		}
		else {
			_SetStatusBarColor("#FFFFFF");
			linear1.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
			imageview2.setColorFilter(0xFFEEEEEE, PorterDuff.Mode.MULTIPLY);
			imageview3.setColorFilter(0xFFEEEEEE, PorterDuff.Mode.MULTIPLY);
			imageview5.setColorFilter(0xFFEEEEEE, PorterDuff.Mode.MULTIPLY);
			_gd(linear3, "#FFFFFF", "#EEEEEE", 5);
			_gd(linear4, "#FFFFFF", "#EEEEEE", 5);
			_gd(linear6, "#FFFFFF", "#EEEEEE", 5);
			_gd(linear7, "#FFFFFF", "#EEEEEE", 5);
			_Shadow(5, 5, "#00BCD4", button1);
			_Shadow(5, 5, "#00ACC1", button2);
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				Profile = _filePath.get((int)(0));
				ProfileName = Uri.parse(Profile).getLastPathSegment();
				FileUtil.resizeBitmapFileToCircle(Profile, FileUtil.getExternalStorageDir().concat("/".concat("Telme").concat("/".concat(".avatar".concat("/".concat(ProfileName))))));
				profile.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(FileUtil.getExternalStorageDir().concat("/".concat("Telme").concat("/".concat(".avatar".concat("/".concat(ProfileName))))), 1024, 1024));
				choose_profile = 1;
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	private void _changeActivityFont (final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				}
				else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					}
					else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	private void _gd (final View _view, final String _c, final String _sc, final double _r) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		
		gd.setColor(Color.parseColor(_c));
		gd.setCornerRadius((float)_r);
		gd.setStroke(2, Color.parseColor(_sc));
		
		_view.setBackground(gd);
	}
	
	
	private void _Shadow (final double _sadw, final double _cru, final String _wc, final View _widgets) {
		android.graphics.drawable.GradientDrawable wd = new android.graphics.drawable.GradientDrawable();
		wd.setColor(Color.parseColor(_wc));
		wd.setCornerRadius((int)_cru);
		_widgets.setElevation((int)_sadw);
		_widgets.setBackground(wd);
	}
	
	
	private void _SetStatusBarColor (final String _color) {
		Window w = this.getWindow();w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(Color.parseColor(_color));
	}
	
	
	private void _curcle_igm_url (final String _url, final ImageView _img_view) {
		_img_view
		Glide.with(getApplicationContext()).load(_url).asBitmap().centerCrop().into(new com.bumptech.glide.request.target.BitmapImageViewTarget(_img_view) {
			@Override protected void setResource(Bitmap resource) {
				android.support.v4.graphics.drawable.RoundedBitmapDrawable circularBitmapDrawable = android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory.create(getApplicationContext().getResources(), resource); circularBitmapDrawable.setCircular(true); _img_view.setImageDrawable(circularBitmapDrawable);
			}
		});
	}
	
	
	private void _SnackBar (final String _Text) {
		ViewGroup layout=(ScrollView)((ScrollView)this .findViewById(R.id.vscroll1));
		android.support.design.widget.Snackbar.make(layout, _Text, android.support.design.widget.Snackbar.LENGTH_LONG) 
		        .setAction("OK", new View.OnClickListener() {
			            @Override 
			            public void onClick(View view) {
				
				            } 
			        }).show();
	}
	
	
	private void _Prog_Dialogue_show (final boolean _ifShow, final String _title, final String _message) {
		if (_ifShow) {
			if (prog == null){
				prog = new ProgressDialog(this);
				prog.setMax(100);
				prog.setIndeterminate(true);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
			}
			prog.setMessage(_message);
			prog.show();
		}
		else {
			if (prog != null){
				prog.dismiss();
			}
		}
	}
	private ProgressDialog prog;
	{
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
