package com.my.newproject23;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.widget.LinearLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.BaseAdapter;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.app.Activity;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.AdapterView;
import com.google.gson.Gson;
import android.net.Uri;
import java.text.DecimalFormat;
import com.google.gson.reflect.TypeToken;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private FloatingActionButton _fab;
	private DrawerLayout _drawer;
	private double num1 = 0;
	private double num2 = 0;
	private double num3 = 0;
	private double y1 = 0;
	private double y2 = 0;
	private double x1 = 0;
	private double x2 = 0;
	private double searchnum = 0;
	private HashMap<String, Object> map = new HashMap<>();
	private String currentfile = "";
	private double songPosition = 0;
	private String smin = "";
	private String ssec = "";
	private String albums = "";
	
	private ArrayList<String> b = new ArrayList<>();
	private ArrayList<String> list1 = new ArrayList<>();
	private ArrayList<String> list2 = new ArrayList<>();
	private ArrayList<String> list3 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> Listmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> searchmap = new ArrayList<>();
	
	private LinearLayout linear1;
	private WebView webview1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear7;
	private LinearLayout linear9;
	private ImageView imageview1;
	private ImageView imageview2;
	private TextView textview1;
	private EditText edittext1;
	private ImageView imageview3;
	private ImageView imageview4;
	private Spinner spinner1;
	private ListView listview4;
	private LinearLayout linear20;
	private ProgressBar progressbar1;
	private LinearLayout linear4;
	private LinearLayout linear13;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private ImageView imageview7;
	private TextView textview3;
	private ImageView imageview5;
	private TextView textview2;
	private ImageView imageview6;
	private LinearLayout linear16;
	private ImageView imageview9;
	private TextView textview4;
	private ImageView imageview11;
	private ImageView imageview12;
	private ImageView imageview13;
	private TextView textview5;
	private ImageView imageview10;
	private SeekBar seekbar1;
	private ImageView imageview14;
	
	private AlertDialog.Builder back_dial;
	private ObjectAnimator anim = new ObjectAnimator();
	private SharedPreferences sf;
	private MediaPlayer mp;
	private TimerTask t002;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_fab = (FloatingActionButton) findViewById(R.id._fab);
		
		_drawer = (DrawerLayout) findViewById(R.id._drawer);ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(MainActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view);
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview1 = (TextView) findViewById(R.id.textview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		listview4 = (ListView) findViewById(R.id.listview4);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		textview3 = (TextView) findViewById(R.id.textview3);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview2 = (TextView) findViewById(R.id.textview2);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		imageview9 = (ImageView) findViewById(R.id.imageview9);
		textview4 = (TextView) findViewById(R.id.textview4);
		imageview11 = (ImageView) findViewById(R.id.imageview11);
		imageview12 = (ImageView) findViewById(R.id.imageview12);
		imageview13 = (ImageView) findViewById(R.id.imageview13);
		textview5 = (TextView) findViewById(R.id.textview5);
		imageview10 = (ImageView) findViewById(R.id.imageview10);
		seekbar1 = (SeekBar) findViewById(R.id.seekbar1);
		imageview14 = (ImageView) findViewById(R.id.imageview14);
		back_dial = new AlertDialog.Builder(this);
		sf = getSharedPreferences("sf", Activity.MODE_PRIVATE);
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_drawer.openDrawer(GravityCompat.START);
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				imageview1.setVisibility(View.VISIBLE);
				imageview2.setVisibility(View.GONE);
				textview1.setVisibility(View.VISIBLE);
				edittext1.setVisibility(View.GONE);
				imageview3.setVisibility(View.GONE);
				imageview4.setVisibility(View.VISIBLE);
				edittext1.getText().clear();
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				_search_word(_charSeq, "1", Listmap);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				textview1.setVisibility(View.VISIBLE);
				edittext1.setVisibility(View.GONE);
				imageview1.setVisibility(View.VISIBLE);
				imageview2.setVisibility(View.GONE);
				imageview3.setVisibility(View.GONE);
				imageview4.setVisibility(View.VISIBLE);
				edittext1.getText().clear();
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				imageview1.setVisibility(View.GONE);
				imageview2.setVisibility(View.VISIBLE);
				textview1.setVisibility(View.GONE);
				edittext1.setVisibility(View.VISIBLE);
				imageview4.setVisibility(View.GONE);
				imageview3.setVisibility(View.VISIBLE);
			}
		});
		
		listview4.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (songPosition == -1) {
					_MPcreate(_position);
					_Mpstart();
				}
				else {
					if (_position == songPosition) {
						if (mp.isPlaying()) {
							_MPpause();
						}
						else {
							_Mpstart();
						}
					}
					else {
						if (mp.isPlaying()) {
							_MPpause();
						}
						mp.reset();
						mp.release();
						_MPcreate(_position);
						_Mpstart();
					}
				}
			}
		});
		
		imageview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (mp.isPlaying()) {
					_MPpause();
				}
				else {
					_Mpstart();
				}
			}
		});
		
		imageview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_drawer.openDrawer(GravityCompat.START);
			}
		});
		
		imageview11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mp.reset();
				mp.release();
				_MPcreate(songPosition - 1);
				_Mpstart();
			}
		});
		
		imageview12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (mp.isPlaying()) {
					_MPpause();
				}
				else {
					_Mpstart();
				}
			}
		});
		
		imageview13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mp.reset();
				mp.release();
				_MPcreate(songPosition + 1);
				_Mpstart();
			}
		});
		
		imageview10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (mp.isLooping()) {
					mp.setLooping(false);
					imageview10.setImageResource(R.drawable.repeat_all);
				}
				else {
					mp.setLooping(true);
					imageview10.setImageResource(R.drawable.repeat1);
				}
			}
		});
		
		seekbar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged (SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				if (mp!=null) {
					mp.seekTo((int)(seekbar1.getProgress()));
				}
			}
		});
	}
	private void initializeLogic() {
		_circular_linear(linear16, 12, "#eceff1");
		linear16.setElevation(10);
		_KeepScreenON(true);
		progressbar1.setVisibility(View.GONE);
		_transparent_status();
		_Get_all_files_type(".mp3");
		_spinner();
		songPosition = -1;
		if (sf.getString("save", "").equals("")) {
			(new GetSongsTask()).execute();
		}
		else {
			Listmap = new Gson().fromJson(sf.getString("save", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			_MPcreate(0);
			listview4.setAdapter(new Listview4Adapter(Listmap));
			((BaseAdapter)listview4.getAdapter()).notifyDataSetChanged();
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		}
		else {
			_exit_dialogue();
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		getSupportActionBar().hide();
		_fab.getContentBackground().setColorFilter(Color.TRANSPARENT,PorterDuff.Mode.SRC_IN);
		_fab.setCompatElevation(0);
		progressbar1.setIndeterminateDrawable(new ChromeFloatingCirclesDrawable.Builder(this).colors(new int[]{0xFFC93437, 0xFF375BF1, 0xFFF7D23E, 0xFF34A350}).build());
		imageview2.setVisibility(View.GONE);
		imageview3.setVisibility(View.GONE);
		edittext1.setVisibility(View.GONE);
		textview1.setTextSize((float)27);
	}
	private void _transparent_status () {
		getWindow().getDecorView().setSystemUiVisibility( View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
		
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w = this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			w.setStatusBarColor(Color.parseColor("#33000000"));
		}
		imageview5.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview10.setColorFilter(0xFFCFD8DC, PorterDuff.Mode.MULTIPLY);
		imageview11.setColorFilter(0xFFCFD8DC, PorterDuff.Mode.MULTIPLY);
		imageview13.setColorFilter(0xFFCFD8DC, PorterDuff.Mode.MULTIPLY);
		imageview14.setColorFilter(0xFFCFD8DC, PorterDuff.Mode.MULTIPLY);
		imageview11.setVisibility(View.INVISIBLE);
		imageview13.setVisibility(View.INVISIBLE);
		linear4.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View p1, MotionEvent p2){
				switch(p2.getAction()) {
					case MotionEvent.ACTION_DOWN: 
					y1 = p2.getY();
					x1 = p2.getX();
					break;
					case MotionEvent.ACTION_UP: 
					y2 = p2.getY();
					x2 = p2.getX();
					
					
					//Create Number Variable y1, y2, x1, x2
					if ( (((y1 - y2) < -250)) ) {
						linear11.setVisibility(View.GONE);
						linear10.setVisibility(View.VISIBLE);
						listview4.setVisibility(View.VISIBLE);
						_fab.setVisibility(View.VISIBLE);
						SketchwareUtil.showMessage(getApplicationContext(), "down done");
						anim.setTarget(linear3);
						anim.setPropertyName("translationY");
						anim.setFloatValues((float)(-178));
						anim.setDuration((int)(250));
						anim.start();
					}
					else {
						if ((((y2 - y1) < -250))) {
							linear10.setVisibility(View.GONE);
							linear11.setVisibility(View.VISIBLE);
							listview4.setVisibility(View.GONE);
							_fab.setVisibility(View.GONE);
							SketchwareUtil.showMessage(getApplicationContext(), "up done");
							anim.setTarget(linear3);
							anim.setPropertyName("translationY");
							anim.setFloatValues((float)(Double.parseDouble("-".concat(String.valueOf((long)(SketchwareUtil.getDisplayHeightPixels(getApplicationContext())))))));
							anim.setDuration((int)(250));
							anim.start();
						}
					}
					break;
				}
				return true;
			}});
	}
	
	
	private void _exit_dialogue () {
		back_dial.setTitle("Do you want to exit application ?");
		back_dial.setMessage("click yes to exit");
		back_dial.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finishAffinity();
				int pid = android.os.Process.myPid();
				android.os.Process.killProcess(pid); 
			}
		});
		back_dial.setNegativeButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				SketchwareUtil.showMessage(getApplicationContext(), "give feedback");
			}
		});
		back_dial.setNeutralButton("Go back", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				webview1.goBack();
			}
		});
		back_dial.create().show();
	}
	
	
	private void _Get_all_files_type (final String _Type) {
		FileUtil.listDir(FileUtil.getExternalStorageDir(), list1);
		num1 = -1;
		for(int _repeat13 = 0; _repeat13 < (int)(list1.size()); _repeat13++) {
			num1++;
			if (list1.get((int)(num1)).endsWith(_Type)) {
				list2.add(list1.get((int)(num1)));
			}
			else {
				if (FileUtil.isDirectory(list1.get((int)(num1)))) {
					FileUtil.listDir(list1.get((int)(num1)), list3);
					num2 = -1;
					for(int _repeat32 = 0; _repeat32 < (int)(list3.size()); _repeat32++) {
						num2++;
						if (list3.get((int)(num2)).endsWith(_Type)) {
							list2.add(list3.get((int)(num2)));
						}
					}
				}
			}
		}
		num3 = -1;
		for(int _repeat45 = 0; _repeat45 < (int)(list2.size()); _repeat45++) {
			num3++;
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("1", list2.get((int)(num3)));
				Listmap.add(_item);
			}
			
		}
	}
	
	
	private void _circular_linear (final View _view, final double _stroke, final String _color) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
		 gd.setStroke((int) _stroke, Color.parseColor(_color));
		gd.setShape(android.graphics.drawable.GradientDrawable.OVAL);
		 _view.setBackground(gd);
	}
	
	
	private void _cust_spinner (final Spinner _spin) {
		String[] countryNames={"Sort Ascendingly","Sort Descendingly"};
		int flags[] = {R.drawable.icon1, R.drawable.icon2};
		CustomAdapter customAdapter=new CustomAdapter(getApplicationContext(),flags,countryNames);
		_spin.setAdapter(customAdapter);
		
	}
	public class CustomAdapter extends BaseAdapter {
		Context context;
		int flags[];
		String[] countryNames;
		LayoutInflater inflter;
		public CustomAdapter(Context applicationContext, int[] flags, String[] countryNames) {
			this.context = applicationContext;
			this.flags = flags;
			this.countryNames = countryNames;
			inflter = (LayoutInflater.from(applicationContext));
		}
		
		@Override
		public int getCount() {
			return flags.length;
		}
		@Override
		public Object getItem(int i) {
			return null;
		}
		@Override public long getItemId(int i) {
			return 0;
		}
		@Override
		public View getView(int i, View view, ViewGroup viewGroup) {
			view = inflter.inflate(R.layout.cust_spinner, null); 
			ImageView icon = (ImageView) view.findViewById(R.id.imageview1);
			TextView names = (TextView) view.findViewById(R.id.textview1); 
			icon.setImageResource(flags[i]); 
			names.setText(countryNames[i]);
			return view;
		}
		
		//Create Custom with custom.xml name
		//add imageview1 and textview1
	}
	
	
	private void _spinner () {
		_cust_spinner(spinner1);
	}
	
	
	private void _extra () {
	}
	
	private class GetSongsTask extends AsyncTask<Void, Void, Void> {
		
		@Override
		protected void onPreExecute() {
			progressbar1.setVisibility(View.VISIBLE);
		}
		
		@Override
		protected Void doInBackground(Void... path) {
			sf.edit().putString("save", new Gson().toJson(Listmap)).commit();
			return null;
		}
		
		 @Override
		protected void onProgressUpdate(Void... values) {
		}
		
		@Override
		protected void onPostExecute(Void param){
			progressbar1.setVisibility(View.GONE);
			listview4.setAdapter(new Listview4Adapter(Listmap));
			((BaseAdapter)listview4.getAdapter()).notifyDataSetChanged();
			SketchwareUtil.showMessage(getApplicationContext(), String.valueOf((long)(Listmap.size())).concat(" Songs Added"));
		}
	}
	
	
	private void _search_word (final String _word, final String _key, final ArrayList<HashMap<String, Object>> _listmap) {
		searchmap.clear();
		if (_word.equals("")) {
			listview4.setAdapter(new Listview4Adapter(_listmap));
		}
		else {
			searchnum = 0;
			for(int _repeat16 = 0; _repeat16 < (int)(Listmap.size()); _repeat16++) {
				map = new HashMap<>();
				map = _listmap.get((int)searchnum);
				if (map.get(_key).toString().toLowerCase().contains(_word.toLowerCase())) {
					searchmap.add(map);
				}
				searchnum++;
			}
			listview4.setAdapter(new Listview4Adapter(searchmap));
		}
	}
	
	
	private void _MPcreate (final double _pos) {
		currentfile = Listmap.get((int)_pos).get("1").toString();
		textview3.setText(Uri.parse(currentfile).getLastPathSegment());
		textview2.setText(Uri.parse(currentfile).getLastPathSegment());
		MediaMetadataRetriever retriever = new MediaMetadataRetriever(); 
		retriever.setDataSource(currentfile); 
		byte[] art = retriever.getEmbeddedPicture(); 
		if( art != null ){ 
			Bitmap bitmap = BitmapFactory.decodeByteArray(art,0,art.length); 
			androidx.core.graphics.drawable.RoundedBitmapDrawable rbd = androidx.core.graphics.drawable.RoundedBitmapDrawableFactory.create(getResources(), bitmap); 
			rbd.setCircular(true); 
			imageview9.setImageDrawable(rbd); 
		} else { 
			imageview9.setImageResource(R.drawable.mon); 
		}
		
		MediaMetadataRetriever retriever1 = new MediaMetadataRetriever(); 
		retriever1.setDataSource(currentfile); 
		byte[] art1 = retriever1.getEmbeddedPicture(); 
		if( art != null ){ 
			Bitmap bitmap = BitmapFactory.decodeByteArray(art,0,art.length); 
			androidx.core.graphics.drawable.RoundedBitmapDrawable rbd = androidx.core.graphics.drawable.RoundedBitmapDrawableFactory.create(getResources(), bitmap); 
			rbd.setCircular(true); 
			_fab.setImageDrawable(rbd); 
		} else { 
			_fab.setImageResource(R.drawable.mon); 
		}
		songPosition = _pos;
		mp = MediaPlayer.create(getApplicationContext(), Uri.fromFile(new java.io.File(currentfile)));
		mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { public void onCompletion(MediaPlayer mp) {  _MPpause();
				mp.reset();
				mp.release();
				songPosition = songPosition + 1;
				if (songPosition < Listmap.size()) {
					_MPcreate(songPosition);
					_Mpstart();
				}   } });
		seekbar1.setMax((int)mp.getDuration());
		smin = new DecimalFormat("00").format((mp.getDuration() / 1000) / 60);
		ssec = new DecimalFormat("00").format((mp.getDuration() / 1000) % 60);
		textview5.setText(smin.concat(":".concat(ssec)));
	}
	
	
	private void _MPpause () {
		mp.pause();
		imageview7.setImageResource(R.drawable.play);
		imageview12.setImageResource(R.drawable.play);
	}
	
	
	private void _Mpstart () {
		mp.start();
		imageview7.setImageResource(R.drawable.pause);
		imageview12.setImageResource(R.drawable.pause);
		imageview11.setVisibility(View.VISIBLE);
		imageview13.setVisibility(View.VISIBLE);
		t002 = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						seekbar1.setProgress((int)mp.getCurrentPosition() + 1);
						textview4.setText(new DecimalFormat("00").format((mp.getCurrentPosition() / 1000) / 60).concat(":".concat(new DecimalFormat("00").format((mp.getCurrentPosition() / 1000) % 60))));
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t002, (int)(400), (int)(400));
	}
	
	
	private void _KeepScreenON (final boolean _True) {
		if (_True) {
			
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		}
		else {
			getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		}
	}
	
	
	private void _fab_rotation () {
		
	}
	
	
	private void _progress_anime () {
	}
	public static class GoogleProgressBar extends ProgressBar {
			public static int _type = 0;
			public static int[] _color = new int[]{0xFFC93437, 0xFF375BF1, 0xFFF7D23E, 0xFF34A350}; //Red, blue, yellow, green
		    private enum ProgressType {
			        FOLDING_CIRCLES,
			        GOOGLE_MUSIC_DICES,
			        NEXUS_ROTATION_CROSS,
			        CHROME_FLOATING_CIRCLES
			    }
		    public GoogleProgressBar(Context context) {
			        this(context, null);
			    }
		    public GoogleProgressBar(Context context, AttributeSet attrs) {
			        this(context, attrs,android.R.attr.progressBarStyle);
			    }
		    public GoogleProgressBar(Context context, AttributeSet attrs, int defStyle) {
			        super(context, attrs, defStyle);
			        if (isInEditMode())
			            return;
			        final int typeIndex = _type;
					final int[] colorsId = _color;
			        android.graphics.drawable.Drawable drawable = buildDrawable(context,typeIndex,colorsId);
			        if(drawable!=null)
			        setIndeterminateDrawable(drawable);
			    }
		    private android.graphics.drawable.Drawable buildDrawable(Context context, int typeIndex,int[] colorsId) {
			        android.graphics.drawable.Drawable drawable = null;
			        ProgressType type = ProgressType.values()[typeIndex];
			        switch (type){
				            case FOLDING_CIRCLES:
				                drawable = new FoldingCirclesDrawable.Builder(context).colors(colorsId).build();
				                break;
				            case GOOGLE_MUSIC_DICES:
				                drawable = new GoogleMusicDicesDrawable.Builder().build();
				                break;
				            case NEXUS_ROTATION_CROSS:
				                drawable = new NexusRotationCrossDrawable.Builder(context).colors(colorsId).build();
				                break;
				            case CHROME_FLOATING_CIRCLES:
				                drawable = new ChromeFloatingCirclesDrawable.Builder(context).colors(colorsId).build();
				                break;
				        }
			        return drawable;
			    }
		    public static void setType(int types) {
			    	_type = types;
			    }
		    public static void setColor(int[] colors) {
			    	_color = colors;
			    }
	}
	
	
	public static class NexusRotationCrossDrawable extends android.graphics.drawable.Drawable implements android.graphics.drawable.Drawable.Callback {
		    private static int ANIMATION_DURATION = 150;
		    private static int ANIMATION_START_DELAY = 300;
		    private static final android.view.animation.Interpolator LINEAR_INTERPOLATOR = new LinearInterpolator();
		    private int mCenter;
		    private Point[] mArrowPoints;
		    private Path mPath;
		    private Paint mPaint1;
		    private Paint mPaint2;
		    private Paint mPaint3;
		    private Paint mPaint4;
		    private int mRotationAngle;
		    public NexusRotationCrossDrawable(int[] colors) {
			        mArrowPoints = new Point[5];
			        mPath = new Path();
			        mPaint1 = new Paint(Paint.ANTI_ALIAS_FLAG);
			        mPaint1.setColor(colors[0]);
			        mPaint2 = new Paint(Paint.ANTI_ALIAS_FLAG);
			        mPaint2.setColor(colors[1]);
			        mPaint3 = new Paint(Paint.ANTI_ALIAS_FLAG);
			        mPaint3.setColor(colors[2]);
			        mPaint4 = new Paint(Paint.ANTI_ALIAS_FLAG);
			        mPaint4.setColor(colors[3]);
			        initObjectAnimator();
			    }
		    private void initObjectAnimator() {
			        final ObjectAnimator objectAnimator = ObjectAnimator.ofInt(this, "rotationAngle", 0, 180);
			        objectAnimator.setInterpolator(LINEAR_INTERPOLATOR);
			        objectAnimator.setDuration(ANIMATION_DURATION);
			        objectAnimator.addListener(new AnimatorListenerAdapter() {
				            @Override
				            public void onAnimationEnd(Animator animation) {
					                if (mRotationAngle == 180) {
						                    objectAnimator.setIntValues(180, 360);
						                    objectAnimator.setStartDelay(ANIMATION_START_DELAY * 2);
						                } else {
						                    objectAnimator.setIntValues(0, 180);
						                    objectAnimator.setStartDelay(ANIMATION_START_DELAY);
						                    mRotationAngle = 0;
						                }
					                objectAnimator.start();
					            }
				        });
			        objectAnimator.start();
			    }
		    @Override
		    public void draw(Canvas canvas) {
			        drawArrows(canvas);
			    }
		    private void drawArrows(Canvas canvas) {
			        canvas.rotate(mRotationAngle, mCenter, mCenter);
			        mPath.reset();
			        mPath.moveTo(mArrowPoints[0].x, mArrowPoints[0].y);
			        for (int i = 1; i < mArrowPoints.length; i++) {
				            mPath.lineTo(mArrowPoints[i].x, mArrowPoints[i].y);
				        }
			        mPath.lineTo(mArrowPoints[0].x, mArrowPoints[0].y);
			        canvas.save();
			        canvas.drawPath(mPath, mPaint1);
			        canvas.restore();
			        canvas.save();
			        canvas.rotate(90, mCenter, mCenter);
			        canvas.drawPath(mPath, mPaint2);
			        canvas.restore();
			        canvas.save();
			        canvas.rotate(180, mCenter, mCenter);
			        canvas.drawPath(mPath, mPaint3);
			        canvas.restore();
			        canvas.save();
			        canvas.rotate(270, mCenter, mCenter);
			        canvas.drawPath(mPath, mPaint4);
			        canvas.restore();
			    }
		    @Override
		    public void invalidateDrawable(android.graphics.drawable.Drawable who) {
			        final Callback callback = getCallback();
			        if (callback != null) {
				            callback.invalidateDrawable(this);
				        }
			    }
		    @Override
		    public void scheduleDrawable(android.graphics.drawable.Drawable who, Runnable what, long when) {
			        final Callback callback = getCallback();
			        if (callback != null) {
				            callback.scheduleDrawable(this, what, when);
				        }
			    }
		    @Override
		    public void unscheduleDrawable(android.graphics.drawable.Drawable who, Runnable what) {
			        final Callback callback = getCallback();
			        if (callback != null) {
				            callback.unscheduleDrawable(this, what);
				        }
			    }
		    @Override
		    public void setAlpha(int alpha) {
			        mPaint1.setAlpha(alpha);
			        mPaint2.setAlpha(alpha);
			        mPaint3.setAlpha(alpha);
			        mPaint4.setAlpha(alpha);
			    }
		    @Override
		    public void setColorFilter(ColorFilter cf) {
			        mPaint1.setColorFilter(cf);
			        mPaint2.setColorFilter(cf);
			        mPaint3.setColorFilter(cf);
			        mPaint4.setColorFilter(cf);
			    }
		    @Override
		    protected void onBoundsChange(Rect bounds) {
			        super.onBoundsChange(bounds);
			        measureDrawable(bounds);
			    }
		    private void measureDrawable(Rect bounds) {
			        mCenter = bounds.centerX();
			        int arrowMargin = bounds.width() / 50;
			        int arrowWidth = bounds.width() / 15;
			        int padding = mCenter - (int) (mCenter /  Math.sqrt(2));
			        mArrowPoints[0] = new Point(mCenter - arrowMargin, mCenter - arrowMargin);
			        mArrowPoints[1] = new Point(mArrowPoints[0].x, mArrowPoints[0].y - arrowWidth);
			        mArrowPoints[2] = new Point(padding + arrowWidth, padding);
			        mArrowPoints[3] = new Point(padding, padding + arrowWidth);
			        mArrowPoints[4] = new Point(mArrowPoints[0].x - arrowWidth, mArrowPoints[0].y);
			    }
		    @Override
		    public int getOpacity() {
			        return PixelFormat.TRANSLUCENT;
			    }
		    void setRotationAngle(int angle) {
			        mRotationAngle = angle;
			    }
		    int getRotationAngle() {
			        return mRotationAngle;
			    }
		    public static class Builder {
			        private int[] mColors;
			        public Builder(Context context) {
				            initDefaults(context);
				        }
			        
			        private void initDefaults(Context context) {
				            mColors = new int[]{0xFFC93437, 0xFF375BF1, 0xFFF7D23E, 0xFF34A350}; //Red, blue, yellow, green
				        }
			        
			        public Builder colors(int[] colors) {
				            if (colors == null || colors.length != 4) {
					                throw new IllegalArgumentException("Your color array must contains 4 values");
					            }
				            mColors = colors;
				            return this;
				        }
			        public android.graphics.drawable.Drawable build() {
				            return new NexusRotationCrossDrawable(mColors);
				        }
			    }
	}
	
	
	public static class GoogleMusicDicesDrawable extends android.graphics.drawable.Drawable implements android.graphics.drawable.Drawable.Callback {
		    private static final int DICE_SIDE_COLOR = Color.parseColor("#FFDBDBDB");
		    private static final int DICE_SIDE_SHADOW_COLOR = Color.parseColor("#FFB8B8B9");
		    private static final int ANIMATION_DURATION = 350;
		    private static final int ANIMATION_START_DELAY = 150;
		    private static final android.view.animation.Interpolator ACCELERATE_INTERPOLATOR = new AccelerateInterpolator();
		    private Paint mPaint;
		    private Paint mPaintShadow;
		    private Paint mPaintCircle;
		    private int mSize;
		    private float mScale;
		    private DiceRotation mDiceRotation;
		    private DiceState[] mDiceStates;
		    private int mDiceState;
		    private enum DiceSide {
			        ONE,
			        TWO,
			        THREE,
			        FOUR,
			        FIVE,
			        SIX
			    }
		    private enum DiceRotation {
			        LEFT,
			        DOWN;
			
			        DiceRotation invert() {
				            return this == LEFT ? DOWN : LEFT;
				        }
			    }
		    private class DiceState {
			        private DiceSide side1;
			        private DiceSide side2;
			        DiceState(DiceSide side1, DiceSide side2) {
				            this.side1 = side1;
				            this.side2 = side2;
				        }
			    }
		    public GoogleMusicDicesDrawable() {
			        init();
			    }
		    private void init() {
			        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
			        mPaint.setColor(DICE_SIDE_COLOR);
			        mPaintShadow = new Paint(Paint.ANTI_ALIAS_FLAG);
			        mPaintShadow.setColor(DICE_SIDE_SHADOW_COLOR);
			        mPaintCircle = new Paint(Paint.ANTI_ALIAS_FLAG);
			        mPaintCircle.setColor(Color.WHITE);
			        mDiceStates = new DiceState[] {
				                new DiceState(DiceSide.ONE, DiceSide.THREE),
				                new DiceState(DiceSide.TWO, DiceSide.THREE),
				                new DiceState(DiceSide.TWO, DiceSide.SIX),
				                new DiceState(DiceSide.FOUR, DiceSide.SIX),
				                new DiceState(DiceSide.FOUR, DiceSide.FIVE),
				                new DiceState(DiceSide.ONE, DiceSide.FIVE)
				        };
			        mDiceRotation = DiceRotation.LEFT;
			        initObjectAnimator();
			    }
		    private void initObjectAnimator() {
			        final ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(this, "scale", 0, 1);
			        objectAnimator.setInterpolator(ACCELERATE_INTERPOLATOR);
			        objectAnimator.setDuration(ANIMATION_DURATION);
			        objectAnimator.setStartDelay(ANIMATION_START_DELAY);
			        objectAnimator.addListener(new AnimatorListenerAdapter() {
				            @Override
				            public void onAnimationEnd(Animator animation) {
					                mScale = 0;
					                mDiceState++;
					                if (mDiceState == mDiceStates.length) {
						                    mDiceState = 0;
						                }
					                mDiceRotation = mDiceRotation.invert();
					                objectAnimator.start();
					            }
				        });
			        objectAnimator.start();
			    }
		    @Override
		    public void draw(Canvas canvas) {
			        if (mDiceRotation != null) {
				            switch (mDiceRotation) {
					                case DOWN:
					                    drawScaleY(canvas);
					                    break;
					                case LEFT:
					                    drawScaleX(canvas);
					                    break;
					            }
				        }
			    }
		    @Override
		    public void setAlpha(int alpha) {
			        mPaint.setAlpha(alpha);
			        mPaintShadow.setAlpha(alpha);
			        mPaintCircle.setAlpha(alpha);
			    }
		    @Override
		    public void setColorFilter(ColorFilter cf) {
			        mPaint.setColorFilter(cf);
			        mPaintShadow.setColorFilter(cf);
			        mPaintCircle.setColorFilter(cf);
			    }
		    @Override
		    public int getOpacity() {
			        return PixelFormat.TRANSLUCENT;
			    }
		    @Override
		    protected void onBoundsChange(Rect bounds) {
			        super.onBoundsChange(bounds);
			        mSize = bounds.width();
			    }
		    @Override
		    public void invalidateDrawable(android.graphics.drawable.Drawable who) {
			        final Callback callback = getCallback();
			        if (callback != null) {
				            callback.invalidateDrawable(this);
				        }
			    }
		    @Override
		    public void scheduleDrawable(android.graphics.drawable.Drawable who, Runnable what, long when) {
			        final Callback callback = getCallback();
			        if (callback != null) {
				            callback.scheduleDrawable(this, what, when);
				        }
			    }
		    @Override
		    public void unscheduleDrawable(android.graphics.drawable.Drawable who, Runnable what) {
			        final Callback callback = getCallback();
			        if (callback != null) {
				            callback.unscheduleDrawable(this, what);
				        }
			    }
		    private void drawScaleX(Canvas canvas) {
			        canvas.save();
			        Matrix matrix = new Matrix();
			        matrix.preScale(1 - mScale, 1, 0, mSize / 2);
			        canvas.concat(matrix);
			        drawDiceSide(canvas, mDiceStates[mDiceState].side1, mScale > 0.1f);
			        canvas.restore();
			        canvas.save();
			        matrix = new Matrix();
			        matrix.preScale(mScale, 1, mSize, mSize / 2);
			        canvas.concat(matrix);
			        drawDiceSide(canvas, mDiceStates[mDiceState].side2, false);
			        canvas.restore();
			    }
		    private void drawScaleY(Canvas canvas) {
			        canvas.save();
			        Matrix matrix = new Matrix();
			        matrix.preScale(1, mScale, mSize / 2, 0);
			        canvas.concat(matrix);
			        drawDiceSide(canvas, mDiceStates[mDiceState].side1, false);
			        canvas.restore();
			        canvas.save();
			        matrix = new Matrix();
			        matrix.preScale(1, 1 - mScale, mSize / 2, mSize);
			        canvas.concat(matrix);
			        drawDiceSide(canvas, mDiceStates[mDiceState].side2, mScale > 0.1f);
			        canvas.restore();
			    }
		    private void drawDiceSide(Canvas canvas, DiceSide side, boolean shadow) {
			        int circleRadius = mSize / 10;
			        canvas.drawRect(0, 0, mSize, mSize, shadow ? mPaintShadow : mPaint);
			        switch (side) {
				            case ONE:
				                canvas.drawCircle(mSize / 2, mSize / 2, circleRadius, mPaintCircle);
				                break;
				            case TWO:
				                canvas.drawCircle(mSize / 4, mSize - mSize / 4, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize - mSize / 4, mSize / 4, circleRadius, mPaintCircle);
				                break;
				            case THREE:
				                canvas.drawCircle(mSize / 2, mSize / 2, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize / 4, mSize / 4, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize - mSize / 4, mSize - mSize / 4, mSize / 10, mPaintCircle);
				                break;
				            case FOUR:
				                canvas.drawCircle(mSize / 4, mSize / 4, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize / 4, mSize - mSize / 4, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize - mSize / 4, mSize - mSize / 4, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize - mSize / 4, mSize / 4, circleRadius, mPaintCircle);
				                break;
				            case FIVE:
				                canvas.drawCircle(mSize / 2, mSize / 2, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize / 4, mSize / 4, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize / 4, mSize - mSize / 4, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize - mSize / 4, mSize - mSize / 4, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize - mSize / 4, mSize / 4, circleRadius, mPaintCircle);
				                break;
				            case SIX:
				                canvas.drawCircle(mSize / 4, mSize / 4, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize / 4, mSize / 2, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize / 4, mSize - mSize / 4, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize - mSize / 4, mSize / 4, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize - mSize / 4, mSize / 2, circleRadius, mPaintCircle);
				                canvas.drawCircle(mSize - mSize / 4, mSize - mSize / 4, circleRadius, mPaintCircle);
				                break;
				        }
			    }
		    float getScale() {
			        return mScale;
			    }
		    void setScale(float scale) {
			        this.mScale = scale;
			    }
		    public static class Builder {
			        public android.graphics.drawable.Drawable build() {
				            return new GoogleMusicDicesDrawable();
				        }
			    }
	}
	
	
	public static class FoldingCirclesDrawable extends android.graphics.drawable.Drawable implements android.graphics.drawable.Drawable.Callback {
		    private static final float MAX_LEVEL = 10000;
		    private static final float CIRCLE_COUNT = ProgressStates.values().length;
		    private static final float MAX_LEVEL_PER_CIRCLE = MAX_LEVEL / CIRCLE_COUNT;
		    private static final int ALPHA_OPAQUE = 255;
		    private static final int ALPHA_ABOVE_DEFAULT = 235;
		    private Paint mFstHalfPaint;
		    private Paint mScndHalfPaint;
		    private Paint mAbovePaint;
		    private RectF mOval = new RectF();
		    private int mDiameter;
		    private Path mPath;
		    private int mHalf;
		    private ProgressStates mCurrentState;
		    private int mControlPointMinimum;
		    private int mControlPointMaximum;
		    private int mAxisValue;
		    private int mAlpha = ALPHA_OPAQUE;
		    private ColorFilter mColorFilter;
		    private static int mColor1;
		    private static int mColor2;
		    private static int mColor3;
		    private static int mColor4;
		    private int fstColor, scndColor;
		    private boolean goesBackward;
		    private enum ProgressStates {
			        FOLDING_DOWN,
			        FOLDING_LEFT,
			        FOLDING_UP,
			        FOLDING_RIGHT
			    }
		    public FoldingCirclesDrawable(int[] colors) {
			        initCirclesProgress(colors);
			    }
		    private void initCirclesProgress(int[] colors) {
			        initColors(colors);
			        mPath = new Path();
			        Paint basePaint = new Paint();
			        basePaint.setAntiAlias(true);
			        mFstHalfPaint = new Paint(basePaint);
			        mScndHalfPaint = new Paint(basePaint);
			        mAbovePaint = new Paint(basePaint);
			        setAlpha(mAlpha);
			        setColorFilter(mColorFilter);
			    }
		    private void initColors(int[] colors) {
			        mColor1=colors[0];
			        mColor2=colors[1];
			        mColor3=colors[2];
			        mColor4=colors[3];
			    }
		    @Override
		    protected void onBoundsChange(Rect bounds) {
			        super.onBoundsChange(bounds);
			        measureCircleProgress(bounds.width(), bounds.height());
			    }
		    @Override
		    protected boolean onLevelChange(int level) {
			        int animationLevel = level == MAX_LEVEL ? 0 : level;
			        int stateForLevel = (int) (animationLevel / MAX_LEVEL_PER_CIRCLE);
			        mCurrentState = ProgressStates.values()[stateForLevel];
			        resetColor(mCurrentState);
			        int levelForCircle = (int) (animationLevel % MAX_LEVEL_PER_CIRCLE);
			        boolean halfPassed;
			        if (!goesBackward) {
				            halfPassed = levelForCircle != (int) (animationLevel % (MAX_LEVEL_PER_CIRCLE / 2));
				        } else {
				            halfPassed = levelForCircle == (int) (animationLevel % (MAX_LEVEL_PER_CIRCLE / 2));
				            levelForCircle = (int) (MAX_LEVEL_PER_CIRCLE - levelForCircle);
				        }
			        mFstHalfPaint.setColor(fstColor);
			        mScndHalfPaint.setColor(scndColor);
			        if (!halfPassed) {
				            mAbovePaint.setColor(mScndHalfPaint.getColor());
				        } else {
				            mAbovePaint.setColor(mFstHalfPaint.getColor());
				        }
			        setAlpha(mAlpha);
			        mAxisValue = (int) (mControlPointMinimum + (mControlPointMaximum - mControlPointMinimum) * (levelForCircle / MAX_LEVEL_PER_CIRCLE));
			        return true;
			    }
		    private void resetColor(ProgressStates currentState) {
			        switch (currentState){
				            case FOLDING_DOWN:
				                fstColor= mColor1;
				                scndColor=mColor2;
				                goesBackward=false;
				            break;
				            case FOLDING_LEFT:
				                fstColor= mColor1;
				                scndColor=mColor3;
				                goesBackward=true;
				                break;
				            case FOLDING_UP:
				                fstColor= mColor3;
				                scndColor=mColor4;
				                goesBackward=true;
				                break;
				            case FOLDING_RIGHT:
				                fstColor=mColor2;
				                scndColor=mColor4;
				                goesBackward=false;
				                break;
				        }
			    }
		    @Override
		    public void draw(Canvas canvas) {
			        if (mCurrentState != null) {
				            makeCirclesProgress(canvas);
				        }
			    }
		    private void measureCircleProgress(int width, int height) {
			        mDiameter = Math.min(width, height);
			        mHalf = mDiameter / 2;
			        mOval.set(0, 0, mDiameter, mDiameter);
			        mControlPointMinimum = -mDiameter / 6;
			        mControlPointMaximum = mDiameter + mDiameter / 6;
			    }
		    private void makeCirclesProgress(Canvas canvas) {
			        switch (mCurrentState) {
				            case FOLDING_DOWN:
				            case FOLDING_UP:
				                drawYMotion(canvas);
				                break;
				            case FOLDING_RIGHT:
				            case FOLDING_LEFT:
				                drawXMotion(canvas);
				                break;
				        }
			        canvas.drawPath(mPath, mAbovePaint);
			    }
		    private void drawXMotion(Canvas canvas) {
			        canvas.drawArc(mOval, 90, 180, true, mFstHalfPaint);
			        canvas.drawArc(mOval, -270, -180, true, mScndHalfPaint);
			        mPath.reset();
			        mPath.moveTo(mHalf, 0);
			        mPath.cubicTo(mAxisValue, 0, mAxisValue, mDiameter, mHalf, mDiameter);
			        mPath.moveTo(mHalf+1, 0);
			        mPath.cubicTo(mAxisValue, 0, mAxisValue, mDiameter, mHalf+1, mDiameter);
			    }
		    private void drawYMotion(Canvas canvas) {
			        canvas.drawArc(mOval, 0, -180, true, mFstHalfPaint);
			        canvas.drawArc(mOval, -180, -180, true, mScndHalfPaint);
			        mPath.reset();
			        mPath.moveTo(0, mHalf);
			        mPath.cubicTo(0, mAxisValue, mDiameter, mAxisValue, mDiameter, mHalf);
			        mPath.moveTo(0, mHalf+1);
			        mPath.cubicTo(0, mAxisValue, mDiameter, mAxisValue, mDiameter, mHalf+1);
			    }
		    @Override
		    public void setAlpha(int alpha) {
			        this.mAlpha = alpha;
			        mFstHalfPaint.setAlpha(alpha);
			        mScndHalfPaint.setAlpha(alpha);
			        int targetAboveAlpha = (ALPHA_ABOVE_DEFAULT * alpha) / ALPHA_OPAQUE;
			        mAbovePaint.setAlpha(targetAboveAlpha);
			    }
		    @Override
		    public void setColorFilter(ColorFilter cf) {
			        this.mColorFilter = cf;
			        mFstHalfPaint.setColorFilter(cf);
			        mScndHalfPaint.setColorFilter(cf);
			        mAbovePaint.setColorFilter(cf);
			    }
		    @Override
		    public int getOpacity() {
			        return PixelFormat.TRANSLUCENT;
			    }
		    @Override
		    public void invalidateDrawable(android.graphics.drawable.Drawable who) {
			        final Callback callback = getCallback();
			        if (callback != null) {
				            callback.invalidateDrawable(this);
				        }
			    }
		    @Override
		    public void scheduleDrawable(android.graphics.drawable.Drawable who, Runnable what, long when) {
			        final Callback callback = getCallback();
			        if (callback != null) {
				            callback.scheduleDrawable(this, what, when);
				        }
			    }
		    @Override
		    public void unscheduleDrawable(android.graphics.drawable.Drawable who, Runnable what) {
			        final Callback callback = getCallback();
			        if (callback != null) {
				            callback.unscheduleDrawable(this, what);
				        }
			    }
		    public static class Builder {
			        private int[] mColors;
			        public Builder(Context context){
				            initDefaults(context);
				        }
			        
			        private void initDefaults(Context context) {
				            //Default values
				            mColors = new int[]{0xFFC93437, 0xFF375BF1, 0xFFF7D23E, 0xFF34A350}; //Red, blue, yellow, green
				        }
			        
			        public Builder colors(int[] colors) {
				            if (colors == null || colors.length == 0) {
					                throw new IllegalArgumentException("Your color array must contains at least 4 values");
					            }
				            mColors = colors;
				            return this;
				        }
			        public android.graphics.drawable.Drawable build() {
				            return new FoldingCirclesDrawable(mColors);
				        }
			    }
	}
	
	
	public static class ChromeFloatingCirclesDrawable extends android.graphics.drawable.Drawable implements android.graphics.drawable.Drawable.Callback {
		    private static final int MAX_LEVEL = 10000;
		    private static final int CENT_LEVEL = MAX_LEVEL / 2;
		    private static final int MID_LEVEL = CENT_LEVEL / 2;
		    private static final int ALPHA_OPAQUE = 255;
		    private static final int ACCELERATION_LEVEL = 2;
		    private int mAlpha = ALPHA_OPAQUE;
		    private ColorFilter mColorFilter;
		    private Point[] mArrowPoints;
		    private Paint mPaint1;
		    private Paint mPaint2;
		    private Paint mPaint3;
		    private Paint mPaint4;
		    private double unit;
		    private int width, x_beg, y_beg, x_end, y_end, offset;
		    private int acceleration = ACCELERATION_LEVEL;
		    private double distance = 0.5 * ACCELERATION_LEVEL * MID_LEVEL * MID_LEVEL;
		    private double max_speed; // set in setAcceleration(...);
		    private double offsetPercentage;
		    private int colorSign;
		    private ProgressStates currentProgressStates = ProgressStates.GREEN_TOP;
		    private enum ProgressStates {
			        GREEN_TOP,
			        YELLOW_TOP,
			        RED_TOP,
			        BLUE_TOP
			    }
		    public ChromeFloatingCirclesDrawable(int[] colors) {
			        initCirclesProgress(colors);
			    }
		    private void initCirclesProgress(int[] colors) {
			        initColors(colors);
			        setAlpha(mAlpha);
			        setColorFilter(mColorFilter);
			        setAcceleration(ACCELERATION_LEVEL);
			        offsetPercentage = 0;
			        colorSign = 1; // |= 1, |= 2, |= 4, |= 8 --> 0xF
			    }
		
		    private void initColors(int[] colors) {
			        mPaint1 = new Paint(Paint.ANTI_ALIAS_FLAG);
			        mPaint1.setColor(colors[0]);
			        mPaint1.setAntiAlias(true);
			        mPaint2 = new Paint(Paint.ANTI_ALIAS_FLAG);
			        mPaint2.setColor(colors[1]);
			        mPaint2.setAntiAlias(true);
			        mPaint3 = new Paint(Paint.ANTI_ALIAS_FLAG);
			        mPaint3.setColor(colors[2]);
			        mPaint3.setAntiAlias(true);
			        mPaint4 = new Paint(Paint.ANTI_ALIAS_FLAG);
			        mPaint4.setColor(colors[3]);
			        mPaint4.setAntiAlias(true);
			    }
		    @Override
		    protected void onBoundsChange(Rect bounds) {
			        super.onBoundsChange(bounds);
			        measureCircleProgress(bounds.width(), bounds.height());
			    }
		    @Override
		    protected boolean onLevelChange(int level) {
			        level %= MAX_LEVEL / acceleration;
			        final int temp_level = level % (MID_LEVEL / acceleration);
			        final int ef_width = (int)(unit * 3.0); // effective width
			        if(level < CENT_LEVEL / acceleration) { // go
				            if(level < MID_LEVEL / acceleration) {
					                if(colorSign == 0xF) {
						                    changeTopColor();
						                    colorSign = 1;
						                }
					                offsetPercentage = 0.5 * acceleration * temp_level * temp_level / distance;
					                offset = (int)(offsetPercentage * ef_width / 2); // x and y direction offset
					            }
				            else {
					                colorSign |= 2;
					                // from mid to end
					                offsetPercentage = (max_speed * temp_level
					                        - 0.5 * acceleration * temp_level * temp_level) / distance
					                        + 1.0;
					                offset = (int)(offsetPercentage * ef_width / 2); // x and y direction offset
					            }
				        }
			        else { // back
				            if(level < (CENT_LEVEL + MID_LEVEL) / acceleration) {
					                // set colorSign
					                if(colorSign == 0x3) {
						                    changeTopColor();
						                    colorSign |= 4;
						                }
					                // from end to mid
					                offsetPercentage = 0.5 * acceleration * temp_level * temp_level  / distance;
					                offset = (int)(ef_width - offsetPercentage * ef_width / 2); // x and y direction offset
					            }
				            else {
					                // set colorSign
					                colorSign |= 8;
					                // from mid to beg
					                offsetPercentage = (max_speed * temp_level
					                        - 0.5 * acceleration * temp_level * temp_level) / distance
					                        + 1.0;
					                offsetPercentage = offsetPercentage == 1.0 ? 2.0 : offsetPercentage;
					                offset = (int)(ef_width - offsetPercentage * ef_width / 2); // x and y direction offset
					            }
				        }
			
			        mArrowPoints[0].set((int)unit+x_beg+offset, (int)unit+y_beg+offset); // mPaint1, left up
			        mArrowPoints[1].set((int)(unit*4.0)+x_beg-offset, (int)(unit*4.0)+y_beg-offset); // mPaint2, right down
			        mArrowPoints[2].set((int)unit+x_beg+offset, (int)(unit*4.0)+y_beg-offset); // mPaint3, left down
			        mArrowPoints[3].set((int)(unit*4.0)+x_beg-offset, (int)unit+y_beg+offset); // mPaint4, right up
			
			        return true;
			    }
		
		    private void changeTopColor() {
			        switch(currentProgressStates){
				            case GREEN_TOP:
				                currentProgressStates = ProgressStates.YELLOW_TOP;
				                break;
				            case YELLOW_TOP:
				                currentProgressStates = ProgressStates.RED_TOP;
				                break;
				            case RED_TOP:
				                currentProgressStates = ProgressStates.BLUE_TOP;
				                break;
				            case BLUE_TOP:
				                currentProgressStates = ProgressStates.GREEN_TOP;
				                break;
				        }
			    }
		
		    @Override
		    public void draw(Canvas canvas) {
			        // draw circles
			        if(currentProgressStates != ProgressStates.RED_TOP)
			            canvas.drawCircle(mArrowPoints[0].x, mArrowPoints[0].y, (float)unit, mPaint1);
			        if(currentProgressStates != ProgressStates.BLUE_TOP)
			            canvas.drawCircle(mArrowPoints[1].x, mArrowPoints[1].y, (float)unit, mPaint2);
			        if(currentProgressStates != ProgressStates.YELLOW_TOP)
			            canvas.drawCircle(mArrowPoints[2].x, mArrowPoints[2].y, (float)unit, mPaint3);
			        if(currentProgressStates != ProgressStates.GREEN_TOP)
			            canvas.drawCircle(mArrowPoints[3].x, mArrowPoints[3].y, (float)unit, mPaint4);
			
			        // draw the top one
			        switch(currentProgressStates){
				            case GREEN_TOP:
				                canvas.drawCircle(mArrowPoints[3].x, mArrowPoints[3].y, (float)unit, mPaint4);
				                break;
				            case YELLOW_TOP:
				                canvas.drawCircle(mArrowPoints[2].x, mArrowPoints[2].y, (float)unit, mPaint3);
				                break;
				            case RED_TOP:
				                canvas.drawCircle(mArrowPoints[0].x, mArrowPoints[0].y, (float)unit, mPaint1);
				                break;
				            case BLUE_TOP:
				                canvas.drawCircle(mArrowPoints[1].x, mArrowPoints[1].y, (float)unit, mPaint2);
				                break;
				        }
			    }
		
		    private void measureCircleProgress(int width, int height) {
			        // get min edge as width
			        if(width > height) {
				            // use height
				            this.width = height - 1; // minus 1 to avoid "3/2=1"
				            x_beg = (width - height) / 2 + 1;
				            y_beg = 1;
				            x_end = x_beg + this.width;
				            y_end = this.width;
				        }
			        else {
				            //use width
				            this.width = width - 1;
				            x_beg = 1;
				            y_beg = (height - width) / 2 + 1;
				            x_end = this.width;
				            y_end = y_beg + this.width;
				        }
			        unit = (double)this.width / 5.0;
			
			        // init the original position, and then set position by offsets
			        mArrowPoints = new Point[4];
			        mArrowPoints[0] = new Point((int)unit+x_beg, (int)unit+y_beg); // mPaint1, left up
			        mArrowPoints[1] = new Point((int)(unit*4.0)+x_beg, (int)(unit*4.0)+y_beg); // mPaint2, right down
			        mArrowPoints[2] = new Point((int)unit+x_beg, (int)(unit*4.0)+y_beg); // mPaint3, left down
			        mArrowPoints[3] = new Point((int)(unit*4.0)+x_beg, (int)unit+y_beg); // mPaint4, right up
			    }
		
		    public void setAcceleration(int acceleration) {
			        this.acceleration = acceleration;
			        distance = 0.5 * acceleration * (MID_LEVEL / acceleration) * (MID_LEVEL / acceleration);
			        max_speed = acceleration * (MID_LEVEL / acceleration);
			    }
		
		    @Override
		    public void setAlpha(int alpha) {
			        mPaint1.setAlpha(alpha);
			        mPaint2.setAlpha(alpha);
			        mPaint3.setAlpha(alpha);
			        mPaint4.setAlpha(alpha);
			    }
		
		    @Override
		    public void setColorFilter(ColorFilter cf) {
			        mColorFilter = cf;
			        mPaint1.setColorFilter(cf);
			        mPaint2.setColorFilter(cf);
			        mPaint3.setColorFilter(cf);
			        mPaint4.setColorFilter(cf);
			    }
		
		    @Override
		    public int getOpacity() {
			        return PixelFormat.TRANSLUCENT;
			    }
		
		    @Override
		    public void invalidateDrawable(android.graphics.drawable.Drawable who) {
			        final Callback callback = getCallback();
			        if (callback != null) {
				            callback.invalidateDrawable(this);
				        }
			    }
		
		    @Override
		    public void scheduleDrawable(android.graphics.drawable.Drawable who, Runnable what, long when) {
			        final Callback callback = getCallback();
			        if (callback != null) {
				            callback.scheduleDrawable(this, what, when);
				        }
			    }
		
		    @Override
		    public void unscheduleDrawable(android.graphics.drawable.Drawable who, Runnable what) {
			        final Callback callback = getCallback();
			        if (callback != null) {
				            callback.unscheduleDrawable(this, what);
				        }
			    }
		
		    public static class Builder {
			        private int[] mColors;
			
			        public Builder(Context context){
				            initDefaults(context);
				            return;
				        }
					
			        private void initDefaults(Context context) {
				            //Default values
				            mColors = new int[]{0xFFC93437, 0xFF375BF1, 0xFFF7D23E, 0xFF34A350}; //Red, blue, yellow, green
				            return;
				        }
					
			        public Builder colors(int[] colors) {
				            if (colors == null || colors.length == 0) {
					                throw new IllegalArgumentException("Your color array must contains at least 4 values");
					            }
				
				            mColors = colors;
				            return this;
				        }
			
			        public android.graphics.drawable.Drawable build() {
				            return new ChromeFloatingCirclesDrawable(mColors);
				        }
			    }
	}
	
	
	{
	}
	
	
	public class Listview4Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview4Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.custom, null);
			}
			
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final ImageView imageview2 = (ImageView) _v.findViewById(R.id.imageview2);
			final TextView textview2 = (TextView) _v.findViewById(R.id.textview2);
			
			Animation animation;
			animation = AnimationUtils.loadAnimation(
			                     getApplicationContext(), android.R.anim.slide_in_left
			                 );
			animation.setDuration(500); linear2.startAnimation(animation); animation = null;
			textview2.setText(Uri.parse(_data.get((int)_position).get("1").toString()).getLastPathSegment());
			_circular_linear(imageview2, 2, "#ffffff");
			albums = _data.get((int)_position).get("1").toString();
			MediaMetadataRetriever retriever = new MediaMetadataRetriever(); 
			retriever.setDataSource(albums); 
			byte[] art = retriever.getEmbeddedPicture(); 
			if( art != null ){ 
				Bitmap bitmap = BitmapFactory.decodeByteArray(art,0,art.length); 
				androidx.core.graphics.drawable.RoundedBitmapDrawable rbd = androidx.core.graphics.drawable.RoundedBitmapDrawableFactory.create(getResources(), bitmap); 
				rbd.setCircular(true); 
				imageview2.setImageDrawable(rbd); 
			} else { 
				imageview2.setImageResource(R.drawable.mon); 
			}
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
