package com.testty;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.ImageView;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private double sy_statebarsize = 0;
	private double sy_forscrolldetect = 0;
	private double sy_xd = 0;
	private double sy_xm = 0;
	private double sy_yd = 0;
	private double sy_ym = 0;
	private double sy_xu = 0;
	private double sy_yu = 0;
	private double sy_screenW = 0;
	private double sy_screenH = 0;
	private String sy_LeftOrRight = "";
	private String sy_bottom_state = "";
	private double hhshs = 0;
	
	private ArrayList<String> sy_colorList = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> test = new ArrayList<>();
	
	private HorizontalScrollView hscroll1;
	private LinearLayout bottom_sheet;
	private LinearLayout scroll_con;
	private LinearLayout leftside;
	private LinearLayout mainpage;
	private LinearLayout rightside;
	private LinearLayout left_statebar;
	private LinearLayout left_lin;
	private LinearLayout line_left;
	private ListView history_list;
	private LinearLayout left_bottom_space;
	private TextView history;
	private LinearLayout m_top;
	private LinearLayout m_bottom;
	private TextView top_text;
	private LinearLayout study_time_pan;
	private ImageView app_icon;
	private TextView app_name;
	private TextView my_name;
	private TextView hours;
	private TextView hrs;
	private TextView minutes;
	private TextView text_mins;
	private LinearLayout statistics_con;
	private LinearLayout take_test_con;
	private LinearLayout statistics_left;
	private LinearLayout line3;
	private LinearLayout statistics_right;
	private TextView total_vocabularies;
	private TextView total_vocabulary_t;
	private TextView total_assignments;
	private TextView total_assignments_t;
	private ImageView test_icon;
	private LinearLayout take_test_pan;
	private ImageView arrow;
	private TextView take_test_text;
	private LinearLayout right_statebar;
	private TextView quicklist;
	private LinearLayout line_right;
	private ListView quick_list;
	private LinearLayout right_bottom_space;
	private LinearLayout bottom_sheet_top_con;
	private LinearLayout bottom_sheet_feild;
	private LinearLayout bottom_sheet_drager;
	private LinearLayout bottom_button_con;
	private LinearLayout option1_ban;
	private LinearLayout vline2;
	private LinearLayout option2_ban;
	private LinearLayout vline;
	private LinearLayout option3_ban;
	private LinearLayout vline3;
	private LinearLayout option4_ban;
	private ImageView option1;
	private TextView option1_text;
	private ImageView option2;
	private TextView option2_text;
	private ImageView option3;
	private TextView option3_text;
	private ImageView option4;
	private TextView option4_text;
	private TextView my_subject_text;
	private ListView my_subject_list;
	
	private ObjectAnimator anim = new ObjectAnimator();
	private TimerTask timer;
	private ObjectAnimator anim1 = new ObjectAnimator();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		hscroll1 = (HorizontalScrollView) findViewById(R.id.hscroll1);
		bottom_sheet = (LinearLayout) findViewById(R.id.bottom_sheet);
		scroll_con = (LinearLayout) findViewById(R.id.scroll_con);
		leftside = (LinearLayout) findViewById(R.id.leftside);
		mainpage = (LinearLayout) findViewById(R.id.mainpage);
		rightside = (LinearLayout) findViewById(R.id.rightside);
		left_statebar = (LinearLayout) findViewById(R.id.left_statebar);
		left_lin = (LinearLayout) findViewById(R.id.left_lin);
		line_left = (LinearLayout) findViewById(R.id.line_left);
		history_list = (ListView) findViewById(R.id.history_list);
		left_bottom_space = (LinearLayout) findViewById(R.id.left_bottom_space);
		history = (TextView) findViewById(R.id.history);
		m_top = (LinearLayout) findViewById(R.id.m_top);
		m_bottom = (LinearLayout) findViewById(R.id.m_bottom);
		top_text = (TextView) findViewById(R.id.top_text);
		study_time_pan = (LinearLayout) findViewById(R.id.study_time_pan);
		app_icon = (ImageView) findViewById(R.id.app_icon);
		app_name = (TextView) findViewById(R.id.app_name);
		my_name = (TextView) findViewById(R.id.my_name);
		hours = (TextView) findViewById(R.id.hours);
		hrs = (TextView) findViewById(R.id.hrs);
		minutes = (TextView) findViewById(R.id.minutes);
		text_mins = (TextView) findViewById(R.id.text_mins);
		statistics_con = (LinearLayout) findViewById(R.id.statistics_con);
		take_test_con = (LinearLayout) findViewById(R.id.take_test_con);
		statistics_left = (LinearLayout) findViewById(R.id.statistics_left);
		line3 = (LinearLayout) findViewById(R.id.line3);
		statistics_right = (LinearLayout) findViewById(R.id.statistics_right);
		total_vocabularies = (TextView) findViewById(R.id.total_vocabularies);
		total_vocabulary_t = (TextView) findViewById(R.id.total_vocabulary_t);
		total_assignments = (TextView) findViewById(R.id.total_assignments);
		total_assignments_t = (TextView) findViewById(R.id.total_assignments_t);
		test_icon = (ImageView) findViewById(R.id.test_icon);
		take_test_pan = (LinearLayout) findViewById(R.id.take_test_pan);
		arrow = (ImageView) findViewById(R.id.arrow);
		take_test_text = (TextView) findViewById(R.id.take_test_text);
		right_statebar = (LinearLayout) findViewById(R.id.right_statebar);
		quicklist = (TextView) findViewById(R.id.quicklist);
		line_right = (LinearLayout) findViewById(R.id.line_right);
		quick_list = (ListView) findViewById(R.id.quick_list);
		right_bottom_space = (LinearLayout) findViewById(R.id.right_bottom_space);
		bottom_sheet_top_con = (LinearLayout) findViewById(R.id.bottom_sheet_top_con);
		bottom_sheet_feild = (LinearLayout) findViewById(R.id.bottom_sheet_feild);
		bottom_sheet_drager = (LinearLayout) findViewById(R.id.bottom_sheet_drager);
		bottom_button_con = (LinearLayout) findViewById(R.id.bottom_button_con);
		option1_ban = (LinearLayout) findViewById(R.id.option1_ban);
		vline2 = (LinearLayout) findViewById(R.id.vline2);
		option2_ban = (LinearLayout) findViewById(R.id.option2_ban);
		vline = (LinearLayout) findViewById(R.id.vline);
		option3_ban = (LinearLayout) findViewById(R.id.option3_ban);
		vline3 = (LinearLayout) findViewById(R.id.vline3);
		option4_ban = (LinearLayout) findViewById(R.id.option4_ban);
		option1 = (ImageView) findViewById(R.id.option1);
		option1_text = (TextView) findViewById(R.id.option1_text);
		option2 = (ImageView) findViewById(R.id.option2);
		option2_text = (TextView) findViewById(R.id.option2_text);
		option3 = (ImageView) findViewById(R.id.option3);
		option3_text = (TextView) findViewById(R.id.option3_text);
		option4 = (ImageView) findViewById(R.id.option4);
		option4_text = (TextView) findViewById(R.id.option4_text);
		my_subject_text = (TextView) findViewById(R.id.my_subject_text);
		my_subject_list = (ListView) findViewById(R.id.my_subject_list);
		
		option1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		option2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		option3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		option4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
	}
	private void initializeLogic() {
		sy_LeftOrRight = "mid";
		sy_bottom_state = "normal";
		sy_screenW = SketchwareUtil.getDisplayWidthPixels(getApplicationContext());
		_sy_getActionBarSize();
		_sy_stateBarCapacity();
		hscroll1.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() { @Override public void onGlobalLayout() { hscroll1.post(new Runnable() { @Override public void run() { 
						hscroll1.scrollTo((int)((sy_screenW/5)*3),0 );
						
					} }); } });
		_sy_hideScrollbar(hscroll1, "h");
		_setUiColor(sy_colorList);
		_setupUiSize(SketchwareUtil.getDisplayHeightPixels(getApplicationContext()), SketchwareUtil.getDisplayWidthPixels(getApplicationContext()));
		_drawers_function(SketchwareUtil.getDisplayWidthPixels(getApplicationContext()), (SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 5) * 3);
		_bottomSheet_function();
		for(int _repeat87 = 0; _repeat87 < (int)(6); _repeat87++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("io", "gg");
				test.add(_item);
			}
			
			my_subject_list.setAdapter(new My_subject_listAdapter(test));
			((BaseAdapter)my_subject_list.getAdapter()).notifyDataSetChanged();
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (sy_bottom_state.equals("open") || !sy_LeftOrRight.equals("mid")) {
			_sy_scrollviewScroll(hscroll1, "h", "to", (SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 5) * 3, 0);
			sy_LeftOrRight = "mid";
			anim.setTarget(bottom_sheet);
			anim.setPropertyName("translationY");
			anim.setFloatValues((float)(bottom_sheet.getTranslationY()), (float)(SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / -6.5d));
			anim.setDuration((int)(150));
			anim.setInterpolator(new LinearInterpolator());
			anim.start();
			anim1.setTarget(scroll_con);
			anim1.setPropertyName("alpha");
			anim1.setFloatValues((float)(scroll_con.getAlpha()), (float)(1));
			anim1.setDuration((int)(150));
			anim1.setInterpolator(new LinearInterpolator());
			anim1.start();
			sy_bottom_state = "normal";
		}
		else {
			finish();
		}
	}
	private void _sy_viewProperties (final View _v, final String _stcol, final String _encol, final String _ori, final String _ra, final double _stro, final String _strcol, final double _elv) {
		double tlr =  Double.parseDouble(_ra.substring((int)(0),(int)(2)));
		double trr = Double.parseDouble(_ra.substring((int)(2),(int)(4)));
		double brr = Double.parseDouble(_ra.substring((int)(4),(int)(6)));
		double blr = Double.parseDouble(_ra.substring((int)(6),(int)(8)));
		
		if(_encol==""){
			int[] colors = {Color.parseColor(_stcol),Color.parseColor(_stcol)};
			
			if(_ori==""){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			if(_ori=="tb"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			if(_ori=="bt"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			if(_ori=="lr"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			if(_ori=="rl"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.RIGHT_LEFT, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			
			
			
			
			
			
			if(_ori=="tlbr"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.TL_BR, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			if(_ori=="trbl"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.TR_BL, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			if(_ori=="brtl"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.BR_TL, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			if(_ori=="bltr"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.BL_TR, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
		}else{
			
			int[] colors = {Color.parseColor(_stcol),Color.parseColor(_encol)};
			
			if(_ori==""){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			if(_ori=="tb"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			if(_ori=="bt"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			if(_ori=="lr"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			if(_ori=="rl"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.RIGHT_LEFT, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			
			
			
			
			
			
			if(_ori=="tlbr"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.TL_BR, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			if(_ori=="trbl"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.TR_BL, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			if(_ori=="brtl"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.BR_TL, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
			if(_ori=="bltr"){
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.BL_TR, colors);
				gd.setCornerRadii(new float[]{(float)tlr,(float)tlr,(float)trr,(float)trr,(float)brr,(float)brr,(float)blr,(float)blr});
				gd.setStroke((int)_stro, Color.parseColor(_strcol));
				_v.setBackground(gd);
				_v.setElevation((float)_elv);
			}
			
		}
		
	}
	
	
	private void _sy_getActionBarSize () {
		sy_statebarsize = 0;
		sy_statebarsize = getStatusBarHeight();
	}
	public int getStatusBarHeight() { 
		int result = 0; 
		int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
		 if (resourceId > 0) { 
			result = getResources().getDimensionPixelSize(resourceId); 
		} return result;
		 }
	{
	}
	
	
	private void _sy_scrollviewScroll (final View _view, final String _hv, final String _orby, final double _x, final double _y) {
		if (_hv.equals("h")) {
			if (_orby.equals("to")) {
				HorizontalScrollView vvio = (HorizontalScrollView)_view;
				vvio.smoothScrollTo((int)_x,(int)_y );
			}
			else {
				HorizontalScrollView lllo = (HorizontalScrollView)_view;
				
				lllo.smoothScrollBy((int)_x,(int)_y );
			}
		}
		else {
			if (_orby.equals("to")) {
				ScrollView ioio = (ScrollView)_view;
				
				ioio.smoothScrollTo((int)_x,(int)_y );
			}
			else {
				ScrollView iojj = (ScrollView)_view;
				
				iojj.smoothScrollBy((int)_x,(int)_y );
			}
		}
	}
	
	
	private void _sy_hideScrollbar (final View _v, final String _hv) {
		if (_hv.equals("h")) {
			HorizontalScrollView ppih = (HorizontalScrollView)_v;
			ppih.setHorizontalScrollBarEnabled(false);
		}
		else {
			ScrollView ppih = (ScrollView)_v;
			ppih.setHorizontalScrollBarEnabled(false);
		}
	}
	
	
	private void _sy_activeSeekbar (final View _sb) {
		SeekBar vviu = (SeekBar)_sb;
		
		
		vviu.setOnTouchListener(new SeekBar.OnTouchListener() {
			@Override
			 public boolean onTouch(View v, MotionEvent event) {
				 int action = event.getAction(); switch (action) {
					 case MotionEvent.ACTION_DOWN: v.getParent().requestDisallowInterceptTouchEvent(true); 
					break;
					case MotionEvent.ACTION_UP: v.getParent().requestDisallowInterceptTouchEvent(false);
					 break;
				}
				v.onTouchEvent(event);
				return true; } });
	}
	
	
	private void _sy_shuffleList (final String _type, final ArrayList<Double> _n, final ArrayList<String> _s, final ArrayList<HashMap<String, Object>> _m) {
		if (_type.equals("n")) {
			Collections.shuffle(_n);
		}
		if (_type.equals("s")) {
			Collections.shuffle(_s);
		}
		if (_type.equals("m")) {
			Collections.shuffle(_m);
		}
		if (!(_type.equals("m") && (_type.equals("s") && _type.equals("n")))) {
			SketchwareUtil.showMessage(getApplicationContext(), "error found!\nshuffle list : is_n_s_m isn't correct.\nyou should write:\nn for number list\ns for string list\nm for map list");
		}
	}
	
	
	private void _sy_actionBarTitle (final String _t, final String _c) {
		getActionBar().setTitle(Html.fromHtml("<font color='"+_c+"'>" +_t + "</font>")); 
	}
	
	
	private void _sy_setBackgroundPath (final View _view, final String _path) {
		_view.setBackground(new android.graphics.drawable.BitmapDrawable(getResources(), FileUtil.decodeSampleBitmapFromPath(_path, 1024, 1024))); 
	}
	
	
	private void _sy_setStateBarColor (final String _col) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(Color.parseColor(_col));
		}
	}
	
	
	private void _sy_stateBarCapacity () {
		getWindow().setFlags( WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS );
	}
	
	
	private void _sy_setWidthAndHeight (final View _v, final double _w, final double _h) {
		if ((_w == -1) && !(_h == -1)) {
			_v.setLayoutParams(new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT,(int)_h));
		}
		if ((_h == -1) && !(_w == -1)) {
			_v.setLayoutParams(new LinearLayout.LayoutParams((int)_w,android.view.ViewGroup.LayoutParams.MATCH_PARENT));
		}
		if (!(_w == -1) && !(_h == -1)) {
			_v.setLayoutParams(new LinearLayout.LayoutParams((int)_w,(int)_h));
		}
		if ((_w == -1) && (_h == -1)) {
			_v.setLayoutParams(new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT,android.view.ViewGroup.LayoutParams.MATCH_PARENT));
		}
	}
	
	
	private void _drawers_function (final double _w, final double _ds) {
		hscroll1.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View p1, MotionEvent p2) {
				switch(p2.getAction()) {
					case MotionEvent.ACTION_DOWN:
					sy_xd = p2.getX();
					sy_yd = p2.getY();
					sy_forscrolldetect = sy_xd;
					break;
					case MotionEvent.ACTION_MOVE:
					sy_xm = p2.getX();
					sy_ym = p2.getY();
					if (sy_forscrolldetect == -1) {
						sy_forscrolldetect = sy_xm - 1;
					}
					hscroll1.scrollTo((int)(hscroll1.getScrollX()-(sy_xm-sy_forscrolldetect)),0 );
					sy_forscrolldetect = sy_xm;
					break;
					case MotionEvent.ACTION_UP:
					sy_xu = p2.getX();
					sy_yu = p2.getY();
					if (sy_xd == sy_xu) {
						_sy_scrollviewScroll(hscroll1, "h", "to", _ds, 0);
						sy_LeftOrRight = "mid";
						break;
					}
					if (sy_LeftOrRight.equals("mid")) {
						if (sy_xm < sy_xd) {
							sy_LeftOrRight = "right";
						}
						if (sy_xm > sy_xd) {
							sy_LeftOrRight = "left";
						}
					}
					else {
						if (sy_LeftOrRight.equals("right")) {
							sy_LeftOrRight = "canR";
						}
						if (sy_LeftOrRight.equals("left")) {
							sy_LeftOrRight = "canL";
						}
					}
					if (sy_LeftOrRight.equals("right")) {
						if ((hscroll1.getScrollX() < (_ds + (_ds * 0.1d))) && (hscroll1.getScrollX() > _ds)) {
							_sy_scrollviewScroll(hscroll1, "h", "to", _ds, 0);
							sy_LeftOrRight = "mid";
						}
						else {
							_sy_scrollviewScroll(hscroll1, "h", "to", _ds * 2, 0);
						}
					}
					if (sy_LeftOrRight.equals("left")) {
						if ((hscroll1.getScrollX() < _ds) && (hscroll1.getScrollX() > (_ds - (_ds * .1d)))) {
							_sy_scrollviewScroll(hscroll1, "h", "to", _ds, 0);
							sy_LeftOrRight = "mid";
						}
						else {
							_sy_scrollviewScroll(hscroll1, "h", "to", 0, 0);
						}
					}
					if (sy_LeftOrRight.equals("canR")) {
						_sy_scrollviewScroll(hscroll1, "h", "to", _ds, 0);
						sy_LeftOrRight = "mid";
					}
					if (sy_LeftOrRight.equals("canL")) {
						_sy_scrollviewScroll(hscroll1, "h", "to", _ds, 0);
						sy_LeftOrRight = "mid";
					}
					sy_forscrolldetect = -1;
					break;
				} return true; }});
	}
	
	
	private void _setupUiSize (final double _h, final double _w) {
		///Basic elements
		_sy_setWidthAndHeight(hscroll1, -1, -1);
		_sy_setWidthAndHeight(mainpage, _w, -1);
		_sy_setWidthAndHeight(leftside, (_w / 5) * 3, -1);
		_sy_setWidthAndHeight(rightside, (_w / 5) * 3, -1);
		_sy_setWidthAndHeight(bottom_sheet, _w, _h);
		bottom_sheet.setTranslationY((float)(_h / -6.5d));
		m_top.setTranslationY((float)(sy_statebarsize));
		statistics_con.setTranslationY((float)(sy_statebarsize));
		take_test_con.setTranslationY((float)(sy_statebarsize));
		_sy_setWidthAndHeight(left_statebar, -1, sy_statebarsize);
		_sy_setWidthAndHeight(right_statebar, -1, sy_statebarsize);
		_sy_setWidthAndHeight(my_subject_list, -1, _h / 2.5d);
	}
	
	
	private void _setUiColor (final ArrayList<String> _lis) {
		_sy_viewProperties(hscroll1, "#000000", "#000000", "", "00000000", 0, "#311B92", 0);
		_sy_viewProperties(leftside, "#000000", "#000000", "", "00202000", 0, "#ffffff", 0);
		_sy_viewProperties(rightside, "#000000", "#000000", "", "20000020", 0, "#ffffff", 0);
		_sy_viewProperties(m_top, "#000000", "#33ffffff", "", "22222222", 0, "#ffffff", 1);
		_sy_viewProperties(statistics_con, "#000000", "", "", "15151515", 1, "#95ffffff", 1);
		_sy_viewProperties(take_test_con, "#000000", "", "", "15151515", 1, "#95ffffff", 1);
		_sy_viewProperties(bottom_sheet_drager, "#66ffffff", "#66ffffff", "", "44444444", 0, "#ffffff", 0);
		_sy_viewProperties(bottom_sheet_top_con, "#262626", "", "", "23232323", 0, "#ffffff", 1);
		_sy_viewProperties(bottom_sheet_feild, "#262626", "", "", "22222222", 0, "#ffffff", 1);
		android.graphics.drawable.ColorDrawable sage = new android.graphics.drawable.ColorDrawable(Color.parseColor("#000000")); 
		my_subject_list.setDivider(sage); my_subject_list.setDividerHeight(8);
	}
	
	
	private void _bottomSheet_function () {
		bottom_sheet.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View p1, MotionEvent p2) {
				switch(p2.getAction()) {
					case MotionEvent.ACTION_DOWN:
					sy_xd = p2.getX();
					sy_yd = p2.getY();
					break;
					case MotionEvent.ACTION_MOVE:
					sy_xm = p2.getX();
					sy_ym = p2.getY();
					bottom_sheet.setTranslationY((float)(bottom_sheet.getTranslationY() + (sy_ym - sy_yd)));
					break;
					case MotionEvent.ACTION_UP:
					sy_xu = p2.getX();
					sy_yu = p2.getY();
					if (sy_bottom_state.equals("normal")) {
						if (bottom_sheet.getTranslationY() < (SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / -5)) {
							sy_bottom_state = "open";
						}
						else {
							sy_bottom_state = "normal";
						}
					}
					else {
						if ((bottom_sheet.getTranslationY() > (SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / -1.5d)) && (bottom_sheet.getTranslationY() < (SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / -1.7d))) {
							sy_bottom_state = "open";
						}
						else {
							sy_bottom_state = "normal";
						}
					}
					if (sy_bottom_state.equals("normal")) {
						anim.setTarget(bottom_sheet);
						anim.setPropertyName("translationY");
						anim.setFloatValues((float)(bottom_sheet.getTranslationY()), (float)(SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / -6.5d));
						anim.setDuration((int)(150));
						anim.setInterpolator(new LinearInterpolator());
						anim.start();
						anim1.setTarget(scroll_con);
						anim1.setPropertyName("alpha");
						anim1.setFloatValues((float)(scroll_con.getAlpha()), (float)(1));
						anim1.setDuration((int)(150));
						anim1.setInterpolator(new LinearInterpolator());
						anim1.start();
					}
					if (sy_bottom_state.equals("open")) {
						anim.setTarget(bottom_sheet);
						anim.setPropertyName("translationY");
						anim.setFloatValues((float)(bottom_sheet.getTranslationY()), (float)(SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / -1.6d));
						anim.setDuration((int)(150));
						anim.setInterpolator(new LinearInterpolator());
						anim.start();
						anim1.setTarget(scroll_con);
						anim1.setPropertyName("alpha");
						anim1.setFloatValues((float)(scroll_con.getAlpha()), (float)(.1d));
						anim1.setDuration((int)(150));
						anim1.setInterpolator(new LinearInterpolator());
						anim1.start();
					}
					break;
				} return true; }});
	}
	
	
	private void _sy_clickEffect (final View _v, final String _c, final String _e) {
		
		android.graphics.drawable.RippleDrawable ripdr1 = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor(_e)}), new android.graphics.drawable.ColorDrawable(Color.parseColor(_c)), null);
		_v.setBackground(ripdr1);
		
		
		
		//HERE #BDBDBD is the color when clicked (ripple)
		
		//#FFFFFF is the background color of the view
		
		//_v. is the view of course :)
		
	}
	
	
	public class My_subject_listAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public My_subject_listAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.subjects_cus_list, null);
			}
			
			final LinearLayout background = (LinearLayout) _v.findViewById(R.id.background);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final LinearLayout linear3 = (LinearLayout) _v.findViewById(R.id.linear3);
			final TextView name = (TextView) _v.findViewById(R.id.name);
			final LinearLayout linear5 = (LinearLayout) _v.findViewById(R.id.linear5);
			final LinearLayout linear6 = (LinearLayout) _v.findViewById(R.id.linear6);
			final TextView pages = (TextView) _v.findViewById(R.id.pages);
			final TextView current_page = (TextView) _v.findViewById(R.id.current_page);
			final TextView last_entry = (TextView) _v.findViewById(R.id.last_entry);
			final LinearLayout icon = (LinearLayout) _v.findViewById(R.id.icon);
			final ImageView options = (ImageView) _v.findViewById(R.id.options);
			final TextView letter = (TextView) _v.findViewById(R.id.letter);
			
			_sy_viewProperties(background, "#262626", "", "", "11111111", 1, "#ffffff", 0);
			_sy_viewProperties(icon, "#9C27B0", "", "", "11111111", 0, "#ffffff", 0);
			_sy_clickEffect(background, "#262626", "#888888");
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
