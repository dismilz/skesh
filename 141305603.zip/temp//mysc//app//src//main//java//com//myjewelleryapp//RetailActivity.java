package com.myjewelleryapp;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import java.text.DecimalFormat;

public class RetailActivity extends Activity {
	
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear12;
	private TextView textview19;
	private TextView textview14;
	private EditText edittext1;
	private TextView textview15;
	private EditText edittext2;
	private Button button1;
	private Button button2;
	private TextView textview1;
	private TextView textview2;
	private TextView textview3;
	private TextView textview4;
	private TextView textview5;
	private TextView textview6;
	private TextView textview7;
	private TextView textview8;
	private TextView textview9;
	private TextView textview10;
	private TextView textview11;
	private TextView textview12;
	private TextView textview13;
	private TextView textview16;
	private TextView textview18;
	
	private SharedPreferences settings2;
	private SharedPreferences sh2;
	private Intent retailabout = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.retail);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		textview19 = (TextView) findViewById(R.id.textview19);
		textview14 = (TextView) findViewById(R.id.textview14);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		textview15 = (TextView) findViewById(R.id.textview15);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		button1 = (Button) findViewById(R.id.button1);
		button2 = (Button) findViewById(R.id.button2);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview8 = (TextView) findViewById(R.id.textview8);
		textview9 = (TextView) findViewById(R.id.textview9);
		textview10 = (TextView) findViewById(R.id.textview10);
		textview11 = (TextView) findViewById(R.id.textview11);
		textview12 = (TextView) findViewById(R.id.textview12);
		textview13 = (TextView) findViewById(R.id.textview13);
		textview16 = (TextView) findViewById(R.id.textview16);
		textview18 = (TextView) findViewById(R.id.textview18);
		settings2 = getSharedPreferences("settings2", Activity.MODE_PRIVATE);
		sh2 = getSharedPreferences("sh2", Activity.MODE_PRIVATE);
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		textview15.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals("123321")) {
					settings2.edit().putString("val", edittext1.getText().toString()).commit();
					SketchwareUtil.showMessage(getApplicationContext(), "saved");
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "");
				}
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals("") || edittext2.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Enter Value");
				}
				else {
					if (textview18.getText().toString().equals(sh2.getString("sh2", ""))) {
						_settextt1(String.valueOf(Double.parseDouble(edittext1.getText().toString())));
						_settextt2(edittext2.getText().toString());
						_settextt3(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(edittext2.getText().toString()) / 1.03d))));
						_settext4(String.valueOf((long)(Double.parseDouble(edittext2.getText().toString()) - Double.parseDouble(String.valueOf((long)(Double.parseDouble(edittext2.getText().toString()) / 1.03d))))));
						_settextt5(String.valueOf(Double.parseDouble(String.valueOf((long)(Double.parseDouble(edittext2.getText().toString()) - Double.parseDouble(String.valueOf((long)(Double.parseDouble(edittext2.getText().toString()) / 1.03d)))))) / 2));
						_settextt6(String.valueOf(Double.parseDouble(new DecimalFormat(".00").format(Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(edittext2.getText().toString()) / 1.03d)))) / Double.parseDouble(String.valueOf(Double.parseDouble(edittext1.getText().toString())))))));
					}
					else {
						if (15000 > Double.parseDouble(edittext2.getText().toString())) {
							_settextt1(String.valueOf(Double.parseDouble(edittext1.getText().toString())));
							_settextt2(edittext2.getText().toString());
							_settextt3(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(edittext2.getText().toString()) / 1.03d))));
							_settext4(String.valueOf((long)(Double.parseDouble(edittext2.getText().toString()) - Double.parseDouble(String.valueOf((long)(Double.parseDouble(edittext2.getText().toString()) / 1.03d))))));
							_settextt5(String.valueOf(Double.parseDouble(String.valueOf((long)(Double.parseDouble(edittext2.getText().toString()) - Double.parseDouble(String.valueOf((long)(Double.parseDouble(edittext2.getText().toString()) / 1.03d)))))) / 2));
							_settextt6(String.valueOf(Double.parseDouble(new DecimalFormat(".00").format(Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(edittext2.getText().toString()) / 1.03d)))) / Double.parseDouble(String.valueOf(Double.parseDouble(edittext1.getText().toString())))))));
							SketchwareUtil.showMessage(getApplicationContext(), "Trial Version!\nRegistered for use value more than 15000\nCall 9988521500");
						}
						else {
							SketchwareUtil.showMessage(getApplicationContext(), "As it Trial Version !\nNot calculate value\nmore than 15000\nCall 9988521500 for Registered");
						}
					}
				}
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				textview2.setText("");
				textview4.setText("");
				textview6.setText("");
				textview8.setText("");
				textview10.setText("");
				textview12.setText("");
				textview16.setText("");
				edittext1.setText("");
				edittext2.setText("");
			}
		});
	}
	private void initializeLogic() {
		sh2.edit().putString("sh2", "123321").commit();
		textview18.setText(settings2.getString("val", ""));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _settextt1 (final String _str1) {
		textview2.setText(_str1);
	}
	
	
	private void _settextt2 (final String _str2) {
		textview16.setText(_str2);
	}
	
	
	private void _settextt3 (final String _str3) {
		textview6.setText(_str3);
	}
	
	
	private void _settext4 (final String _str4) {
		textview8.setText(_str4);
	}
	
	
	private void _settextt5 (final String _str5) {
		textview10.setText(_str5);
		textview12.setText(_str5);
	}
	
	
	private void _settextt6 (final String _str6) {
		textview4.setText(_str6);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
