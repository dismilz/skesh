package com.myjewelleryapp;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.widget.AdapterView;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import java.text.DecimalFormat;

public class InvoiceActivity extends Activity {
	
	
	private ArrayList<String> list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> map = new ArrayList<>();
	
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear13;
	private LinearLayout linear12;
	private LinearLayout linear51;
	private LinearLayout linear54;
	private LinearLayout linear57;
	private LinearLayout linear58;
	private TextView textview5;
	private TextView textview7;
	private EditText edittext1;
	private TextView textview2;
	private EditText editrate;
	private TextView textview1;
	private EditText editweight;
	private Button button4;
	private TextView textview3;
	private EditText editpolish;
	private TextView textview4;
	private EditText editlabour;
	private Spinner spinner2;
	private TextView viewnetlabour;
	private Button button2;
	private Button button3;
	private TextView textview6;
	
	private Intent invoicetorsult = new Intent();
	private SharedPreferences shinvoice;
	private SharedPreferences savedboard;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.invoice);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear51 = (LinearLayout) findViewById(R.id.linear51);
		linear54 = (LinearLayout) findViewById(R.id.linear54);
		linear57 = (LinearLayout) findViewById(R.id.linear57);
		linear58 = (LinearLayout) findViewById(R.id.linear58);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview7 = (TextView) findViewById(R.id.textview7);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		textview2 = (TextView) findViewById(R.id.textview2);
		editrate = (EditText) findViewById(R.id.editrate);
		textview1 = (TextView) findViewById(R.id.textview1);
		editweight = (EditText) findViewById(R.id.editweight);
		button4 = (Button) findViewById(R.id.button4);
		textview3 = (TextView) findViewById(R.id.textview3);
		editpolish = (EditText) findViewById(R.id.editpolish);
		textview4 = (TextView) findViewById(R.id.textview4);
		editlabour = (EditText) findViewById(R.id.editlabour);
		spinner2 = (Spinner) findViewById(R.id.spinner2);
		viewnetlabour = (TextView) findViewById(R.id.viewnetlabour);
		button2 = (Button) findViewById(R.id.button2);
		button3 = (Button) findViewById(R.id.button3);
		textview6 = (TextView) findViewById(R.id.textview6);
		shinvoice = getSharedPreferences("shinv", Activity.MODE_PRIVATE);
		savedboard = getSharedPreferences("svdboard", Activity.MODE_PRIVATE);
		
		linear11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		linear54.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				savedboard.edit().putString("date", _charSeq).commit();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		textview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (editweight.getText().toString().equals("123321")) {
					shinvoice.edit().putString("val", editweight.getText().toString()).commit();
					SketchwareUtil.showMessage(getApplicationContext(), "saved");
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "");
				}
			}
		});
		
		editrate.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				savedboard.edit().putString("val1", _charSeq).commit();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		editweight.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				spinner2.setSelection((int)(0));
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				editweight.setText("");
			}
		});
		
		editpolish.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				savedboard.edit().putString("val2", _charSeq).commit();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		editlabour.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		editlabour.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				spinner2.setSelection((int)(0));
				savedboard.edit().putString("val3", _charSeq).commit();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (_position == 0) {
					viewnetlabour.setText("0");
				}
				if (_position == 1) {
					if (editweight.getText().toString().equals("") || editlabour.getText().toString().equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Fill weight and labour");
					}
					else {
						viewnetlabour.setText(String.valueOf((long)(Double.parseDouble(editlabour.getText().toString()) * Double.parseDouble(editweight.getText().toString()))));
					}
				}
				if (_position == 2) {
					viewnetlabour.setText(editlabour.getText().toString());
				}
			}
			
			@Override
			public void onNothingSelected(AdapterView<?> _param1) {
				
			}
		});
		
		viewnetlabour.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (textview6.getText().toString().equals(shinvoice.getString("sh1", ""))) {
					if (editlabour.getText().toString().equals("")) {
						editlabour.setText("0");
					}
					if (editpolish.getText().toString().equals("")) {
						editpolish.setText("0");
					}
					if (editweight.getText().toString().equals("") || editrate.getText().toString().equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Enter Value");
					}
					else {
						invoicetorsult.setAction(Intent.ACTION_VIEW);
						invoicetorsult.setClass(getApplicationContext(), ResultinvoiceActivity.class);
						invoicetorsult.putExtra("strweight", editweight.getText().toString());
						invoicetorsult.putExtra("strrate", editrate.getText().toString());
						invoicetorsult.putExtra("strpolish", String.valueOf(Double.parseDouble(new DecimalFormat(".00").format(Double.parseDouble(editweight.getText().toString()) * (Double.parseDouble(editpolish.getText().toString()) / 100)))));
						invoicetorsult.putExtra("strlabour", viewnetlabour.getText().toString());
						invoicetorsult.putExtra("stramount", String.valueOf((long)(((Double.parseDouble(editweight.getText().toString()) + Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat(".00").format(Double.parseDouble(editweight.getText().toString()) * (Double.parseDouble(editpolish.getText().toString()) / 100)))))) * Double.parseDouble(editrate.getText().toString())) + Double.parseDouble(viewnetlabour.getText().toString()))));
						invoicetorsult.putExtra("strigst", String.valueOf((long)(Double.parseDouble(String.valueOf((long)(((Double.parseDouble(editweight.getText().toString()) + Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat(".00").format(Double.parseDouble(editweight.getText().toString()) * (Double.parseDouble(editpolish.getText().toString()) / 100)))))) * Double.parseDouble(editrate.getText().toString())) + Double.parseDouble(viewnetlabour.getText().toString())))) * 0.03d)));
						invoicetorsult.putExtra("strcgst", String.valueOf(Double.parseDouble(new DecimalFormat(".0").format(Double.parseDouble(String.valueOf((long)(Double.parseDouble(String.valueOf((long)(((Double.parseDouble(editweight.getText().toString()) + Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat(".00").format(Double.parseDouble(editweight.getText().toString()) * (Double.parseDouble(editpolish.getText().toString()) / 100)))))) * Double.parseDouble(editrate.getText().toString())) + Double.parseDouble(viewnetlabour.getText().toString())))) * 0.03d))) / 2))));
						invoicetorsult.putExtra("strsgst", String.valueOf(Double.parseDouble(new DecimalFormat(".0").format(Double.parseDouble(String.valueOf((long)(Double.parseDouble(String.valueOf((long)(((Double.parseDouble(editweight.getText().toString()) + Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat(".00").format(Double.parseDouble(editweight.getText().toString()) * (Double.parseDouble(editpolish.getText().toString()) / 100)))))) * Double.parseDouble(editrate.getText().toString())) + Double.parseDouble(viewnetlabour.getText().toString())))) * 0.03d))) / 2))));
						invoicetorsult.putExtra("strnetamount", String.valueOf((long)(Double.parseDouble(String.valueOf((long)(((Double.parseDouble(editweight.getText().toString()) + Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat(".00").format(Double.parseDouble(editweight.getText().toString()) * (Double.parseDouble(editpolish.getText().toString()) / 100)))))) * Double.parseDouble(editrate.getText().toString())) + Double.parseDouble(viewnetlabour.getText().toString())))) + Double.parseDouble(String.valueOf((long)(Double.parseDouble(String.valueOf((long)(((Double.parseDouble(editweight.getText().toString()) + Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat(".00").format(Double.parseDouble(editweight.getText().toString()) * (Double.parseDouble(editpolish.getText().toString()) / 100)))))) * Double.parseDouble(editrate.getText().toString())) + Double.parseDouble(viewnetlabour.getText().toString())))) * 0.03d))))));
						invoicetorsult.putExtra("date", edittext1.getText().toString());
						startActivity(invoicetorsult);
					}
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Only Registered use this feature\nCall 9988521500 for Registered");
				}
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				editweight.setText("");
				editrate.setText("");
				editpolish.setText("");
				editlabour.setText("");
				viewnetlabour.setText("");
			}
		});
	}
	private void initializeLogic() {
		list.add("Choose");
		list.add("Per gm");
		list.add("Amount");
		spinner2.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, list));
		shinvoice.edit().putString("sh1", "123321").commit();
		textview6.setText(shinvoice.getString("val", ""));
		editrate.setText(savedboard.getString("val1", ""));
		editpolish.setText(savedboard.getString("val2", ""));
		editlabour.setText(savedboard.getString("val3", ""));
		edittext1.setText(savedboard.getString("date", ""));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _wt1 (final String _wt1v) {
		
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
