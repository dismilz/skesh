package com.myjewelleryapp;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
	
	
	private ArrayList<String> edittext = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout linear1;
	private LinearLayout linear3;
	private LinearLayout linear6;
	private LinearLayout linear4;
	private LinearLayout linear11;
	private LinearLayout linear14;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear15;
	private Button button5;
	private Button button3;
	private Button button6;
	private Button button4;
	private TextView textview20;
	private TextView textview2;
	private EditText estimaterate;
	private TextView textview3;
	private TextView textview7;
	private EditText totalamount;
	private Button button1;
	private Button button2;
	private TextView textview9;
	private TextView netweightvalue;
	private TextView textview19;
	private TextView netrate;
	private LinearLayout linear7;
	private TextView textview18;
	private TextView textview11;
	private TextView textview14;
	private TextView taxamt;
	private TextView textview15;
	private TextView cgstamt;
	private TextView textview17;
	private TextView sgstamt;
	private TextView textview13;
	private TextView totalamounttext;
	private TextView textview23;
	
	private Intent intent1 = new Intent();
	private Intent intent2 = new Intent();
	private SharedPreferences setting;
	private SharedPreferences sh1;
	private Intent showmsg = new Intent();
	private Intent invoice = new Intent();
	private Intent mix = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		button5 = (Button) findViewById(R.id.button5);
		button3 = (Button) findViewById(R.id.button3);
		button6 = (Button) findViewById(R.id.button6);
		button4 = (Button) findViewById(R.id.button4);
		textview20 = (TextView) findViewById(R.id.textview20);
		textview2 = (TextView) findViewById(R.id.textview2);
		estimaterate = (EditText) findViewById(R.id.estimaterate);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview7 = (TextView) findViewById(R.id.textview7);
		totalamount = (EditText) findViewById(R.id.totalamount);
		button1 = (Button) findViewById(R.id.button1);
		button2 = (Button) findViewById(R.id.button2);
		textview9 = (TextView) findViewById(R.id.textview9);
		netweightvalue = (TextView) findViewById(R.id.netweightvalue);
		textview19 = (TextView) findViewById(R.id.textview19);
		netrate = (TextView) findViewById(R.id.netrate);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		textview18 = (TextView) findViewById(R.id.textview18);
		textview11 = (TextView) findViewById(R.id.textview11);
		textview14 = (TextView) findViewById(R.id.textview14);
		taxamt = (TextView) findViewById(R.id.taxamt);
		textview15 = (TextView) findViewById(R.id.textview15);
		cgstamt = (TextView) findViewById(R.id.cgstamt);
		textview17 = (TextView) findViewById(R.id.textview17);
		sgstamt = (TextView) findViewById(R.id.sgstamt);
		textview13 = (TextView) findViewById(R.id.textview13);
		totalamounttext = (TextView) findViewById(R.id.totalamounttext);
		textview23 = (TextView) findViewById(R.id.textview23);
		setting = getSharedPreferences("setting", Activity.MODE_PRIVATE);
		sh1 = getSharedPreferences("sh1", Activity.MODE_PRIVATE);
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				invoice.setAction(Intent.ACTION_VIEW);
				invoice.setClass(getApplicationContext(), InvoiceActivity.class);
				startActivity(invoice);
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent1.setAction(Intent.ACTION_VIEW);
				intent1.setClass(getApplicationContext(), RetailActivity.class);
				startActivity(intent1);
			}
		});
		
		button6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mix.setAction(Intent.ACTION_VIEW);
				mix.setClass(getApplicationContext(), MixtureActivity.class);
				startActivity(mix);
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent2.setAction(Intent.ACTION_VIEW);
				intent2.setClass(getApplicationContext(), AboutActivity.class);
				startActivity(intent2);
			}
		});
		
		estimaterate.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		textview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (estimaterate.getText().toString().equals("123321")) {
					setting.edit().putString("val", estimaterate.getText().toString()).commit();
					SketchwareUtil.showMessage(getApplicationContext(), "saved");
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "");
				}
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (estimaterate.getText().toString().equals("") || totalamount.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Enter Value");
				}
				else {
					if (textview23.getText().toString().equals(sh1.getString("sh1", ""))) {
						_settext2(totalamount.getText().toString());
						_settext3(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(totalamount.getText().toString()) / 1.03d))));
						_settext4(String.valueOf((long)(Double.parseDouble(totalamount.getText().toString()) - Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(totalamount.getText().toString()) / 1.03d)))))));
						_setext5(String.valueOf(Double.parseDouble(new DecimalFormat(".0").format(Double.parseDouble(String.valueOf((long)(Double.parseDouble(totalamount.getText().toString()) - Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(totalamount.getText().toString()) / 1.03d))))))) / 2))));
						_settext6(String.valueOf(Double.parseDouble(new DecimalFormat(".0").format(Double.parseDouble(String.valueOf((long)(Double.parseDouble(totalamount.getText().toString()) - Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(totalamount.getText().toString()) / 1.03d))))))) / 2))));
						_settext7(String.valueOf(Double.parseDouble(new DecimalFormat(".000").format(Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(totalamount.getText().toString()) / 1.03d)))) / (Double.parseDouble(estimaterate.getText().toString()) / 10)))));
						_settext8(String.valueOf(Double.parseDouble(new DecimalFormat(".000").format(Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(totalamount.getText().toString()) / 1.03d)))) / Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat(".000").format(Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(totalamount.getText().toString()) / 1.03d)))) / (Double.parseDouble(estimaterate.getText().toString()) / 10)))))))));
					}
					else {
						if (Double.parseDouble(totalamount.getText().toString()) < 15000) {
							_settext2(totalamount.getText().toString());
							_settext3(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(totalamount.getText().toString()) / 1.03d))));
							_settext4(String.valueOf((long)(Double.parseDouble(totalamount.getText().toString()) - Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(totalamount.getText().toString()) / 1.03d)))))));
							_setext5(String.valueOf(Double.parseDouble(new DecimalFormat(".0").format(Double.parseDouble(String.valueOf((long)(Double.parseDouble(totalamount.getText().toString()) - Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(totalamount.getText().toString()) / 1.03d))))))) / 2))));
							_settext6(String.valueOf(Double.parseDouble(new DecimalFormat(".0").format(Double.parseDouble(String.valueOf((long)(Double.parseDouble(totalamount.getText().toString()) - Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(totalamount.getText().toString()) / 1.03d))))))) / 2))));
							_settext7(String.valueOf(Double.parseDouble(new DecimalFormat(".000").format(Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(totalamount.getText().toString()) / 1.03d)))) / (Double.parseDouble(estimaterate.getText().toString()) / 10)))));
							_settext8(String.valueOf(Double.parseDouble(new DecimalFormat(".00").format(Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(totalamount.getText().toString()) / 1.03d)))) / Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat(".000").format(Double.parseDouble(String.valueOf(Double.parseDouble(new DecimalFormat("0").format(Double.parseDouble(totalamount.getText().toString()) / 1.03d)))) / (Double.parseDouble(estimaterate.getText().toString()) / 10)))))))));
							SketchwareUtil.showMessage(getApplicationContext(), "                          Trial Version!\nPlease Registered for use value greater than 15000. Contact 9988521500");
						}
						else {
							SketchwareUtil.showMessage(getApplicationContext(), "As it Trial Version !\nNot calculate value\nmore than 15000\nCall 9988521500 for Registered");
						}
					}
				}
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				estimaterate.setText("");
				totalamount.setText("");
				netweightvalue.setText("");
				netrate.setText("");
				cgstamt.setText("");
				sgstamt.setText("");
				totalamounttext.setText("");
				taxamt.setText("");
				textview11.setText("");
			}
		});
		
		textview23.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
	}
	private void initializeLogic() {
		sh1.edit().putString("sh1", "123321").commit();
		textview23.setText(setting.getString("val", ""));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _settext (final double _str) {
		
	}
	
	
	private void _settext2 (final String _str2) {
		totalamounttext.setText(_str2);
	}
	
	
	private void _settext3 (final String _str3) {
		textview11.setText(_str3);
	}
	
	
	private void _settext4 (final String _str4) {
		taxamt.setText(_str4);
	}
	
	
	private void _setext5 (final String _str5) {
		cgstamt.setText(_str5);
	}
	
	
	private void _settext6 (final String _str6) {
		sgstamt.setText(_str6);
	}
	
	
	private void _settext7 (final String _str7) {
		netweightvalue.setText(_str7);
	}
	
	
	private void _settext8 (final String _str8) {
		netrate.setText(_str8);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
