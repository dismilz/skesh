package com.myjewelleryapp;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.view.View;

public class ResultinvoiceActivity extends Activity {
	
	
	private LinearLayout linear1;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear9;
	private LinearLayout linear8;
	private TextView omjewels;
	private TextView address;
	private ImageView imageview3;
	private TextView roughestimate;
	private ImageView imageview4;
	private TextView textview1;
	private TextView vweight;
	private TextView textview3;
	private TextView vpolish;
	private TextView textview2;
	private TextView vrate;
	private TextView textview4;
	private TextView vlabour;
	private TextView textview5;
	private TextView vtotalbeforrtax;
	private TextView textview6;
	private TextView vsgst;
	private TextView textview9;
	private TextView vcgst;
	private TextView textview8;
	private TextView vigst;
	private EditText box;
	private TextView textview7;
	private TextView vnetamount;
	private TextView textview13;
	private TextView textdate;
	
	private Intent resultinvoice = new Intent();
	private Intent main = new Intent();
	private Intent retail = new Intent();
	private Intent invoice = new Intent();
	private SharedPreferences savename;
	private SharedPreferences saveom;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.resultinvoice);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		omjewels = (TextView) findViewById(R.id.omjewels);
		address = (TextView) findViewById(R.id.address);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		roughestimate = (TextView) findViewById(R.id.roughestimate);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview1 = (TextView) findViewById(R.id.textview1);
		vweight = (TextView) findViewById(R.id.vweight);
		textview3 = (TextView) findViewById(R.id.textview3);
		vpolish = (TextView) findViewById(R.id.vpolish);
		textview2 = (TextView) findViewById(R.id.textview2);
		vrate = (TextView) findViewById(R.id.vrate);
		textview4 = (TextView) findViewById(R.id.textview4);
		vlabour = (TextView) findViewById(R.id.vlabour);
		textview5 = (TextView) findViewById(R.id.textview5);
		vtotalbeforrtax = (TextView) findViewById(R.id.vtotalbeforrtax);
		textview6 = (TextView) findViewById(R.id.textview6);
		vsgst = (TextView) findViewById(R.id.vsgst);
		textview9 = (TextView) findViewById(R.id.textview9);
		vcgst = (TextView) findViewById(R.id.vcgst);
		textview8 = (TextView) findViewById(R.id.textview8);
		vigst = (TextView) findViewById(R.id.vigst);
		box = (EditText) findViewById(R.id.box);
		textview7 = (TextView) findViewById(R.id.textview7);
		vnetamount = (TextView) findViewById(R.id.vnetamount);
		textview13 = (TextView) findViewById(R.id.textview13);
		textdate = (TextView) findViewById(R.id.textdate);
		savename = getSharedPreferences("savename", Activity.MODE_PRIVATE);
		saveom = getSharedPreferences("saveom", Activity.MODE_PRIVATE);
		
		omjewels.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		address.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		roughestimate.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				savename.edit().putString("saveroughestimate", box.getText().toString()).commit();
			}
		});
		
		vweight.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		textview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				savename.edit().putString("savename", box.getText().toString()).commit();
				SketchwareUtil.showMessage(getApplicationContext(), "Saved");
			}
		});
		
		textview9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				savename.edit().putString("saveaddress", box.getText().toString()).commit();
			}
		});
		
		textview8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				savename.edit().putString("saveroughestimate", box.getText().toString()).commit();
			}
		});
	}
	private void initializeLogic() {
		vweight.setText(getIntent().getStringExtra("strweight"));
		vrate.setText(getIntent().getStringExtra("strrate"));
		vpolish.setText(getIntent().getStringExtra("strpolish"));
		vlabour.setText(getIntent().getStringExtra("strlabour"));
		vtotalbeforrtax.setText(getIntent().getStringExtra("stramount"));
		vigst.setText(getIntent().getStringExtra("strigst"));
		vsgst.setText(getIntent().getStringExtra("strsgst"));
		vcgst.setText(getIntent().getStringExtra("strcgst"));
		vnetamount.setText(getIntent().getStringExtra("strnetamount"));
		textdate.setText(getIntent().getStringExtra("date"));
		omjewels.setText(savename.getString("savename", ""));
		address.setText(savename.getString("saveaddress", ""));
		roughestimate.setText(savename.getString("saveroughestimate", ""));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
