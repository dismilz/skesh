package com.chat.scloud;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;

public class LoginActivity extends AppCompatActivity {
	
	
	private HashMap<String, Object> map_daftar = new HashMap<>();
	private boolean isRegister = false;
	
	private LinearLayout linear1;
	private ImageView imageview1;
	private TextView textview1;
	private TextView textview2;
	private LinearLayout linear2;
	private TextView textview3;
	private EditText edittext1;
	private TextView textview4;
	private EditText edittext2;
	private TextView textview5;
	private Button button1;
	private LinearLayout linear3;
	private TextView textview6;
	private TextView textview7;
	
	private Intent i = new Intent();
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private AlertDialog.Builder dialog;
	private AlertDialog.Builder dialog2;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.login);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		textview3 = (TextView) findViewById(R.id.textview3);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		textview4 = (TextView) findViewById(R.id.textview4);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		textview5 = (TextView) findViewById(R.id.textview5);
		button1 = (Button) findViewById(R.id.button1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview7 = (TextView) findViewById(R.id.textview7);
		auth = FirebaseAuth.getInstance();
		dialog = new AlertDialog.Builder(this);
		dialog2 = new AlertDialog.Builder(this);
		
		textview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				LinearLayout mylayout = new LinearLayout(LoginActivity.this);
				
				LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
				
				mylayout.setLayoutParams(params); mylayout.setOrientation(LinearLayout.VERTICAL);
				
				final EditText myedittext = new EditText(LoginActivity.this);
				myedittext.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
				myedittext.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
				 
				mylayout.addView(myedittext);
				dialog.setView(mylayout);
				myedittext.setHint("Enter your Email");
				dialog.setCancelable(false);
				dialog.setTitle("Reset Password");
				dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (myedittext.getText().toString().trim().length() > 0) {
							auth.sendPasswordResetEmail(myedittext.getText().toString().trim()).addOnCompleteListener(_auth_reset_password_listener);
							_createSnackBar("Check your email to reset password");
						}
						else {
							_createSnackBar("Fill the blanks!");
						}
					}
				});
				dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().trim().length() == 0) {
					_createSnackBar("Fill all those blanks!");
				}
				else {
					if (edittext2.getText().toString().length() == 0) {
						_createSnackBar("Fill all those blanks!");
					}
					else {
						if (isRegister) {
							auth.createUserWithEmailAndPassword(edittext1.getText().toString().trim(), edittext2.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_create_user_listener);
						}
						else {
							auth.signInWithEmailAndPassword(edittext1.getText().toString().trim(), edittext2.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_sign_in_listener);
						}
						_CoreProgressLoading(true);
					}
				}
			}
		});
		
		textview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (isRegister) {
					isRegister = false;
					textview1.setText("Welcome Back,");
					textview2.setText("Sign in to continue");
					button1.setText("Login");
					textview6.setText("New user?");
					textview7.setText("Sign Up");
					textview5.setVisibility(View.VISIBLE);
				}
				else {
					isRegister = true;
					textview1.setText("Welcome,");
					textview2.setText("Sign up to continue");
					button1.setText("Sign Up");
					textview6.setText("Old user?");
					textview7.setText("Sign In");
					textview5.setVisibility(View.GONE);
				}
			}
		});
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				_CoreProgressLoading(false);
				if (_success) {
					auth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() { 
						@Override
						public void onComplete(@androidx.annotation.NonNull
						 Task<Void> task) {
							
							if (task.isSuccessful()) {
								FirebaseAuth.getInstance().signOut();
								_createSnackBar("Check your email to verify.");
							} else {
								FirebaseAuth.getInstance().signOut();
								_createSnackBar("Verification failed to send!");
							}
							
						}});
				}
				else {
					_createSnackBar(_errorMessage);
					FirebaseAuth.getInstance().signOut();
				}
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				_CoreProgressLoading(false);
				if (_success) {
					if (auth.getCurrentUser().isEmailVerified()) {
						i.setClass(getApplicationContext(), MainActivity.class);
						startActivity(i);
						finish();
					}
					else {
						dialog2.setCancelable(false);
						dialog2.setTitle("Email is not verified");
						dialog2.setMessage("Would you like to re-verify? ");
						dialog2.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								auth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() { 
									@Override
									public void onComplete(@androidx.annotation.NonNull
									 Task<Void> task) {
										
										if (task.isSuccessful()) {
											FirebaseAuth.getInstance().signOut();
											_createSnackBar("Check your email to verify.");
										} else {
											FirebaseAuth.getInstance().signOut();
											_createSnackBar("Verification failed to send!");
										}
										
									}});
							}
						});
						dialog2.setNegativeButton("No", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								FirebaseAuth.getInstance().signOut();
							}
						});
						dialog2.create().show();
					}
				}
				else {
					_createSnackBar(_errorMessage);
					FirebaseAuth.getInstance().signOut();
				}
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _createSnackBar (final String _message) {
		ViewGroup parentLayout = (ViewGroup) ((ViewGroup) this .findViewById(android.R.id.content)).getChildAt(0);
		   com.google.android.material.snackbar.Snackbar.make(parentLayout, _message, com.google.android.material.snackbar.Snackbar.LENGTH_LONG) 
		        .setAction("OK", new View.OnClickListener() {
			            @Override 
			            public void onClick(View view) {
				
				            } 
			        }).show();
	}
	
	
	private void _CoreProgressLoading (final boolean _ifShow) {
		if (_ifShow) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.setMessage(null);
			coreprog.show();
			coreprog.setContentView(R.layout.custom_dialog);
		}
		else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
