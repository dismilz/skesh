package com.chat.scloud;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.Intent;
import android.content.ClipData;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Continuation;
import android.net.Uri;
import java.io.File;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import com.google.gson.Gson;
import com.bumptech.glide.Glide;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class ProfileActivity extends AppCompatActivity {
	
	public final int REQ_CD_FP = 101;
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private double get_data_user = 0;
	private boolean edit_prof = false;
	private HashMap<String, Object> put_data = new HashMap<>();
	private HashMap<String, Object> map_intent = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> lm_data_user = new ArrayList<>();
	private ArrayList<String> ls_ = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear_profile_about;
	private LinearLayout linear11;
	private LinearLayout linear24;
	private Button button2;
	private LinearLayout linear15;
	private LinearLayout linear2;
	private LinearLayout linear6;
	private LinearLayout linear3;
	private LinearLayout linear26;
	private LinearLayout linear4;
	private ImageView imageview_follow;
	private ImageView imageview1;
	private ImageView imageview11;
	private LinearLayout linear25;
	private TextView textview2;
	private Button button1;
	private TextView textview1;
	private EditText edittext1;
	private TextView textview3;
	private EditText edittext2;
	private TextView textview4;
	private LinearLayout linear23;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private ImageView star;
	private TextView textview16;
	private ImageView imageview4;
	private TextView textview7;
	private ImageView imageview3;
	private TextView textview6;
	private ImageView imageview2;
	private TextView textview5;
	private TextView textview15;
	private LinearLayout linear20;
	private LinearLayout linear19;
	private ImageView imageview10;
	private LinearLayout linear22;
	private TextView textview13;
	private TextView textview11;
	private ImageView imageview9;
	private LinearLayout linear21;
	private TextView textview12;
	private TextView textview10;
	private TextView textview9;
	private LinearLayout linear10;
	private ImageView imageview5;
	private ImageView imageview6;
	private ImageView imageview7;
	private ImageView imageview8;
	
	private DatabaseReference data_user = _firebase.getReference("data user");
	private ChildEventListener _data_user_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private StorageReference fs = _firebase_storage.getReference("data");
	private OnCompleteListener<Uri> _fs_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fs_download_success_listener;
	private OnSuccessListener _fs_delete_success_listener;
	private OnProgressListener _fs_upload_progress_listener;
	private OnProgressListener _fs_download_progress_listener;
	private OnFailureListener _fs_failure_listener;
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.profile);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear_profile_about = (LinearLayout) findViewById(R.id.linear_profile_about);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear24 = (LinearLayout) findViewById(R.id.linear24);
		button2 = (Button) findViewById(R.id.button2);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear26 = (LinearLayout) findViewById(R.id.linear26);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		imageview_follow = (ImageView) findViewById(R.id.imageview_follow);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		imageview11 = (ImageView) findViewById(R.id.imageview11);
		linear25 = (LinearLayout) findViewById(R.id.linear25);
		textview2 = (TextView) findViewById(R.id.textview2);
		button1 = (Button) findViewById(R.id.button1);
		textview1 = (TextView) findViewById(R.id.textview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		textview3 = (TextView) findViewById(R.id.textview3);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		textview4 = (TextView) findViewById(R.id.textview4);
		linear23 = (LinearLayout) findViewById(R.id.linear23);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		star = (ImageView) findViewById(R.id.star);
		textview16 = (TextView) findViewById(R.id.textview16);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview7 = (TextView) findViewById(R.id.textview7);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview6 = (TextView) findViewById(R.id.textview6);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview15 = (TextView) findViewById(R.id.textview15);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		imageview10 = (ImageView) findViewById(R.id.imageview10);
		linear22 = (LinearLayout) findViewById(R.id.linear22);
		textview13 = (TextView) findViewById(R.id.textview13);
		textview11 = (TextView) findViewById(R.id.textview11);
		imageview9 = (ImageView) findViewById(R.id.imageview9);
		linear21 = (LinearLayout) findViewById(R.id.linear21);
		textview12 = (TextView) findViewById(R.id.textview12);
		textview10 = (TextView) findViewById(R.id.textview10);
		textview9 = (TextView) findViewById(R.id.textview9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		imageview8 = (ImageView) findViewById(R.id.imageview8);
		auth = FirebaseAuth.getInstance();
		fp.setType("image/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		d = new AlertDialog.Builder(this);
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.setTitle("SignOut");
				d.setMessage("SignOut now?");
				d.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						i.setClass(getApplicationContext(), LoginActivity.class);
						startActivity(i);
						FirebaseAuth.getInstance().signOut();
						finish();
					}
				});
				d.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				d.create().show();
			}
		});
		
		imageview_follow.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edit_prof) {
					startActivityForResult(fp, REQ_CD_FP);
				}
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				map_intent = new HashMap<>();
				map_intent.put("uid", getIntent().getStringExtra("uid"));
				map_intent.put("push key", "");
				i.putExtra("data", new Gson().toJson(map_intent));
				
				startActivity(i);
			}
		});
		
		linear12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		linear13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.putExtra("uid", getIntent().getStringExtra("uid"));
				
				startActivity(i);
				finish();
			}
		});
		
		linear14.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.putExtra("uid", getIntent().getStringExtra("uid"));
				i.setClass(getApplicationContext(), PesanActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		linear20.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		linear19.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		_data_user_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		data_user.addChildEventListener(_data_user_child_listener);
		
		_fs_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				SketchwareUtil.showMessage(getApplicationContext(), "Uploading ".concat(String.valueOf((long)(_progressValue)).concat("%")));
			}
		};
		
		_fs_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fs_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				SketchwareUtil.showMessage(getApplicationContext(), "Upload complete");
				put_data.put("pic url", _downloadUrl);
				data_user.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(put_data);
				_curcle_igm_url(_downloadUrl, imageview1);
			}
		};
		
		_fs_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_fs_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fs_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		setTitle("Profile");
		linear24.setVisibility(View.GONE);
		_RoundandShadow(10, 8, "#f44336", button2);
		_RoundandShadow(8, 0, "#eceff1", edittext1);
		_RoundandShadow(8, 0, "#eceff1", edittext2);
		edittext1.setVisibility(View.GONE);
		edit_prof = false;
		edittext2.setVisibility(View.GONE);
		data_user.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				lm_data_user = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						lm_data_user.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				get_data_user = 0;
				for(int _repeat36 = 0; _repeat36 < (int)(lm_data_user.size()); _repeat36++) {
					if (getIntent().getStringExtra("uid").equals(lm_data_user.get((int)get_data_user).get("uid").toString())) {
						textview1.setText(lm_data_user.get((int)get_data_user).get("username").toString());
						textview2.setText(lm_data_user.get((int)get_data_user).get("email").toString());
						edittext1.setText(lm_data_user.get((int)get_data_user).get("username").toString());
						if ("".equals(lm_data_user.get((int)get_data_user).get("pic url").toString())) {
							imageview1.setColorFilter(0xFF757575, PorterDuff.Mode.MULTIPLY);
						}
						else {
							_roundImageViewUrl(imageview1, 500, lm_data_user.get((int)get_data_user).get("pic url").toString());
						}
						if (lm_data_user.get((int)get_data_user).containsKey("about")) {
							textview4.setText(lm_data_user.get((int)get_data_user).get("about").toString());
							edittext2.setText(lm_data_user.get((int)get_data_user).get("about").toString());
						}
						else {
							textview4.setText(lm_data_user.get((int)get_data_user).get("username").toString());
						}
					}
					get_data_user++;
				}
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
		imageview2.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		imageview3.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		imageview4.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		imageview5.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		imageview6.setColorFilter(0xFF9E9E9E, PorterDuff.Mode.MULTIPLY);
		imageview7.setColorFilter(0xFFF44336, PorterDuff.Mode.MULTIPLY);
		imageview8.setColorFilter(0xFF00C853, PorterDuff.Mode.MULTIPLY);
		imageview_follow.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		star.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		_circleRipple("#cfd8dc", linear12);
		_circleRipple("#cfd8dc", linear13);
		_circleRipple("#cfd8dc", linear14);
		_circleRipple("#cfd8dc", linear23);
		_circleRipple("#cfd8dc", imageview_follow);
		_RoundandShadow(0, 12, "#ffffff", linear_profile_about);
		_RoundandShadow(0, 8, "#ffffff", linear24);
		_RoundandShadow(0, 8, "#ffffff", linear11);
		_RoundandShadow(0, 8, "#ffffff", linear15);
		_RoundandShadow(10, 0, "#607d8b", button1);
		_RoundAndBorder(button1, "#ffffff", 2, "#607d8b", 10);
		_RoundAndBorder(linear19, "#ffffff", 2, "#607d8b", 10);
		_RoundAndBorder(linear20, "#ffffff", 2, "#607d8b", 10);
		_RippleEffect_Round(linear19, "#ffffff", 10);
		_RippleEffect_Round(linear20, "#ffffff", 10);
		if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(getIntent().getStringExtra("uid"))) {
			imageview_follow.setVisibility(View.GONE);
			button2.setVisibility(View.VISIBLE);
		}
		else {
			_RoundAndBorder(button1, "#ffffff", 4, "#f44336", 10);
			button1.setText("report");
			button1.setTextColor(0xFFF44336);
			button2.setVisibility(View.GONE);
		}
		imageview_follow.setVisibility(View.GONE);
		linear23.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				FileUtil.resizeBitmapFileRetainRatio(_filePath.get((int)(0)), FileUtil.getPackageDataDir(getApplicationContext()).concat("/pic_temp/pic.png"), 300);
				fs.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/pic/".concat("pic.png"))).putFile(Uri.fromFile(new File(FileUtil.getPackageDataDir(getApplicationContext()).concat("/pic_temp/pic.png")))).addOnFailureListener(_fs_failure_listener).addOnProgressListener(_fs_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return fs.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/pic/".concat("pic.png"))).getDownloadUrl();
					}}).addOnCompleteListener(_fs_upload_success_listener);
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	private void _circleRipple (final String _color, final View _v) {
		android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor(_color)});
		android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , null, null);
		_v.setBackground(ripdrb);
	}
	
	
	private void _RoundAndBorder (final View _view, final String _color1, final double _border, final String _color2, final double _round) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color1));
		gd.setCornerRadius((int) _round);
		gd.setStroke((int) _border, Color.parseColor(_color2));
		_view.setBackground(gd);
	}
	
	
	private void _RoundandShadow (final double _Radius, final double _Elevation, final String _color, final View _v) {
		float r = (float) _Radius;
		float e = (float) _Elevation;
		_v.setElevation(e);
		android.graphics.drawable.GradientDrawable s=new android.graphics.drawable.GradientDrawable();
		s.setColor(Color.parseColor(_color));
		s.setCornerRadius(r);
		_v.setBackground(s);
	}
	
	
	private void _RippleEffect_Round (final View _view, final String _color, final double _clr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_color));
		GG.setCornerRadius((float)_clr);
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor("#FF757575")}), GG, null);
		_view.setBackground(RE);
	}
	
	
	private void _roundImageViewUrl (final ImageView _imageview, final double _round, final String _url) {
		
		Glide
		.with(getApplicationContext())
		.load(_url)
		.asBitmap()
		.into(
		  new com.bumptech.glide.request.target.SimpleTarget<Bitmap>(100,100) {
			    @Override public void onResourceReady(Bitmap resource, com.bumptech.glide.request.animation.GlideAnimation glideAnimation) {
				 _imageview.setImageBitmap(getRoundedCornerBitmap(cropToSquare(resource), ((int)_round)));
				
				  }
		});
		
	}
	
	public static Bitmap cropToSquare(Bitmap bitmap){
		  int width = bitmap.getWidth();
		  int height = bitmap.getHeight();
		  int newWidth = (height > width) ? width : height;
		  int newHeight = (height > width)? height - ( height - width) : height;
		  int cropW = (width - height) / 2;
		  cropW = (cropW < 0)? 0: cropW;
		  int cropH = (height - width) / 2;
		  cropH = (cropH < 0)? 0: cropH;
		  Bitmap cropImg = Bitmap.createBitmap(bitmap, cropW, cropH, newWidth, newHeight);
		  return cropImg;
	}
	
	
	
	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
		
		int img_w=bitmap.getWidth();
		int img_h=bitmap.getHeight();
		int max_size=img_h;
		if(img_w!=img_h){
			  max_size=Math.min(img_w, img_h);
		}
		final Rect rect = new Rect(0, 0, max_size, max_size);
		
		Bitmap output = Bitmap.createBitmap(max_size, max_size, Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(output);
		final int color = 0xff00ff00;
		final Paint paint = new Paint();
		final RectF rectF = new RectF(rect);
		final float roundPx = pixels;
		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
		paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
		canvas.drawBitmap(bitmap, rect, rect, paint);
		return output;
		//Moreblock by Ilyasse Salama
	}
	
	
	private void _curcle_igm_url (final String _url, final ImageView _img_view) {
		
		Glide.with(getApplicationContext()).load(_url).asBitmap().centerCrop().into(new com.bumptech.glide.request.target.BitmapImageViewTarget(_img_view) {
			@Override protected void setResource(Bitmap resource) {
				androidx.core.graphics.drawable.RoundedBitmapDrawable circularBitmapDrawable = androidx.core.graphics.drawable.RoundedBitmapDrawableFactory.create(getApplicationContext().getResources(), resource); circularBitmapDrawable.setCircular(true); _img_view.setImageDrawable(circularBitmapDrawable);
			}
		});
	}
	
	
	private void _get_user_info () {
		_RoundandShadow(10, 8, "#f44336", button2);
		_RoundandShadow(8, 0, "#eceff1", edittext1);
		_RoundandShadow(8, 0, "#eceff1", edittext2);
		edittext1.setVisibility(View.GONE);
		edit_prof = false;
		edittext2.setVisibility(View.GONE);
		data_user.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				lm_data_user = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						lm_data_user.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				get_data_user = 0;
				for(int _repeat19 = 0; _repeat19 < (int)(lm_data_user.size()); _repeat19++) {
					if (getIntent().getStringExtra("uid").equals(lm_data_user.get((int)get_data_user).get("uid").toString())) {
						textview1.setText(lm_data_user.get((int)get_data_user).get("username").toString());
						textview2.setText(lm_data_user.get((int)get_data_user).get("email").toString());
						edittext1.setText(lm_data_user.get((int)get_data_user).get("username").toString());
						if ("".equals(lm_data_user.get((int)get_data_user).get("pic url").toString())) {
							imageview1.setColorFilter(0xFF757575, PorterDuff.Mode.MULTIPLY);
						}
						else {
							_roundImageViewUrl(imageview1, 500, lm_data_user.get((int)get_data_user).get("pic url").toString());
						}
						if (lm_data_user.get((int)get_data_user).containsKey("about")) {
							textview4.setText(lm_data_user.get((int)get_data_user).get("about").toString());
							edittext2.setText(lm_data_user.get((int)get_data_user).get("about").toString());
						}
						else {
							textview4.setText(lm_data_user.get((int)get_data_user).get("username").toString());
						}
					}
					get_data_user++;
				}
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
		imageview2.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		imageview3.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		imageview4.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		imageview5.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		imageview6.setColorFilter(0xFF9E9E9E, PorterDuff.Mode.MULTIPLY);
		imageview7.setColorFilter(0xFFF44336, PorterDuff.Mode.MULTIPLY);
		imageview8.setColorFilter(0xFF00C853, PorterDuff.Mode.MULTIPLY);
		imageview_follow.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		star.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		_circleRipple("#cfd8dc", linear12);
		_circleRipple("#cfd8dc", linear13);
		_circleRipple("#cfd8dc", linear14);
		_circleRipple("#cfd8dc", linear23);
		_circleRipple("#cfd8dc", imageview_follow);
		_RoundandShadow(0, 12, "#ffffff", linear_profile_about);
		_RoundandShadow(0, 8, "#ffffff", linear24);
		_RoundandShadow(0, 8, "#ffffff", linear11);
		_RoundandShadow(0, 8, "#ffffff", linear15);
		_RoundandShadow(10, 0, "#607d8b", button1);
		_RoundAndBorder(button1, "#ffffff", 2, "#607d8b", 10);
		_RoundAndBorder(linear19, "#ffffff", 2, "#607d8b", 10);
		_RoundAndBorder(linear20, "#ffffff", 2, "#607d8b", 10);
		_RippleEffect_Round(linear19, "#ffffff", 10);
		_RippleEffect_Round(linear20, "#ffffff", 10);
		if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(getIntent().getStringExtra("uid"))) {
			imageview_follow.setVisibility(View.GONE);
			button2.setVisibility(View.VISIBLE);
		}
		else {
			_RoundAndBorder(button1, "#ffffff", 4, "#f44336", 10);
			button1.setText("report");
			button1.setTextColor(0xFFF44336);
			button2.setVisibility(View.GONE);
		}
		imageview_follow.setVisibility(View.GONE);
		linear23.setVisibility(View.GONE);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
