package com.chat.scloud;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.Button;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import java.util.Timer;
import java.util.TimerTask;
import android.app.Activity;
import android.content.SharedPreferences;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.media.SoundPool;
import android.media.MediaPlayer;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class PesanActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private String str = "";
	private String chat_str = "";
	private String uid2 = "";
	private String chat_str_2 = "";
	private double get_message = 0;
	private HashMap<String, Object> map_get_pesan = new HashMap<>();
	private double besar = 0;
	private double kecil = 0;
	private String warna_uid1 = "";
	private String warna_uid_2 = "";
	private boolean onchildAdded = false;
	private double length = 0;
	private double place = 0;
	private double get_username = 0;
	private HashMap<String, Object> map_pesan = new HashMap<>();
	private String push_key = "";
	private String pesan_ = "";
	private String listchat_u1 = "";
	private String listchat_u2 = "";
	private String error = "";
	private HashMap<String, Object> map_key_u2 = new HashMap<>();
	private double sound_sent = 0;
	private double sound_receive = 0;
	private double s1 = 0;
	private double s2 = 0;
	private HashMap<String, Object> map_key_pesan = new HashMap<>();
	private boolean get_messages = false;
	private String list_chat_str = "";
	private boolean pause = false;
	
	private ArrayList<HashMap<String, Object>> lm_listchat_temp = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_pesan = new ArrayList<>();
	private ArrayList<String> ls = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_data_user = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_test = new ArrayList<>();
	private ArrayList<String> ls_tedt = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_list_chat = new ArrayList<>();
	
	private LinearLayout linear1;
	private ListView listview1;
	private LinearLayout linear3;
	private LinearLayout linear2;
	private ImageView imageview1;
	private EditText edittext2;
	private LinearLayout linear4;
	private Button button2;
	private ImageView imageview3;
	private ImageView imageview2;
	
	private DatabaseReference chat = _firebase.getReference(""+chat_str+"");
	private ChildEventListener _chat_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private DatabaseReference chat_2 = _firebase.getReference(""+chat_str_2+"");
	private ChildEventListener _chat_2_child_listener;
	private TimerTask tim;
	private SharedPreferences share;
	private Calendar c = Calendar.getInstance();
	private SharedPreferences pesan;
	private DatabaseReference listChatU1 = _firebase.getReference(""+listchat_u1+"");
	private ChildEventListener _listChatU1_child_listener;
	private DatabaseReference listChatU2 = _firebase.getReference(""+listchat_u2+"");
	private ChildEventListener _listChatU2_child_listener;
	private SoundPool sound;
	private MediaPlayer mp;
	private ObjectAnimator anim = new ObjectAnimator();
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private DatabaseReference data_user = _firebase.getReference("data user");
	private ChildEventListener _data_user_child_listener;
	private DatabaseReference list_chat = _firebase.getReference(""+list_chat_str+"");
	private ChildEventListener _list_chat_child_listener;
	private SharedPreferences listchat;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pesan);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		listview1 = (ListView) findViewById(R.id.listview1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		button2 = (Button) findViewById(R.id.button2);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		auth = FirebaseAuth.getInstance();
		share = getSharedPreferences("share", Activity.MODE_PRIVATE);
		pesan = getSharedPreferences("pesan", Activity.MODE_PRIVATE);
		net = new RequestNetwork(this);
		listchat = getSharedPreferences("listchat", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				get_username = 0;
				get_message = 0;
				anim.setTarget(linear4);
				anim.setPropertyName("translationX");
				anim.setFloatValues((float)(0 - SketchwareUtil.getDisplayWidthPixels(getApplicationContext())), (float)(SketchwareUtil.getLocationX(imageview1)));
				anim.setDuration((int)(200));
				anim.setRepeatCount((int)(0));
				anim.setInterpolator(new LinearInterpolator());
				anim.start();
			}
		});
		
		edittext2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				button2.setEnabled(false);
				anim.setTarget(button2);
				anim.setPropertyName("alpha");
				anim.setFloatValues((float)(0.5d));
				anim.setDuration((int)(100));
				anim.setRepeatMode(ValueAnimator.RESTART);
				anim.setRepeatCount((int)(0));
				anim.setInterpolator(new LinearInterpolator());
				anim.start();
				if (_charSeq.length() > 0) {
					button2.setEnabled(true);
					anim.setTarget(button2);
					anim.setPropertyName("alpha");
					anim.setFloatValues((float)(1));
					anim.setDuration((int)(100));
					anim.setRepeatMode(ValueAnimator.RESTART);
					anim.setRepeatCount((int)(0));
					anim.setInterpolator(new LinearInterpolator());
					anim.start();
				}
				pesan_ = _charSeq;
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				net.startRequestNetwork(RequestNetworkController.GET, "http://google.com/", "", _net_request_listener);
				button2.setAlpha((float)(0.6d));
				button2.setEnabled(false);
				button2.setText("sending...");
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		_chat_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (onchildAdded) {
					lm_pesan.add(_childValue);
					listview1.setAdapter(new Listview1Adapter(lm_pesan));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					listview1.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL); listview1.setStackFromBottom(true);
					if (get_messages) {
						if (lm_pesan.get((int)lm_pesan.size() - 1).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							sound_sent = sound.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);
						}
						else {
							sound_receive = sound.play((int)(2), 1.0f, 1.0f, 1, (int)(0), 1.0f);
						}
					}
					pesan.edit().putString(uid2, new Gson().toJson(lm_pesan)).commit();
					share.edit().putString(uid2, lm_pesan.get((int)lm_pesan.size() - 1).get("push key").toString()).commit();
				}
				else {
					
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		chat.addChildEventListener(_chat_child_listener);
		
		_chat_2_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				map_key_u2.clear();
				map_key_u2.put(_childKey, "uid2");
				share.edit().putString("key".concat(uid2), new Gson().toJson(map_key_u2)).commit();
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				map_key_u2.clear();
				map_key_u2.put(_childKey, "uid2");
				share.edit().putString("key".concat(uid2), new Gson().toJson(map_key_u2)).commit();
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				map_key_u2.clear();
				share.edit().putString("key".concat(uid2), new Gson().toJson(map_key_u2)).commit();
				_SortMap(lm_pesan, "push key", false, true);
				listview1.setAdapter(new Listview1Adapter(lm_pesan));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				listview1.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL); listview1.setStackFromBottom(true);
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		chat_2.addChildEventListener(_chat_2_child_listener);
		
		_listChatU1_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		listChatU1.addChildEventListener(_listChatU1_child_listener);
		
		_listChatU2_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		listChatU2.addChildEventListener(_listChatU2_child_listener);
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				map_pesan.clear();
				c = Calendar.getInstance();
				push_key = chat.push().getKey();
				map_pesan = new HashMap<>();
				map_pesan.put("pesan", pesan_);
				map_pesan.put("tanggal", new SimpleDateFormat("dd/MM/yyyy").format(c.getTime()));
				map_pesan.put("jam", new SimpleDateFormat("HH:mm").format(c.getTime()));
				map_pesan.put("gmt", new SimpleDateFormat("ZZZZ").format(c.getTime()));
				map_pesan.put("reply", "");
				map_pesan.put("reply id", "");
				map_pesan.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map_pesan.put("push key", push_key);
				map_pesan.put("tipe", "pc");
				chat.child(push_key).updateChildren(map_pesan);
				chat_2.child(push_key).updateChildren(map_pesan);
				map_pesan.put("uid2", uid2);
				listChatU1.child(uid2).updateChildren(map_pesan);
				map_pesan.put("uid2", FirebaseAuth.getInstance().getCurrentUser().getUid());
				listChatU2.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map_pesan);
				edittext2.setText("");
				button2.setAlpha((float)(0.5d));
				button2.setText("send");
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				button2.setAlpha((float)(1));
				button2.setEnabled(true);
				button2.setText("send");
				SketchwareUtil.showMessage(getApplicationContext(), "Check your Internet connection");
			}
		};
		
		_data_user_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		data_user.addChildEventListener(_data_user_child_listener);
		
		_list_chat_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				_get_list_chat();
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				_get_list_chat();
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				_get_list_chat();
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		list_chat.addChildEventListener(_list_chat_child_listener);
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		linear4.setTranslationX((float)(0 - SketchwareUtil.getDisplayWidthPixels(getApplicationContext())));
		list_chat.removeEventListener(_list_chat_child_listener);
		list_chat_str = "chat list/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid());
		list_chat = _firebase.getReference(list_chat_str);
		list_chat.addChildEventListener(_list_chat_child_listener);
		_get_child_key();
		_circleRipple("#2196f3", imageview1);
		imageview1.setColorFilter(0xFF9E9E9E, PorterDuff.Mode.MULTIPLY);
		share.edit().putString("list_chat_", "ya").commit();
		edittext2.setMaxHeight(230);
		sound = new SoundPool((int)(2), AudioManager.STREAM_MUSIC, 0);
		sound_receive = sound.load(getApplicationContext(), R.raw.sent, 1);
		sound_sent = sound.load(getApplicationContext(), R.raw.new_message, 1);
		uid2 = getIntent().getStringExtra("uid");
		chat.removeEventListener(_chat_child_listener);
		chat_str = "chat/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(getIntent().getStringExtra("uid"))));
		chat = _firebase.getReference(chat_str);
		chat.addChildEventListener(_chat_child_listener);
		chat_2.removeEventListener(_chat_2_child_listener);
		chat_str_2 = "chat/".concat(getIntent().getStringExtra("uid").concat("/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid())));
		chat_2 = _firebase.getReference(chat_str_2);
		chat_2.addChildEventListener(_chat_2_child_listener);
		listChatU1.removeEventListener(_listChatU1_child_listener);
		listchat_u1 = "chat list/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid());
		listChatU1 = _firebase.getReference(listchat_u1);
		listChatU1.addChildEventListener(_listChatU1_child_listener);
		listChatU2.removeEventListener(_listChatU2_child_listener);
		listchat_u2 = "chat list/".concat(uid2);
		listChatU2 = _firebase.getReference(listchat_u2);
		listChatU2.addChildEventListener(_listChatU2_child_listener);
		if (!"".equals(share.getString("data user", ""))) {
			lm_data_user = new Gson().fromJson(share.getString("data user", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		}
		data_user.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				lm_data_user = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						lm_data_user.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				get_username = 0;
				for(int _repeat85 = 0; _repeat85 < (int)(lm_data_user.size()); _repeat85++) {
					if (uid2.equals(lm_data_user.get((int)get_username).get("uid").toString())) {
						setTitle(lm_data_user.get((int)get_username).get("username").toString());
					}
					get_username++;
				}
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
		get_messages = true;
		_get_message_();
		button2.setEnabled(false);
		button2.setAlpha((float)(0.5d));
		_RoundAndBorder(linear4, "#2196f3", 0, "#2196f3", 50);
		_RoundAndBorder(button2, "#2196f3", 0, "#2196f3", 50);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onStop() {
		super.onStop();
		get_messages = false;
		share.edit().putString("list_chat_", "").commit();
	}
	
	@Override
	public void onResume() {
		super.onResume();
		get_messages = true;
		share.edit().putString("list_chat_", "ya").commit();
	}
	private void _SortMap (final ArrayList<HashMap<String, Object>> _listMap, final String _key, final boolean _isNumber, final boolean _Ascending) {
		final Object _keyObject = _key;
		Collections.sort(_listMap, new Comparator<HashMap<String,Object>>(){
			public int compare(HashMap<String,Object> _compareMap1, HashMap<String,Object> _compareMap2){
				if (_isNumber) {
					int _count1 = Integer.valueOf(_compareMap1.get(_key).toString());
					int _count2 = Integer.valueOf(_compareMap2.get(_key).toString());
					if (_Ascending) {
						return _count1 < _count2 ? -1 : _count1 < _count2 ? 1 : 0;
					}
					else {
						return _count1 > _count2 ? -1 : _count1 > _count2 ? 1 : 0;
					}
				}
				else {
					if (_Ascending) {
						return (_compareMap1.get(_key).toString()).compareTo(_compareMap2.get(_key).toString());
					}
					else {
						return (_compareMap2.get(_key).toString()).compareTo(_compareMap1.get(_key).toString());
					}
				}
			}});
		///Use true or false blocks if sorting number of listmap
	}
	
	
	private void _hide_date (final double _n, final View _v) {
		_v.setVisibility(View.GONE);
		if ((_n == 0) && (lm_pesan.size() == 1)) {
			_v.setVisibility(View.VISIBLE);
		}
		if (_n == (lm_pesan.size() - 1)) {
			_v.setVisibility(View.VISIBLE);
		}
		if (!(_n == (lm_pesan.size() - 1)) && !(_n == 0)) {
			if (!lm_pesan.get((int)_n).get("uid").toString().equals(lm_pesan.get((int)_n + 1).get("uid").toString())) {
				_v.setVisibility(View.VISIBLE);
			}
		}
	}
	
	
	private void _advancedCorners (final View _view, final String _color, final double _n1, final double _n2, final double _n3, final double _n4) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		
		gd.setCornerRadii(new float[]{(int)_n1,(int)_n1,(int)_n2,(int)_n2,(int)_n4,(int)_n4,(int)_n3,(int)_n3});
		
		_view.setBackground(gd);
	}
	
	
	private void _get_message_ () {
		if (!pesan.getString(uid2, "").equals("")) {
			lm_pesan = new Gson().fromJson(pesan.getString(uid2, ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			listview1.setAdapter(new Listview1Adapter(lm_pesan));
			((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			listview1.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL); listview1.setStackFromBottom(true);
		}
		if (get_messages) {
			chat.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					lm_pesan = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							lm_pesan.add(_map);
						}
					}
					catch (Exception _e) {
						_e.printStackTrace();
					}
					if (lm_pesan.size() > 0) {
						listview1.setAdapter(new Listview1Adapter(lm_pesan));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						listview1.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL); listview1.setStackFromBottom(true);
						if (share.getString(uid2, "").equals(lm_pesan.get((int)lm_pesan.size() - 1).get("push key").toString())) {
							
						}
						else {
							if (lm_pesan.get((int)lm_pesan.size() - 1).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
								sound_sent = sound.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);
							}
							else {
								sound_receive = sound.play((int)(2), 1.0f, 1.0f, 1, (int)(0), 1.0f);
							}
						}
						share.edit().putString(uid2, lm_pesan.get((int)lm_pesan.size() - 1).get("push key").toString()).commit();
					}
					tim = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									onchildAdded = true;
								}
							});
						}
					};
					_timer.schedule(tim, (int)(500));
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
		}
	}
	
	
	private void _saveList (final SharedPreferences _getShPref, final ArrayList<String> _getList, final boolean _isSaving) {
		//set SharedPreferences and ListString when you start this block
		if (!_getShPref.getString("length", "").equals("")) {
			if (_isSaving) {
				//saves the list
				length = _getList.size();
				place = length - 1;
				_getShPref.edit().putString("length", String.valueOf((long)(length))).commit();
				for(int _repeat16 = 0; _repeat16 < (int)(length); _repeat16++) {
					_getShPref.edit().putString(String.valueOf((long)(place)), _getList.get((int)(place))).commit();
					place--;
				}
			}
			else {
				//read from SharedPreferences
				length = Double.parseDouble(_getShPref.getString("length", ""));
				place = length - 1;
				for(int _repeat43 = 0; _repeat43 < (int)(length); _repeat43++) {
					_getList.add(_getShPref.getString(String.valueOf((long)(place)), ""));
					place--;
				}
			}
		}
		else {
			
		}
	}
	
	
	private void _RoundAndBorder (final View _view, final String _color1, final double _border, final String _color2, final double _round) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color1));
		gd.setCornerRadius((int) _round);
		gd.setStroke((int) _border, Color.parseColor(_color2));
		_view.setBackground(gd);
	}
	
	
	private void _get_child_key () {
		
	}
	
	
	private void _circleRipple (final String _color, final View _v) {
		android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor(_color)});
		android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , null, null);
		_v.setBackground(ripdrb);
	}
	
	
	private void _get_list_chat () {
		list_chat.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				lm_list_chat = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						lm_list_chat.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				listchat.edit().putString("ls", new Gson().toJson(lm_list_chat)).commit();
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.pesanf, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final LinearLayout linear_tgl = (LinearLayout) _v.findViewById(R.id.linear_tgl);
			final LinearLayout linear_pesan = (LinearLayout) _v.findViewById(R.id.linear_pesan);
			final TextView textview3 = (TextView) _v.findViewById(R.id.textview3);
			final TextView textview2 = (TextView) _v.findViewById(R.id.textview2);
			final TextView tanggal = (TextView) _v.findViewById(R.id.tanggal);
			
			textview3.setVisibility(View.GONE);
			c = Calendar.getInstance();
			try {
				if (lm_pesan.get((int)_position).containsKey("pesan")) {
					textview2.setText(lm_pesan.get((int)_position).get("pesan").toString());
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "tidak ada key pesan");
				}
			}
			
			catch (Exception e)
			{
				error = e.toString();
				SketchwareUtil.showMessage(getApplicationContext(), error);
			}
			try {
				if (lm_pesan.get((int)_position).containsKey("tanggal")) {
					tanggal.setText(lm_pesan.get((int)_position).get("tanggal").toString());
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "tanggal tidak ada");
				}
			}
			
			catch (Exception e)
			{
				error = e.toString();
				SketchwareUtil.showMessage(getApplicationContext(), error);
			}
			if (lm_pesan.get((int)_position).containsKey("uid")) {
				tanggal.setText("sent".concat(" • ".concat(lm_pesan.get((int)_position).get("tanggal").toString())));
				if (new SimpleDateFormat("dd/MM/yyyy").format(c.getTime()).equals(lm_pesan.get((int)_position).get("tanggal").toString())) {
					tanggal.setText("sent".concat(" • ".concat(lm_pesan.get((int)_position).get("jam").toString())));
				}
				if (new SimpleDateFormat("dd/MM/yyyy").format(c.getTime()).equals(lm_pesan.get((int)_position).get("tanggal").toString())) {
					tanggal.setText(lm_pesan.get((int)_position).get("jam").toString());
				}
				if (lm_pesan.get((int)_position).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					linear1.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
					linear_tgl.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
					linear1.setPadding(60,2,8,2);
				}
				else {
					linear1.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
					linear_tgl.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
					linear1.setPadding(8,2,60,2);
				}
				_hide_date(_position, linear_tgl);
			}
			else {
				chat.child(lm_pesan.get((int)_position).get("push key").toString()).removeValue();
			}
			if (!FirebaseAuth.getInstance().getCurrentUser().getUid().equals(lm_pesan.get((int)_position).get("uid").toString())) {
				
				textview2.setTextColor(Color.parseColor("#000000"));
			}
			
			if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(lm_pesan.get((int)_position).get("uid").toString())) {
				_advancedCorners(linear_pesan, "#607d8b", 8, 8, 8, 8);
			}
			else {
				_advancedCorners(linear_pesan, "#ffffff", 8, 8, 8, 8);
			}
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
