package comp.c6;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import android.widget.ImageView;
import android.content.SharedPreferences;
import java.util.Timer;
import java.util.TimerTask;
import android.app.AlertDialog;
import android.content.DialogInterface;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.AdListener;
import com.bumptech.glide.Glide;

public class ImageActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ProgressBar progressbar1;
	private AdView adview1;
	private ImageView imageview1;
	
	private SharedPreferences file;
	private TimerTask r;
	private AlertDialog.Builder db;
	private InterstitialAd ad;
	private AdListener _ad_ad_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.image);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		adview1 = (AdView) findViewById(R.id.adview1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		file = getSharedPreferences("file", Activity.MODE_PRIVATE);
		db = new AlertDialog.Builder(this);
		
		_ad_ad_listener = new AdListener() {
			@Override
			public void onAdLoaded() {
				ad.show();
			}
			
			@Override
			public void onAdFailedToLoad(int _param1) {
				final int _errorCode = _param1;
				SketchwareUtil.showMessage(getApplicationContext(), "failed");
			}
			
			@Override
			public void onAdOpened() {
				
			}
			
			@Override
			public void onAdClosed() {
				
			}
		};
	}
	private void initializeLogic() {
		Glide.with(getApplicationContext()).load(Uri.parse(file.getString("1", ""))).into(imageview1);
		r = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						linear1.setVisibility(View.GONE);
						SketchwareUtil.showMessage(getApplicationContext(), "loaded....");
						db.setMessage("HOLD YOU\n\n1:UP VOLUME DOWN--\n\n2:AND YOU POWER OFF BUTTON AT THE SAME TIME\n\n");
						db.setPositiveButton("ok", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						db.create().show();
					}
				});
			}
		};
		_timer.schedule(r, (int)(1000));
		ad = new InterstitialAd(getApplicationContext());
		ad.setAdListener(_ad_ad_listener);
		ad.setAdUnitId("ca-app-pub-7284199344685037/5762253214");
		ad.loadAd(new AdRequest.Builder().addTestDevice("3A87EEFBE4F35EF77D6F58E13CFDF0E2")
		.build());
		ad.show();
		adview1.loadAd(new AdRequest.Builder().addTestDevice("3A87EEFBE4F35EF77D6F58E13CFDF0E2")
		.build());
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
