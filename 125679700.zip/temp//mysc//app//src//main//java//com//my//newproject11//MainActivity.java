package com.my.newproject11;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.view.View;

public class MainActivity extends AppCompatActivity {
	
	
	private boolean collapseBool = false;
	
	private LinearLayout action_back;
	private LinearLayout bottom_line;
	private LinearLayout action_fore;
	private LinearLayout linear4;
	private LinearLayout line_back;
	private LinearLayout line_fore;
	private LinearLayout cardview;
	private TextView textview1;
	private LinearLayout image_background;
	private ImageView imageview1;
	private LinearLayout button1;
	private LinearLayout button2;
	private LinearLayout button3;
	private LinearLayout linear8;
	private TextView textview2;
	private TextView textview3;
	private TextView textview4;
	private ImageView collapsing_button;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout line_1;
	private LinearLayout line_2;
	private LinearLayout line_3;
	private ImageView imageview2;
	private TextView textview5;
	private ImageView imageview3;
	private TextView textview6;
	private ImageView imageview4;
	private TextView textview7;
	private LinearLayout line_4;
	private LinearLayout line_5;
	private LinearLayout line_6;
	private ImageView imageview5;
	private TextView textview8;
	private ImageView imageview6;
	private TextView textview9;
	private ImageView imageview7;
	private TextView textview10;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		action_back = (LinearLayout) findViewById(R.id.action_back);
		bottom_line = (LinearLayout) findViewById(R.id.bottom_line);
		action_fore = (LinearLayout) findViewById(R.id.action_fore);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		line_back = (LinearLayout) findViewById(R.id.line_back);
		line_fore = (LinearLayout) findViewById(R.id.line_fore);
		cardview = (LinearLayout) findViewById(R.id.cardview);
		textview1 = (TextView) findViewById(R.id.textview1);
		image_background = (LinearLayout) findViewById(R.id.image_background);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		button1 = (LinearLayout) findViewById(R.id.button1);
		button2 = (LinearLayout) findViewById(R.id.button2);
		button3 = (LinearLayout) findViewById(R.id.button3);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		collapsing_button = (ImageView) findViewById(R.id.collapsing_button);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		line_1 = (LinearLayout) findViewById(R.id.line_1);
		line_2 = (LinearLayout) findViewById(R.id.line_2);
		line_3 = (LinearLayout) findViewById(R.id.line_3);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview5 = (TextView) findViewById(R.id.textview5);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview6 = (TextView) findViewById(R.id.textview6);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview7 = (TextView) findViewById(R.id.textview7);
		line_4 = (LinearLayout) findViewById(R.id.line_4);
		line_5 = (LinearLayout) findViewById(R.id.line_5);
		line_6 = (LinearLayout) findViewById(R.id.line_6);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview8 = (TextView) findViewById(R.id.textview8);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		textview9 = (TextView) findViewById(R.id.textview9);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		textview10 = (TextView) findViewById(R.id.textview10);
		
		collapsing_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (collapseBool) {
					_TransitionManager(bottom_line, 200);
					_TransitionManager(action_back, 200);
					button1.setVisibility(View.GONE);
					button2.setVisibility(View.GONE);
					button3.setVisibility(View.GONE);
					bottom_line.setVisibility(View.VISIBLE);
					collapseBool = false;
					_Animator(collapsing_button, "rotation", 0, 200);
				}
				else {
					_TransitionManager(bottom_line, 200);
					_TransitionManager(action_back, 200);
					button1.setVisibility(View.VISIBLE);
					button2.setVisibility(View.VISIBLE);
					button3.setVisibility(View.VISIBLE);
					bottom_line.setVisibility(View.GONE);
					collapseBool = true;
					_Animator(collapsing_button, "rotation", 180, 200);
				}
			}
		});
	}
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) { getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); }
		_setBG(action_back, "#D86BBA", "#A90DB9", 0, 0, 400, 400, 50, "#B5009F");
		_setBG(action_fore, "#FFFFFF", "#FFFFFF", 0, 0, 400, 400, 50, "#000000");
		_setBG(line_back, "#D86BBA", "#A90DB9", 0, 0, 400, 400, 0, "#d100ff");
		_setBG(line_fore, "#FFFFFF", "#FFFFFF", 0, 0, 400, 400, 0, "#000000");
		_addCardView(image_background, 10, 200, 10, 10, true, "#ffffff");
		button1.setVisibility(View.GONE);
		button2.setVisibility(View.GONE);
		button3.setVisibility(View.GONE);
		_setBackground(line_1, "#ffffff", "#fff4fe", 20, 10, "#D86BBA");
		_setBackground(line_2, "#ffffff", "#fff4fe", 20, 10, "#D86BBA");
		_setBackground(line_3, "#ffffff", "#fff4fe", 20, 10, "#D86BBA");
		_setBackground(line_4, "#ffffff", "#fff4fe", 20, 10, "#D86BBA");
		_setBackground(line_5, "#ffffff", "#fff4fe", 20, 10, "#D86BBA");
		_setBackground(line_6, "#ffffff", "#fff4fe", 20, 10, "#D86BBA");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _setBackground (final View _view, final String _color1, final String _color2, final double _radius, final double _shadow, final String _shadowColor) {
		int[] colors = { Color.parseColor(_color1), Color.parseColor(_color2) }; android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.RIGHT_LEFT, colors); gd.setCornerRadius((int)_radius); _view.setBackground(gd);
		_view.setElevation((int)_shadow);
		_view.setOutlineSpotShadowColor(Color.parseColor(_shadowColor));
	}
	
	
	private void _setBG (final View _view, final String _color1, final String _color2, final double _lt, final double _rt, final double _rb, final double _lb, final double _shadow, final String _shadowColor) {
		int[] colors = { Color.parseColor(_color1), Color.parseColor(_color2) }; android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.RIGHT_LEFT, colors);
		gd.setCornerRadii(new float[]{(int)_lt,(int)_lt,(int)_rt,(int)_rt,(int)_rb,(int)_rb,(int)_lb,(int)_lb});
		_view.setBackground(gd);
		
		_view.setElevation((int)_shadow);
		_view.setOutlineSpotShadowColor(Color.parseColor(_shadowColor));
	}
	
	
	private void _addCardView (final View _layoutView, final double _margins, final double _cornerRadius, final double _cardElevation, final double _cardMaxElevation, final boolean _preventCornerOverlap, final String _backgroundColor) {
		androidx.cardview.widget.CardView cv = new androidx.cardview.widget.CardView(this);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
		int m = (int)_margins;
		lp.setMargins(m,m,m,m);
		cv.setLayoutParams(lp);
		int c = Color.parseColor(_backgroundColor);
		cv.setCardBackgroundColor(c);
		cv.setRadius((float)_cornerRadius);
		cv.setCardElevation((float)_cardElevation);
		cv.setMaxCardElevation((float)_cardMaxElevation);
		cv.setPreventCornerOverlap(_preventCornerOverlap);
		if(_layoutView.getParent() instanceof LinearLayout){
			ViewGroup vg = ((ViewGroup)_layoutView.getParent());
			vg.removeView(_layoutView);
			vg.removeAllViews();
			vg.addView(cv);
			cv.addView(_layoutView);
		}else{
			
		}
	}
	
	
	private void _TransitionManager (final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration);
		autoTransition.setInterpolator(new android.view.animation.DecelerateInterpolator()); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	private void _Animator (final View _view, final String _propertyName, final double _value, final double _duration) {
		ObjectAnimator anim = new ObjectAnimator();
		anim.setTarget(_view);
		anim.setPropertyName(_propertyName);
		anim.setFloatValues((float)_value);
		anim.setDuration((long)_duration);
		anim.start();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
