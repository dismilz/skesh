package com.example.like;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.EditText;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.view.View;

public class HomeActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String push_key = "";
	private HashMap<String, Object> map_feed = new HashMap<>();
	private HashMap<String, Object> put_like = new HashMap<>();
	private HashMap<String, Object> map_like = new HashMap<>();
	private double n = 0;
	private double n_ls_like = 0;
	private double num_like = 0;
	private double likes = 0;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_like = new ArrayList<>();
	private ArrayList<String> ls_like = new ArrayList<>();
	
	private ListView listview1;
	private LinearLayout linear1;
	private Button button1;
	private EditText edittext1;
	
	private DatabaseReference feed = _firebase.getReference("feed");
	private ChildEventListener _feed_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private DatabaseReference like = _firebase.getReference("like_key");
	private ChildEventListener _like_child_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		listview1 = (ListView) findViewById(R.id.listview1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		button1 = (Button) findViewById(R.id.button1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		auth = FirebaseAuth.getInstance();
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals("")) {
					
				}
				else {
					push_key = feed.push().getKey();
					map_feed.put("push key", push_key);
					map_feed.put("message", edittext1.getText().toString());
					map_feed.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					map_feed.put(FirebaseAuth.getInstance().getCurrentUser().getUid(), "uid");
					feed.child(push_key).updateChildren(map_feed);
					put_like = new HashMap<>();
					put_like.put(push_key, "push key");
					like.child(push_key).updateChildren(put_like);
				}
			}
		});
		
		_feed_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				feed.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						_SortMap(listmap, "push key", false, false);
						listview1.setAdapter(new Listview1Adapter(listmap));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		feed.addChildEventListener(_feed_child_listener);
		
		_like_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		like.addChildEventListener(_like_child_listener);
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		feed.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				listmap = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						listmap.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				_SortMap(listmap, "push key", false, false);
				listview1.setAdapter(new Listview1Adapter(listmap));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _SortMap (final ArrayList<HashMap<String, Object>> _listMap, final String _key, final boolean _isNumber, final boolean _Ascending) {
		Collections.sort(_listMap, new Comparator<HashMap<String,Object>>(){
			public int compare(HashMap<String,Object> _compareMap1, HashMap<String,Object> _compareMap2){
				if (_isNumber) {
					int _count1 = Integer.valueOf(_compareMap1.get(_key).toString());
					int _count2 = Integer.valueOf(_compareMap2.get(_key).toString());
					if (_Ascending) {
						return _count1 < _count2 ? -1 : _count1 < _count2 ? 1 : 0;
					}
					else {
						return _count1 > _count2 ? -1 : _count1 > _count2 ? 1 : 0;
					}
				}
				else {
					if (_Ascending) {
						return (_compareMap1.get(_key).toString()).compareTo(_compareMap2.get(_key).toString());
					}
					else {
						return (_compareMap2.get(_key).toString()).compareTo(_compareMap1.get(_key).toString());
					}
				}
			}});
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.post, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			final TextView textview2 = (TextView) _v.findViewById(R.id.textview2);
			
			textview1.setText(listmap.get((int)_position).get("message").toString());
			imageview1.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
			like.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					lm_like = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							lm_like.add(_map);
						}
					}
					catch (Exception _e) {
						_e.printStackTrace();
					}
					textview2.setText(String.valueOf((long)(0)));
					map_like.clear();
					ls_like.clear();
					num_like = 0;
					for(int _repeat20 = 0; _repeat20 < (int)(lm_like.size()); _repeat20++) {
						if (lm_like.get((int)num_like).containsKey(listmap.get((int)_position).get("push key").toString())) {
							map_like = lm_like.get((int)num_like);
							SketchwareUtil.getAllKeysFromMap(map_like, ls_like);
							likes = 0;
							n_ls_like = 0;
							if (map_like.containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid()) && map_like.get(FirebaseAuth.getInstance().getCurrentUser().getUid()).toString().equals("true")) {
								imageview1.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
								imageview1.setImageResource(R.drawable.ic_thumb_up_white);
							}
							for(int _repeat41 = 0; _repeat41 < (int)(ls_like.size()); _repeat41++) {
								if (map_like.get(ls_like.get((int)(n_ls_like))).toString().equals("true")) {
									likes++;
									textview2.setText(String.valueOf((long)(likes)));
								}
								n_ls_like++;
							}
							if (!map_like.containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
								imageview1.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
								imageview1.setImageResource(R.drawable.ic_thumb_up_white);
							}
						}
						num_like++;
					}
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					like.addListenerForSingleValueEvent(new ValueEventListener() {
						@Override
						public void onDataChange(DataSnapshot _dataSnapshot) {
							lm_like = new ArrayList<>();
							try {
								GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
								for (DataSnapshot _data : _dataSnapshot.getChildren()) {
									HashMap<String, Object> _map = _data.getValue(_ind);
									lm_like.add(_map);
								}
							}
							catch (Exception _e) {
								_e.printStackTrace();
							}
							num_like = 0;
							for(int _repeat64 = 0; _repeat64 < (int)(lm_like.size()); _repeat64++) {
								if (lm_like.get((int)num_like).containsKey(listmap.get((int)_position).get("push key").toString())) {
									map_like = lm_like.get((int)num_like);
									SketchwareUtil.getAllKeysFromMap(map_like, ls_like);
									likes = 0;
									n_ls_like = 0;
									for(int _repeat76 = 0; _repeat76 < (int)(ls_like.size()); _repeat76++) {
										if (map_like.get(ls_like.get((int)(n_ls_like))).toString().equals("true")) {
											likes++;
										}
										n_ls_like++;
									}
									if (map_like.containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
										if (map_like.get(FirebaseAuth.getInstance().getCurrentUser().getUid()).toString().equals("true")) {
											put_like.put(FirebaseAuth.getInstance().getCurrentUser().getUid(), "false");
											put_like.put(listmap.get((int)_position).get("push key").toString(), "post id");
											like.child(listmap.get((int)_position).get("push key").toString()).updateChildren(put_like);
											likes--;
											textview2.setText(String.valueOf((long)(likes)));
											imageview1.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
											imageview1.setImageResource(R.drawable.ic_thumb_up_white);
										}
										else {
											if (map_like.get(FirebaseAuth.getInstance().getCurrentUser().getUid()).toString().equals("false")) {
												imageview1.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
												imageview1.setImageResource(R.drawable.ic_thumb_up_white);
												put_like.put(FirebaseAuth.getInstance().getCurrentUser().getUid(), "true");
												put_like.put(listmap.get((int)_position).get("push key").toString(), "post id");
												like.child(listmap.get((int)_position).get("push key").toString()).updateChildren(put_like);
												likes++;
												textview2.setText(String.valueOf((long)(likes)));
											}
										}
									}
									else {
										imageview1.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
										imageview1.setImageResource(R.drawable.ic_thumb_up_white);
										put_like.put(FirebaseAuth.getInstance().getCurrentUser().getUid(), "true");
										put_like.put(listmap.get((int)_position).get("push key").toString(), "post id");
										like.child(listmap.get((int)_position).get("push key").toString()).updateChildren(put_like);
										likes++;
										textview2.setText(String.valueOf((long)(likes)));
									}
								}
								num_like++;
							}
							put_like.clear();
						}
						@Override
						public void onCancelled(DatabaseError _databaseError) {
						}
					});
				}
			});
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
