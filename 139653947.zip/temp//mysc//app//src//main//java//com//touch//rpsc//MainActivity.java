package com.touch.rpsc;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Timer;
import java.util.TimerTask;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.view.View;
import android.graphics.Typeface;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private double numb = 0;
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear8;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private ImageView player;
	private ImageView ai;
	private TextView textview2;
	private TextView score;
	private LinearLayout linear7;
	private TextView win;
	private ImageView paper;
	private ImageView rock;
	private ImageView sc;
	private TextView textview3;
	private TextView textview4;
	
	private TimerTask time;
	private AlertDialog.Builder dlg;
	private SharedPreferences save;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		player = (ImageView) findViewById(R.id.player);
		ai = (ImageView) findViewById(R.id.ai);
		textview2 = (TextView) findViewById(R.id.textview2);
		score = (TextView) findViewById(R.id.score);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		win = (TextView) findViewById(R.id.win);
		paper = (ImageView) findViewById(R.id.paper);
		rock = (ImageView) findViewById(R.id.rock);
		sc = (ImageView) findViewById(R.id.sc);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		dlg = new AlertDialog.Builder(this);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		
		player.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		paper.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				player.setVisibility(View.VISIBLE);
				ai.setVisibility(View.VISIBLE);
				_AI_Player();
				player.setImageResource(R.drawable.paper);
				if (numb == 1) {
					win.setText("Win!");
					win.setTextColor(0xFF76FF03);
					score.setText(String.valueOf((long)(Double.parseDouble(score.getText().toString()) + 1)));
				}
				if (numb == 2) {
					win.setText("Draw");
					win.setTextColor(0xFF000000);
				}
				if (numb == 3) {
					win.setText("Lose");
					win.setTextColor(0xFFF44336);
				}
			}
		});
		
		rock.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				player.setVisibility(View.VISIBLE);
				ai.setVisibility(View.VISIBLE);
				_AI_Player();
				player.setImageResource(R.drawable.scie);
				if (numb == 1) {
					win.setText("Lose");
					win.setTextColor(0xFFFF1744);
				}
				if (numb == 2) {
					win.setText("Win");
					win.setTextColor(0xFF76FF03);
					score.setText(String.valueOf((long)(Double.parseDouble(score.getText().toString()) + 1)));
				}
				if (numb == 3) {
					win.setText("Draw");
					win.setTextColor(0xFF000000);
				}
			}
		});
		
		sc.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				player.setVisibility(View.VISIBLE);
				ai.setVisibility(View.VISIBLE);
				_AI_Player();
				player.setImageResource(R.drawable.rock);
				if (numb == 1) {
					win.setText("Draw");
					win.setTextColor(0xFF000000);
				}
				if (numb == 2) {
					win.setText("Lose");
					win.setTextColor(0xFFFF1744);
				}
				if (numb == 3) {
					win.setText("Win");
					win.setTextColor(0xFF76FF03);
					score.setText(String.valueOf((long)(Double.parseDouble(score.getText().toString()) + 1)));
				}
			}
		});
	}
	private void initializeLogic() {
		numb = 0;
		if (numb == 11) {
			player.setVisibility(View.GONE);
			ai.setVisibility(View.GONE);
			win.setTextColor(0xFF000000);
		}
		score.setText("0");
		win.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/computeramok.ttf"), 0);
		score.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/computeramok.ttf"), 0);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/computeramok.ttf"), 0);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/computeramok.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/computeramok.ttf"), 0);
		if (textview4.getText().toString().toUpperCase().contains(score.getText().toString())) {
			if (save.getString("score", "").equals("")) {
				textview4.setText("0");
			}
			else {
				textview4.setText(save.getString("score", ""));
			}
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		save.edit().putString("score", score.getText().toString()).commit();
		finish();
	}
	private void _AI_Player () {
		numb = SketchwareUtil.getRandom((int)(1), (int)(3));
		if (numb == 1) {
			ai.setImageResource(R.drawable.rock_ai);
		}
		if (numb == 2) {
			ai.setImageResource(R.drawable.paper_ai);
		}
		if (numb == 3) {
			ai.setImageResource(R.drawable.sc_ai);
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
