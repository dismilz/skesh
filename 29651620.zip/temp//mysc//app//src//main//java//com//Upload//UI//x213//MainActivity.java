package com.Upload.UI.x213;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.Button;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.AdapterView;
import android.view.View;

public class MainActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	private FloatingActionButton _fab;
	private double n = 0;
	private double tv = 0;
	
	private ArrayList<String> list = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout linear1;
	private ListView listview1;
	private ImageView imageview1;
	private EditText edittext1;
	private Button clear;
	
	private SharedPreferences f;
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	private Intent ii = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_fab = (FloatingActionButton) findViewById(R.id._fab);
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		listview1 = (ListView) findViewById(R.id.listview1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		clear = (Button) findViewById(R.id.clear);
		f = getSharedPreferences("f", Activity.MODE_PRIVATE);
		d = new AlertDialog.Builder(this);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				i.setClass(getApplicationContext(), OpenActivity.class);
				i.putExtra("A", list.get((int)(_position)));
				i.putExtra("B", f.getString(list.get((int)(_position)), ""));
				startActivity(i);
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				list.clear();
				n = 0;
				while(true) {
					if (f.getString(String.valueOf((long)(n)), "").equals("")) {
						break;
					}
					else {
						if (_charSeq.length() > f.getString(String.valueOf((long)(n)), "").length()) {
							
						}
						else {
							if (f.getString(String.valueOf((long)(n)), "").substring((int)(0), (int)(_charSeq.length())).toLowerCase().contains(_charSeq.toLowerCase())) {
								list.add(f.getString(String.valueOf((long)(n)), ""));
							}
						}
						n++;
					}
				}
				listview1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_list_item_1, list));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		clear.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				edittext1.setText("");
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				list.add(edittext1.getText().toString());
			}
		});
	}
	private void initializeLogic() {
		i.setClass(getApplicationContext(), WalcomeActivity.class);
		startActivity(i);
		tv = 1;
		if (f.getString("-1", "").equals("")) {
			_words();
			f.edit().putString("-1", "-1").commit();
		}
		else {
			
		}
		list.clear();
		n = 0;
		while(true) {
			if (f.getString(String.valueOf((long)(n)), "").equals("")) {
				break;
			}
			else {
				if (f.getString(String.valueOf((long)(n)), "").length() > 0) {
					list.add(f.getString(String.valueOf((long)(n)), ""));
				}
				n++;
			}
		}
		listview1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_list_item_1, list));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		d.setTitle("exit");
		d.setMessage("rr you so want to exit");
		d.setPositiveButton("yess", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finish();
			}
		});
		d.setNegativeButton("NO", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		d.create().show();
	}
	private void _Add (final double _post, final String _word, final String _meaning) {
		f.edit().putString(String.valueOf((long)(_post)), _word).commit();
		f.edit().putString(_word, _meaning).commit();
	}
	
	
	private void _words () {
		_Add(0, "ActionBar Show/Hide", "/*Use Below Two Codes When Support Library Is Not Active*/\n\n//show actionbar \n getActionBar().show() \n\n//hide ActionBar \n getActionBar().hide();\n\n\n/*Use Below Two Codes When Support Library Is Active*/\n\n//show actionbar \n getSupportActionBar().show() \n\n//hide ActionBar \n getSupportActionBar().hide();\n");
		_Add(1, "ActionBar Color", "\n/*ActionBar Color...*/\n\nActionBar actionBar = getActionBar(); actionBar.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.parseColor(\"#191919\")));\nif (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {\n    Window w = MainActivity.this.getWindow();\n    w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);\n    w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);\n    w.setStatusBarColor(Color.parseColor(\"#000000\"));\n}\n\n/*Change ActionBar Title Color*/\n\ngetActionBar().setTitle(Html.fromHtml(\"<font color='#FF0000'>Color Tools</font>\"));\n\n/*Change In Action Bar Header / Statues Bar */\n\ntry {\nif (Build.VERSION.SDK_INT >= 21) {\ngetWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);\ngetWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);\ngetWindow().setStatusBarColor(0xFF263238);\nheaders.setElevation(10f); //your actionbar linear\n}\n}\ncatch (Exception e) {\n};");
		_Add(2, "Background (HEX COLOR)", "textview1.setBackgroundColor(Color.parseColor(\"#ff0000\"));\n\n/*Above textview1 BackgroundColor Is Red*/\n\n/*OR*/\n\n\nlinear1.setBackgroundColor(Color.parseColor(\"#0000ff\"));\n\n/*Above linear1 BackgroundColor Is Blue*/");
		_Add(3, "Button ColorStateList", "\nandroid.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();\n\nbg.setColor(new android.content.res.ColorStateList(new int[][] {{-android.R.attr.state_pressed}, {android.R.attr.state_pressed}},new int[] {Color.parseColor(\"#901020\"), Color.parseColor(\"#40109020\")}));\nbg.setShape(1);\nbg.setCornerRadius(10);\nbg.setStroke(2, new android.content.res.ColorStateList(new int[][] {{-android.R.attr.state_pressed}, {android.R.attr.state_pressed}}, new int[] {Color.parseColor(\"#505050\"), Color.parseColor(\"#502010\")}));\n\nbutton1.setBackground(bg);");
		_Add(4, "ColorPicker", "\npublic static interface OnColorChangedListener\n	{\n		public void onColorChanged(ColorPicker picker, int color);\n	}\nclass ColorPicker extends LinearLayout\n{	\n	private SeekBar r;\n	private SeekBar g;\n	private SeekBar b;\n	private EditText hex;\n	private TextView colorShow;\n	private SeekBar.OnSeekBarChangeListener listener;\n	private OnColorChangedListener l;\n	public ColorPicker(Context c)\n	{\n		super(c);\n		init();\n	}\n	\n	private void init(){\n		setPadding(16, 16, 16, 16);\n		setGravity(Gravity.CENTER);\n		setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));\n		colorShow = new TextView(getContext());\n		colorShow.setLayoutParams(new ViewGroup.LayoutParams(60, 60));\n		addView(colorShow);	\n		listener = new SeekBar.OnSeekBarChangeListener(){\n			@Override\n			public void onProgressChanged(SeekBar p1, int p2, boolean p3)\n			{\n				int color = Color.rgb(r.getProgress(), g.getProgress(), b.getProgress());\n				String temp = String.format(\"%1\\$08x\", color); //sketchware: TODO \"%1\\$0x\"\n				String result = temp.substring(2);\n				hex.setText(\"#\" + result);\n				hex.getBackground().setColorFilter(color, PorterDuff.Mode.SRC_IN);\n				colorShow.setBackgroundColor(color);\n				\n				if(l != null) l.onColorChanged(ColorPicker.this, color);\n			}\n			@Override public void onStartTrackingTouch(SeekBar p1){}\n			@Override public void onStopTrackingTouch(SeekBar p1){}\n		};\n		LinearLayout lay2 = new LinearLayout(getContext());\n		lay2.setOrientation(VERTICAL);\n		lay2.setPadding(8, 0, 8, 8);\n		lay2.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));\n		hex = new EditText(getContext());\n		ViewGroup.MarginLayoutParams params = new ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);\n		params.setMargins(16, 0, 16, 0);\n		hex.setLayoutParams(params);\n		hex.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);\n		hex.setText(\"#000000\");\n		hex.setOnEditorActionListener(new TextView.OnEditorActionListener(){\n				@Override\n				public boolean onEditorAction(TextView text, int code, KeyEvent event)\n				{\n					try {\n						int color = Color.parseColor(text.getText().toString());\n						r.setProgress(Color.red(color));\n						g.setProgress(Color.green(color));\n						b.setProgress(Color.blue(color));\n					} catch(Exception e){\n						Toast.makeText(getContext(), \"Color code is wrong\", Toast.LENGTH_SHORT).show();\n					}\n					return true;\n				}\n			});\n		lay2.addView(hex);\n		r = new SeekBar(getContext());\n		setProgressColor(r, 0xffcc5577);\n		r.setMax(255);\n		r.setOnSeekBarChangeListener(listener);\n		lay2.addView(r);\n		g = new SeekBar(getContext());\n		setProgressColor(g, 0xff339977);\n		g.setMax(255);\n		g.setOnSeekBarChangeListener(listener);\n		lay2.addView(g);\n		b = new SeekBar(getContext());\n		setProgressColor(b, 0xff6077bb);\n		b.setMax(255);\n		b.setOnSeekBarChangeListener(listener);\n		lay2.addView(b);\n		addView(lay2);\n		int color = Color.parseColor(hex.getText().toString());\n		r.setProgress(Color.red(color));\n		g.setProgress(Color.green(color));\n		b.setProgress(Color.blue(color));\n		colorShow.setBackgroundColor(color);\n	}\n	public void setColor(int color)\n	{\n		hex.setText(\"#\" + String.format(\"%1\\$08x\", color).substring(2));\n		r.setProgress(Color.red(color));\n		g.setProgress(Color.green(color));\n		b.setProgress(Color.blue(color));\n	}\n	public int getColor(boolean refreshFromSlider)\n	{\n		if(refreshFromSlider) listener.onProgressChanged(null, 0, false);\n		return Color.parseColor(hex.getText().toString());\n	}\n	public int getColor()\n	{\n		return getColor(true);\n	}\n	public void setOnColorChangedListener(OnColorChangedListener l)\n	{\n		this.l = l;\n	}\n	private void setProgressColor(AbsSeekBar bar, int color)\n	{\n		bar.getProgressDrawable().setColorFilter(color, PorterDuff.Mode.SRC_IN); bar.getThumb().setColorFilter(color, PorterDuff.Mode.SRC_IN);\n	}\n}\n\n// ColorPicker coll = new ColorPicker(MainActivity.this);\n// linear1.addView(coll);\n// Set Color: coll.setColor(Color.parseColor(\"#FFFF00\"));\n// To Get Color\ncoll.getColor();");
		_Add(5, "FAB Color Animator", "\nfinal ObjectAnimator animator = ObjectAnimator.ofInt(_fab, \"backgroundTint\", Color.rgb(0, 121, 107), Color.rgb(226, 143, 34));\nanimator.setDuration(2000L);\nanimator.setEvaluator(new ArgbEvaluator());\nanimator.setInterpolator(new DecelerateInterpolator(2));\nanimator.addUpdateListener(new ObjectAnimator.AnimatorUpdateListener() {\n    @Override\n    public void onAnimationUpdate(ValueAnimator animation) {\n        int animatedValue = (int) animation.getAnimatedValue();\n        _fab.setBackgroundTintList(android.content.res.ColorStateList.valueOf(animatedValue));\n    }\n});\nanimator.start();");
		_Add(6, "Gradient Color", "\n//Gradient Code Starts Here\nint[] colors = {Color.rgb(138,41,81),Color.rgb(41,53,158)};\nandroid.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.BR_TL, colors);\ngd.setCornerRadius(0f); \ngd.setStroke(0,Color.WHITE);\nif(android.os.Build.VERSION.SDK_INT >= 16) {linear1.setBackground(gd); } else {linear1.setBackgroundDrawable(gd);}\n//End of Gradient Generator");
		_Add(7, "ProgressBar Color", "\nprogressBar.getProgressDrawable().setColorFilter(Color.RED, android.graphics.PorterDuff.Mode.SRC_IN);\n\n\n\n//with drawable\nandroid.graphics.drawable.Drawable progressDrawable = progressBar.getProgressDrawable().mutate(); progressDrawable.setColorFilter(Color.RED, android.graphics.PorterDuff.Mode.SRC_IN); progressBar.setProgressDrawable(progressDrawable);");
		_Add(8, "Text Color", "\ntextview1.setTextColor(Color.parseColor(\"#000000\"));");
		_Add(9, "ActionBar Fullscreen", "\n//full screen\ngetWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);\n\n//unfullscreen\ngetWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);");
		_Add(10, "Class  Drawable", "\nimageview1.setBackground(Drawables.getSelectableDrawableFor(Color.parseColor(\"#404040\")));\nimageview1.setClickable(true);\n\n}\n\npublic static class Drawables {\n    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {\n        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {\n            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();\n            stateListDrawable.addState(\n                new int[]{android.R.attr.state_pressed},\n                new android.graphics.drawable.ColorDrawable(Color.parseColor(\"#ffffff\"))\n            );\n            stateListDrawable.addState(\n                new int[]{android.R.attr.state_focused},\n                new android.graphics.drawable.ColorDrawable(Color.parseColor(\"#00ffffff\"))\n            );\n            stateListDrawable.addState(\n                new int[]{},\n                new android.graphics.drawable.ColorDrawable(Color.parseColor(\"#00ffffff\"))\n            );\n            return stateListDrawable;\n        } else {\n            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);\n            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor(\"#00ffffff\"));\n            \nandroid.graphics.drawable.Drawable rippleColor = getRippleColor(color);\n            return new android.graphics.drawable.RippleDrawable(\n                pressedColor,\n                defaultColor,\n                rippleColor\n            );\n        }\n    }\n\n    private static android.graphics.drawable.Drawable getRippleColor(int color) {\n        float[] outerRadii = new float[8];\n        Arrays.fill(outerRadii, 0);\n        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);\n        \nandroid.graphics.drawable.ShapeDrawable shapeDrawable = new \nandroid.graphics.drawable.ShapeDrawable(r);\n        shapeDrawable.getPaint().setColor(color);\n        return shapeDrawable;\n    }\n \n    private static int lightenOrDarken(int color, double fraction) {\n        if (canLighten(color, fraction)) {\n            return lighten(color, fraction);\n        } else {\n            return darken(color, fraction);\n        }\n    }\n \n    private static int lighten(int color, double fraction) {\n        int red = Color.red(color);\n        int green = Color.green(color);\n        int blue = Color.blue(color);\n        red = lightenColor(red, fraction);\n        green = lightenColor(green, fraction);\n        blue = lightenColor(blue, fraction);\n        int alpha = Color.alpha(color);\n        return Color.argb(alpha, red, green, blue);\n    }\n \n    private static int darken(int color, double fraction) {\n        int red = Color.red(color);\n        int green = Color.green(color);\n        int blue = Color.blue(color);\n        red = darkenColor(red, fraction);\n        green = darkenColor(green, fraction);\n        blue = darkenColor(blue, fraction);\n        int alpha = Color.alpha(color);\n \n        return Color.argb(alpha, red, green, blue);\n    }\n \n    private static boolean canLighten(int color, double fraction) {\n        int red = Color.red(color);\n        int green = Color.green(color);\n        int blue = Color.blue(color);\n        return canLightenComponent(red, fraction)\n            && canLightenComponent(green, fraction)\n            && canLightenComponent(blue, fraction);\n    }\n \n    private static boolean canLightenComponent(int colorComponent, double fraction) {\n        int red = Color.red(colorComponent);\n        int green = Color.green(colorComponent);\n        int blue = Color.blue(colorComponent);\n        return red + (red * fraction) < 255\n            && green + (green * fraction) < 255\n            && blue + (blue * fraction) < 255;\n    }\n \n    private static int darkenColor(int color, double fraction) {\n        return (int) Math.max(color - (color * fraction), 0);\n    }\n \n    private static int lightenColor(int color, double fraction) {\n        return (int) Math.min(color + (color * fraction), 255);\n    }\n}\npublic static class CircleDrawables {\n    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {\n        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {\n            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();\n            stateListDrawable.addState(\n                new int[]{android.R.attr.state_pressed},\n                new android.graphics.drawable.ColorDrawable(Color.parseColor(\"#ffffff\"))\n            );\n            stateListDrawable.addState(\n                new int[]{android.R.attr.state_focused},\n                new android.graphics.drawable.ColorDrawable(Color.parseColor(\"#00ffffff\"))\n            );\n            stateListDrawable.addState(\n                new int[]{},\n                new android.graphics.drawable.ColorDrawable(Color.parseColor(\"#00ffffff\"))\n            );\n            return stateListDrawable;\n        } else {\n            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);\n            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor(\"#00ffffff\"));\n            \nandroid.graphics.drawable.Drawable rippleColor = getRippleColor(color);\n            return new android.graphics.drawable.RippleDrawable(\n                pressedColor,\n                defaultColor,\n                rippleColor\n            );\n        }\n    }\n\n    private static android.graphics.drawable.Drawable getRippleColor(int color) {\n        float[] outerRadii = new float[180];\n        Arrays.fill(outerRadii, 80);\n        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);\n        \nandroid.graphics.drawable.ShapeDrawable shapeDrawable = new \nandroid.graphics.drawable.ShapeDrawable(r);\n        shapeDrawable.getPaint().setColor(color);\n        return shapeDrawable;\n    }\n \n    private static int lightenOrDarken(int color, double fraction) {\n        if (canLighten(color, fraction)) {\n            return lighten(color, fraction);\n        } else {\n            return darken(color, fraction);\n        }\n    }\n \n    private static int lighten(int color, double fraction) {\n        int red = Color.red(color);\n        int green = Color.green(color);\n        int blue = Color.blue(color);\n        red = lightenColor(red, fraction);\n        green = lightenColor(green, fraction);\n        blue = lightenColor(blue, fraction);\n        int alpha = Color.alpha(color);\n        return Color.argb(alpha, red, green, blue);\n    }\n \n    private static int darken(int color, double fraction) {\n        int red = Color.red(color);\n        int green = Color.green(color);\n        int blue = Color.blue(color);\n        red = darkenColor(red, fraction);\n        green = darkenColor(green, fraction);\n        blue = darkenColor(blue, fraction);\n        int alpha = Color.alpha(color);\n \n        return Color.argb(alpha, red, green, blue);\n    }\n \n    private static boolean canLighten(int color, double fraction) {\n        int red = Color.red(color);\n        int green = Color.green(color);\n        int blue = Color.blue(color);\n        return canLightenComponent(red, fraction)\n            && canLightenComponent(green, fraction)\n            && canLightenComponent(blue, fraction);\n    }\n \n    private static boolean canLightenComponent(int colorComponent, double fraction) {\n        int red = Color.red(colorComponent);\n        int green = Color.green(colorComponent);\n        int blue = Color.blue(colorComponent);\n        return red + (red * fraction) < 255\n            && green + (green * fraction) < 255\n            && blue + (blue * fraction) < 255;\n    }\n \n    private static int darkenColor(int color, double fraction) {\n        return (int) Math.max(color - (color * fraction), 0);\n    }\n \n    private static int lightenColor(int color, double fraction) {\n        return (int) Math.min(color + (color * fraction), 255);\n}\n}\n\npublic void drawableclass() {");
		_Add(11, "Context Menu", "\nregisterForContextMenu(listview1);\n}\n@Override\npublic void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {\nsuper.onCreateContextMenu(menu, v, menuInfo); \nmenu.setHeaderTitle(\"Select the Action\"); \nmenu.add(0,v.getId(),0,\"Delete\");\nmenu.add(0,v.getId(),0,\"UpperCase\"); \nmenu.add(0,v.getId(),0,\"LowerCase\");\n}\n@Override\npublic boolean onContextItemSelected(MenuItem item) {\nif(item.getTitle()==\"Delete\") {\nToast.makeText(this, \"Delete was pressed\", Toast.LENGTH_SHORT).show();\n} else if(item.getTitle()==\"UpperCase\") {\nToast.makeText(this, \"UpperCase was pressed\", Toast.LENGTH_SHORT).show();\n} else if(item.getTitle()==\"LowerCase\") {\nToast.makeText(this, \"LowerCase was pressed\", Toast.LENGTH_SHORT).show();\n}\nreturn true;\n");
		_Add(12, "ActionBar Back Hmon", "\ngetActionBar().setDisplayHomeAsUpEnabled(true);\n/* */} \n@Override \npublic boolean onMenuItemSelected(int featureId, MenuItem item) {\nint itemId = item.getItemId(); \nswitch (itemId) {\ncase android.R.id.home:\nfinish();\nbreak;\n}\nreturn true;\n");
		_Add(13, "ActionBar Set Icon", "getActionBar().setIcon(r.drawable.icon_name);");
		_Add(14, "ActionBar Subtitle", "\ngetActionBar().setSubtitle(\"Subtitle\");");
		_Add(15, "ActionBar Title", "\ngetActionBar().setTitle(\"Title\");");
		_Add(16, "ActionBar Title RGBG", "\nString Int_title = String.format(Locale.US, \"#%06X\", (0xFFFFFF & Color.argb(120,50,90,10)));\n\ngetActionBar().setTitle(Html.fromHtml(\"<font color=\\\\\"\" + Int_title + \"\\\\\">Gabriel</font>\"));");
		_Add(17, "AppList With Icon(LAUNCH)", "\nIntent startupIntent = new Intent(Intent.ACTION_MAIN); 		startupIntent.addCategory(Intent.CATEGORY_LAUNCHER);  		final android.content.pm.PackageManager pm = getPackageManager(); 		List<android.content.pm.ResolveInfo> activities = pm.queryIntentActivities(startupIntent,0);   		Collections.sort(activities, new Comparator<android.content.pm.ResolveInfo>() {  				public int compare(android.content.pm.ResolveInfo a, android.content.pm.ResolveInfo b) {  					android.content.pm.PackageManager pm = getPackageManager();  					return String.CASE_INSENSITIVE_ORDER.compare(  						a.loadLabel(pm).toString(),  						b.loadLabel(pm).toString());  				}  			});   		ArrayAdapter<android.content.pm.ResolveInfo> adapter = new ArrayAdapter<android.content.pm.ResolveInfo>(  			this, android.R.layout.simple_list_item_1, activities) {  			public View getView(int pos, View convertView, ViewGroup parent) { TextView tv = new TextView(MainActivity.this);  				android.content.pm.ResolveInfo ri = getItem(pos);  			tv.setText(ri.loadLabel(pm));  	LinearLayout lin = new LinearLayout(MainActivity.this);ImageView iv = new ImageView(MainActivity.this);iv.setImageDrawable(ri.loadIcon(pm));lin.addView(iv);lin.addView(tv);tv.setGravity(Gravity.CENTER_VERTICAL);tv.setPadding(16,0,0,0);tv.setTextSize(16);tv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT ));LinearLayout.LayoutParams p =	new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.MATCH_PARENT);p.width = 70;p.height = 70;p.bottomMargin = 4;p.topMargin = 4;iv.setLayoutParams(p);lin.setPadding(6,6,6,6);return lin;  			}  		};  		listview1.setAdapter(adapter); 		 		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {  				@Override 				public void onItemClick(AdapterView adapter, View v, int position, long id) 				{ 					android.content.pm.ResolveInfo resolveInfo = (android.content.pm.ResolveInfo)adapter.getItemAtPosition(position);  					android.content.pm.ActivityInfo activityInfo = resolveInfo.activityInfo;  					if (activityInfo == null) return;  					Intent i = new Intent(Intent.ACTION_MAIN);  					i.setClassName(activityInfo.applicationInfo.packageName, activityInfo.name);  					startActivity(i); 				}  			 		});;");
		_Add(18, "AsynkTask Example", "\nprivate class AsyncTaskEx extends AsyncTask<Void, Void, Void> {\n\n    /** The system calls this to perform work in a worker thread and\n    * delivers it the parameters given to AsyncTask.execute() */\n    @Override\n    protected Void doInBackground(Void... arg0) {\n        StartTimer();//call your method here it will run in background\n        return null;\n    }\n\n    /** The system calls this to perform work in the UI thread and delivers\n    * the result from doInBackground() */\n    @Override\n    protected void onPostExecute(Void result) {\n        //Write some code you want to execute on UI after doInBackground() completes\n        return ;\n    }\n\n    @Override\n    protected void onPreExecute() {\n        //Write some code you want to execute on UI before doInBackground() starts\n        return ;\n    }\n}\n\n\n//Write this class inside your Activity and call where you want execute your method\n\nnew AsyncTaskEx().execute();");
		_Add(19, "WebView Touch to Copy", "\nwebview1.setOnTouchListener(new View.OnTouchListener() {\nBoolean tF;\n@Override public boolean onTouch(View v, MotionEvent event) {\nshowMessage(\"Aan\");\ntF = true;\nswitch (event.getAction()) {\ncase MotionEvent.ACTION_DOWN: tF = false;\nshowMessage(\"0\");\n}\nreturn tF;\n}\n});\n");
		_Add(20, "WebView Certificate", "\ntextview1.setText(webview1.getCertificate().toString());");
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
