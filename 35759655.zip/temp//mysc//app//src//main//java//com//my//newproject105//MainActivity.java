package com.my.newproject105;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.webkit.WebView;
import android.webkit.WebSettings;

public class MainActivity extends Activity {
	
	
	private WebView webview7;
	private WebView webview8;
	private WebView webview9;
	private WebView webview10;
	private WebView webview11;
	private WebView webview12;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		webview7 = (WebView) findViewById(R.id.webview7);
		webview7.getSettings().setJavaScriptEnabled(true);
		webview7.getSettings().setSupportZoom(true);
		webview8 = (WebView) findViewById(R.id.webview8);
		webview8.getSettings().setJavaScriptEnabled(true);
		webview8.getSettings().setSupportZoom(true);
		webview9 = (WebView) findViewById(R.id.webview9);
		webview9.getSettings().setJavaScriptEnabled(true);
		webview9.getSettings().setSupportZoom(true);
		webview10 = (WebView) findViewById(R.id.webview10);
		webview10.getSettings().setJavaScriptEnabled(true);
		webview10.getSettings().setSupportZoom(true);
		webview11 = (WebView) findViewById(R.id.webview11);
		webview11.getSettings().setJavaScriptEnabled(true);
		webview11.getSettings().setSupportZoom(true);
		webview12 = (WebView) findViewById(R.id.webview12);
		webview12.getSettings().setJavaScriptEnabled(true);
		webview12.getSettings().setSupportZoom(true);
		
		webview7.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		webview8.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		webview9.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		webview10.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		webview11.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		webview12.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
	}
	private void initializeLogic() {
		webview7.loadUrl("data:text/html,<html><body> <marquee behavior=\"scroll\" direction=\"left\">".concat("AauraParti YouTube channel".concat("</marquee></html></body> ")));
		webview8.loadUrl("data:text/html,<html><body><marquee behavior=\"alternate\"><h2<alignt style=\"color:red\">".concat("Aaura parti YouTube channel".concat("</h2></marquee></html></body> ")));
		webview9.loadUrl("data:text/html,<html><body> <marquee behavior=\"scroll\" direction=\"right\">".concat("AauraParti YouTube channel".concat("</marquee></html></body>")));
		webview10.loadUrl("data:text/html,<html><body> <marquee behavior=\"scroll\" direction=\"up\">".concat("AauraParti YouTube channel".concat("</marquee> </html></body> ")));
		webview11.loadUrl("data:text/html,<html><body> <marquee behavior=\"scroll\" direction=\"down\">".concat("Aaura parti YouTube channel".concat("</marquee></html></body>")));
		webview12.loadUrl("\n\ndata:text/html,<html><body> <marquee behavior=\"scroll\" direction=\"left\" scrollamount=\"1\">Very slow...</marquee>\n<marquee behavior=\"scroll\" direction=\"left\" scrollamount=\"10\">Faster...</marquee>\n<marquee behavior=\"scroll\" direction=\"left\" scrollamount=\"20\">Fast...</marquee>\n<marquee behavior=\"scroll\" direction=\"left\" scrollamount=\"50\">Lightning!</marquee>\n</html></body> \n\n");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
