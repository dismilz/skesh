package com.my.newproject10;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.ProgressBar;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import android.widget.LinearLayout;
import android.widget.Button;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.AdListener;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class MainActivity extends Activity {
	
	
	private ProgressBar progressbar1;
	private AdView adview2;
	private AdView adview1;
	private LinearLayout linear1;
	private AdView adview3;
	private Button button1;
	
	private InterstitialAd i;
	private AdListener _i_ad_listener;
	private Intent in = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		adview2 = (AdView) findViewById(R.id.adview2);
		adview1 = (AdView) findViewById(R.id.adview1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		adview3 = (AdView) findViewById(R.id.adview3);
		button1 = (Button) findViewById(R.id.button1);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (mRewardedVideoAd.isLoaded()) {
					mRewardedVideoAd.show();
				} else {
					Toast.makeText(MainActivity.this, "Ad not loaded ", Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		_i_ad_listener = new AdListener() {
			@Override
			public void onAdLoaded() {
				i.show();
			}
			
			@Override
			public void onAdFailedToLoad(int _param1) {
				final int _errorCode = _param1;
				SketchwareUtil.showMessage(getApplicationContext(), "ad load fail".concat(String.valueOf((long)(_errorCode))));
			}
			
			@Override
			public void onAdOpened() {
				
			}
			
			@Override
			public void onAdClosed() {
				
			}
		};
	}
	private void initializeLogic() {
		i = new InterstitialAd(getApplicationContext());
		i.setAdListener(_i_ad_listener);
		i.setAdUnitId("ca-app-pub-5120195730124524/5140410453");
		i.loadAd(new AdRequest.Builder().addTestDevice("1E787150582DDED245AE047B4923D1DD")
		.build());
		adview1.loadAd(new AdRequest.Builder().addTestDevice("1E787150582DDED245AE047B4923D1DD")
		.build());
		adview2.loadAd(new AdRequest.Builder().addTestDevice("1E787150582DDED245AE047B4923D1DD")
		.build());
		adview3.loadAd(new AdRequest.Builder().addTestDevice("1E787150582DDED245AE047B4923D1DD")
		.build());
		_Video_Ads();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onPause() {
		super.onPause();
		mRewardedVideoAd.pause(this);
	}
	
	@Override
	public void onResume() {
		super.onResume();
		mRewardedVideoAd.resume(this);
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		mRewardedVideoAd.destroy(this);
	}
	private void _extra () {
	}
	com.google.android.gms.ads.reward.RewardedVideoAd mRewardedVideoAd;
	private void loadRewardedVideoAd() {
		mRewardedVideoAd.loadAd("ca-app-pub-5120195730124524/2705818800", new AdRequest.Builder().build());
	}
	
	
	private void _Video_Ads () {
		com.google.android.gms.ads.MobileAds.initialize(this, "ca-app-pub-3940256099942544/1033173712");
		//AauraParti YouTube channel;
		// Define mRewardedVideoAd
		mRewardedVideoAd = com.google.android.gms.ads.MobileAds.getRewardedVideoAdInstance(this);
		// Set RewardedVideoAdListener for mRewardedVideoAd
		mRewardedVideoAd.setRewardedVideoAdListener(new com.google.android.gms.ads.reward.RewardedVideoAdListener(){
			@Override
			public void onRewarded(com.google.android.gms.ads.reward.RewardItem reward) {
				
				in.setClass(getApplicationContext(), HomeActivity.class);
				startActivity(in);
			}
			@Override
			public void onRewardedVideoAdLeftApplication() {
				Toast.makeText(MainActivity.this, "onRewardedVideoAdLeftApplication", Toast.LENGTH_SHORT).show();
			}
			@Override
			public void onRewardedVideoAdClosed() {
				Toast.makeText(MainActivity.this, "Video Ad Closed", Toast.LENGTH_SHORT).show();
				// Reload new Ad when Ad is closed
				loadRewardedVideoAd();
			}
			@Override
			public void onRewardedVideoAdFailedToLoad(int errorCode) {
				Toast.makeText(MainActivity.this, "Video Ad Load Failed", Toast.LENGTH_SHORT).show();
			}
			@Override
			public void onRewardedVideoAdLoaded() {
				Toast.makeText(MainActivity.this, "Video Ad Loaded", Toast.LENGTH_SHORT).show();
			}
			@Override
			public void onRewardedVideoAdOpened() {
				Toast.makeText(MainActivity.this, "Video Ad Opened", Toast.LENGTH_SHORT).show();
			}
			@Override
			public void onRewardedVideoStarted() {
				Toast.makeText(MainActivity.this, "Video Ad Started", Toast.LENGTH_SHORT).show();
			}
			@Override
			public void onRewardedVideoCompleted() {
				Toast.makeText(MainActivity.this, "Video Ad Completed", Toast.LENGTH_SHORT).show();
			}
		});
		// Load the Rewarded Video Ad
		loadRewardedVideoAd();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
