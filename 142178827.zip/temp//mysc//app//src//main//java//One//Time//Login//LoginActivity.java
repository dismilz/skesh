package One.Time.Login;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ProgressBar;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.app.Activity;
import android.content.SharedPreferences;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.view.View;
import com.google.gson.Gson;

public class LoginActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> user = new HashMap<>();
	
	private LinearLayout linear1;
	private LinearLayout line_login_login;
	private LinearLayout line_forgot_forgot;
	private LinearLayout line_register;
	private ImageView imageview1;
	private TextView textview1;
	private TextView textview2;
	private EditText edittext1;
	private EditText edittext2;
	private Button button3;
	private LinearLayout linear3;
	private TextView textview4;
	private ProgressBar progressbar1;
	private TextView textview11;
	private TextView textview3;
	private ImageView imageview2;
	private TextView textview5;
	private TextView textview6;
	private EditText edittext3;
	private Button button1;
	private ProgressBar progressbar2;
	private ImageView imageview3;
	private TextView textview7;
	private TextView textview8;
	private EditText edittext4;
	private EditText edittext5;
	private EditText edittext6;
	private EditText edittext7;
	private Button button2;
	private LinearLayout linear4;
	private ProgressBar progressbar3;
	private TextView textview12;
	private TextView textview10;
	
	private Intent intent = new Intent();
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private SharedPreferences name;
	private DatabaseReference firebasedatabase = _firebase.getReference("users");
	private ChildEventListener _firebasedatabase_child_listener;
	private SharedPreferences all;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.login);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		line_login_login = (LinearLayout) findViewById(R.id.line_login_login);
		line_forgot_forgot = (LinearLayout) findViewById(R.id.line_forgot_forgot);
		line_register = (LinearLayout) findViewById(R.id.line_register);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		button3 = (Button) findViewById(R.id.button3);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		textview4 = (TextView) findViewById(R.id.textview4);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		textview11 = (TextView) findViewById(R.id.textview11);
		textview3 = (TextView) findViewById(R.id.textview3);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview6 = (TextView) findViewById(R.id.textview6);
		edittext3 = (EditText) findViewById(R.id.edittext3);
		button1 = (Button) findViewById(R.id.button1);
		progressbar2 = (ProgressBar) findViewById(R.id.progressbar2);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview8 = (TextView) findViewById(R.id.textview8);
		edittext4 = (EditText) findViewById(R.id.edittext4);
		edittext5 = (EditText) findViewById(R.id.edittext5);
		edittext6 = (EditText) findViewById(R.id.edittext6);
		edittext7 = (EditText) findViewById(R.id.edittext7);
		button2 = (Button) findViewById(R.id.button2);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		progressbar3 = (ProgressBar) findViewById(R.id.progressbar3);
		textview12 = (TextView) findViewById(R.id.textview12);
		textview10 = (TextView) findViewById(R.id.textview10);
		auth = FirebaseAuth.getInstance();
		name = getSharedPreferences("name", Activity.MODE_PRIVATE);
		all = getSharedPreferences("all", Activity.MODE_PRIVATE);
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals("") || edittext2.getText().toString().equals("")) {
					if (edittext1.getText().toString().equals("")) {
						_Error(edittext1, "Enter your email");
					}
					if (edittext2.getText().toString().equals("")) {
						_Error(edittext2, "enter your password");
					}
				}
				else {
					auth.signInWithEmailAndPassword(edittext1.getText().toString(), edittext2.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_sign_in_listener);
					progressbar1.setVisibility(View.VISIBLE);
				}
			}
		});
		
		textview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				line_login_login.setVisibility(View.GONE);
				line_forgot_forgot.setVisibility(View.VISIBLE);
				line_register.setVisibility(View.GONE);
			}
		});
		
		textview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				line_login_login.setVisibility(View.GONE);
				line_forgot_forgot.setVisibility(View.GONE);
				line_register.setVisibility(View.VISIBLE);
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext3.getText().toString().equals("")) {
					_Error(edittext3, "Enter your Email id");
				}
				else {
					auth.sendPasswordResetEmail(edittext3.getText().toString()).addOnCompleteListener(_auth_reset_password_listener);
					progressbar2.setVisibility(View.VISIBLE);
				}
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext4.getText().toString().equals("") || ((edittext5.getText().toString().equals("") || edittext6.getText().toString().equals("")) || edittext7.getText().toString().equals(""))) {
					if (edittext4.getText().toString().equals("")) {
						_Error(edittext4, "Enter your name");
					}
					if (edittext5.getText().toString().equals("")) {
						_Error(edittext5, "Enter your email");
					}
					if (edittext6.getText().toString().equals("")) {
						_Error(edittext6, "Enter your password");
					}
					if (edittext7.getText().toString().equals("")) {
						_Error(edittext7, "Enter your Confirm password");
					}
				}
				else {
					if (edittext6.getText().toString().equals(edittext7.getText().toString())) {
						auth.createUserWithEmailAndPassword(edittext5.getText().toString(), edittext7.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_create_user_listener);
						name.edit().putString("name", edittext4.getText().toString()).commit();
						progressbar3.setVisibility(View.VISIBLE);
					}
				}
			}
		});
		
		textview10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				line_login_login.setVisibility(View.VISIBLE);
				line_forgot_forgot.setVisibility(View.GONE);
				line_register.setVisibility(View.GONE);
			}
		});
		
		_firebasedatabase_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if ((FirebaseAuth.getInstance().getCurrentUser() != null) && _childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("nick")) {
						if (_childValue.get("nick").toString().trim().equals("")) {
							_childValue.put("nick", "nick_".concat(FirebaseAuth.getInstance().getCurrentUser().getUid().substring((int)(0), (int)(6))));
						}
					}
					else {
						_childValue.put("nick", "Nick_".concat(FirebaseAuth.getInstance().getCurrentUser().getUid().substring((int)(0), (int)(6))));
					}
					if (!edittext4.getText().toString().trim().equals("")) {
						_childValue.put("nick", edittext4.getText().toString().trim());
					}
					firebasedatabase.child(_childKey).updateChildren(_childValue);
					all.edit().putString("account", new Gson().toJson(_childValue)).commit();
					finish();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if ((FirebaseAuth.getInstance().getCurrentUser() != null) && _childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("nick")) {
						if (_childValue.get("nick").toString().trim().equals("")) {
							_childValue.put("nick", "nick_".concat(FirebaseAuth.getInstance().getCurrentUser().getUid().substring((int)(0), (int)(6))));
						}
					}
					else {
						_childValue.put("nick", "Nick_".concat(FirebaseAuth.getInstance().getCurrentUser().getUid().substring((int)(0), (int)(6))));
					}
					if (!edittext4.getText().toString().trim().equals("")) {
						_childValue.put("nick", edittext4.getText().toString().trim());
					}
					firebasedatabase.child(_childKey).updateChildren(_childValue);
					all.edit().putString("account", new Gson().toJson(_childValue)).commit();
					finish();
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		firebasedatabase.addChildEventListener(_firebasedatabase_child_listener);
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					progressbar3.setVisibility(View.GONE);
					edittext1.setText(edittext5.getText().toString());
					edittext2.setText(edittext7.getText().toString());
					auth.signInWithEmailAndPassword(edittext5.getText().toString(), edittext7.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_sign_in_listener);
				}
				else {
					_Toast("ffc0c0", "00bcd4", "Not register");
				}
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					progressbar1.setVisibility(View.GONE);
					intent.setClass(getApplicationContext(), HameActivity.class);
					startActivity(intent);
					_Toast("ffffff", "00bcd4", "loggedin Successful.");
					
					user = new HashMap<>();
					user.put("date", String.valueOf((long)(0)));
					firebasedatabase.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(user);
					firebasedatabase.addChildEventListener(_firebasedatabase_child_listener);
				}
				else {
					_Toast("ffc0c0", "00bcd4", _errorMessage);
				}
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				progressbar2.setVisibility(View.GONE);
				if (_success) {
					_Toast("ffffff", "00bcd4", "Password Reset link sent to your email address.");
				}
				else {
					_Toast("ffc0c0", "00bcd4", "Error! Password Reset link could not be sent.");
				}
			}
		};
	}
	private void initializeLogic() {
		line_login_login.setVisibility(View.VISIBLE);
		progressbar1.setVisibility(View.GONE);
		progressbar2.setVisibility(View.GONE);
		progressbar3.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _Error (final TextView _view, final String _message) {
		_view.setError(_message);
	}
	
	
	private void _Toast (final String _bg, final String _st, final String _msg) {
		TextView tvu = new TextView(this);
		
		tvu.setLayoutParams(
		  new ViewGroup.LayoutParams(
		    android.widget.LinearLayout
		    .LayoutParams.WRAP_CONTENT,
		    android.widget.LinearLayout
		    .LayoutParams.WRAP_CONTENT)
		);
		tvu.setTextColor(Color.parseColor("#"+_st));
		tvu.setGravity(Gravity.CENTER);
		tvu.setText(_msg);
		
		
		LinearLayout v = new LinearLayout(this);
		
		android.graphics.drawable.GradientDrawable gd =
		  new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor("#"+_bg));
		gd.setStroke((int)getDip(2), Color.parseColor("#"+_st));
		gd.setCornerRadius(6);
		v.setBackground(gd);
		v.setPadding((int)getDip(8),(int)getDip(8),(int)getDip(8),(int)getDip(8));
		
		v.addView(tvu);
		
		
		Toast t = Toast.makeText(getApplicationContext(),"",Toast.LENGTH_SHORT);
		t.setView(v);
		t.show();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
