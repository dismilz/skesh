package com.Age.Calculator;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Button;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;

public class MainActivity extends Activity {
	
	
	private LinearLayout linear1;
	private LinearLayout linear3;
	private LinearLayout linearrr;
	private TextView textview1;
	private EditText edittext1;
	private ImageView imageview1;
	private TextView textview2;
	private EditText edittext2;
	private Button exit;
	
	private AlertDialog.Builder D;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linearrr = (LinearLayout) findViewById(R.id.linearrr);
		textview1 = (TextView) findViewById(R.id.textview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		exit = (Button) findViewById(R.id.exit);
		D = new AlertDialog.Builder(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				showDatePickerDialog(imageview1);
			}
		});
		
		exit.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				D.setTitle("Exit");
				D.setMessage("Are You Sure Want To Exit ?");
				D.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						finish();
					}
				});
				D.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				D.create().show();
			}
		});
	}
	private void initializeLogic() {
		linear3.setElevation(10f);
		linear1.setElevation(10f);
		
		
		android.graphics.drawable.GradientDrawable a1 = new android.graphics.drawable.GradientDrawable();
		a1.setColor(Color.parseColor("#FF008DCC"));
		a1.setCornerRadius(20);
		exit.setBackground(a1);
		_text1();
		_text2();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		D.setTitle("Exit");
		D.setMessage("Are You Sure Want To Exit ?");
		D.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finish();
			}
		});
		D.setNegativeButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		D.create().show();
	}
	private void _extra () {
	}
	public void showDatePickerDialog(View v) {
		DialogFragment newFragment = new DatePickerFragment();
		newFragment.show(getFragmentManager(), "datePicker");
	}
	public static class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
		Calendar now = Calendar.getInstance();
		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {
			int y = now.get(Calendar.YEAR);
			int m = now.get(Calendar.MONTH);
			int d = now.get(Calendar.DAY_OF_MONTH);
			return new DatePickerDialog(getActivity(), this, y, m, d);
		}
		public void onDateSet(DatePicker view, int year, int month, int day) {
			int mon = month +1;
			Calendar birthDay = Calendar.getInstance();
			String date = day + "/" + mon + "/" + year;
			EditText edittext21 = getActivity().findViewById(R.id.edittext1);
			EditText edittext22 = getActivity().findViewById(R.id.edittext2);
			edittext21.setText(date);
			birthDay.set(Calendar.YEAR, year);
			birthDay.set(Calendar.MONTH, month);
			birthDay.set(Calendar.DAY_OF_MONTH, day);
			double diff = (long)(now.getTimeInMillis() - birthDay.getTimeInMillis());
			if (diff < 0) {
				Toast.makeText(getContext(), "Selected date is in future.", Toast.LENGTH_SHORT).show();
				edittext22.setText("");
			} else {
				int years = now.get(Calendar.YEAR) - birthDay.get(Calendar.YEAR);
				int currMonth = now.get(Calendar.MONTH) + 1;
				int birthMonth = birthDay.get(Calendar.MONTH) + 1;
				int months = currMonth - birthMonth;
				if (months < 0){
					years--;
					months = 12 - birthMonth + currMonth;
					if (now.get(Calendar.DATE) < birthDay.get(Calendar.DATE))
					months--;
				} else if (months == 0 && now.get(Calendar.DATE) < birthDay.get(Calendar.DATE)){
					years--;
					months = 11;
				}
				int days = 0;
				if (now.get(Calendar.DATE) > birthDay.get(Calendar.DATE))
				days = now.get(Calendar.DATE) - birthDay.get(Calendar.DATE);
				else if (now.get(Calendar.DATE) < birthDay.get(Calendar.DATE))
				{
					int today = now.get(Calendar.DAY_OF_MONTH);
					now.add(Calendar.MONTH, -1);
					days = now.getActualMaximum(Calendar.DAY_OF_MONTH) - birthDay.get(Calendar.DAY_OF_MONTH) + today;
				} else {
					days = 0;
					if (months == 12){
						years++;
						months = 0;
					}
				}
				edittext22.setText(years + " years, " + months + " months, " + days + " days");
			}
		}
	}
	
	
	private void _text1 () {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor("#FFFFFF"));
		gd.setCornerRadius(10);
		edittext1.setBackground(gd);
	}
	
	
	private void _text2 () {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor("#FFFFFF"));
		gd.setCornerRadius(10);
		edittext2.setBackground(gd);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
