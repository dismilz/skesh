package com.crn.hack;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import com.airbnb.lottie.*;
import android.widget.ProgressBar;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import java.util.Timer;
import java.util.TimerTask;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.AdListener;
import android.view.View;

public class HackingActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private double num = 0;
	private double sex = 0;
	
	private LinearLayout linear3;
	private LinearLayout linear1;
	private ImageView imageview1;
	private TextView textview3;
	private TextView textview2;
	private LinearLayout linear2;
	private LinearLayout linear7;
	private LinearLayout hack;
	private LinearLayout linear14;
	private LinearLayout ads;
	private LinearLayout linear12;
	private LinearLayout linear4;
	private EditText edittext1;
	private ImageView imageview2;
	private Button button1;
	private LinearLayout linear8;
	private LinearLayout linear11;
	private LinearLayout linear9;
	private TextView textview8;
	private TextView textview6;
	private TextView textview7;
	private TextView textview4;
	private ImageView imageview3;
	private LinearLayout linear13;
	private LottieAnimationView lottie1;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private TextView textview9;
	private TextView textview10;
	private ProgressBar progressbar1;
	private TextView textview12;
	private AdView adview1;
	private ImageView imageview4;
	private TextView textview5;
	
	private TimerTask time;
	private TimerTask u;
	private InterstitialAd ad;
	private AdListener _ad_ad_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.hacking);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		hack = (LinearLayout) findViewById(R.id.hack);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		ads = (LinearLayout) findViewById(R.id.ads);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		button1 = (Button) findViewById(R.id.button1);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		textview8 = (TextView) findViewById(R.id.textview8);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview4 = (TextView) findViewById(R.id.textview4);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		lottie1 = (LottieAnimationView) findViewById(R.id.lottie1);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		textview9 = (TextView) findViewById(R.id.textview9);
		textview10 = (TextView) findViewById(R.id.textview10);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		textview12 = (TextView) findViewById(R.id.textview12);
		adview1 = (AdView) findViewById(R.id.adview1);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		
		linear12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().length() > 1) {
					_hideKeyboard(linear1);
					linear2.setVisibility(View.GONE);
					textview10.setText(edittext1.getText().toString());
					linear14.setVisibility(View.VISIBLE);
					textview2.setVisibility(View.GONE);
					textview3.setVisibility(View.GONE);
					button1.setVisibility(View.INVISIBLE);
					linear12.setVisibility(View.GONE);
					hack.setVisibility(View.VISIBLE);
					linear11.setVisibility(View.VISIBLE);
					num = 5;
					time = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									if (textview6.getText().toString().equals("0")) {
										time.cancel();
										u.cancel();
										linear2.setVisibility(View.VISIBLE);
										linear12.setVisibility(View.VISIBLE);
										textview3.setVisibility(View.VISIBLE);
										textview2.setVisibility(View.VISIBLE);
										hack.setVisibility(View.INVISIBLE);
										linear14.setVisibility(View.INVISIBLE);
										SketchwareUtil.showMessage(getApplicationContext(), "Failed, check username and try again");
										ad.show();
										ad = new InterstitialAd(getApplicationContext());
										ad.setAdListener(_ad_ad_listener);
										ad.setAdUnitId("ca-app-pub-7079259853236423/9080876652");
										ad.loadAd(new AdRequest.Builder().addTestDevice("B0F228FB1F4A3C764FD85387FCDD6CE8")
										.build());
									}
									else {
										num--;
										textview6.setText(String.valueOf((long)(num)));
										ad.show();
										ad = new InterstitialAd(getApplicationContext());
										ad.setAdListener(_ad_ad_listener);
										ad.setAdUnitId("ca-app-pub-7079259853236423/9080876652");
										ad.loadAd(new AdRequest.Builder().addTestDevice("B0F228FB1F4A3C764FD85387FCDD6CE8")
										.build());
									}
								}
							});
						}
					};
					_timer.scheduleAtFixedRate(time, (int)(60000), (int)(60000));
					u = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									sex++;
									if (textview4.getText().toString().equals("60")) {
										sex = 0;
										textview4.setText("0");
									}
									else {
										textview4.setText(String.valueOf((long)(sex)));
									}
								}
							});
						}
					};
					_timer.scheduleAtFixedRate(u, (int)(1000), (int)(1000));
					ad.show();
					ad = new InterstitialAd(getApplicationContext());
					ad.setAdListener(_ad_ad_listener);
					ad.setAdUnitId("ca-app-pub-7079259853236423/9080876652");
					ad.loadAd(new AdRequest.Builder().addTestDevice("B0F228FB1F4A3C764FD85387FCDD6CE8")
					.build());
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Enter correct username");
				}
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().length() > 1) {
					_hideKeyboard(linear1);
					linear2.setVisibility(View.GONE);
					textview10.setText(edittext1.getText().toString());
					textview3.setVisibility(View.GONE);
					textview2.setVisibility(View.GONE);
					linear14.setVisibility(View.VISIBLE);
					button1.setVisibility(View.INVISIBLE);
					hack.setVisibility(View.VISIBLE);
					linear11.setVisibility(View.VISIBLE);
					num = 5;
					time = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									if (textview6.getText().toString().equals("0")) {
										time.cancel();
										u.cancel();
										linear2.setVisibility(View.VISIBLE);
										linear12.setVisibility(View.VISIBLE);
										hack.setVisibility(View.INVISIBLE);
										textview3.setVisibility(View.VISIBLE);
										textview2.setVisibility(View.VISIBLE);
										linear14.setVisibility(View.INVISIBLE);
										SketchwareUtil.showMessage(getApplicationContext(), "Failed, check username and try again");
										ad.show();
										ad = new InterstitialAd(getApplicationContext());
										ad.setAdListener(_ad_ad_listener);
										ad.setAdUnitId("ca-app-pub-7079259853236423/9080876652");
										ad.loadAd(new AdRequest.Builder().addTestDevice("B0F228FB1F4A3C764FD85387FCDD6CE8")
										.build());
									}
									else {
										num--;
										textview6.setText(String.valueOf((long)(num)));
										ad.show();
										ad = new InterstitialAd(getApplicationContext());
										ad.setAdListener(_ad_ad_listener);
										ad.setAdUnitId("ca-app-pub-7079259853236423/9080876652");
										ad.loadAd(new AdRequest.Builder().addTestDevice("B0F228FB1F4A3C764FD85387FCDD6CE8")
										.build());
									}
								}
							});
						}
					};
					_timer.scheduleAtFixedRate(time, (int)(60000), (int)(60000));
					u = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									sex++;
									if (textview4.getText().toString().equals("60")) {
										sex = 0;
										textview4.setText("0");
									}
									else {
										textview4.setText(String.valueOf((long)(sex)));
									}
								}
							});
						}
					};
					_timer.scheduleAtFixedRate(u, (int)(1000), (int)(1000));
					ad.show();
					ad = new InterstitialAd(getApplicationContext());
					ad.setAdListener(_ad_ad_listener);
					ad.setAdUnitId("ca-app-pub-7079259853236423/9080876652");
					ad.loadAd(new AdRequest.Builder().addTestDevice("B0F228FB1F4A3C764FD85387FCDD6CE8")
					.build());
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Enter correct username");
				}
			}
		});
		
		_ad_ad_listener = new AdListener() {
			@Override
			public void onAdLoaded() {
				
			}
			
			@Override
			public void onAdFailedToLoad(int _param1) {
				final int _errorCode = _param1;
				
			}
			
			@Override
			public void onAdOpened() {
				
			}
			
			@Override
			public void onAdClosed() {
				
			}
		};
	}
	private void initializeLogic() {
		int[] colors = { Color.parseColor("#3b5998"), Color.parseColor("#3b5998") }; android.graphics.drawable.GradientDrawable CRNOJ = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colors);
		CRNOJ.setCornerRadii(new float[]{(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)20});
		CRNOJ.setStroke((int) 0, Color.parseColor("#000000"));
		button1.setElevation((float) 5);
		button1.setBackground(CRNOJ);
		//Milz
		linear11.setVisibility(View.INVISIBLE);
		linear12.setVisibility(View.GONE);
		hack.setVisibility(View.INVISIBLE);
		linear13.setVisibility(View.GONE);
		linear14.setVisibility(View.INVISIBLE);
		adview1.loadAd(new AdRequest.Builder().addTestDevice("B0F228FB1F4A3C764FD85387FCDD6CE8")
		.build());
		LottieAnimationView lv = new LottieAnimationView(this);
		
		lv.setAnimation("pro.json");
		
		lv.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
		
		lv.setRepeatCount(-1);
				lv.setRepeatMode(com.airbnb.lottie.LottieDrawable.RESTART);
		
		hack.addView(lv);
		lv.playAnimation();
		ad = new InterstitialAd(getApplicationContext());
		ad.setAdListener(_ad_ad_listener);
		ad.setAdUnitId("ca-app-pub-7079259853236423/9080876652");
		ad.loadAd(new AdRequest.Builder().addTestDevice("B0F228FB1F4A3C764FD85387FCDD6CE8")
		.build());
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		ad.show();
		ad = new InterstitialAd(getApplicationContext());
		ad.setAdListener(_ad_ad_listener);
		ad.setAdUnitId("ca-app-pub-7079259853236423/9080876652");
		ad.loadAd(new AdRequest.Builder().addTestDevice("B0F228FB1F4A3C764FD85387FCDD6CE8")
		.build());
	}
	
	@Override
	public void onBackPressed() {
		
	}
	private void _hideKeyboard (final View _view) {
		if(_view.requestFocus()){
			android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(_view.getWindowToken(),0);
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
