package com.SKETCHit.sketch.backup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.app.Activity;
import android.content.SharedPreferences;
import java.util.Timer;
import java.util.TimerTask;
import android.content.Intent;
import android.content.ClipData;
import android.app.AlertDialog;
import android.content.DialogInterface;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
	
	public final int REQ_CD_ZIPF = 101;
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private String buildGradle = "";
	private String name = "";
	private double position = 0;
	private String id = "";
	private String sat = "";
	private double searchnum = 0;
	private HashMap<String, Object> map = new HashMap<>();
	private String zip_to = "";
	private String Sketchware = "";
	private String zip_from = "";
	private String final_destination = "";
	private String path1 = "";
	private String from = "";
	private String to = "";
	private String idd = "";
	private String path = "";
	private double mfirstVisibleItem = 0;
	private double firstVisibleItem = 0;
	
	private ArrayList<String> liststring = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	private ArrayList<String> project_name = new ArrayList<>();
	
	private ListView listview1;
	
	private SharedPreferences sharedata;
	private TimerTask t;
	private Intent zipf = new Intent(Intent.ACTION_GET_CONTENT);
	private TimerTask r1;
	private TimerTask r2;
	private AlertDialog.Builder d;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		listview1 = (ListView) findViewById(R.id.listview1);
		sharedata = getSharedPreferences("sharedata", Activity.MODE_PRIVATE);
		zipf.setType("*/*");
		zipf.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		d = new AlertDialog.Builder(this);
	}
	private void initializeLogic() {
		setTitle("Made By Manish Nirmal");
		FileUtil.listDir(FileUtil.getExternalStorageDir().concat("/.sketchware/data/"), liststring);
				Collections.sort(liststring, String.CASE_INSENSITIVE_ORDER);
				position = 0;
				for(int _repeat15 = 0; _repeat15 < (int)(liststring.size()); _repeat15++) {
						{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("key", liststring.get((int)(position)));
								listmap.add(_item);
						}
						
						position++;
				}
				position = 0;
				for(int _repeat119 = 0; _repeat119 < (int)(liststring.size()); _repeat119++) {
						id = Uri.parse(liststring.get((int)(position))).getLastPathSegment();
						sat = "";
						try { java.io.File folder = new java.io.File(Environment.getExternalStorageDirectory(), ".sketchware/mysc/" + id + "/bin");
								java.io.File[] listOfFiles = folder.listFiles();
								
								for(int b = 0; b < listOfFiles.length; b++) {
										    if (listOfFiles[b].getName().endsWith(".apk.res")) {
												        sat = listOfFiles[b].getName();
												sat = sat.substring((int)(0), (int)(sat.indexOf(".apk")));
												break;
												    }
								} } catch(Exception e) {}
						if (sat.equals("")) {
								project_name.add("Unknow Project");
						}
						else {
								project_name.add(sat);
						}
						position++;
				}
				listview1.setAdapter(new Listview1Adapter(listmap));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup"))) {
						
				}
				else {
						FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup"));
				}
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/temp"))) {
						final_destination = FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/temp");
				}
				else {
						FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/temp"));
				}
		
		SketchwareUtil.showMessage(getApplicationContext(), "Made By SKETCHit");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_ZIPF:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				idd = sharedata.getString("idzip", "");
								path = _filePath.get((int)(0));
								final ProgressDialog prog = new ProgressDialog(MainActivity.this);prog.setMax(100);prog.setMessage("Coping Files....");prog.setIndeterminate(true);prog.setCancelable(false);prog.show();
								r1 = new TimerTask() {
										@Override
										public void run() {
												runOnUiThread(new Runnable() {
														@Override
														public void run() {
																FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/zip/"));
																FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/zip/"));
																_UnZip(path, FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/zip/"));
																FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(idd.concat("/file"))));
																FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(idd.concat("/library"))));
																FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(idd.concat("/logic"))));
																FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(idd.concat("/resource"))));
																FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(idd.concat("/view"))));
																if (!Uri.parse(path).getLastPathSegment().endsWith(".zip")) {
																		SketchwareUtil.showMessage(getApplicationContext(), "Not Sketch_Backup file!");
																		finish();
																}
																else {
																		if (!FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/zip/temp"))) {
																				SketchwareUtil.showMessage(getApplicationContext(), "Not Sketch_Backup file!");
																				finish();
																		}
																		else {
																				_Copy(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/zip/temp/data/"), FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(idd.concat("/"))));
																				if (!FileUtil.isExistFile("/.sketchware/mysc/".concat(idd.concat("/")))) {
																						FileUtil.makeDir("/.sketchware/mysc/".concat(idd.concat("/")));
																						_Copy(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/zip/temp/mysc/"), FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/".concat(idd.concat("/"))));
																				}
																				else {
																						FileUtil.deleteFile("/.sketchware/mysc/".concat(idd.concat("/app")));
																						FileUtil.deleteFile("/.sketchware/mysc/".concat(idd.concat("/bin")));
																						FileUtil.deleteFile("/.sketchware/mysc/".concat(idd.concat("/gen")));
																						FileUtil.deleteFile("/.sketchware/mysc/".concat(idd.concat("/build.gradle")));
																						FileUtil.deleteFile("/.sketchware/mysc/".concat(idd.concat("/settings.gradle")));
																						_Copy(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/zip/temp/mysc/"), FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/".concat(idd.concat("/"))));
																				}
																				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(idd)));
																				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(idd)));
																				_Copy(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/zip/temp/resources/icons/"), FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(idd.concat("/"))));
																				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/images/".concat(idd)));
																				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/images/".concat(idd)));
																				_Copy(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/zip/temp/resources/images/"), FileUtil.getExternalStorageDir().concat("/.sketchware/resources/images/".concat(idd.concat("/"))));
																				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/sounds/".concat(idd)));
																				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/sounds/".concat(idd)));
																				_Copy(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/zip/temp/resources/sounds/"), FileUtil.getExternalStorageDir().concat("/.sketchware/resources/sounds/".concat(idd.concat("/"))));
																				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/fonts/".concat(idd)));
																				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/fonts/".concat(idd)));
																				_Copy(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/zip/temp/resources/fonts/"), FileUtil.getExternalStorageDir().concat("/.sketchware/resources/fonts/".concat(idd.concat("/"))));
																				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/comment/".concat(idd)))) {
																						FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/comment/".concat(idd)));
																						FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/comment/".concat(idd)));
																						_Copy(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/zip/temp/resources/comment/"), FileUtil.getExternalStorageDir().concat("/.sketchware/resources/comment/".concat(idd)));
																				}
																				prog.hide();
																				SketchwareUtil.showMessage(getApplicationContext(), "Successfully Restored!");
										Toast.makeText(MainActivity.this, "Made By Manish Nirmal & Powerd By SKETCHit", Toast.LENGTH_SHORT).show();
										
																		}
																}
														}
												});
										}
								};
								_timer.schedule(r1, (int)(100));
					
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	private void _Elevation (final View _view, final double _number) {
		
		_view.setElevation((int)_number);
	}
	
	
	private void _gd (final View _view, final double _numb, final String _color) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_numb);
		_view.setBackground(gd);
	}
	
	
	private void _click_effect (final View _view, final String _c) {
		_view.setBackground(Drawables.getSelectableDrawableFor(Color.parseColor(_c)));
		_view.setClickable(true);
		
	}
	
	public static class Drawables {
		    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {
			        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
				            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_pressed},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_focused},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            return stateListDrawable;
				        } else {
				            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);
				            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"));
				            
				android.graphics.drawable.Drawable rippleColor = getRippleColor(color);
				            return new android.graphics.drawable.RippleDrawable(
				                pressedColor,
				                defaultColor,
				                rippleColor
				            );
				        }
			    }
		
		    private static android.graphics.drawable.Drawable getRippleColor(int color) {
			        float[] outerRadii = new float[8];
			        Arrays.fill(outerRadii, 0);
			        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);
			        
			android.graphics.drawable.ShapeDrawable shapeDrawable = new 
			android.graphics.drawable.ShapeDrawable(r);
			        shapeDrawable.getPaint().setColor(color);
			        return shapeDrawable;
			    }
		 
		    private static int lightenOrDarken(int color, double fraction) {
			        if (canLighten(color, fraction)) {
				            return lighten(color, fraction);
				        } else {
				            return darken(color, fraction);
				        }
			    }
		 
		    private static int lighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = lightenColor(red, fraction);
			        green = lightenColor(green, fraction);
			        blue = lightenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static int darken(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = darkenColor(red, fraction);
			        green = darkenColor(green, fraction);
			        blue = darkenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			 
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static boolean canLighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        return canLightenComponent(red, fraction)
			            && canLightenComponent(green, fraction)
			            && canLightenComponent(blue, fraction);
			    }
		 
		    private static boolean canLightenComponent(int colorComponent, double fraction) {
			        int red = Color.red(colorComponent);
			        int green = Color.green(colorComponent);
			        int blue = Color.blue(colorComponent);
			        return red + (red * fraction) < 255
			            && green + (green * fraction) < 255
			            && blue + (blue * fraction) < 255;
			    }
		 
		    private static int darkenColor(int color, double fraction) {
			        return (int) Math.max(color - (color * fraction), 0);
			    }
		 
		    private static int lightenColor(int color, double fraction) {
			        return (int) Math.min(color + (color * fraction), 255);
			    }
	}
	public static class CircleDrawables {
		    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {
			        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
				            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_pressed},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_focused},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            return stateListDrawable;
				        } else {
				            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);
				            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"));
				            
				android.graphics.drawable.Drawable rippleColor = getRippleColor(color);
				            return new android.graphics.drawable.RippleDrawable(
				                pressedColor,
				                defaultColor,
				                rippleColor
				            );
				        }
			    }
		
		    private static android.graphics.drawable.Drawable getRippleColor(int color) {
			        float[] outerRadii = new float[180];
			        Arrays.fill(outerRadii, 80);
			        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);
			        
			android.graphics.drawable.ShapeDrawable shapeDrawable = new 
			android.graphics.drawable.ShapeDrawable(r);
			        shapeDrawable.getPaint().setColor(color);
			        return shapeDrawable;
			    }
		 
		    private static int lightenOrDarken(int color, double fraction) {
			        if (canLighten(color, fraction)) {
				            return lighten(color, fraction);
				        } else {
				            return darken(color, fraction);
				        }
			    }
		 
		    private static int lighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = lightenColor(red, fraction);
			        green = lightenColor(green, fraction);
			        blue = lightenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static int darken(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = darkenColor(red, fraction);
			        green = darkenColor(green, fraction);
			        blue = darkenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			 
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static boolean canLighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        return canLightenComponent(red, fraction)
			            && canLightenComponent(green, fraction)
			            && canLightenComponent(blue, fraction);
			    }
		 
		    private static boolean canLightenComponent(int colorComponent, double fraction) {
			        int red = Color.red(colorComponent);
			        int green = Color.green(colorComponent);
			        int blue = Color.blue(colorComponent);
			        return red + (red * fraction) < 255
			            && green + (green * fraction) < 255
			            && blue + (blue * fraction) < 255;
			    }
		 
		    private static int darkenColor(int color, double fraction) {
			        return (int) Math.max(color - (color * fraction), 0);
			    }
		 
		    private static int lightenColor(int color, double fraction) {
			        return (int) Math.min(color + (color * fraction), 255);
		}
	}
	
	public void drawableclass() {
	}
	
	
	private void _check () {
		FileUtil.makeDir(zip_to.concat(id));
		zip_from = zip_to.concat(id);
		FileUtil.copyFile(Sketchware.concat("data/".concat(id)), zip_from);
		FileUtil.copyFile(Sketchware.concat("mysc/list/".concat(id)), zip_from);
		FileUtil.copyFile(Sketchware.concat("resources/comment/".concat(id)), zip_from);
		FileUtil.copyFile(Sketchware.concat("resources/fonts/".concat(id)), zip_from);
		FileUtil.copyFile(Sketchware.concat("resources/icons/".concat(id)), zip_from);
		FileUtil.copyFile(Sketchware.concat("resources/images/".concat(id)), zip_from);
		FileUtil.copyFile(Sketchware.concat("resources/sounds/".concat(id)), zip_from);
		FileUtil.makeDir(final_destination.concat(id));
		SketchwareUtil.showMessage(getApplicationContext(), "zipped");
	}
	
	
	private void _copy2 (final String _sfrom, final String _sto) {
		FileUtil.writeFile("Its For Request Permission", "Don't Remove This Block");
		copydir cp = new copydir();
		cp.copydirectory(_sfrom,_sto);
	}
	public static class copydir {
		public static void copydirectory(String src, String dest) {
			java.io.File srcFolder = new java.io.File(src);
			java.io.File destFolder = new java.io.File(dest);
			if(!srcFolder.exists()) {
				System.out.println("Directory does not exist.");
				//just exit
				System.exit(0);
			} else {
				try{
					copyDirectory(srcFolder,destFolder);
				} catch(java.io.IOException e) {
					e.printStackTrace();
					//error, just exit
					System.exit(0);
				}
			}
			System.out.println("Done");
		}
		public static void copyDirectory(java.io.File src , java.io.File target) throws java.io.IOException {
			if (src.isDirectory()) {
				if (!target.exists()) {
					target.mkdir();
				}
				String[] children = src.list();
				for (int i=0; i<children.length; i++) {
					copyDirectory(new java.io.File(src, children[i]),new java.io.File(target, children[i]));
				}
			} else {
				java.io.InputStream in = new java.io.FileInputStream(src);
				java.io.OutputStream out = new java.io.FileOutputStream(target);
				// Copy the bits from instream to outstream
				byte[] buf = new byte[1024];
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
				in.close();
				out.close();
			}
		} 
	}
	{
	}
	
	
	private void _Copy_data (final String _project_no) {
		FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/data/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/data/"));
				_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/data/"));
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/mysc/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/mysc/"));
				_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/mysc/"));
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/mysc/bin/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/mysc/bin/"));
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/list/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/list/"));
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/list/".concat(_project_no.concat("/"))))) {
						_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/list/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/list/"));
				}
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/icons/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/icons/"));
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(_project_no.concat("/"))))) {
						_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/icons/"));
				}
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/images/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/images/"));
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/images/".concat(_project_no.concat("/"))))) {
						_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/images/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/images/"));
				}
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/sounds/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/sounds/"));
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/sounds/".concat(_project_no.concat("/"))))) {
						_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/sounds/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/sounds/"));
				}
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/fonts/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/fonts/"));
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/fonts/".concat(_project_no.concat("/"))))) {
						_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/fonts/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/fonts/"));
				}
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/comment/"));
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/comment/"));
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/comment/".concat(_project_no.concat("/"))))) {
						_copy2(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/comment/".concat(_project_no.concat("/"))), FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/resources/comment/"));
				}
		
	}
	
	
	private void _zip (final String _source, final String _destination) {
		FileUtil.writeFile("Don't Remove it Thanks .\nFound by: tekken-rca\nModified By: Amitoj", "This Block Added for Manage Permission");
		try {
			java.util.zip.ZipOutputStream os = new java.util.zip.ZipOutputStream(new java.io.FileOutputStream(_destination));
					zip(os, _source, null);
					os.close();
		}
		
		catch(java.io.IOException e) {}
	}
	private void zip(java.util.zip.ZipOutputStream os, String filePath, String name) throws java.io.IOException
		{
				java.io.File file = new java.io.File(filePath);
				java.util.zip.ZipEntry entry = new java.util.zip.ZipEntry((name != null ? name + java.io.File.separator : "") + file.getName() + (file.isDirectory() ? java.io.File.separator : ""));
				os.putNextEntry(entry);
				
				if(file.isFile()) {
						java.io.InputStream is = new java.io.FileInputStream(file);
						int size = is.available();
						byte[] buff = new byte[size];
						int len = is.read(buff);
						os.write(buff, 0, len);
						return;
				}
				
				java.io.File[] fileArr = file.listFiles();
				for(java.io.File subFile : fileArr) {
						zip(os, subFile.getAbsolutePath(), entry.getName());
				}
	}
	
	
	private void _backup () {
		final ProgressDialog prog = new ProgressDialog(MainActivity.this);prog.setMax(100);prog.setMessage("Backuping Projects Files...... ");prog.setIndeterminate(true);prog.setCancelable(false);prog.show();
				t = new TimerTask() {
						@Override
						public void run() {
								runOnUiThread(new Runnable() {
										@Override
										public void run() {
												_Copy_data(sharedata.getString("id", ""));
												if (!FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/Sketch_Backup/Backuped_Projects/".concat("")))) {
														FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/Sketch_Backup/Backuped_Projects/".concat("")));
												}
												from = FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/data/temp/");
												to = FileUtil.getExternalStorageDir().concat("/Sketch_Backup/Backuped_Projects/".concat(sharedata.getString("id", "").concat(".zip")));
												_zip(from, to);
												prog.hide();
												SketchwareUtil.showMessage(getApplicationContext(), "Successfully Backuped!");
										}
								});
						}
				};
				_timer.schedule(t, (int)(100));
			
	}
	
	
	private void _UnZip (final String _fileZip, final String _destDir) {
		try
		{
			java.io.File outdir = new java.io.File(_destDir);
			java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(_fileZip));
			java.util.zip.ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null)
			{
				name = entry.getName();
				if(entry.isDirectory())
				{
					mkdirs(outdir, name);
					continue;
				}
				
				/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (java.io.IOException e)
		{
			e.printStackTrace();
		}
	}
	private static void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
	{
		byte[] buffer = new byte[4096];
		java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(java.io.File outdir, String path)
	{
		java.io.File d = new java.io.File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name)
	{
		int s = name.lastIndexOf(java.io.File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
	
	
	private void _Copy (final String _path, final String _pathto) {
		copy(new java.io.File(_path), new java.io.File(_pathto));
		 } public void copy(java.io.File sourceLocation, java.io.File targetLocation)
	 {
		  try {
			  if (sourceLocation.isDirectory())
			  {
				   copyDirectory(sourceLocation, targetLocation);
				  }
			  else
			  {
				   copyFile(sourceLocation, targetLocation);
				  }
			  } catch(Exception e){ throw new RuntimeException(e); }
		 }
	 private void copyDirectory(java.io.File source, java.io.File target)
	 {
		  if (!target.exists())
		  {
			   target.mkdir();
			  }
		  for (String f : source.list())
		  {
			   copy(new java.io.File(source, f), new java.io.File(target, f));
			  }
		 }
	 private void copyFile(java.io.File source, java.io.File target)
	 {
		  try {
			  try ( java.io.InputStream in = new java.io.FileInputStream(source); java.io.OutputStream out = new java.io.FileOutputStream(target) )
			  {
				   byte[] buf = new byte[1024]; int length; while ((length = in.read(buf)) > 0)
				   {
					    out.write(buf, 0, length);
					   }
				  }
			  } catch(Exception e) { throw new RuntimeException(e); }
		
	}
	
	
	private void _share1 (final String _dat, final boolean _file, final String _des) {
		if (_file) {
			Intent shareIntent = new Intent(Intent.ACTION_SEND); shareIntent.setType("text/plain"); shareIntent.putExtra(Intent.EXTRA_STREAM, Uri.parse(_dat));
			startActivity(Intent.createChooser(shareIntent, "Share"));
		}
		else {
			Intent shareIntent = new Intent(Intent.ACTION_SEND); shareIntent.setType("text/plain"); shareIntent.putExtra(Intent.EXTRA_TEXT, (_dat));
			startActivity(Intent.createChooser(shareIntent, "Share"));
		}
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.cus, null);
			}
			
			final LinearLayout back = (LinearLayout) _v.findViewById(R.id.back);
			final LinearLayout clickl = (LinearLayout) _v.findViewById(R.id.clickl);
			final LinearLayout line_show = (LinearLayout) _v.findViewById(R.id.line_show);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final LinearLayout linear3 = (LinearLayout) _v.findViewById(R.id.linear3);
			final LinearLayout linear10 = (LinearLayout) _v.findViewById(R.id.linear10);
			final ImageView i = (ImageView) _v.findViewById(R.id.i);
			final TextView t = (TextView) _v.findViewById(R.id.t);
			final TextView p = (TextView) _v.findViewById(R.id.p);
			final ImageView dropdown = (ImageView) _v.findViewById(R.id.dropdown);
			final LinearLayout show_color = (LinearLayout) _v.findViewById(R.id.show_color);
			final LinearLayout linear12 = (LinearLayout) _v.findViewById(R.id.linear12);
			final LinearLayout backup_btn = (LinearLayout) _v.findViewById(R.id.backup_btn);
			final LinearLayout restore_btn = (LinearLayout) _v.findViewById(R.id.restore_btn);
			final LinearLayout share_btn = (LinearLayout) _v.findViewById(R.id.share_btn);
			final LinearLayout info_btn = (LinearLayout) _v.findViewById(R.id.info_btn);
			final ImageView imageview3 = (ImageView) _v.findViewById(R.id.imageview3);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final ImageView imageview2 = (ImageView) _v.findViewById(R.id.imageview2);
			final TextView textview2 = (TextView) _v.findViewById(R.id.textview2);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			final TextView textview4 = (TextView) _v.findViewById(R.id.textview4);
			final ImageView imageview4 = (ImageView) _v.findViewById(R.id.imageview4);
			final TextView textview3 = (TextView) _v.findViewById(R.id.textview3);
			
			Sketchware = FileUtil.getExternalStorageDir().concat("/.sketchware/");
						_Elevation(back, 5);
						_click_effect(clickl, "#E0E0E0");
						if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/").concat(Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment()).concat("/icon.png"))) {
								i.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/").concat(Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment()).concat("/icon.png"), 1024, 1024));
						}
						else {
								i.setImageResource(R.drawable.android_icon);
						}
						if (FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/").concat(Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment().concat("/app/build.gradle"))).equals("")) {
								p.setText("no packge loaded");
						}
						else {
								buildGradle = FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/").concat(Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment().concat("/app/build.gradle")));
								name = buildGradle.substring((int)(buildGradle.indexOf("applicationId")), (int)(buildGradle.indexOf("minSdkVersion")));
								name = name.replace("applicationId \"", "");
								name = name.replace("\"", "");
								p.setText(name);
						}
						t.setText(project_name.get((int)((project_name.size() - _position) - 1)));
						clickl.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										if (show_color.isEnabled()) {
												show_color.setVisibility(View.GONE);
												dropdown.setImageResource(R.drawable.ic_expand_more_grey);
												show_color.setEnabled(false);
										}
										else {
												show_color.setVisibility(View.VISIBLE);
												dropdown.setImageResource(R.drawable.ic_expand_less_grey);
												show_color.setEnabled(true);
										}
								}
						});
						show_color.setVisibility(View.GONE);
						dropdown.setImageResource(R.drawable.ic_expand_more_grey);
						show_color.setEnabled(false);
						_click_effect(backup_btn, "#E0E0E0");
						_click_effect(restore_btn, "#E0E0E0");
						_click_effect(share_btn, "#E0E0E0");
						_click_effect(info_btn, "#E0E0E0");
						backup_btn.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										sharedata.edit().putString("id", Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment()).commit();
										_backup();
					Toast.makeText(MainActivity.this, "Made By Manish Nirmal & Powerd By SKETCHit", Toast.LENGTH_SHORT).show();
								}
						});
						restore_btn.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										sharedata.edit().putString("idzip", Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment()).commit();
										startActivityForResult(zipf, REQ_CD_ZIPF);
								}
						});
						share_btn.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
										final ProgressDialog prog = new ProgressDialog(MainActivity.this);prog.setMax(100);prog.setMessage("Sharing Project Files..... ");prog.setIndeterminate(true);prog.setCancelable(false);prog.show();
										r2 = new TimerTask() {
												@Override
												public void run() {
														runOnUiThread(new Runnable() {
																@Override
																public void run() {
																		if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/Share_Projects"))) {
																				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/Share_Projects"));
																				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/Share_Projects"));
																		}
																		else {
																				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/Share_Projects"));
																		}
																		_Copy_data(Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment());
																		from = FileUtil.getExternalStorageDir().concat("/.SKETCHit/data/temp/");
																		to = FileUtil.getExternalStorageDir().concat("/.Sketch_Backup/Share_Projects/".concat(Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment().concat(".zip")));
																		_zip(from, to);
																		_share1(to, true, Uri.parse(liststring.get((int)((liststring.size() - _position) - 1))).getLastPathSegment().concat(".zip"));
									Toast.makeText(MainActivity.this, "Made By Manish Nirmal & Powerd By SKETCHit", Toast.LENGTH_SHORT).show();
																		prog.hide();
																}
														});
												}
										};
										_timer.schedule(r2, (int)(100));
								}
						});
						info_btn.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
					Toast.makeText(MainActivity.this, "Made By Manish Nirmal & Powerd By SKETCHit", Toast.LENGTH_SHORT).show();
										d.setTitle("Project Information");
										d.setMessage("Project ID :- ".concat(liststring.get((int)((liststring.size() - _position) - 1))));
										d.setPositiveButton("OK", new DialogInterface.OnClickListener() {
												@Override
												public void onClick(DialogInterface _dialog, int _which) {
														
												}
										});
										d.create().show();
								}
						});
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
