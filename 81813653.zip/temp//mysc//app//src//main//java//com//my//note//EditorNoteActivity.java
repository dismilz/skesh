package com.my.note;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.content.SharedPreferences;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import android.Manifest;
import android.content.pm.PackageManager;

public class EditorNoteActivity extends Activity {
	
	
	private boolean save_checker = false;
	private String KEY_DATA = "";
	private HashMap<String, Object> HashMap = new HashMap<>();
	private String COLOR = "";
	private String GENERATE_DATA_PATH = "";
	
	private ArrayList<HashMap<String, Object>> addData = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout action_bar;
	private LinearLayout line;
	private LinearLayout title_line;
	private EditText text;
	private ImageView back;
	private TextView textview1;
	private ImageView save;
	private EditText title;
	private LinearLayout color;
	
	private Calendar calendar = Calendar.getInstance();
	private SharedPreferences data;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.editor_note);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		action_bar = (LinearLayout) findViewById(R.id.action_bar);
		line = (LinearLayout) findViewById(R.id.line);
		title_line = (LinearLayout) findViewById(R.id.title_line);
		text = (EditText) findViewById(R.id.text);
		back = (ImageView) findViewById(R.id.back);
		textview1 = (TextView) findViewById(R.id.textview1);
		save = (ImageView) findViewById(R.id.save);
		title = (EditText) findViewById(R.id.title);
		color = (LinearLayout) findViewById(R.id.color);
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		
		text.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.trim().equals("")) {
					_Animator(save, "scaleX", 0, 200);
					_Animator(save, "scaleY", 0, 200);
					save_checker = false;
				}
				else {
					if (!save_checker) {
						_Animator(save, "scaleX", 1, 200);
						_Animator(save, "scaleY", 1, 200);
						save_checker = true;
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE); imm.hideSoftInputFromWindow(title.getWindowToken(), 0);
				finish();
			}
		});
		
		save.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE); imm.hideSoftInputFromWindow(title.getWindowToken(), 0);
				addData = new Gson().fromJson(data.getString(KEY_DATA, ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				GENERATE_DATA_PATH = FileUtil.getExternalStorageDir().concat("/Note 404./data/".concat(title.getText().toString().concat("-".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(1000000000), (int)(9999999999d))))).concat(".e404"))));
				calendar = Calendar.getInstance();
				HashMap = new HashMap<>();
				HashMap.put("type", "note");
				HashMap.put("title", title.getText().toString());
				HashMap.put("data", text.getText().toString());
				HashMap.put("color", COLOR);
				HashMap.put("date", new SimpleDateFormat("dd-MMM, yyyy").format(calendar.getTime()));
				HashMap.put("path", GENERATE_DATA_PATH);
				addData.add(HashMap);
				data.edit().putString(KEY_DATA, new Gson().toJson(addData)).commit();
				FileUtil.writeFile(GENERATE_DATA_PATH, new Gson().toJson(HashMap));
				finish();
			}
		});
	}
	private void initializeLogic() {
		_AppData();
		_ui();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _ui () {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) { getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); }
		_setBackground(title_line, 20, 0, "#F5F5F5", false);
		_setBackground(back, 50, 0, "#ffffff", true);
		_setBackground(save, 50, 0, "#ffffff", true);
		_setBackground(color, 50, 2, "#eeeeee", true);
		save.setScaleX((float)(0));
		save.setScaleY((float)(0));
	}
	
	
	private void _setBackground (final View _view, final double _radius, final double _shadow, final String _color, final boolean _ripple) {
		if (_ripple) {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			_view.setElevation((int)_shadow);
			android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#9e9e9e")});
			android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
			_view.setClickable(true);
			_view.setBackground(ripdrb);
		}
		else {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			_view.setBackground(gd);
			_view.setElevation((int)_shadow);
		}
	}
	
	
	private void _Animator (final View _view, final String _propertyName, final double _value, final double _duration) {
		ObjectAnimator anim = new ObjectAnimator();
		anim.setTarget(_view);
		anim.setPropertyName(_propertyName);
		anim.setFloatValues((float)_value);
		anim.setDuration((long)_duration);
		anim.start();
	}
	
	
	private void _AppData () {
		KEY_DATA = "data";
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
