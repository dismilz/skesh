package com.my.note;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.view.View;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class MainActivity extends Activity {
	
	
	private boolean search_bool = false;
	private HashMap<String, Object> HashMap = new HashMap<>();
	private String type_main = "";
	private String type_draft = "";
	private String type_note = "";
	private String type_code = "";
	private String type_multipleNote = "";
	private String LIST_DATA = "";
	private String KEY_DATA = "";
	
	private ArrayList<HashMap<String, Object>> List = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> addData = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout action_bar;
	private ListView listview;
	private ImageView but_menu;
	private TextView textview1;
	private EditText edittext1;
	private ImageView but_search;
	
	private Intent intent = new Intent();
	private SharedPreferences data;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		action_bar = (LinearLayout) findViewById(R.id.action_bar);
		listview = (ListView) findViewById(R.id.listview);
		but_menu = (ImageView) findViewById(R.id.but_menu);
		textview1 = (TextView) findViewById(R.id.textview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		but_search = (ImageView) findViewById(R.id.but_search);
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		
		but_menu.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		but_search.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (search_bool) {
					textview1.setVisibility(View.VISIBLE);
					edittext1.setVisibility(View.GONE);
					search_bool = false;
				}
				else {
					textview1.setVisibility(View.GONE);
					edittext1.setVisibility(View.VISIBLE);
					edittext1.setText("");
					search_bool = true;
				}
			}
		});
	}
	private void initializeLogic() {
		_AppData();
		_ui();
		_LoadData();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		_LoadData();
	}
	private void _ui () {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) { getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); }
		edittext1.setVisibility(View.GONE);
		_setBackground(action_bar, 20, 5, "#ffffff", false);
		_setBackground(but_menu, 50, 0, "#ffffff", true);
		_setBackground(but_search, 50, 0, "#ffffff", true);
	}
	
	
	private void _setBackground (final View _view, final double _radius, final double _shadow, final String _color, final boolean _ripple) {
		if (_ripple) {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			_view.setElevation((int)_shadow);
			android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#9e9e9e")});
			android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
			_view.setClickable(true);
			_view.setBackground(ripdrb);
		}
		else {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			_view.setBackground(gd);
			_view.setElevation((int)_shadow);
		}
	}
	
	
	private void _LoadData () {
		if (data.getString(KEY_DATA, "").equals("")) {
			HashMap = new HashMap<>();
			HashMap.put("type", type_main);
			HashMap.put("title", "Dashboard");
			HashMap.put("value", "null");
			addData.add(HashMap);
			data.edit().putString(KEY_DATA, new Gson().toJson(addData)).commit();
		}
		else {
			
		}
		List = new Gson().fromJson(data.getString(KEY_DATA, ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		listview.setAdapter(new ListviewAdapter(List));
		((BaseAdapter)listview.getAdapter()).notifyDataSetChanged();
	}
	
	
	private void _AppData () {
		type_main = "main";
		type_draft = "draft";
		type_note = "note";
		type_code = "code";
		type_multipleNote = "multipleNote";
		KEY_DATA = "data";
		LIST_DATA = data.getString(KEY_DATA, "");
	}
	
	
	private void _setHolder (final View _holder) {
		ViewGroup viewgroup = (ViewGroup) _holder.getParent();
		
		for (int i = 0; i < viewgroup.getChildCount(); i++)
		{
			    View nextChild = (View) viewgroup.getChildAt(i);
			nextChild.setVisibility(View.GONE);
		}
		_holder.setVisibility(View.VISIBLE);
	}
	
	
	public class ListviewAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public ListviewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.group_item, null);
			}
			
			final LinearLayout line1 = (LinearLayout) _v.findViewById(R.id.line1);
			final LinearLayout line2 = (LinearLayout) _v.findViewById(R.id.line2);
			final LinearLayout line3 = (LinearLayout) _v.findViewById(R.id.line3);
			final LinearLayout line4 = (LinearLayout) _v.findViewById(R.id.line4);
			final LinearLayout admob = (LinearLayout) _v.findViewById(R.id.admob);
			final LinearLayout linear6 = (LinearLayout) _v.findViewById(R.id.linear6);
			final LinearLayout linear7 = (LinearLayout) _v.findViewById(R.id.linear7);
			final LinearLayout line_cloud = (LinearLayout) _v.findViewById(R.id.line_cloud);
			final LinearLayout line_analytics = (LinearLayout) _v.findViewById(R.id.line_analytics);
			final LinearLayout linear14 = (LinearLayout) _v.findViewById(R.id.linear14);
			final LinearLayout linear15 = (LinearLayout) _v.findViewById(R.id.linear15);
			final ImageView imageview5 = (ImageView) _v.findViewById(R.id.imageview5);
			final TextView textview8 = (TextView) _v.findViewById(R.id.textview8);
			final TextView textview10 = (TextView) _v.findViewById(R.id.textview10);
			final TextView textview11 = (TextView) _v.findViewById(R.id.textview11);
			final LinearLayout linear16 = (LinearLayout) _v.findViewById(R.id.linear16);
			final LinearLayout linear17 = (LinearLayout) _v.findViewById(R.id.linear17);
			final ImageView imageview6 = (ImageView) _v.findViewById(R.id.imageview6);
			final TextView textview9 = (TextView) _v.findViewById(R.id.textview9);
			final LinearLayout line_create = (LinearLayout) _v.findViewById(R.id.line_create);
			final LinearLayout button_newnote = (LinearLayout) _v.findViewById(R.id.button_newnote);
			final LinearLayout button_newcode = (LinearLayout) _v.findViewById(R.id.button_newcode);
			final LinearLayout button_newmultyple = (LinearLayout) _v.findViewById(R.id.button_newmultyple);
			final LinearLayout dot_1 = (LinearLayout) _v.findViewById(R.id.dot_1);
			final TextView textview5 = (TextView) _v.findViewById(R.id.textview5);
			final ImageView imageview8 = (ImageView) _v.findViewById(R.id.imageview8);
			final LinearLayout dot_2 = (LinearLayout) _v.findViewById(R.id.dot_2);
			final TextView textview6 = (TextView) _v.findViewById(R.id.textview6);
			final ImageView imageview9 = (ImageView) _v.findViewById(R.id.imageview9);
			final LinearLayout dot_3 = (LinearLayout) _v.findViewById(R.id.dot_3);
			final TextView textview7 = (TextView) _v.findViewById(R.id.textview7);
			final ImageView imageview10 = (ImageView) _v.findViewById(R.id.imageview10);
			final LinearLayout line_draft = (LinearLayout) _v.findViewById(R.id.line_draft);
			final TextView textview12 = (TextView) _v.findViewById(R.id.textview12);
			final TextView textview13 = (TextView) _v.findViewById(R.id.textview13);
			final ImageView imageview7 = (ImageView) _v.findViewById(R.id.imageview7);
			final LinearLayout line_multyplenote = (LinearLayout) _v.findViewById(R.id.line_multyplenote);
			final LinearLayout l3_type_color = (LinearLayout) _v.findViewById(R.id.l3_type_color);
			final LinearLayout linear23 = (LinearLayout) _v.findViewById(R.id.linear23);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final LinearLayout linear3 = (LinearLayout) _v.findViewById(R.id.linear3);
			final TextView title = (TextView) _v.findViewById(R.id.title);
			final TextView description = (TextView) _v.findViewById(R.id.description);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			final TextView length = (TextView) _v.findViewById(R.id.length);
			final TextView textview4 = (TextView) _v.findViewById(R.id.textview4);
			final LinearLayout linear4 = (LinearLayout) _v.findViewById(R.id.linear4);
			final TextView size = (TextView) _v.findViewById(R.id.size);
			final LinearLayout note_linear = (LinearLayout) _v.findViewById(R.id.note_linear);
			final LinearLayout l4_type_color = (LinearLayout) _v.findViewById(R.id.l4_type_color);
			final LinearLayout linear21 = (LinearLayout) _v.findViewById(R.id.linear21);
			final TextView l4_title = (TextView) _v.findViewById(R.id.l4_title);
			final LinearLayout linear20 = (LinearLayout) _v.findViewById(R.id.linear20);
			final TextView l4_date = (TextView) _v.findViewById(R.id.l4_date);
			final LinearLayout linear25 = (LinearLayout) _v.findViewById(R.id.linear25);
			
			if (List.get((int)_position).get("type").toString().equals(type_main)) {
				_setHolder(line1);
				_setBackground(line_cloud, 20, 5, "#ffffff", true);
				_setBackground(line_analytics, 20, 5, "#ffffff", true);
				_setBackground(line_create, 20, 5, "#ffffff", false);
				_setBackground(button_newnote, 20, 0, "#ffffff", true);
				_setBackground(button_newcode, 20, 0, "#ffffff", true);
				_setBackground(button_newmultyple, 20, 0, "#ffffff", true);
				_setBackground(dot_1, 50, 0, "#FFC107", false);
				_setBackground(dot_2, 50, 0, "#F44336", false);
				_setBackground(dot_3, 50, 0, "#008DCD", false);
				button_newnote.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						intent.setClass(getApplicationContext(), EditorNoteActivity.class);
						startActivity(intent);
					}
				});
			}
			if (List.get((int)_position).get("type").toString().equals(type_note)) {
				_setHolder(line4);
				_setBackground(note_linear, 20, 5, "#ffffff", true);
				_setBackground(l4_type_color, 20, 0, "#FFC107", false);
				l4_title.setText(List.get((int)_position).get("title").toString());
				l4_date.setText(List.get((int)_position).get("date").toString());
			}
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
