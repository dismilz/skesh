package WhatsApp.chat;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.View;

public class LoginActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private boolean isLogin = false;
	private HashMap<String, Object> userbiodata = new HashMap<>();
	
	private LinearLayout opening;
	private LinearLayout login_register;
	private TextView textview1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private Button login_1;
	private LinearLayout linear4;
	private Button register_1;
	private LinearLayout linear8;
	private EditText acc_name;
	private EditText email;
	private EditText pass;
	private TextView textview2;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private Button button1;
	private Button login_2;
	private Button register_2;
	
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private DatabaseReference usersauth = _firebase.getReference("auth/users");
	private ChildEventListener _usersauth_child_listener;
	private Calendar c = Calendar.getInstance();
	private SharedPreferences user;
	private Intent a = new Intent();
	private ObjectAnimator opening_animation = new ObjectAnimator();
	private ObjectAnimator loginregist_anim = new ObjectAnimator();
	private ObjectAnimator loginregist = new ObjectAnimator();
	private ObjectAnimator opening1 = new ObjectAnimator();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.login);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		opening = (LinearLayout) findViewById(R.id.opening);
		login_register = (LinearLayout) findViewById(R.id.login_register);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		login_1 = (Button) findViewById(R.id.login_1);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		register_1 = (Button) findViewById(R.id.register_1);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		acc_name = (EditText) findViewById(R.id.acc_name);
		email = (EditText) findViewById(R.id.email);
		pass = (EditText) findViewById(R.id.pass);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		button1 = (Button) findViewById(R.id.button1);
		login_2 = (Button) findViewById(R.id.login_2);
		register_2 = (Button) findViewById(R.id.register_2);
		auth = FirebaseAuth.getInstance();
		user = getSharedPreferences("user", Activity.MODE_PRIVATE);
		
		login_1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_showActionBar(true);
				login_register.setVisibility(View.VISIBLE);
				opening.setVisibility(View.GONE);
				acc_name.setVisibility(View.VISIBLE);
				login_2.setVisibility(View.VISIBLE);
				register_2.setVisibility(View.GONE);
				isLogin = true;
			}
		});
		
		register_1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_showActionBar(true);
				opening.setVisibility(View.GONE);
				login_register.setVisibility(View.VISIBLE);
				login_2.setVisibility(View.GONE);
				register_2.setVisibility(View.VISIBLE);
				acc_name.setVisibility(View.VISIBLE);
				isLogin = true;
			}
		});
		
		textview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				a.setClass(getApplicationContext(), SettingsActivity.class);
				a.putExtra("resetPass", "yes");
				startActivity(a);
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				opening.setVisibility(View.VISIBLE);
				login_register.setVisibility(View.GONE);
				isLogin = false;
			}
		});
		
		login_2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				auth.signInWithEmailAndPassword(email.getText().toString(), pass.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_sign_in_listener);
			}
		});
		
		register_2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				auth.createUserWithEmailAndPassword(email.getText().toString(), pass.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_create_user_listener);
			}
		});
		
		_usersauth_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		usersauth.addChildEventListener(_usersauth_child_listener);
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					c = Calendar.getInstance();
					userbiodata = new HashMap<>();
					userbiodata.put("nickname", acc_name.getText().toString());
					userbiodata.put("email", email.getText().toString());
					userbiodata.put("password", pass.getText().toString());
					userbiodata.put("createdate", new SimpleDateFormat("HH:mm:ss D/MM/yyyy").format(c.getTime()));
					user.edit().putString("nickname", acc_name.getText().toString()).commit();
					user.edit().putString("email", email.getText().toString()).commit();
					user.edit().putString("pass", pass.getText().toString()).commit();
					usersauth.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(userbiodata);
					a.setClass(getApplicationContext(), ConvListActivity.class);
					startActivity(a);
					finish();
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					user.edit().putString("nickname", acc_name.getText().toString()).commit();
					user.edit().putString("email", email.getText().toString()).commit();
					user.edit().putString("pass", pass.getText().toString()).commit();
					a.setClass(getApplicationContext(), ConvListActivity.class);
					startActivity(a);
					finish();
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		_gd(login_1, "#009688", "#000000", 75);
		_gd(register_1, "#009688", "#000000", 75);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (isLogin) {
			opening.setVisibility(View.VISIBLE);
			login_register.setVisibility(View.GONE);
			isLogin = false;
		}
		else {
			finish();
		}
	}
	private void _radius_widget (final View _view, final double _radius, final String _color, final double _stroke) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((float)_radius);
		
		_view.setBackground(gd);
	}
	
	
	private void _showActionBar (final boolean _condition) {
		
	}
	
	
	private void _gd (final View _view, final String _c, final String _sc, final double _r) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		
		gd.setColor(Color.parseColor(_c));
		gd.setCornerRadius((float)_r);
		gd.setStroke(2, Color.parseColor(_sc));
		
		_view.setBackground(gd);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
