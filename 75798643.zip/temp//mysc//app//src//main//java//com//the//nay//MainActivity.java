package com.the.nay;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import java.util.Timer;
import java.util.TimerTask;
import android.app.Activity;
import android.content.SharedPreferences;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.AdapterView;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> mapUser = new HashMap<>();
	private String device = "";
	private String model = "";
	private String android_id = "";
	private String api_level = "";
	private String id = "";
	private HashMap<String, Object> mapMessage = new HashMap<>();
	private double n = 0;
	private String gone_data = "";
	private String color = "";
	private double random = 0;
	private String key = "";
	private HashMap<String, Object> cmap = new HashMap<>();
	private double limiter = 0;
	private String reply_user_id = "";
	private String reply_user_name = "";
	private String reply_user_message = "";
	private boolean reply_check = false;
	private String msg_key = "";
	private String reply_message_key = "";
	private double reply_length = 0;
	private double rp_current = 0;
	
	private ArrayList<HashMap<String, Object>> list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> userList = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> currentList = new ArrayList<>();
	private ArrayList<String> reply_list = new ArrayList<>();
	
	private LinearLayout main_linear;
	private LinearLayout top_item;
	private LinearLayout linear4;
	private ImageView imageview1;
	private TextView textview1;
	private LinearLayout you;
	private ProgressBar progressbar1;
	private TextView your_name;
	private TextView your_color;
	private LinearLayout linear2;
	private LinearLayout bottom_item;
	private ListView listview1;
	private LinearLayout rp;
	private ImageView reply_view;
	private TextView reply_length_text;
	private LinearLayout reply;
	private LinearLayout linear9;
	private ImageView imageview2;
	private LinearLayout linear11;
	private ImageView imageview3;
	private TextView textview2;
	private TextView textview3;
	private LinearLayout linear7;
	private EditText message;
	private LinearLayout linear6;
	private ImageView send_button;
	
	private TimerTask timer;
	private SharedPreferences userData;
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private DatabaseReference message_reply = _firebase.getReference("message_reply");
	private ChildEventListener _message_reply_child_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		main_linear = (LinearLayout) findViewById(R.id.main_linear);
		top_item = (LinearLayout) findViewById(R.id.top_item);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		you = (LinearLayout) findViewById(R.id.you);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		your_name = (TextView) findViewById(R.id.your_name);
		your_color = (TextView) findViewById(R.id.your_color);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		bottom_item = (LinearLayout) findViewById(R.id.bottom_item);
		listview1 = (ListView) findViewById(R.id.listview1);
		rp = (LinearLayout) findViewById(R.id.rp);
		reply_view = (ImageView) findViewById(R.id.reply_view);
		reply_length_text = (TextView) findViewById(R.id.reply_length_text);
		reply = (LinearLayout) findViewById(R.id.reply);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		message = (EditText) findViewById(R.id.message);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		send_button = (ImageView) findViewById(R.id.send_button);
		userData = getSharedPreferences("userData", Activity.MODE_PRIVATE);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				list.remove((int)(_position));
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				_getReplyData(_position);
				_reply_block(true);
				return true;
			}
		});
		
		reply_view.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				n = 0;
				for(int _repeat11 = 0; _repeat11 < (int)(list.size()); _repeat11++) {
					if (reply_list.size() == 0) {
						
					}
					else {
						if (list.get((int)n).get("message_key").toString().equals(reply_list.get((int)(0)))) {
							reply_list.remove((int)(0));
							reply_length_text.setText(String.valueOf((long)(reply_list.size())));
							listview1.smoothScrollToPosition((int)(n));
							if (reply_list.size() == 0) {
								rp.setVisibility(View.GONE);
							}
							mapMessage = new HashMap<>();
							mapMessage.put("reply_user_id", "true");
							message_reply.child(list.get((int)n).get("message_key").toString()).updateChildren(mapMessage);
							mapMessage.clear();
							break;
						}
						n++;
					}
				}
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_reply_block(false);
			}
		});
		
		message.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < _charSeq.trim().length()) {
					send_button.setVisibility(View.VISIBLE);
				}
				else {
					send_button.setVisibility(View.GONE);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		send_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				msg_key = message_reply.push().getKey();
				if (reply_check) {
					mapMessage = new HashMap<>();
					mapMessage.put("user_name", userData.getString("user_name", ""));
					mapMessage.put("user_id", userData.getString("user_id", ""));
					mapMessage.put("user_message", message.getText().toString());
					mapMessage.put("user_reply", "true");
					mapMessage.put("reply_user_id", reply_user_id);
					mapMessage.put("reply_user_name", reply_user_name);
					mapMessage.put("reply_user_message", reply_user_message);
					mapMessage.put("reply_message_key", reply_message_key);
					mapMessage.put("message_key", msg_key);
					message_reply.child(msg_key).updateChildren(mapMessage);
					mapMessage.clear();
					_reply_block(false);
				}
				else {
					mapMessage = new HashMap<>();
					mapMessage.put("user_name", userData.getString("user_name", ""));
					mapMessage.put("user_id", userData.getString("user_id", ""));
					mapMessage.put("user_message", message.getText().toString());
					mapMessage.put("user_reply", "false");
					mapMessage.put("message_key", msg_key);
					message_reply.child(msg_key).updateChildren(mapMessage);
					mapMessage.clear();
				}
				message.setText("");
			}
		});
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				users.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						userList = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								userList.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		_message_reply_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				reply_length = 0;
				rp_current = 0;
				message_reply.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						list = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								list.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						progressbar1.setVisibility(View.GONE);
						listview1.setAdapter(new Listview1Adapter(list));
						_refreshNotify();
						_textview_color(your_color, userData.getString("user_color", ""));
						your_name.setText(userData.getString("user_name", ""));
						you.setVisibility(View.VISIBLE);
						if (_childValue.containsKey("user_reply")) {
							if (_childValue.get("user_reply").toString().equals("true")) {
								if (_childValue.get("reply_user_id").toString().equals(userData.getString("user_id", ""))) {
									rp.setVisibility(View.VISIBLE);
									reply_length++;
									reply_list.add(_childValue.get("message_key").toString());
									reply_length_text.setText(String.valueOf((long)(reply_list.size())));
								}
								else {
									
								}
							}
							else {
								
							}
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				message_reply.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						list = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								list.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						_refreshNotify();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		message_reply.addChildEventListener(_message_reply_child_listener);
	}
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) { getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); }
		_SX_CornerRadius_card(top_item, "#ffffff", 12);
		_SX_CornerRadius_card(bottom_item, "#f5f5f5", 0);
		_SX_CornerRadius_card(reply_length_text, "#008dcd", 50);
		send_button.setVisibility(View.GONE);
		you.setVisibility(View.GONE);
		rp.setVisibility(View.GONE);
		listview1.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
		listview1.setStackFromBottom(true);
		device = android.os.Build.DEVICE;
		
		model = android.os.Build.MODEL;
		
		android_id = android.os.Build.ID;
		api_level = android.os.Build.VERSION.SDK;
		
		rp.setTranslationZ(5);
		key = String.valueOf((long)(SketchwareUtil.getRandom((int)(100000), (int)(999999))));
		_id_creator();
		_user_color();
		_reply_block(false);
		if (userData.getString("sign", "").equals("")) {
			userData.edit().putString("user_id", key).commit();
			userData.edit().putString("user_name", "user_".concat(key)).commit();
			userData.edit().putString("sign", "true").commit();
			userData.edit().putString("user_color", color).commit();
			mapUser = new HashMap<>();
			mapUser.put("user_name", "user_".concat(key));
			mapUser.put("user_id", key);
			mapUser.put("country", "UZ");
			mapUser.put("user_color", color);
			users.child(key).updateChildren(mapUser);
			mapUser.clear();
		}
		else {
			
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _SX_CornerRadius_card (final View _view, final String _color, final double _value) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_value);
		_view.setBackground(gd);
		
		if (Build.VERSION.SDK_INT >= 21){
			_view.setElevation(5);
		}
	}
	
	
	private void _CardStyle (final View _view, final double _shadow, final double _radius, final String _color, final boolean _touch) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_radius);
		_view.setBackground(gd);
		
		if (Build.VERSION.SDK_INT >= 21){
			_view.setElevation((int)_shadow);}
		if (_touch) {
			_view.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()){
						case MotionEvent.ACTION_DOWN:{
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues(0.9f);
							scaleX.setDuration(100);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues(0.9f);
							scaleY.setDuration(100);
							scaleY.start();
							break;
						}
						case MotionEvent.ACTION_UP:{
							
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues((float)1);
							scaleX.setDuration(100);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues((float)1);
							scaleY.setDuration(100);
							scaleY.start();
							
							break;
						}
					}
					return false;
				}
			});
		}
	}
	
	
	private void _TransitionManager (final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	private void _id_creator () {
		n = 0;
		gone_data = android_id;
		android_id = "";
		for(int _repeat11 = 0; _repeat11 < (int)(gone_data.length()); _repeat11++) {
			if (!".".equals(gone_data.substring((int)(n), (int)(n + 1)))) {
				android_id = android_id.concat(gone_data.substring((int)(n), (int)(n + 1)));
			}
			n++;
		}
	}
	
	
	private void _SX_CornerRadius_4 (final View _view, final String _color1, final String _color2, final double _str, final double _n1, final double _n2, final double _n3, final double _n4) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		
		gd.setColor(Color.parseColor(_color1));
		
		gd.setStroke((int)_str, Color.parseColor(_color2));
		
		gd.setCornerRadii(new float[]{(int)_n1,(int)_n1,(int)_n2,(int)_n2,(int)_n3,(int)_n3,(int)_n4,(int)_n4});
		
		_view.setBackground(gd);
		
		_view.setElevation(4);
	}
	
	
	private void _addCardView (final View _layoutView, final double _margins, final double _cornerRadius, final double _cardElevation, final double _cardMaxElevation, final boolean _preventCornerOverlap, final String _backgroundColor) {
		androidx.cardview.widget.CardView cv = new androidx.cardview.widget.CardView(this);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
		int m = (int)_margins;
		lp.setMargins(m,m,m,m);
		cv.setLayoutParams(lp);
		int c = Color.parseColor(_backgroundColor);
		cv.setCardBackgroundColor(c);
		cv.setRadius((float)_cornerRadius);
		cv.setCardElevation((float)_cardElevation);
		cv.setMaxCardElevation((float)_cardMaxElevation);
		cv.setPreventCornerOverlap(_preventCornerOverlap);
		if(_layoutView.getParent() instanceof LinearLayout){
			ViewGroup vg = ((ViewGroup)_layoutView.getParent());
			vg.removeView(_layoutView);
			vg.removeAllViews();
			vg.addView(cv);
			cv.addView(_layoutView);
		}else{
			
		}
	}
	
	
	private void _user_color () {
		random = SketchwareUtil.getRandom((int)(1), (int)(18));
		if (random == 1) {
			color = "#D32F2F";
		}
		if (random == 2) {
			color = "#C2185B";
		}
		if (random == 3) {
			color = "#7B1FA2";
		}
		if (random == 4) {
			color = "#512DA8";
		}
		if (random == 5) {
			color = "#303F9F";
		}
		if (random == 6) {
			color = "#1976D2";
		}
		if (random == 7) {
			color = "#03A9F4";
		}
		if (random == 8) {
			color = "#0097A7";
		}
		if (random == 9) {
			color = "#009688";
		}
		if (random == 10) {
			color = "#4CAF50";
		}
		if (random == 11) {
			color = "#8BC34A";
		}
		if (random == 12) {
			color = "#AFB42B";
		}
		if (random == 13) {
			color = "#FBC02D";
		}
		if (random == 14) {
			color = "#FFA000";
		}
		if (random == 15) {
			color = "#E64A19";
		}
		if (random == 16) {
			color = "#795548";
		}
		if (random == 17) {
			color = "#607D8B";
		}
		if (random == 18) {
			color = "#008DCD";
		}
	}
	
	
	private void _textview_color (final TextView _view, final String _color) {
		_view.setTextColor(Color.parseColor(_color));
	}
	
	
	private void _imageColorFilter (final ImageView _view, final String _color) {
		_view.setColorFilter(Color.parseColor(_color), PorterDuff.Mode.MULTIPLY);
	}
	
	
	private void _refresh () {
		limiter = list.size() - 1;
		for(int _repeat10 = 0; _repeat10 < (int)(40); _repeat10++) {
			if (((list.size() - 1) - 40) < limiter) {
				listview1.setAdapter(new Listview1Adapter(list));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			limiter--;
		}
	}
	
	
	private void _reply_block (final boolean _reply) {
		_TransitionManager(main_linear, 100);
		if (_reply) {
			reply.setVisibility(View.VISIBLE);
			reply_check = true;
		}
		else {
			reply.setVisibility(View.GONE);
			reply_check = false;
		}
	}
	
	
	private void _tm (final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	private void _getReplyData (final double _position) {
		reply_user_id = list.get((int)_position).get("user_id").toString();
		reply_user_name = list.get((int)_position).get("user_name").toString();
		reply_user_message = list.get((int)_position).get("user_message").toString();
		reply_message_key = list.get((int)_position).get("message_key").toString();
		textview2.setText(reply_user_name);
		textview3.setText(reply_user_message);
	}
	
	
	private void _scrollMessage (final String _key) {
		n = 0;
		for(int _repeat10 = 0; _repeat10 < (int)(list.size()); _repeat10++) {
			if (_key.equals(list.get((int)n).get("message_key").toString())) {
				listview1.smoothScrollToPosition((int)(n));
				break;
			}
			n++;
		}
	}
	
	
	private void _refreshNotify () {
		listview1.deferNotifyDataSetChanged();
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.custom, null);
			}
			
			final LinearLayout a1 = (LinearLayout) _v.findViewById(R.id.a1);
			final LinearLayout b1 = (LinearLayout) _v.findViewById(R.id.b1);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final LinearLayout a1_view = (LinearLayout) _v.findViewById(R.id.a1_view);
			final LinearLayout linear10 = (LinearLayout) _v.findViewById(R.id.linear10);
			final LinearLayout a1_cardview = (LinearLayout) _v.findViewById(R.id.a1_cardview);
			final ImageView a1_image = (ImageView) _v.findViewById(R.id.a1_image);
			final LinearLayout a1_line = (LinearLayout) _v.findViewById(R.id.a1_line);
			final ImageView reply_button = (ImageView) _v.findViewById(R.id.reply_button);
			final LinearLayout a1_reply = (LinearLayout) _v.findViewById(R.id.a1_reply);
			final TextView a1_username = (TextView) _v.findViewById(R.id.a1_username);
			final TextView a1_message = (TextView) _v.findViewById(R.id.a1_message);
			final LinearLayout a1_bulbing = (LinearLayout) _v.findViewById(R.id.a1_bulbing);
			final LinearLayout linear8 = (LinearLayout) _v.findViewById(R.id.linear8);
			final TextView a1_reply_user = (TextView) _v.findViewById(R.id.a1_reply_user);
			final TextView a1_reply_message = (TextView) _v.findViewById(R.id.a1_reply_message);
			final LinearLayout b1_line = (LinearLayout) _v.findViewById(R.id.b1_line);
			final LinearLayout b1_reply = (LinearLayout) _v.findViewById(R.id.b1_reply);
			final TextView b1_message = (TextView) _v.findViewById(R.id.b1_message);
			final LinearLayout b1_bulbing = (LinearLayout) _v.findViewById(R.id.b1_bulbing);
			final LinearLayout linear4 = (LinearLayout) _v.findViewById(R.id.linear4);
			final TextView b1_reply_user = (TextView) _v.findViewById(R.id.b1_reply_user);
			final TextView b1_rebly_message = (TextView) _v.findViewById(R.id.b1_rebly_message);
			
			if (userData.getString("user_id", "").equals(list.get((int)_position).get("user_id").toString())) {
				b1_message.setAutoLinkMask(android.text.util.Linkify.ALL);
				    b1_message.setLinkTextColor(Color.parseColor("#4dd0e1"));
				
				b1_message.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());
				a1.setVisibility(View.GONE);
				b1.setVisibility(View.VISIBLE);
				if (list.get((int)_position).containsKey("user_message")) {
					b1_message.setText(list.get((int)_position).get("user_message").toString());
				}
				if (list.get((int)_position).containsKey("user_reply")) {
					if (list.get((int)_position).get("user_reply").toString().equals("true")) {
						b1_reply.setVisibility(View.VISIBLE);
						b1_reply_user.setText(list.get((int)_position).get("reply_user_name").toString());
						b1_rebly_message.setText(list.get((int)_position).get("reply_user_message").toString());
					}
					else {
						b1_reply.setVisibility(View.GONE);
					}
				}
				if (_position == 0) {
					_SX_CornerRadius_4(b1_line, "#008dcd", "#008dcd", 0, 50, 50, 3, 50);
					if (list.size() == 1) {
						_SX_CornerRadius_4(b1_line, "#008dcd", "#008dcd", 0, 50, 50, 50, 50);
					}
					else {
						if (!list.get((int)_position).get("user_id").toString().equals(list.get((int)_position + 1).get("user_id").toString())) {
							_SX_CornerRadius_4(b1_line, "#008dcd", "#008dcd", 0, 50, 50, 50, 50);
						}
					}
				}
				else {
					if (!list.get((int)_position).get("user_id").toString().equals(list.get((int)_position - 1).get("user_id").toString())) {
						_SX_CornerRadius_4(b1_line, "#008dcd", "#008dcd", 0, 50, 50, 3, 50);
						if (_position == (list.size() - 1)) {
							_SX_CornerRadius_4(b1_line, "#008dcd", "#008dcd", 0, 50, 50, 50, 50);
						}
						else {
							if (!list.get((int)_position).get("user_id").toString().equals(list.get((int)_position + 1).get("user_id").toString())) {
								_SX_CornerRadius_4(b1_line, "#008dcd", "#008dcd", 0, 50, 50, 50, 50);
							}
						}
					}
					else {
						if (_position == (list.size() - 1)) {
							if (list.get((int)_position).get("user_id").toString().equals(list.get((int)_position - 1).get("user_id").toString())) {
								_SX_CornerRadius_4(b1_line, "#008dcd", "#008dcd", 0, 50, 3, 50, 50);
							}
							else {
								_SX_CornerRadius_4(b1_line, "#008dcd", "#008dcd", 0, 50, 50, 50, 50);
							}
						}
						else {
							if (list.get((int)_position).get("user_id").toString().equals(list.get((int)_position - 1).get("user_id").toString()) && list.get((int)_position).get("user_id").toString().equals(list.get((int)_position + 1).get("user_id").toString())) {
								_SX_CornerRadius_4(b1_line, "#008dcd", "#008dcd", 0, 50, 3, 3, 50);
							}
							else {
								if (list.get((int)_position).get("user_id").toString().equals(list.get((int)_position + 1).get("user_id").toString())) {
									_SX_CornerRadius_4(b1_line, "#008dcd", "#008dcd", 0, 50, 50, 3, 50);
								}
								else {
									_SX_CornerRadius_4(b1_line, "#008dcd", "#008dcd", 0, 50, 3, 50, 50);
								}
							}
						}
					}
				}
			}
			else {
				a1_message.setAutoLinkMask(android.text.util.Linkify.ALL);
				    a1_message.setLinkTextColor(Color.parseColor("#4dd0e1"));
				
				a1_message.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());
				a1.setVisibility(View.VISIBLE);
				b1.setVisibility(View.GONE);
				linear2.setVisibility(View.GONE);
				a1_view.setVisibility(View.VISIBLE);
				if (true) {
					n = 0;
					for(int _repeat54 = 0; _repeat54 < (int)(userList.size()); _repeat54++) {
						if (list.get((int)_position).get("user_id").toString().equals(userList.get((int)n).get("user_id").toString())) {
							_textview_color(a1_username, userList.get((int)n).get("user_color").toString());
							_imageColorFilter(a1_image, userList.get((int)n).get("user_color").toString());
							break;
						}
						n++;
					}
				}
				if (list.get((int)_position).containsKey("user_message")) {
					a1_message.setText(list.get((int)_position).get("user_message").toString());
				}
				if (list.get((int)_position).containsKey("user_name")) {
					a1_username.setText(list.get((int)_position).get("user_name").toString());
				}
				if (list.get((int)_position).containsKey("user_reply")) {
					if (list.get((int)_position).get("user_reply").toString().equals("true")) {
						a1_reply.setVisibility(View.VISIBLE);
						a1_reply_user.setText(list.get((int)_position).get("reply_user_name").toString());
						a1_reply_message.setText(list.get((int)_position).get("reply_user_message").toString());
					}
					else {
						a1_reply.setVisibility(View.GONE);
					}
				}
				_addCardView(a1_cardview, 8, 50, 2, 2, true, "#ffffff");
				if (_position == 0) {
					_SX_CornerRadius_4(a1_line, "#F5F5F5", "#F5F5F5", 0, 50, 50, 50, 3);
					if (list.size() == 1) {
						linear2.setVisibility(View.VISIBLE);
						a1_view.setVisibility(View.GONE);
					}
					else {
						if (!list.get((int)_position).get("user_id").toString().equals(list.get((int)_position + 1).get("user_id").toString())) {
							_SX_CornerRadius_4(a1_line, "#F5F5F5", "#F5F5F5", 0, 50, 50, 50, 50);
							linear2.setVisibility(View.VISIBLE);
							a1_view.setVisibility(View.GONE);
						}
					}
				}
				else {
					if (!list.get((int)_position).get("user_id").toString().equals(list.get((int)_position - 1).get("user_id").toString())) {
						_SX_CornerRadius_4(a1_line, "#F5F5F5", "#F5F5F5", 0, 50, 50, 50, 3);
						linear2.setVisibility(View.GONE);
						a1_view.setVisibility(View.VISIBLE);
						if (_position == (list.size() - 1)) {
							_SX_CornerRadius_4(a1_line, "#F5F5F5", "#F5F5F5", 0, 50, 50, 50, 50);
							linear2.setVisibility(View.VISIBLE);
							a1_view.setVisibility(View.GONE);
						}
						else {
							if (!list.get((int)_position).get("user_id").toString().equals(list.get((int)_position + 1).get("user_id").toString())) {
								_SX_CornerRadius_4(a1_line, "#F5F5F5", "#F5F5F5", 0, 50, 50, 50, 50);
								linear2.setVisibility(View.VISIBLE);
								a1_view.setVisibility(View.GONE);
							}
						}
					}
					else {
						if (_position == (list.size() - 1)) {
							if (list.get((int)_position).get("user_id").toString().equals(list.get((int)_position - 1).get("user_id").toString())) {
								_SX_CornerRadius_4(a1_line, "#F5F5F5", "#F5F5F5", 0, 3, 50, 50, 50);
							}
							else {
								_SX_CornerRadius_4(a1_line, "#F5F5F5", "#F5F5F5", 0, 50, 50, 50, 50);
							}
							linear2.setVisibility(View.VISIBLE);
							a1_view.setVisibility(View.GONE);
						}
						else {
							if (list.get((int)_position).get("user_id").toString().equals(list.get((int)_position - 1).get("user_id").toString()) && list.get((int)_position).get("user_id").toString().equals(list.get((int)_position + 1).get("user_id").toString())) {
								_SX_CornerRadius_4(a1_line, "#F5F5F5", "#F5F5F5", 0, 3, 50, 50, 3);
								linear2.setVisibility(View.GONE);
								a1_view.setVisibility(View.VISIBLE);
							}
							else {
								if (list.get((int)_position).get("user_id").toString().equals(list.get((int)_position + 1).get("user_id").toString())) {
									_SX_CornerRadius_4(a1_line, "#F5F5F5", "#F5F5F5", 0, 50, 50, 50, 3);
									linear2.setVisibility(View.GONE);
									a1_view.setVisibility(View.VISIBLE);
								}
								else {
									_SX_CornerRadius_4(a1_line, "#F5F5F5", "#F5F5F5", 0, 3, 50, 50, 50);
									linear2.setVisibility(View.VISIBLE);
									a1_view.setVisibility(View.GONE);
								}
							}
						}
					}
				}
			}
			reply_button.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_getReplyData(_position);
					_reply_block(true);
				}
			});
			a1_reply.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_scrollMessage(list.get((int)_position).get("reply_message_key").toString());
					_refreshNotify();
				}
			});
			b1_reply.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_scrollMessage(list.get((int)_position).get("reply_message_key").toString());
					_refreshNotify();
				}
			});
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
