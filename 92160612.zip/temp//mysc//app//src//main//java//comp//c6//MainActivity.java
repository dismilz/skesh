package comp.c6;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import android.graphics.Typeface;
import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {
	
	
	private LinearLayout linear3;
	private LinearLayout linear1;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private ImageView imageview1;
	private TextView textview2;
	private ImageView imageview2;
	private TextView textview1;
	private LinearLayout linear2;
	private EditText edittext3;
	private TextView textview3;
	private LinearLayout linear9;
	private EditText edittext5;
	private LinearLayout linear10;
	private EditText edittext6;
	private Button button1;
	private ImageView imageview3;
	
	private RequestNetwork Api;
	private RequestNetwork.RequestListener _Api_request_listener;
	private AlertDialog.Builder bc;
	private Intent iad = new Intent();
	private SharedPreferences file;
	private Intent web = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		edittext3 = (EditText) findViewById(R.id.edittext3);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		edittext5 = (EditText) findViewById(R.id.edittext5);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		edittext6 = (EditText) findViewById(R.id.edittext6);
		button1 = (Button) findViewById(R.id.button1);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		Api = new RequestNetwork(this);
		bc = new AlertDialog.Builder(this);
		file = getSharedPreferences("file", Activity.MODE_PRIVATE);
		
		edittext6.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				file.edit().putString("1", "http://".concat("mynamepixs.com/result_display.php?id=".concat(edittext6.getText().toString().concat("&name=".concat(edittext5.getText().toString().concat("&name2=".concat(edittext3.getText().toString()))))))).commit();
				Api.startRequestNetwork(RequestNetworkController.GET, "http://mynamepixs.com/", "a", _Api_request_listener);
				Glide.with(getApplicationContext()).load(Uri.parse("http://mynamepixs.com/result_display.php?id=".concat(edittext6.getText().toString().concat("&name=".concat(edittext5.getText().toString().concat("&name2=".concat(edittext3.getText().toString()))))))).into(imageview3);
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				web.setClass(getApplicationContext(), ImageActivity.class);
				startActivity(web);
			}
		});
		
		_Api_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "connected");
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "NO INTERNET CONNECTION");
			}
		};
	}
	private void initializeLogic() {
		Api.startRequestNetwork(RequestNetworkController.GET, "http://mynamepixs.com/", "a", _Api_request_listener);
		_round_stock(30, 30, 30, 30, "cyan", linear1, 1, "blue");
		_round_stock(30, 30, 30, 30, "cyan", textview1, 1, "blue");
		_round_stock(30, 30, 30, 30, "cyan", edittext3, 1, "blue");
		_round_stock(30, 30, 30, 30, "cyan", textview2, 1, "blue");
		_round_stock(30, 30, 30, 30, "cyan", imageview1, 1, "blue");
		_round_stock(30, 30, 30, 30, "cyan", imageview2, 1, "blue");
		_round_stock(30, 30, 30, 30, "cyan", imageview3, 1, "blue");
		_round_stock(30, 30, 30, 30, "cyan", textview3, 1, "blue");
		_round_stock(30, 30, 30, 30, "cyan", edittext5, 1, "blue");
		_round_stock(30, 30, 30, 30, "cyan", edittext6, 1, "blue");
		_round_stock(30, 30, 30, 30, "green", button1, 1, "blue");
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nin.ttf"), 1);
		edittext3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nin.ttf"), 1);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nin.ttf"), 1);
		edittext5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nin.ttf"), 1);
		edittext6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nin.ttf"), 1);
		button1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/nin.ttf"), 1);
		bc.setTitle("Numbers");
		bc.setMessage("numbers to change photo design input\n\nnumbers up to =2550\ntry=2525\n\n\nFOR MORE COOL PHOTOS \n  VIST: http://mynamepixs.com/\n\nFOR HELP:\nEMAIL: notiks254@gmail.com\n");
		bc.setPositiveButton("help", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				SketchwareUtil.showMessage(getApplicationContext(), "email copied to cilp board");
			}
		});
		bc.setNeutralButton("website", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				web.setAction(Intent.ACTION_VIEW);
				web.setData(Uri.parse("http://mynamepixs.com/"));
				startActivity(web);
			}
		});
		bc.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				SketchwareUtil.showMessage(getApplicationContext(), "wellcome made in Kenya");
			}
		});
		bc.create().show();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		bc.setMessage("Do you really want to Exit!");
		bc.setPositiveButton("YES", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finish();
			}
		});
		bc.setNegativeButton("NO", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		bc.create().show();
	}
	private void _round_stock (final double _one, final double _two, final double _three, final double _four, final String _color, final View _view, final double _swidth, final String _scolor) {
		Double left_top = _one;
		Double right_top = _two;
		Double left_bottom = _three;
		Double right_bottom = _four;
		Double sw = _swidth;
		android.graphics.drawable.GradientDrawable s = new android.graphics.drawable.GradientDrawable();
		s.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		s.setCornerRadii(new float[] {left_top.floatValue(),left_top.floatValue(), right_top.floatValue(),right_top.floatValue(), left_bottom.floatValue(),left_bottom.floatValue(), right_bottom.floatValue(),right_bottom.floatValue()});
		s.setColor(Color.parseColor(_color));
		_view.setBackground(s);
		s.setStroke(sw.intValue(), Color.parseColor(_scolor));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
