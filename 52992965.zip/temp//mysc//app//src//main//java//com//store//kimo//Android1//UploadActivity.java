package com.store.kimo.Android1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import android.widget.ProgressBar;
import android.widget.EditText;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.app.Activity;
import android.content.SharedPreferences;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.Intent;
import android.net.Uri;
import android.content.ClipData;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Continuation;
import java.io.File;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import com.bumptech.glide.Glide;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class UploadActivity extends AppCompatActivity {
	
	public final int REQ_CD_FICON = 101;
	public final int REQ_CD_SCREEN1 = 102;
	public final int REQ_CD_SCREEN2 = 103;
	public final int REQ_CD_SCREEN3 = 104;
	public final int REQ_CD_FAPP = 105;
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private String iconpath = "";
	private String iconname = "";
	private String apppath = "";
	private String appname = "";
	private String scr1path = "";
	private String scr1name = "";
	private String scr2path = "";
	private String scr2name = "";
	private String scrpath3 = "";
	private String scrname3 = "";
	private double nuicon = 0;
	private double nuapp = 0;
	private double nuscr1 = 0;
	private double nuscr2 = 0;
	private double nuscr3 = 0;
	private HashMap<String, Object> mapv = new HashMap<>();
	private String trans_icon = "";
	private String trans_url = "";
	private String trans_scr1 = "";
	private String trans_scr2 = "";
	private String trans_scr3 = "";
	
	private ArrayList<String> u = new ArrayList<>();
	
	private LinearLayout linear4;
	private ScrollView add_info_box;
	private ImageView imageview2_info_pic;
	private TextView textview3_info_name;
	private ImageView imageview3;
	private TextView textview3;
	private LinearLayout linear6;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear20;
	private LinearLayout linear23;
	private AdView adview1;
	private LinearLayout linear7;
	private LinearLayout linear9;
	private TextView textview1;
	private ProgressBar progressbar4;
	private ImageView imageview7;
	private ImageView imageview1_icon;
	private TextView textview2;
	private EditText edittext1_app_name;
	private LinearLayout linear3;
	private TextView textview6_path;
	private TextView textview5;
	private ProgressBar progressbar1_app;
	private ImageView imageview4_app;
	private Button button1_selectapp;
	private EditText edittext_description;
	private TextView textview4;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private ImageView imageview6_screen1;
	private LinearLayout linear16;
	private ProgressBar progressbar1;
	private ImageView imageview4;
	private ImageView imageview7_screen2;
	private LinearLayout linear17;
	private ProgressBar progressbar2;
	private ImageView imageview5;
	private ImageView imageview8_screen3;
	private LinearLayout linear18;
	private ProgressBar progressbar3;
	private ImageView imageview6;
	private Button button2_upload;
	
	private SharedPreferences name;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private Intent llll = new Intent();
	private Intent sett = new Intent();
	private SharedPreferences saveinfo;
	private SharedPreferences profile;
	private Intent ficon = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent screen1 = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent screen2 = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent screen3 = new Intent(Intent.ACTION_GET_CONTENT);
	private StorageReference fbsgupicon = _firebase_storage.getReference("fbsgupicon");
	private OnCompleteListener<Uri> _fbsgupicon_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fbsgupicon_download_success_listener;
	private OnSuccessListener _fbsgupicon_delete_success_listener;
	private OnProgressListener _fbsgupicon_upload_progress_listener;
	private OnProgressListener _fbsgupicon_download_progress_listener;
	private OnFailureListener _fbsgupicon_failure_listener;
	private StorageReference fbsgupapp = _firebase_storage.getReference("fbsgupapp");
	private OnCompleteListener<Uri> _fbsgupapp_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fbsgupapp_download_success_listener;
	private OnSuccessListener _fbsgupapp_delete_success_listener;
	private OnProgressListener _fbsgupapp_upload_progress_listener;
	private OnProgressListener _fbsgupapp_download_progress_listener;
	private OnFailureListener _fbsgupapp_failure_listener;
	private StorageReference fbsgupscr1 = _firebase_storage.getReference("fbsgupscr1");
	private OnCompleteListener<Uri> _fbsgupscr1_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fbsgupscr1_download_success_listener;
	private OnSuccessListener _fbsgupscr1_delete_success_listener;
	private OnProgressListener _fbsgupscr1_upload_progress_listener;
	private OnProgressListener _fbsgupscr1_download_progress_listener;
	private OnFailureListener _fbsgupscr1_failure_listener;
	private StorageReference fbsgscr2 = _firebase_storage.getReference("fbsgscr2");
	private OnCompleteListener<Uri> _fbsgscr2_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fbsgscr2_download_success_listener;
	private OnSuccessListener _fbsgscr2_delete_success_listener;
	private OnProgressListener _fbsgscr2_upload_progress_listener;
	private OnProgressListener _fbsgscr2_download_progress_listener;
	private OnFailureListener _fbsgscr2_failure_listener;
	private StorageReference fbsgupscr3 = _firebase_storage.getReference("fbsgupscr3");
	private OnCompleteListener<Uri> _fbsgupscr3_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fbsgupscr3_download_success_listener;
	private OnSuccessListener _fbsgupscr3_delete_success_listener;
	private OnProgressListener _fbsgupscr3_upload_progress_listener;
	private OnProgressListener _fbsgupscr3_download_progress_listener;
	private OnFailureListener _fbsgupscr3_failure_listener;
	private DatabaseReference fb = _firebase.getReference("fb");
	private ChildEventListener _fb_child_listener;
	private SharedPreferences urltransfer;
	private SharedPreferences icontrans;
	private SharedPreferences scr1trans;
	private SharedPreferences scr2trans;
	private SharedPreferences scr3trans;
	private Intent fapp = new Intent(Intent.ACTION_GET_CONTENT);
	private AlertDialog.Builder cancel_d;
	private RequestNetwork network_request;
	private RequestNetwork.RequestListener _network_request_request_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.upload);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		add_info_box = (ScrollView) findViewById(R.id.add_info_box);
		imageview2_info_pic = (ImageView) findViewById(R.id.imageview2_info_pic);
		textview3_info_name = (TextView) findViewById(R.id.textview3_info_name);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		linear23 = (LinearLayout) findViewById(R.id.linear23);
		adview1 = (AdView) findViewById(R.id.adview1);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		textview1 = (TextView) findViewById(R.id.textview1);
		progressbar4 = (ProgressBar) findViewById(R.id.progressbar4);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		imageview1_icon = (ImageView) findViewById(R.id.imageview1_icon);
		textview2 = (TextView) findViewById(R.id.textview2);
		edittext1_app_name = (EditText) findViewById(R.id.edittext1_app_name);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		textview6_path = (TextView) findViewById(R.id.textview6_path);
		textview5 = (TextView) findViewById(R.id.textview5);
		progressbar1_app = (ProgressBar) findViewById(R.id.progressbar1_app);
		imageview4_app = (ImageView) findViewById(R.id.imageview4_app);
		button1_selectapp = (Button) findViewById(R.id.button1_selectapp);
		edittext_description = (EditText) findViewById(R.id.edittext_description);
		textview4 = (TextView) findViewById(R.id.textview4);
		hscroll1 = (HorizontalScrollView) findViewById(R.id.hscroll1);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		imageview6_screen1 = (ImageView) findViewById(R.id.imageview6_screen1);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		imageview7_screen2 = (ImageView) findViewById(R.id.imageview7_screen2);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		progressbar2 = (ProgressBar) findViewById(R.id.progressbar2);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		imageview8_screen3 = (ImageView) findViewById(R.id.imageview8_screen3);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		progressbar3 = (ProgressBar) findViewById(R.id.progressbar3);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		button2_upload = (Button) findViewById(R.id.button2_upload);
		name = getSharedPreferences("name", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		saveinfo = getSharedPreferences("saveinfo", Activity.MODE_PRIVATE);
		profile = getSharedPreferences("profile", Activity.MODE_PRIVATE);
		ficon.setType("image/*");
		ficon.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		screen1.setType("image/*");
		screen1.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		screen2.setType("image/*");
		screen2.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		screen3.setType("image/*");
		screen3.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		urltransfer = getSharedPreferences("urltransfer", Activity.MODE_PRIVATE);
		icontrans = getSharedPreferences("icontrans", Activity.MODE_PRIVATE);
		scr1trans = getSharedPreferences("scr1trans", Activity.MODE_PRIVATE);
		scr2trans = getSharedPreferences("scr2trans", Activity.MODE_PRIVATE);
		scr3trans = getSharedPreferences("scr3trans", Activity.MODE_PRIVATE);
		fapp.setType("*/*");
		fapp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		cancel_d = new AlertDialog.Builder(this);
		network_request = new RequestNetwork(this);
		
		imageview2_info_pic.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "press on setting icon to edit your profile");
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sett.setClass(getApplicationContext(), UserprofActivity.class);
				startActivity(sett);
				SketchwareUtil.showMessage(getApplicationContext(), "edit profile");
			}
		});
		
		imageview1_icon.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(ficon, REQ_CD_FICON);
			}
		});
		
		edittext1_app_name.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.length() > 19) {
					edittext1_app_name.setTextColor(0xFFF44336);
					SketchwareUtil.showMessage(getApplicationContext(), "the maximum number of letters is 19");
				}
				else {
					edittext1_app_name.setTextColor(0xFF000000);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button1_selectapp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(fapp, REQ_CD_FAPP);
			}
		});
		
		imageview6_screen1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(screen1, REQ_CD_SCREEN1);
			}
		});
		
		imageview7_screen2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(screen2, REQ_CD_SCREEN2);
			}
		});
		
		imageview8_screen3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(screen3, REQ_CD_SCREEN3);
			}
		});
		
		button2_upload.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				network_request.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com", "k", _network_request_request_listener);
				button2_upload.setEnabled(false);
			}
		});
		
		_fbsgupicon_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				imageview7.setVisibility(View.GONE);
				progressbar4.setVisibility(View.VISIBLE);
				SketchwareUtil.showMessage(getApplicationContext(), "uploaded : ".concat(String.valueOf((long)(_progressValue)).concat("%")));
				button2_upload.setEnabled(false);
			}
		};
		
		_fbsgupicon_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fbsgupicon_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				imageview7.setImageResource(R.drawable.right);
				progressbar4.setVisibility(View.GONE);
				imageview7.setVisibility(View.VISIBLE);
				nuicon = 1;
				trans_icon = _downloadUrl;
				button2_upload.setEnabled(true);
			}
		};
		
		_fbsgupicon_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_fbsgupicon_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fbsgupicon_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				imageview7.setImageResource(R.drawable.error);
				progressbar4.setVisibility(View.GONE);
				imageview7.setVisibility(View.VISIBLE);
				SketchwareUtil.showMessage(getApplicationContext(), "Failed to upload the reason is : ".concat(_message));
				button2_upload.setEnabled(true);
			}
		};
		
		_fbsgupapp_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				imageview4_app.setVisibility(View.GONE);
				progressbar1_app.setVisibility(View.VISIBLE);
				SketchwareUtil.showMessage(getApplicationContext(), "uploaded : ".concat(String.valueOf((long)(_progressValue)).concat("%")));
				button2_upload.setEnabled(false);
			}
		};
		
		_fbsgupapp_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fbsgupapp_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				imageview4_app.setImageResource(R.drawable.right);
				imageview4_app.setVisibility(View.VISIBLE);
				progressbar1_app.setVisibility(View.GONE);
				nuapp = 1;
				trans_url = _downloadUrl;
				button2_upload.setEnabled(true);
			}
		};
		
		_fbsgupapp_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_fbsgupapp_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fbsgupapp_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				imageview4_app.setImageResource(R.drawable.error);
				imageview4_app.setVisibility(View.VISIBLE);
				progressbar1_app.setVisibility(View.GONE);
				SketchwareUtil.showMessage(getApplicationContext(), _message);
				button2_upload.setEnabled(true);
			}
		};
		
		_fbsgupscr1_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				linear16.setVisibility(View.VISIBLE);
				imageview4.setVisibility(View.GONE);
				progressbar1.setVisibility(View.VISIBLE);
				SketchwareUtil.showMessage(getApplicationContext(), "uploaded : ".concat(String.valueOf((long)(_progressValue)).concat("%")));
				button2_upload.setEnabled(false);
			}
		};
		
		_fbsgupscr1_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fbsgupscr1_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				imageview4.setImageResource(R.drawable.right);
				linear16.setVisibility(View.VISIBLE);
				imageview4.setVisibility(View.VISIBLE);
				progressbar1.setVisibility(View.GONE);
				nuscr1 = 1;
				trans_scr1 = _downloadUrl;
				button2_upload.setEnabled(true);
			}
		};
		
		_fbsgupscr1_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_fbsgupscr1_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fbsgupscr1_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				imageview4.setImageResource(R.drawable.error);
				linear16.setVisibility(View.VISIBLE);
				imageview4.setVisibility(View.VISIBLE);
				progressbar1.setVisibility(View.GONE);
				SketchwareUtil.showMessage(getApplicationContext(), _message);
				button2_upload.setEnabled(true);
			}
		};
		
		_fbsgscr2_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				linear17.setVisibility(View.VISIBLE);
				imageview5.setVisibility(View.GONE);
				progressbar2.setVisibility(View.VISIBLE);
				SketchwareUtil.showMessage(getApplicationContext(), "uploaded : ".concat(String.valueOf((long)(_progressValue)).concat("%")));
				button2_upload.setEnabled(false);
			}
		};
		
		_fbsgscr2_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fbsgscr2_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				imageview5.setImageResource(R.drawable.right);
				linear17.setVisibility(View.VISIBLE);
				imageview5.setVisibility(View.VISIBLE);
				progressbar2.setVisibility(View.GONE);
				nuscr2 = 1;
				trans_scr2 = _downloadUrl;
				button2_upload.setEnabled(true);
			}
		};
		
		_fbsgscr2_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_fbsgscr2_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fbsgscr2_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				imageview5.setImageResource(R.drawable.error);
				linear17.setVisibility(View.VISIBLE);
				imageview5.setVisibility(View.VISIBLE);
				progressbar2.setVisibility(View.GONE);
				SketchwareUtil.showMessage(getApplicationContext(), _message);
				button2_upload.setEnabled(true);
			}
		};
		
		_fbsgupscr3_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				linear18.setVisibility(View.VISIBLE);
				imageview6.setVisibility(View.GONE);
				progressbar3.setVisibility(View.VISIBLE);
				SketchwareUtil.showMessage(getApplicationContext(), "uploaded : ".concat(String.valueOf((long)(_progressValue)).concat("%")));
				button2_upload.setEnabled(false);
			}
		};
		
		_fbsgupscr3_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fbsgupscr3_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				imageview6.setImageResource(R.drawable.right);
				linear18.setVisibility(View.VISIBLE);
				imageview6.setVisibility(View.VISIBLE);
				progressbar3.setVisibility(View.GONE);
				nuscr3 = 1;
				trans_scr3 = _downloadUrl;
				button2_upload.setEnabled(true);
			}
		};
		
		_fbsgupscr3_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_fbsgupscr3_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fbsgupscr3_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				imageview6.setImageResource(R.drawable.error);
				linear18.setVisibility(View.VISIBLE);
				imageview6.setVisibility(View.VISIBLE);
				progressbar3.setVisibility(View.GONE);
				SketchwareUtil.showMessage(getApplicationContext(), _message);
				button2_upload.setEnabled(true);
			}
		};
		
		_fb_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fb.addChildEventListener(_fb_child_listener);
		
		_network_request_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				if (edittext1_app_name.getText().toString().equals("") || edittext_description.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "can't upload , please fill this fields");
					edittext1_app_name.setTextColor(0xFFF44336);
					edittext_description.setTextColor(0xFFF44336);
					edittext1_app_name.setHintTextColor(0xFFF44336);
					edittext_description.setHintTextColor(0xFFF44336);
					button2_upload.setEnabled(true);
				}
				else {
					if (edittext1_app_name.getText().toString().length() > 19) {
						SketchwareUtil.showMessage(getApplicationContext(), "the maximum number of letters is 19");
						edittext1_app_name.setTextColor(0xFFF44336);
						button2_upload.setEnabled(true);
					}
					else {
						if ((nuicon == 0) || ((nuapp == 0) || ((nuscr1 == 0) || ((nuscr2 == 0) || (nuscr3 == 0))))) {
							SketchwareUtil.showMessage(getApplicationContext(), "you must add app icon And app And 3 screenshots.");
							button2_upload.setEnabled(true);
						}
						else {
							if ((nuicon == 1) || ((nuapp == 1) || ((nuscr1 == 1) || ((nuscr2 == 1) || (nuscr3 == 1))))) {
								edittext1_app_name.setTextColor(0xFF000000);
								edittext_description.setTextColor(0xFF000000);
								edittext1_app_name.setHintTextColor(0xFF000000);
								edittext_description.setHintTextColor(0xFF000000);
								SketchwareUtil.showMessage(getApplicationContext(), "uploading your app please wait..");
								mapv = new HashMap<>();
								mapv.put("owner", name.getString("name", ""));
								mapv.put("profile", profile.getString("profile", ""));
								mapv.put("email", name.getString("email", ""));
								mapv.put("appname", edittext1_app_name.getText().toString());
								mapv.put("appdescription", edittext_description.getText().toString());
								mapv.put("appicon", trans_icon);
								mapv.put("url", trans_url);
								mapv.put("screen1", trans_scr1);
								mapv.put("screen2", trans_scr2);
								mapv.put("screen3", trans_scr3);
								fb.push().updateChildren(mapv);
								mapv.clear();
								SketchwareUtil.showMessage(getApplicationContext(), "upload success");
								button2_upload.setEnabled(true);
								finish();
							}
						}
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "i can't upload your app please double check on your connection + ".concat(_message));
				button2_upload.setEnabled(true);
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		adview1.loadAd(new AdRequest.Builder().addTestDevice("5C73353DA47FF2EF2D6D00C770C113F1")
		.build());
		setTitle("upload App");
		imageview4_app.setVisibility(View.GONE);
		progressbar1_app.setVisibility(View.GONE);
		imageview7.setVisibility(View.GONE);
		progressbar4.setVisibility(View.GONE);
		linear16.setVisibility(View.GONE);
		linear17.setVisibility(View.GONE);
		linear18.setVisibility(View.GONE);
		_radius("#FFFFFF", 8, linear1);
		_radius("#FFFFFF", 8, linear2);
		_radius("#FFFFFF", 8, linear20);
		_radius("#FFFFFF", 8, linear23);
		_radius("#FFFFFF", 8, linear7);
		textview3_info_name.setText(name.getString("name", ""));
		Glide.with(getApplicationContext()).load(Uri.parse(profile.getString("profile", ""))).into(imageview2_info_pic);
		nuicon = 0;
		nuapp = 0;
		nuscr1 = 0;
		nuscr2 = 0;
		nuscr3 = 0;
		if ((FirebaseAuth.getInstance().getCurrentUser() != null) && !name.getString("email", "").equals("")) {
			
		}
		else {
			llll.setClass(getApplicationContext(), LoginSignupActivity.class);
			startActivity(llll);
			SketchwareUtil.showMessage(getApplicationContext(), "you must login first");
			finish();
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FICON:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				iconpath = _filePath.get((int)(0));
				iconname = Uri.parse(_filePath.get((int)(0))).getLastPathSegment();
				imageview1_icon.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(iconpath, 1024, 1024));
				fbsgupicon.child(iconname).putFile(Uri.fromFile(new File(iconpath))).addOnFailureListener(_fbsgupicon_failure_listener).addOnProgressListener(_fbsgupicon_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return fbsgupicon.child(iconname).getDownloadUrl();
					}}).addOnCompleteListener(_fbsgupicon_upload_success_listener);
				SketchwareUtil.showMessage(getApplicationContext(), "uploading app icon");
			}
			else {
				
			}
			break;
			
			case REQ_CD_SCREEN1:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				scr1path = _filePath.get((int)(0));
				scr1name = Uri.parse(_filePath.get((int)(0))).getLastPathSegment();
				imageview6_screen1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(scr1path, 1024, 1024));
				fbsgupscr1.child(scr1name).putFile(Uri.fromFile(new File(scr1path))).addOnFailureListener(_fbsgupscr1_failure_listener).addOnProgressListener(_fbsgupscr1_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return fbsgupscr1.child(scr1name).getDownloadUrl();
					}}).addOnCompleteListener(_fbsgupscr1_upload_success_listener);
				SketchwareUtil.showMessage(getApplicationContext(), "uploading Screenshot 1");
			}
			else {
				
			}
			break;
			
			case REQ_CD_SCREEN2:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				scr2path = _filePath.get((int)(0));
				scr2name = Uri.parse(_filePath.get((int)(0))).getLastPathSegment();
				imageview7_screen2.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(scr2path, 1024, 1024));
				fbsgscr2.child(scr2name).putFile(Uri.fromFile(new File(scr2path))).addOnFailureListener(_fbsgscr2_failure_listener).addOnProgressListener(_fbsgscr2_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return fbsgscr2.child(scr2name).getDownloadUrl();
					}}).addOnCompleteListener(_fbsgscr2_upload_success_listener);
				SketchwareUtil.showMessage(getApplicationContext(), "uploading screenshot 2");
			}
			else {
				
			}
			break;
			
			case REQ_CD_SCREEN3:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				scrpath3 = _filePath.get((int)(0));
				scrname3 = Uri.parse(_filePath.get((int)(0))).getLastPathSegment();
				imageview8_screen3.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(scrpath3, 1024, 1024));
				fbsgupscr3.child(scrname3).putFile(Uri.fromFile(new File(scrpath3))).addOnFailureListener(_fbsgupscr3_failure_listener).addOnProgressListener(_fbsgupscr3_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return fbsgupscr3.child(scrname3).getDownloadUrl();
					}}).addOnCompleteListener(_fbsgupscr3_upload_success_listener);
				SketchwareUtil.showMessage(getApplicationContext(), "uploading screenshot 3");
			}
			else {
				
			}
			break;
			
			case REQ_CD_FAPP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				apppath = _filePath.get((int)(0));
				appname = Uri.parse(_filePath.get((int)(0))).getLastPathSegment();
				textview6_path.setText("selected : ".concat(Uri.parse(_filePath.get((int)(0))).getLastPathSegment()));
				if (textview6_path.getText().toString().contains(".apk".toLowerCase())) {
					fbsgupapp.child(appname).putFile(Uri.fromFile(new File(apppath))).addOnFailureListener(_fbsgupapp_failure_listener).addOnProgressListener(_fbsgupapp_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
						@Override
						public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
							return fbsgupapp.child(appname).getDownloadUrl();
						}}).addOnCompleteListener(_fbsgupapp_upload_success_listener);
					SketchwareUtil.showMessage(getApplicationContext(), "uploading your app");
				}
				else {
					textview6_path.setText("select Only Apk Files !");
					SketchwareUtil.showMessage(getApplicationContext(), "please select apk File");
				}
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		textview3_info_name.setText(name.getString("name", ""));
		Glide.with(getApplicationContext()).load(Uri.parse(profile.getString("profile", ""))).into(imageview2_info_pic);
	}
	
	@Override
	public void onBackPressed() {
		cancel_d.setTitle("close page");
		cancel_d.setMessage("do you want to close this page ?!");
		cancel_d.setPositiveButton("Yes !", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finish();
			}
		});
		cancel_d.setNegativeButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		cancel_d.create().show();
	}
	private void _radius (final String _color, final double _numb, final View _view) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_numb);
		_view.setBackground(gd);
		_view.setElevation((int)_numb);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
